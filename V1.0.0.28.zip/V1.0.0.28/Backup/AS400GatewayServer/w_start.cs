﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using AS400GatewayServer.MYCLS;
namespace AS400GatewayServer
{
    public partial class w_start : Form
    {

        private MYCLS.DataAgent mobj_dataAgent;
        private string m_strSys_CheckTimer = "10";
        // 執行狀況
        private int gi_timeout = 10;
        private int gi_count = 0;
     
        public w_start()
        {
            InitializeComponent();


 
            mobj_dataAgent = new MYCLS.DataAgent();

            this.Text = this.Text + "_" + Properties.Settings.Default.ServerID + "(V" + Application.ProductVersion + ")";
        }
        ~w_start()
        {
            dispose();
        }
        public void dispose()
        {
            if (mobj_dataAgent != null)
            {
                mobj_dataAgent.dispose();
            }
            GC.SuppressFinalize(this);
        }
        private bool m_blnRunning = false;



        public bool wf_is_running()
        {
            return m_blnRunning;
        }

        public void wf_set_running(bool ab_status)
        {

            m_blnRunning = ab_status;
            if (m_blnRunning)
            {
                //啟動

                //// 要設定啟動工作項目
                button_start.Enabled = false;
                button_stop.Enabled = true;

                pictureBox_paused.Visible = false;
                pictureBox_running.Visible = true;
                pictureBox_running1.Visible = false;

                //ShowMessage("連接中...");


                mobj_dataAgent.Vlst_SysMsg = listBox_SysMsg;
                mobj_dataAgent.Vlst_Connections = listConnections;
                mobj_dataAgent.Vfrm_Master = this;
                mobj_dataAgent.Vpic_APOrder = picAPOrder;
                mobj_dataAgent.Vpic_APReply = picAPReply;
                mobj_dataAgent.Vpic_AS400Client = picAS400Client;
                mobj_dataAgent.Vpic_AS400Server = picAS400Server;
                //added by peter V1.0.0.4
                mobj_dataAgent.Vpic_AS400ClientFor2 = picAS400Client2;
                //added by peter V1.0.0.4
                mobj_dataAgent.Vpic_AS400ServerFor2 = picAS400Server2;
                mobj_dataAgent.Vpic_Web = picWeb;

                //added by peter V1.0.0.11
                mobj_dataAgent.Vpic_AS400ClientFor3 = picAS400Client3;
                //added by peter V1.0.0.11
                mobj_dataAgent.Vpic_AS400ServerFor3 = picAS400Server3;
               


                mobj_dataAgent.Vpic_APInfo = picAPInfo;

                mobj_dataAgent.start();

              
            }
            else
            {
                //停止
                //// 要設定中止工作項目
                button_start.Enabled = true;
                button_stop.Enabled = false;

                pictureBox_paused.Visible = true;
                pictureBox_running.Visible = false;
                pictureBox_running1.Visible = false;
                // mobj_dataAgent.close();

                //ShowMessage("中斷連接...");
                mobj_dataAgent.dispose();
                
            }
        }
        private void w_start_Load(object sender, EventArgs e)
        {
            wf_set_running(false);
            timer_running.Enabled = true;
        }

        private void w_start_FormClosed(object sender, FormClosedEventArgs e)
        {
            wf_set_running(false);
        }

        private void button_close_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            m_blnRunning = true;
            wf_set_running(true);
        }

        private void button_stop_Click(object sender, EventArgs e)
        {
            m_blnRunning = false;
            wf_set_running(false);
        }
        private void timer_running_Tick(object sender, EventArgs e)
        {
            if (wf_is_running())
            {
                gi_count = 0;
                pictureBox_paused.Visible = false;
                if (pictureBox_running.Visible)
                {
                    pictureBox_running.Visible = false;
                    pictureBox_running1.Visible = true;
                }
                else
                {
                    pictureBox_running.Visible = true;
                    pictureBox_running1.Visible = false;
                }
            }
            else
            {
                pictureBox_paused.Visible = true;
                gi_count++;
            }

            if (!wf_is_running())
            {
                wf_set_running(false);
                wf_set_running(true);
            }



            DataAgent.BASEPATH = "";
            DataAgent.BASEPATH = DataAgent.BASEPATH.Trim().Length == 0 ? AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() : DataAgent.BASEPATH;

            int closeweek = int.Parse(Properties.Settings.Default.CloseTimeByWeek);
            int begin = int.Parse(Properties.Settings.Default.ClearDataTime);
            int now = int.Parse(DateTime.Now.ToString("HHmm"));




            if (now > begin)//跨日
            {
                if (DataAgent.TradeDate != DateTime.Now.ToString("yyyyMMdd"))
                {

                    if (closeweek == -1 || (int)DateTime.Now.DayOfWeek == closeweek)
                    {

                        this.Close();
                    }
                    else
                    {
                        wf_set_running(false);


                        wf_set_running(true);
                    }
                }
            }

        }

               private void button_ClearSysLog_Click(object sender, EventArgs e)
        {
            try
            {
                listBox_SysMsg.Items.Clear();
            }
            catch (Exception ex) { }
        }



        private void picAPReply_Click(object sender, EventArgs e)
        {

        }

        private void lblAPReply_Click(object sender, EventArgs e)
        {

        }
        private bool isrun = false;




        private void button2_Click(object sender, EventArgs e)
        {
            GC.Collect();
            mobj_dataAgent.Vobj_SEQMapping.Clear();
            mobj_dataAgent.Vdt_MappingIp.Rows.Clear();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
          
          //  byte[] raw = ASCIIEncoding.ASCII.GetBytes("020200460        1F0080009811980ITIMB9044   B9044 1120120315SFFITX   201203000000000 N00010814000000000000000000000000000000000830000000000006400000F0009  NTT081230000000000000000000200000000081230000\n");
           //  byte[] raw = ASCIIEncoding.ASCII.GetBytes("0123999291       9001?L?????B?z                                                              ".PadRight(123,' '));
             byte[] raw = ASCIIEncoding.ASCII.GetBytes("0220004A0000022  1F0080009805080ITIMC2441   C2441 1120150727SFFIOBF  201508000000000 N00020002893000000000000000022800000000000640000000000004800000F0366  NTT000305900000000000000010000000000000294500000001200000006000");

            mobj_dataAgent._RI.ResolveReceive(raw);
        }

        private void w_start_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {

                wf_set_running(false);
               
            }
            catch (Exception ex)
            {
            }
        }


    }
}