﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
namespace AS400GatewayServer.MYCLS
{

    public class DisplayMsg
    {

        //const
        private const string DATETIME_FORMAT = "yyyy/MMdd HH:mm:ss";

        public static System.Windows.Forms.ListBox mlst_SysMsg;
        public static System.Windows.Forms.ListBox mlst_Connections;
        public static System.Windows.Forms.Form mfrm_Master;
        public static System.Windows.Forms.PictureBox mpic_APOrder;
        public static System.Windows.Forms.PictureBox mpic_APReply;
        public static System.Windows.Forms.PictureBox mpic_AS400Server;
        public static System.Windows.Forms.PictureBox mpic_AS400Client;
        //added by peter V1.0.0.4
        public static System.Windows.Forms.PictureBox mpic_AS400ServerFor2;
        //added by peter V1.0.0.4
        public static System.Windows.Forms.PictureBox mpic_AS400ClientFor2;

        //added by peter V1.0.0.11
        public static System.Windows.Forms.PictureBox mpic_AS400ServerFor3;
        //added by peter V1.0.0.11
        public static System.Windows.Forms.PictureBox mpic_AS400ClientFor3;

        public static System.Windows.Forms.PictureBox mpic_WEB;

        public static System.Windows.Forms.PictureBox mpic_APInfo;
        public DisplayMsg()
        {

        }

        /// <summary>
        /// UI顯示連線內容的listBox
        /// </summary>
        public ListBox Vlst_Connections
        {
            get
            {
                return mlst_Connections;
            }
            set
            {
                mlst_Connections = value;
            }
        }

        /// <summary>
        /// UI顯示系統狀態資訊的listBox
        /// </summary>
        public ListBox Vlst_SysMsg
        {
            get
            {
                return mlst_SysMsg;
            }
            set
            {
                mlst_SysMsg = value;
            }
        }

        /// <summary>
        /// UI的form
        /// </summary>
        public Form Vfrm_Master
        {
            get
            {
                return mfrm_Master;
            }
            set
            {
                mfrm_Master = value;
            }
        }

        public PictureBox Vpic_APOrder
        {
            get
            {
                return mpic_APOrder;
            }
            set
            {
                mpic_APOrder = value;
            }
        }

        public PictureBox Vpic_APReply
        {
            get
            {
                return mpic_APReply;
            }
            set
            {
                mpic_APReply = value;
            }
        }
        public PictureBox Vpic_AS400Client
        {
            get
            {
                return mpic_AS400Client;
            }
            set
            {
                mpic_AS400Client = value;
            }
        }
        public PictureBox Vpic_AS400Server
        {
            get
            {
                return mpic_AS400Server;
            }
            set
            {
                mpic_AS400Server = value;
            }
        }
        //added by peter V1.0.0.4
        public PictureBox Vpic_AS400ClientFor2
        {
            get
            {
                return mpic_AS400ClientFor2;
            }
            set
            {
                mpic_AS400ClientFor2 = value;
            }
        }
        //added by peter V1.0.0.4
        public PictureBox Vpic_AS400ServerFor2
        {
            get
            {
                return mpic_AS400ServerFor2;
            }
            set
            {
                mpic_AS400ServerFor2 = value;
            }
        }
        //added by peter V1.0.0.11
        public PictureBox Vpic_AS400ClientFor3
        {
            get
            {
                return mpic_AS400ClientFor3;
            }
            set
            {
                mpic_AS400ClientFor3 = value;
            }
        }
        //added by peter V1.0.0.11
        public PictureBox Vpic_AS400ServerFor3
        {
            get
            {
                return mpic_AS400ServerFor3;
            }
            set
            {
                mpic_AS400ServerFor3 = value;
            }
        }
        public PictureBox Vpic_Web
        {
            get
            {
                return mpic_WEB;
            }
            set
            {
                mpic_WEB = value;
            }
        }

        public PictureBox Vpic_APInfo
        {
            get
            {
                return mpic_APInfo;
            }
            set
            {
                mpic_APInfo = value;
            }
        }
 
        public delegate void AddMessageDelegate(string Data);
        public delegate void ChangePicStatusDelegate(string objConnet, string strMsg);

        private void AddStatusMessage(string astring_msg)
        {
            if (mlst_SysMsg.Items.Count > 100)
            {
                mlst_SysMsg.Items.Clear();
            }
            mlst_SysMsg.Items.Add(DateTime.Now.ToString(DATETIME_FORMAT) + " " + astring_msg);
        }
        private void AddConnections(string astring_msg)
        {

            mlst_Connections.Items.Add(astring_msg);
        }
        private void RemoveConnections(string astring_msg)
        {

            mlst_Connections.Items.Remove(astring_msg);
        }

        /// <summary>
        /// 顯示新增連線
        /// </summary>
        public void displayAddConnections(string strMsg)
        {
            mfrm_Master.Invoke(new AddMessageDelegate(this.AddConnections), new object[] { strMsg });
        }
        /// <summary>
        /// 更新移除連線
        /// </summary>
        public void displayRemoveConnections(string strMsg)
        {
            mfrm_Master.Invoke(new AddMessageDelegate(this.RemoveConnections), new object[] { strMsg });
        }
        /// <summary>
        /// 顯示系統狀態資訊
        /// </summary>
        public void displayStatusMsg(string strMsg)
        {
            try
            {
                mfrm_Master.Invoke(new AddMessageDelegate(this.AddStatusMessage), new object[] { strMsg });
            }
            catch(Exception ex)
            {
            }
        }

        public void displayPicStatus(string objConnet,string strMsg)
        {
            try
            {
                mfrm_Master.Invoke(new ChangePicStatusDelegate(this.ChangePicStatus), new object[] { objConnet, strMsg });
            }
            catch (Exception ex)
            {
            }
        }

        private void ChangePicStatus(string objConnet,string msg)
        {
            switch (objConnet)
            {
                case "APOrder":
                    if (msg == "Connected")
                    {
                        mpic_APOrder.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_APOrder.Image = Properties.Resources.Disconnected;
                    }
                    break;
                case "APReply":
                    if (msg == "Connected")
                    {
                        mpic_APReply.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_APReply.Image = Properties.Resources.Disconnected;
                    }
                    break;
                case "AS400Client":
                    if (msg == "Connected")
                    {
                        mpic_AS400Client.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_AS400Client.Image = Properties.Resources.Disconnected;
                    }
                    break;
                case "AS400Server":
                    if (msg == "Connected")
                    {
                        mpic_AS400Server.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_AS400Server.Image = Properties.Resources.Disconnected;
                    }
                    break;
                //added by peter V1.0.0.4
                case "AS400ClientFor2":
                    if (msg == "Connected")
                    {
                        mpic_AS400ClientFor2.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_AS400ClientFor2.Image = Properties.Resources.Disconnected;
                    }
                    break;
                //added by peter V1.0.0.4
                case "AS400ServerFor2":
                    if (msg == "Connected")
                    {
                        mpic_AS400ServerFor2.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_AS400ServerFor2.Image = Properties.Resources.Disconnected;
                    }
                    break;
                //added by peter V1.0.0.11
                case "AS400ClientFor3":
                    if (msg == "Connected")
                    {
                        mpic_AS400ClientFor3.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_AS400ClientFor3.Image = Properties.Resources.Disconnected;
                    }
                    break;
                //added by peter V1.0.0.11
                case "AS400ServerFor3":
                    if (msg == "Connected")
                    {
                        mpic_AS400ServerFor3.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_AS400ServerFor3.Image = Properties.Resources.Disconnected;
                    }
                    break;
                case "WEB":
                    if (msg == "Connected")
                    {
                        mpic_WEB.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_WEB.Image = Properties.Resources.Disconnected;
                    }
                    break;
                case "APInfo":
                    if (msg == "Connected")
                    {
                        mpic_APInfo.Image = Properties.Resources.Connected;
                    }
                    else
                    {
                        mpic_APInfo.Image = Properties.Resources.Disconnected;
                    }
                    break;
                   
             
            }

        }
    }
}
