﻿using System;
using System.Collections.Generic;
using System.Text;
#if (SECURE)
using Dart.PowerTCP.Sockets;
#else
using Dart.PowerTCP.SslSockets;
#endif
using System.Collections;
using System.Threading;
using System.Data;
using System.Data.SqlClient;
namespace AS400GatewayServer.MYCLS
{
    public class ReplyConnection
    {
        /// <summary>
        /// socket
        /// </summary>
        Tcp m_Tcp;

#if (SECURE) 
	public static int DefStandardPort{get{return 7;}}
	public static int DefSslPort{get{return 7;}}
	public static string ServerName{get{return "PowerTCP SSL Echo Server";}}
#else
        public static int DefPort { get { return 7; } }
        public static string ServerName { get { return "PowerTCP Echo Server"; } }
#endif


        /// <summary>
        /// 錯誤訊息
        /// </summary>
        private WriterLOG AOBJ_ErrorLog;
        /// <summary>
        /// 執行訊息
        /// </summary>
        private WriterLOG AOBJ_InfoLog;
        /// <summary>
        /// 負責暫存行情資訊記憶體
        /// </summary>
        private Queue<string> m_QueueData = new Queue<string>();
        /// <summary>
        /// 負責處理行情資訊thread
        /// </summary>
        private System.Threading.Thread m_objTrdSocket;


        /// <summary>
        /// 分公司
        /// </summary>
        private string mstr_Company;
        /// <summary>
        /// 營業員帳號
        /// </summary>
        private string mstr_AE = "";
        private string mstr_Type;
        private string mstr_adress;
        private string mstr_port;
        private string mstr_ip;
        private string mstr_loginTime;
        private Hashtable mobj_Accounts;
        private string status = "0";
        private string mstr_seq;
        private c_Functions.SyncEvents syncConnectionEvents = new c_Functions.SyncEvents();
        private DataAgent mobj_Parent;
        /// <summary>
        /// 物件初始化
        /// </summary>
        public ReplyConnection(Tcp tcp, string LogFileName, string StartUpPath, string type, DataAgent parent)
        {
            // LogFileName and StartUpPath are not used by this sample
            // if you want to see how to use a Log File, take a look at the
            // Pop or Web Server samples
            mobj_Parent = parent;
            mobj_Accounts = new Hashtable();
            mstr_Type = type;
            m_Tcp = tcp;
            mstr_adress = m_Tcp.RemoteEndPoint.Address.ToString() + ":" + m_Tcp.RemoteEndPoint.Port.ToString();
            mstr_ip = m_Tcp.RemoteEndPoint.Address.ToString();
            mstr_port = m_Tcp.RemoteEndPoint.Port.ToString();
            m_Tcp.SendTimeout = 60000;
            AOBJ_ErrorLog = new WriterLOG(type + "ConnErrorSktServer" + tcp.RemoteEndPoint.Address.ToString() + tcp.RemoteEndPoint.Port.ToString());
            AOBJ_InfoLog = new WriterLOG(type + "ConnInfoSktServer" + tcp.RemoteEndPoint.Address.ToString() + tcp.RemoteEndPoint.Port.ToString());

            execStartThread();
        }
        ~ReplyConnection()
        {
            ReplyConnectionDispose();
        }
        /// <summary>
        /// 啟動thread
        /// </summary>
        private void execStartThread()
        {
            try
            {
                if (m_objTrdSocket != null)
                {
                    m_objTrdSocket.Abort();
                }
                m_objTrdSocket = new System.Threading.Thread(new ThreadStart(execQueueData), 256 * 1024);
                m_objTrdSocket.IsBackground = true;
                m_objTrdSocket.Start();
            }
            catch (Exception ex)
            {
                ReplyConnectionDispose();
            }
        }
        /// <summary>
        /// 終止thread
        /// </summary>
        private void AbortThread()
        {
            if (AOBJ_ErrorLog != null)
            {
                AOBJ_ErrorLog.Close();
            }

            if (AOBJ_InfoLog != null)
            {
                AOBJ_InfoLog.Close();
            }
            if (m_objTrdSocket != null)
            {
                m_objTrdSocket.Abort();
            }
        }

        public void ReplyConnectionDispose()
        {


            lock (mobj_Parent.mdt_MappingIp)
            {
                DataRow[] dr = mobj_Parent.mdt_MappingIp.Select("seq='" + mstr_seq + "'");
                if (dr.Length > 0)
                {
                    //判斷如果在TradeClientCollection有找到rip,避免註冊連線重連oip會被清掉,只把rip清空,不刪除整筆

                    lock (mobj_Parent.mobj_TradeClientCollection)
                    {


                        if (mobj_Parent.mobj_TradeClientCollection.ContainsKey(dr[0]["oip"].ToString()))
                        {
                            dr[0]["rip"] = "";
                        }
                        else
                        {
                            dr[0].Delete();
                        }
                    }
                }

            }

            AbortThread();
            if (m_Tcp != null)
            {
                //儲存使用者離線時間

                status = "1";
                //判斷使用者帶空白,不寫入資料庫 20121012
                if (mstr_AE.Trim() != "")
                {
                    string[] arrPutIPLogoutCmd = new string[1];
                    arrPutIPLogoutCmd[0] = "UPDATE  [dbo].[tblReplyIPLog]"
                      + "SET [logoutTime] ='" + DateTime.Now.ToString("HH:mm:ss") + "',[status] = '" + status + "'"
                    + "WHERE userid='" + mstr_AE + "' and ip='" + mstr_ip + "' and port='" + mstr_port + "' and  logintime ='" + mstr_loginTime + "'";
                    mobj_Parent.mobj_SaveDB.PutData2Queue(arrPutIPLogoutCmd);
                }
                m_Tcp.Close();
                m_Tcp = null;
            }
            AOBJ_ErrorLog.WriteEntryData("e");
            GC.SuppressFinalize(this);

        }
        /// <summary>
        /// 物件執行
        /// </summary>
        public void Execute()
        {

            try
            {
                //設定頭碼欄位
                byte[] lbyt_Head = new byte[1];
                //設定長度欄位
                byte[] lbyt_Len = new byte[4];
                ///設定內文
                byte[] lbyt_Data;
                //內文長度
                int lint_Len = 0;

                //讀取頭碼
                c_Functions.TCP_ByteRead(m_Tcp, lbyt_Head, 0, 1);
                //內文字串
                string STR_ReceivedData;

                //判斷頭碼是否為連線code:0x01
                if (lbyt_Head[0] == 0x01 || lbyt_Head[0] == 0x03)
                {
                    //讀取內文長度
                    c_Functions.TCP_ByteRead(m_Tcp, lbyt_Len, 0, 4);
                    //將封包轉換成整數
                    lint_Len = int.Parse(new string(Encoding.Default.GetChars(lbyt_Len)));
                    //初始內文封包
                    lbyt_Data = new byte[lint_Len];
                    //讀取內文
                    c_Functions.TCP_ByteRead(m_Tcp, lbyt_Data, 0, lint_Len);
                    //將內文轉換成string
                    STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Data));
                    //將尾碼/0去掉
                    STR_ReceivedData = STR_ReceivedData.Replace("/0", "");
                    if (lbyt_Head[0] == 0x01)
                    {
                        //依照連線內容.確認是否為真正用戶端傳送訊息:分公司碼+營業員帳號
                        mstr_Company = STR_ReceivedData.Substring(14, 7);
                        mstr_AE = STR_ReceivedData.Substring(21, 20).Trim();

                        //判斷使用者帶空白,不寫入資料庫 20121012
                        if (mstr_AE.Trim() != "")
                        {

                            //add by samantha 20090818存入使用者登入資訊
                            mstr_loginTime = DateTime.Now.ToString("HH:mm:ss");
                            string[] arrPutIPLoginCmd = new string[1];
                            arrPutIPLoginCmd[0] = " INSERT INTO [dbo].[tblReplyIPLog] "
                            + "  ([UserId],[IP],[port],[loginTime],[status],[LogDate])VALUES "
                            + "('" + mstr_AE + "','" + mstr_ip + "','" + mstr_port + "','" + mstr_loginTime + "','" + status + "',convert(char(8),getdate(),112))";
                            mobj_Parent.mobj_SaveDB.PutData2Queue(arrPutIPLoginCmd);
                        }
                        //回傳通知使用者連上確認訊息msgCode=0x02
                        PutData2Queue("02");
                    }

                    else if (lbyt_Head[0] == 0x03)
                    {
                        mstr_seq = STR_ReceivedData.Substring(14, 25);
                        lock (mobj_Parent.mdt_MappingIp)
                        {

                            DataRow[] dr = mobj_Parent.mdt_MappingIp.Select("seq='" + mstr_seq + "'");
                            if (dr.Length > 0)
                            {
                                dr[0]["rip"] = mstr_adress;

                            }
                            else
                            {
                                DataRow drnew = mobj_Parent.mdt_MappingIp.NewRow();
                                drnew["seq"] = mstr_seq;
                                drnew["rip"] = mstr_adress;
                                drnew["oip"] = "";
                                mobj_Parent.mdt_MappingIp.Rows.Add(drnew);
                            }

                        }

                        PutData2Queue("0400");
                        AOBJ_ErrorLog.WriteEntryData(STR_ReceivedData);
                    }
                    //建立當使用維持連線存在間的迴圈
                    while (m_Tcp.Connected)
                    {
                        //迴圈中不斷讀取資訊
                        //讀頭碼
                        c_Functions.TCP_ByteRead(m_Tcp, lbyt_Head, 0, 1);
                        //讀長度
                        c_Functions.TCP_ByteRead(m_Tcp, lbyt_Len, 0, 4);
                        lint_Len = int.Parse(new string(Encoding.Default.GetChars(lbyt_Len)));
                        //讀內文
                        lbyt_Data = new byte[lint_Len];
                        c_Functions.TCP_ByteRead(m_Tcp, lbyt_Data, 0, lint_Len);

                        //判斷收到13,再回給client ack msgCode=19
                        if (lbyt_Head[0] == 0x13)
                        {
                            PutData2Queue("19");
                            mobj_Parent.displayStatusMsg("19Alive:" + m_Tcp.RemoteEndPoint.Address.ToString());
                        }
                        else if (lbyt_Head[0] == 0x11)
                        {
                            if (mstr_Type == "Reply")
                            {
                                STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Data));
                                mstr_seq = STR_ReceivedData;
                                lock (mobj_Parent.mdt_MappingIp)
                                {

                                    DataRow[] dr = mobj_Parent.mdt_MappingIp.Select("seq='" + mstr_seq + "'");
                                    if (dr.Length > 0)
                                    {
                                        dr[0]["rip"] = mstr_adress;

                                    }
                                    else
                                    {
                                        DataRow drnew = mobj_Parent.mdt_MappingIp.NewRow();
                                        drnew["seq"] = mstr_seq;
                                        drnew["rip"] = mstr_adress;
                                        drnew["oip"] = "";
                                        mobj_Parent.mdt_MappingIp.Rows.Add(drnew);
                                    }

                                }
                                AOBJ_ErrorLog.WriteEntryData(STR_ReceivedData);
                                PutData2Queue("11");
                            }
                        }
                        else if (lbyt_Head[0] == 0x0f)//收到查詢訊息msgCode=15
                        {
                            ////將內文轉換成string




                        }

                    }

                }
                else
                {
                    lbyt_Data = new byte[lint_Len];
                    STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Head))
                        + new string(Encoding.Default.GetChars(lbyt_Len))
                        + new string(Encoding.Default.GetChars(lbyt_Data));
                    mobj_Parent.displayStatusMsg("資料有誤:" + STR_ReceivedData);
                }
            }
            catch (Exception ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.StackTrace.ToString() + "/" + ex.ToString());
                mobj_Parent.displayStatusMsg(m_Tcp.RemoteEndPoint.ToString() + ": Exception:" + ex.StackTrace);
            }
            finally
            {
                if (m_Tcp != null)
                {
                    //儲存使用者離線時間
                    string[] arrPutIPLogoutCmd = new string[1];
                    status = "1";
                    arrPutIPLogoutCmd[0] = "UPDATE [dbo].[tblReplyIPLog]"
                      + "SET [logoutTime] ='" + DateTime.Now.ToString("HH:mm:ss") + "',[status] = '" + status + "'"
                    + "WHERE userid='" + mstr_AE + "' and ip='" + mstr_ip + "' and port='" + mstr_port + "' and  logintime ='" + mstr_loginTime + "'";
                    mobj_Parent.mobj_SaveDB.PutData2Queue(arrPutIPLogoutCmd);

                    m_Tcp.Close();
                    m_Tcp = null;
                }
                this.ReplyConnectionDispose();
            }
        }

        /// <summary>
        /// 資訊傳送
        /// </summary>
        public void SendMessage(string str_Data)
        {
            try
            {
                //判斷連線是否存在
                if (m_Tcp != null && m_Tcp.Connected)
                {
                    //取得頭碼
                    byte byte_TradeFlag = byte.Parse(str_Data.Substring(0, 2));

                    byte byte_EndFlag = byte.Parse("10");

                    string lstr_Msg_No = "";
                    if (str_Data.Length > 3)
                    {
                        lstr_Msg_No = "00";
                        str_Data = str_Data.Substring(2, str_Data.Length - 2);
                    }
                    else
                    {
                        lstr_Msg_No = "00";
                        str_Data = "";
                    }

                    byte[] SendDataBuffer = new byte[100];
                    int lint_Len = 0;
                    Encoding EncodType;
                    EncodType = Encoding.Default;
                    switch (byte_TradeFlag)
                    {
                        //回傳連線確認訊息    
                        case 0x02://格式:" "+長度(4)+分公司(3)+使用者ID(10)+"00"||"99"+內文(?)+" "
                            str_Data = mstr_Company.PadRight(3, ' ') + mstr_AE.PadRight(10, ' ')
                                + (mstr_AE != null ? "00" : "99") + str_Data;

                            break;
                        //回傳行情訊息
                        case 0x0e://格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = "00" + c_Functions.EncodeString(str_Data);
                            break;
                        case 0x0f://格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = "99" + c_Functions.EncodeString(str_Data);
                            byte_TradeFlag = 0x0e;
                            break;
                        //回傳連線確認訊息    
                        case 0x04://格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = str_Data;

                            break;
                        //回傳alive訊息
                        case 0x13://回傳alive資訊//格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = lstr_Msg_No + str_Data;
                            AOBJ_InfoLog.WriteEntryData("Alive");
                            break;
                        case 0x0b://回傳11資訊//格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = lstr_Msg_No + str_Data;
                            AOBJ_InfoLog.WriteEntryData("11");
                            break;
                        default:
                            break;

                    }

                    lint_Len = c_Functions.getStringLen(str_Data) + 1;
                    //將字串轉成buffer
                    SendDataBuffer = EncodType.GetBytes(" " + lint_Len.ToString().PadLeft(4, '0') + str_Data + " ");
                    //加尾碼
                    SendDataBuffer.SetValue(byte_EndFlag, SendDataBuffer.Length - 1);
                    //將頭碼加在buffer最前面
                    SendDataBuffer.SetValue(byte_TradeFlag, 0);
                    AOBJ_InfoLog.WriteEntryData(str_Data);
                    m_Tcp.Send(SendDataBuffer);
                }
            }
            catch (Exception ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.StackTrace.ToString() + "/" + ex.ToString());
            }
        }


        /// <summary>
        /// 外部資訊傳入
        /// </summary>
        public void PutData2Queue(string str_Data)
        {

            lock (((ICollection)m_QueueData).SyncRoot)
            {
                m_QueueData.Enqueue(str_Data);
                syncConnectionEvents.NewItemEvent.Set();
            }


        }
        /// <summary>
        /// 不斷取出Queue資訊
        /// </summary>

        private void execQueueData()
        {
            while (WaitHandle.WaitAny(syncConnectionEvents.EventArray) != 1)
            {
                do
                {
                    string data = "";

                    lock (((ICollection)m_QueueData).SyncRoot)
                    {

                        if (m_QueueData.Count > 0)
                        {
                            //判斷先把DEQ資料放在DATA變數裡
                            data = m_QueueData.Dequeue();
                        }

                    }

                    //等到確定取得資料做送資料動作
                    if (data != "")
                    {


                        SendMessage(data);


                    }
                } while (m_QueueData.Count > 0);

            }
        }


    }
}
