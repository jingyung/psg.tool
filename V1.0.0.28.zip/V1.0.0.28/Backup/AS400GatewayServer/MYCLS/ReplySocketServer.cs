﻿using System;
using System.Collections.Generic;
using System.Text;
using Dart.PowerTCP.SslSockets;
using System.Windows.Forms;

namespace AS400GatewayServer.MYCLS
{

    public class ReplySocketServer 
    {
        private WriterLOG mobj_ErrorLog;
        private Dart.PowerTCP.SslSockets.Server m_MarketInfoSktServer;
        public string mstr_IP;
        public int mint_Port;
        public string AS400_IP;
        public int AS400_Port;
        public System.Collections.Hashtable mobj_clientCollection;
        private System.ComponentModel.IContainer components;
        private string mstr_name;
        public ReplySocketServer(string name)
        {
            mstr_name = name;
            this.components = new System.ComponentModel.Container();
            mobj_ErrorLog = new WriterLOG(mstr_name + "SocketServerError");
            try
            {

                mobj_clientCollection = new System.Collections.Hashtable();
                m_MarketInfoSktServer = new Dart.PowerTCP.SslSockets.Server(this.components);
                m_MarketInfoSktServer.Editor = this.m_MarketInfoSktServer;
            }
            catch (Exception ex)
            {
                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }

        }

        ~ReplySocketServer()
        {
            SocketServerDispose();
        }

        public void SocketServerDispose()
        {
            if (mobj_clientCollection != null)
            {
                foreach (Object key in mobj_clientCollection.Keys)
                {

                    ReplyConnection conn = (ReplyConnection)mobj_clientCollection[key.ToString()];
                    conn.ReplyConnectionDispose();
                }
            }
            if (m_MarketInfoSktServer != null)
            {

                m_MarketInfoSktServer.Close();
            }
            if (mobj_ErrorLog != null)
            {
                mobj_ErrorLog.Close();
            }
            //AbortThread();
            GC.SuppressFinalize(this);
        }

        public void SocketServerStart()
        {
            try
            {
                // 啟動SOCKET

                m_MarketInfoSktServer.Listen(mstr_IP, mint_Port);

            }
            catch (Exception ex)
            {
                m_MarketInfoSktServer.Abort();
                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }
        }

        public void SocketServerClose()
        {
            try
            {
                // 中斷SOCKET
                if (m_MarketInfoSktServer.Active)
                {
                    m_MarketInfoSktServer.Close();
                }
            }
            catch (Exception ex)
            {

                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }
        }
      
    }
}