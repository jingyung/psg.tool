﻿using System;
using System.Collections.Generic;
using System.Text;
#if (SECURE)
using Dart.PowerTCP.Sockets;
#else
using Dart.PowerTCP.SslSockets;
#endif
using System.Collections;
using System.Threading;
using System.Data;
using System.Data.SqlClient;
using com.ddsc.BI.Account;

namespace AS400GatewayServer.MYCLS
{
    public class Connection
    {
        /// <summary>
        /// socket
        /// </summary>
        Tcp m_Tcp;

#if (SECURE) 
	public static int DefStandardPort{get{return 7;}}
	public static int DefSslPort{get{return 7;}}
	public static string ServerName{get{return "PowerTCP SSL Echo Server";}}
#else
        public static int DefPort { get { return 7; } }
        public static string ServerName { get { return "PowerTCP Echo Server"; } }
#endif
        public DataTable mdt_NetWorkIdMappling;

        com.ddsc.BI.Account.TradeIntegration _TI;
        /// <summary>
        /// 錯誤訊息
        /// </summary>
        private WriterLOG AOBJ_ErrorLog;
        /// <summary>
        /// 執行訊息
        /// </summary>
        private WriterLOG AOBJ_InfoLog;
        /// <summary>
        /// 負責暫存行情資訊記憶體
        /// </summary>
        private Queue<string> m_QueueData = new Queue<string>();
        /// <summary>
        /// 負責處理行情資訊thread
        /// </summary>
        private System.Threading.Thread m_objTrdSocket;


        /// <summary>
        /// 分公司
        /// </summary>
        private string mstr_Company;
        /// <summary>
        /// 營業員帳號
        /// </summary>
        private string mstr_AE = "";
        private string mstr_adress;
        private string mstr_port;
        private string mstr_ip;
        private string mstr_loginTime;

        string _WithdrawKey = "";

        private string status = "0";
        private string mstr_seq;
        private c_Functions.SyncEvents syncConnectionEvents = new c_Functions.SyncEvents();
        private DataAgent mobj_Parent;

        /// <summary>
        /// 物件初始化
        /// </summary>
        public Connection(Tcp tcp, string LogFileName, string StartUpPath, string type, DataAgent parent)
        {
            // LogFileName and StartUpPath are not used by this sample
            // if you want to see how to use a Log File, take a look at the
            // Pop or Web Server samples
            _TI = new TradeIntegration();
            m_Tcp = tcp;
            mstr_adress = m_Tcp.RemoteEndPoint.Address.ToString() + ":" + m_Tcp.RemoteEndPoint.Port.ToString();
            mstr_ip = m_Tcp.RemoteEndPoint.Address.ToString();
            mstr_port = m_Tcp.RemoteEndPoint.Port.ToString();
            m_Tcp.SendTimeout = 60000;
            AOBJ_ErrorLog = new WriterLOG(type + "ConnErrorSktServer" + tcp.RemoteEndPoint.Address.ToString() + tcp.RemoteEndPoint.Port.ToString() + DateTime.Now.ToString("HHmmssfff"));
            AOBJ_InfoLog = new WriterLOG(type + "ConnInfoSktServer" + tcp.RemoteEndPoint.Address.ToString() + tcp.RemoteEndPoint.Port.ToString() + DateTime.Now.ToString("HHmmssfff"));
            mobj_Parent = parent;
            mdt_NetWorkIdMappling = new DataTable();
            mdt_NetWorkIdMappling.Columns.Add("seq");
            mdt_NetWorkIdMappling.Columns.Add("seqNo");
            mdt_NetWorkIdMappling.Columns.Add("networkid");
            mdt_NetWorkIdMappling.PrimaryKey = new DataColumn[] { mdt_NetWorkIdMappling.Columns["seq"], mdt_NetWorkIdMappling.Columns["seqno"] };
            //v1.0.0.25 modified by peter on 20170711 修正為交易日避免後台KEY重複
            //_WithdrawKey = DateTime.Now.ToString("yyyy").Substring(3, 1) + DateTime.Now.ToString("MM") + DateTime.Now.ToString("dd");
            //20170711
            _WithdrawKey = DataAgent.TradeDate.Substring(3, 1) + DataAgent.TradeDate.Substring(4, 2) + DataAgent.TradeDate.Substring(6, 2);

            execStartThread();
        }
        ~Connection()
        {
            ConnectionDispose();
        }
        /// <summary>
        /// 啟動thread
        /// </summary>
        private void execStartThread()
        {
            try
            {
                if (m_objTrdSocket != null)
                {
                    m_objTrdSocket.Abort();
                }
                m_objTrdSocket = new System.Threading.Thread(new ThreadStart(execQueueData), 256 * 1024);
                m_objTrdSocket.IsBackground = true;
                m_objTrdSocket.Start();
            }
            catch (Exception ex)
            {
                ConnectionDispose();
            }
        }
        /// <summary>
        /// 終止thread
        /// </summary>
        private void AbortThread()
        {
            if (AOBJ_ErrorLog != null)
            {
                AOBJ_ErrorLog.Close();
            }

            if (AOBJ_InfoLog != null)
            {
                AOBJ_InfoLog.Close();
            }
            if (m_objTrdSocket != null)
            {
                m_objTrdSocket.Abort();
            }
        }





        public void ConnectionDispose()
        {

            lock (mobj_Parent.mdt_MappingIp)
            {

                DataRow[] dr = mobj_Parent.mdt_MappingIp.Select("seq='" + mstr_seq + "'");
                if (dr.Length > 0)
                {

                    //判斷如果在ReplyClientCollection有找到rip,避免註冊連線重連rip會被清掉,只把oip清空,不刪除整筆
                    lock (mobj_Parent.mobj_ReplyClientCollection)
                    {

                        if (mobj_Parent.mobj_ReplyClientCollection.ContainsKey(dr[0]["rip"].ToString()))
                        {
                            dr[0]["oip"] = "";
                        }
                        else
                        {
                            dr[0].Delete();
                        }
                    }
                }

            }
            string adress = mstr_adress;
            AbortThread();
            if (m_Tcp != null)
            {
                //儲存使用者離線時間
                status = "1";
                //判斷使用者帶空白,不寫入資料庫 20121012
                if (mstr_AE.Trim() != "")
                {
                    string[] arrPutIPLogoutCmd = new string[1];
                    arrPutIPLogoutCmd[0] = "UPDATE  [dbo].[tblInfoIPLog]"
                      + "SET [logoutTime] ='" + DateTime.Now.ToString("HH:mm:ss") + "',[status] = '" + status + "'"
                    + "WHERE userid='" + mstr_AE + "' and ip='" + mstr_ip + "' and port='" + mstr_port + "' and  logintime ='" + mstr_loginTime + "'";
                    mobj_Parent.mobj_SaveDB.PutData2Queue(arrPutIPLogoutCmd);
                }
                m_Tcp.Close();
                m_Tcp = null;
            }

            GC.SuppressFinalize(this);

        }
        /// <summary>
        /// 物件執行
        /// </summary>
        public void Execute()
        {

            try
            {
                //設定頭碼欄位
                byte[] lbyt_Head = new byte[1];
                //設定長度欄位
                byte[] lbyt_Len = new byte[4];
                ///設定內文
                byte[] lbyt_Data;
                //內文長度
                int lint_Len = 0;
                //讀取頭碼
                c_Functions.TCP_ByteRead(m_Tcp, lbyt_Head, 0, 1);
                //內文字串
                string STR_ReceivedData;

                //判斷頭碼是否為連線code:0x01
                if (lbyt_Head[0] == 0x01 || lbyt_Head[0] == 0x03)
                {

                    //讀取內文長度
                    c_Functions.TCP_ByteRead(m_Tcp, lbyt_Len, 0, 4);
                    //將封包轉換成整數
                    lint_Len = int.Parse(new string(Encoding.Default.GetChars(lbyt_Len)));
                    //初始內文封包
                    lbyt_Data = new byte[lint_Len];
                    //讀取內文
                    c_Functions.TCP_ByteRead(m_Tcp, lbyt_Data, 0, lint_Len);
                    //將內文轉換成string
                    STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Data));
                    //將尾碼/0去掉
                    STR_ReceivedData = STR_ReceivedData.Replace("/0", "");
                    if (lbyt_Head[0] == 0x01)
                    {
                        //依照連線內容.確認是否為真正用戶端傳送訊息:分公司碼+營業員帳號
                        mstr_Company = STR_ReceivedData.Substring(14, 7);
                        mstr_AE = STR_ReceivedData.Substring(21, 20).Trim();
                        //判斷使用者帶空白,不寫入資料庫 20121012
                        if (mstr_AE.Trim() != "")
                        {
                            //add by samantha 20090818存入使用者登入資訊
                            mstr_loginTime = DateTime.Now.ToString("HH:mm:ss");
                            string[] arrPutIPLoginCmd = new string[1];
                            arrPutIPLoginCmd[0] = " INSERT INTO [dbo].[tblInfoIPLog] "
                            + "  ([UserId],[IP],[port],[loginTime],[status],[LogDate])VALUES "
                            + "('" + mstr_AE + "','" + mstr_ip + "','" + mstr_port + "','" + mstr_loginTime + "','" + status + "',convert(char(8),getdate(),112))";
                            mobj_Parent.mobj_SaveDB.PutData2Queue(arrPutIPLoginCmd);
                        }
                        //回傳通知使用者連上確認訊息msgCode=0x02
                        PutData2Queue("02");
                    }
                    else if (lbyt_Head[0] == 0x03)
                    {
                        lock (mobj_Parent.mdt_MappingIp)
                        {
                            string rip = "";
                            mstr_seq = STR_ReceivedData.Substring(14, 25);
                            DataRow[] dr = mobj_Parent.mdt_MappingIp.Select("seq='" + mstr_seq + "'");
                            if (dr.Length > 0)
                            {
                                dr[0]["oip"] = mstr_adress;
                            }
                            else
                            {
                                DataRow drnew = mobj_Parent.mdt_MappingIp.NewRow();
                                drnew["seq"] = mstr_seq;
                                drnew["rip"] = rip;
                                drnew["oip"] = mstr_adress;
                                mobj_Parent.mdt_MappingIp.Rows.Add(drnew);
                            }
                        }
                        PutData2Queue("0400");
                        AOBJ_ErrorLog.WriteEntryData(STR_ReceivedData);
                    }
                    //建立當使用維持連線存在間的迴圈
                    while (m_Tcp.Connected)
                    {
                        //迴圈中不斷讀取資訊
                        //讀頭碼
                        c_Functions.TCP_ByteRead(m_Tcp, lbyt_Head, 0, 1);
                        //讀長度
                        c_Functions.TCP_ByteRead(m_Tcp, lbyt_Len, 0, 4);
                        lint_Len = int.Parse(new string(Encoding.Default.GetChars(lbyt_Len)));
                        //讀內文
                        lbyt_Data = new byte[lint_Len];
                        c_Functions.TCP_ByteRead(m_Tcp, lbyt_Data, 0, lint_Len);



                        byte[] buffer = new byte[lbyt_Head.Length + lbyt_Len.Length + lbyt_Data.Length];

                        Array.Copy(lbyt_Head, 0, buffer, 0, lbyt_Head.Length);
                        Array.Copy(lbyt_Len, 0, buffer, 0 + lbyt_Head.Length, lbyt_Len.Length);
                        Array.Copy(lbyt_Data, 0, buffer, 0 + lbyt_Head.Length + lbyt_Len.Length, lbyt_Data.Length);


                        //判斷收到13,再回給client ack msgCode=19
                        if (lbyt_Head[0] == 0x13)
                        {
                            PutData2Queue("19");
                            mobj_Parent.displayStatusMsg("19Alive:" + m_Tcp.RemoteEndPoint.Address.ToString());
                        }
                        else if (lbyt_Head[0] == 0x11)
                        {
                            STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Data));


                            lock (mobj_Parent.mdt_MappingIp)
                            {
                                string rip = "";
                                mstr_seq = STR_ReceivedData;
                                DataRow[] dr = mobj_Parent.mdt_MappingIp.Select("seq='" + mstr_seq + "'");
                                if (dr.Length > 0)
                                {
                                    dr[0]["oip"] = mstr_adress;
                                }
                                else
                                {
                                    DataRow drnew = mobj_Parent.mdt_MappingIp.NewRow();
                                    drnew["seq"] = mstr_seq;
                                    drnew["rip"] = rip;
                                    drnew["oip"] = mstr_adress;
                                    mobj_Parent.mdt_MappingIp.Rows.Add(drnew);
                                }
                            }
                            AOBJ_ErrorLog.WriteEntryData(STR_ReceivedData);
                            PutData2Queue("11");
                        }
                        else if (lbyt_Head[0] == 0x0f || lbyt_Head[0] == 0x0d)//收到查詢訊息msgCode=15
                        {
                            string T2b = DateTime.Now.ToString("HH:mm:ss.fff");
                            //取得電文資訊:sample電文:seq.Encoding.Default.GetString(new byte[]{0x50}).0000000.0000000.XXX.
                            STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Data));
                            //將尾碼\n去掉
                            // STR_ReceivedData = STR_ReceivedData.Replace("\n", "");
                            STR_ReceivedData = STR_ReceivedData.Substring(0, STR_ReceivedData.Length - 1);
                            //V1.0.0.10 Added by Peter 20131007
                            STR_ReceivedData = c_Functions.DecodeString(STR_ReceivedData);
                            AOBJ_InfoLog.WriteEntryData(STR_ReceivedData);
                            int rn = 0;
                            string strHead = "";
                            string strSeq = "";
                            string strBody = "";
                            string SOURCE = "";
                            string FIRM = "";
                            string ACTNO = "";
                            string CURRENCY = "";

                            int CurrentSerial = 0;
                            int CurrentSerialFor3 = 0;
                            Byte bytHead;
                            // 因人民幣需求 預設台幣  V1.0.0.15 modified by peter on 20150617
                            CURRENCY = "NTT";
                            if (lbyt_Head[0] == 0x0d)
                            {
                                strHead = STR_ReceivedData.Substring(28, 1);
                                bytHead = Encoding.Default.GetBytes(strHead)[0];
                                strSeq = STR_ReceivedData.Substring(1, 27);
                                strBody = STR_ReceivedData.Substring(29, STR_ReceivedData.Length - 29);
                                if (bytHead != 0x61 && bytHead != 0x64 && bytHead != 0x24)
                                {


                                    //  SOURCE = STR_ReceivedData.Substring(0, 1).PadLeft(2, ' ');
                                    //V1.0.0.3 modified by peter 
                                    SOURCE = Properties.Settings.Default.Source;
                                    FIRM = strBody.Substring(0, 7);
                                    ACTNO = strBody.Substring(7, 7);
                                    if (strBody.Length == 17)//含幣別
                                    {
                                        CURRENCY = strBody.Substring(14, 3);
                                        if (CURRENCY == "TWD")
                                            CURRENCY = "NTT";
                                    }

                                }

                            }
                            else //少SOURCE
                            {
                                strHead = STR_ReceivedData.Substring(27, 1);
                                bytHead = Encoding.Default.GetBytes(strHead)[0];
                                strSeq = STR_ReceivedData.Substring(0, 27);
                                strBody = STR_ReceivedData.Substring(28, STR_ReceivedData.Length - 28);
                                if (bytHead != 0x61 && bytHead != 0x64 && bytHead != 0x24)
                                {

                                    //SOURCE = "".PadLeft(2, ' ');
                                    //V1.0.0.3 modified by peter 
                                    SOURCE = Properties.Settings.Default.Source;
                                    FIRM = strBody.Substring(0, 7);
                                    ACTNO = strBody.Substring(7, 7);
                                    if (strBody.Length == 17)//含幣別
                                    {
                                        CURRENCY = strBody.Substring(14, 3);
                                        if (CURRENCY == "TWD")
                                            CURRENCY = "NTT";
                                    }
                                }
                            }
                            if (bytHead == 0x23)
                            {
                                CURRENCY = strBody.Substring(14, 3);
                                if (CURRENCY == "TWD")
                                    CURRENCY = "NTT";
                            }
                            string networkId = "";
                            Byte[] byt_send = null;
                            //判斷是否為多筆申請
                            switch (bytHead)
                            {
                                case 0x61:
                                case 0x64:

                                    string SEQNO = strBody.Substring(5, 4);

                                    lock (mdt_NetWorkIdMappling)
                                    {
                                        if (mdt_NetWorkIdMappling.Rows.Find(new object[] { strSeq, SEQNO }) == null)
                                        {
                                            DataRow[] drDatas = mdt_NetWorkIdMappling.Select("Seq='" + strSeq + "'");
                                            if (drDatas.Length > 0)
                                            { //V1.0.0.10 Modified by peter
                                                networkId = drDatas[0]["networkId"].ToString();

                                            }
                                            else
                                            {
                                                lock (mobj_Parent.mobj_serialLock)
                                                {
                                                    mobj_Parent.mint_CurrentSerial++;
                                                    //V1.0.0.10 Modified by peter
                                                    CurrentSerial = mobj_Parent.mint_CurrentSerial;
                                                    networkId = Properties.Settings.Default.SrcCode + CurrentSerial.ToString("X").PadLeft(7, '0');

                                                }
                                            }
                                            mdt_NetWorkIdMappling.Rows.Add(new object[] { strSeq, SEQNO, networkId });
                                        }
                                        else
                                        { //V1.0.0.10 Modified by peter
                                            networkId = mdt_NetWorkIdMappling.Rows.Find(new object[] { strSeq, SEQNO })["networkId"].ToString();
                                        }
                                    }



                                    switch (bytHead)
                                    {
                                        case 0x61:
                                            AccountSockClientParserFunction.DDSCREQUESTCOMBINE t = new AccountSockClientParserFunction.DDSCREQUESTCOMBINE();
                                            AccountSockClientParserFunction.ByteArrayToDDSCREQUESTCOMBINEStructure(buffer, ref t);
                                            byt_send = _TI.getPSGREQUESTCOMBINE(new string(t.TYPE), networkId, new string(t.COUNT)
                                                                                                            , new string(t.SEQNO)
                                                                                                            , new string(t.COMPANY)
                                                                                                            , new string(t.ACTNO)
                                                                                                            , new string(t.Comno1)
                                                                                                            , new string(t.Comym1)
                                                                                                            , new string(t.Stkprc1)
                                                                                                            , new string(t.Callput1)
                                                                                                            , new string(t.BS1)
                                                                                                            , new string(t.Qty1)
                                                                                                            , new string(t.Comno2)
                                                                                                            , new string(t.Comym2)
                                                                                                            , new string(t.Stkprc2)
                                                                                                            , new string(t.Callput2)
                                                                                                            , new string(t.BS2)
                                                                                                            , new string(t.Qty2));



                                            break;
                                        case 0x64:
                                            AccountSockClientParserFunction.DDSCREQUESTNET DDSCREQUESTNET = new AccountSockClientParserFunction.DDSCREQUESTNET();
                                            AccountSockClientParserFunction.ByteArrayToDDSCREQUESTNETStructure(buffer, ref DDSCREQUESTNET);
                                            byt_send = _TI.getPSGREQUESTNET(networkId, new string(DDSCREQUESTNET.COUNT)
                                                                                    , new string(DDSCREQUESTNET.SEQNO)
                                                                                    , new string(DDSCREQUESTNET.COMPANY)
                                                                                    , new string(DDSCREQUESTNET.ACTNO));
                                            break;
                                    }

                                    break;
                                case 0x24:

                                    AccountSockClientParserFunction.DDSCREQUESTWITHDRAW DDSCREQUESTWITHDRAW = new AccountSockClientParserFunction.DDSCREQUESTWITHDRAW();
                                    AccountSockClientParserFunction.ByteArrayToDDSCREQUESTWITHDRAWStructure(buffer, ref DDSCREQUESTWITHDRAW);

                                    if ((new string(DDSCREQUESTWITHDRAW.TYPE)).Trim() == "2")//取消
                                    {
                                        networkId = new string(DDSCREQUESTWITHDRAW.SEQNO);
                                    }
                                    else
                                    {
                                        lock (mobj_Parent.mobj_serialLockFor3)
                                        {



                                            mobj_Parent.mint_CurrentSerialFor3++;
                                            CurrentSerialFor3 = mobj_Parent.mint_CurrentSerialFor3;
                                            networkId = _WithdrawKey + CurrentSerialFor3.ToString().PadLeft(4, '0');
                                        }
                                    }
                                    break;

                                default:
                                    lock (mobj_Parent.mobj_serialLock)
                                    {

                                        mobj_Parent.mint_CurrentSerial++;
                                        CurrentSerial = mobj_Parent.mint_CurrentSerial;
                                        //networkId = mobj_Parent.mint_CurrentSerial.ToString().PadLeft(8, '0');
                                        networkId = (Properties.Settings.Default.SrcCode + CurrentSerial.ToString("X").PadLeft(7, '0')).PadRight(10, ' ');
                                    }


                                    break;
                            }



                            lock (mobj_Parent.Vobj_SEQMapping)
                            {
                                if (!mobj_Parent.Vobj_SEQMapping.ContainsKey(networkId))
                                {
                                    mobj_Parent.Vobj_SEQMapping.Add(networkId, new string[] { strSeq, mstr_adress, strHead });
                                }
                                else
                                {
                                    mobj_Parent.Vobj_SEQMapping[networkId] = new string[] { strSeq, mstr_adress, strHead };
                                }
                            }


                            try
                            {
                                if (!bool.Parse(Properties.Settings.Default.TESTMODE))
                                {
                                    if (bytHead == 0x61 || bytHead == 0x64)
                                    {
                                        //rn = mobj_Parent.Vobj_mobc.Mob_iTXSend(401, byt_send, "TAIFEX.REQUEST.0x" + BitConverter.ToString(new byte[] { bytHead }) + "." + Properties.Settings.Default.ServerID, "");
                                        if (byt_send != null)
                                        {
                                            mobj_Parent.AS400ClientFor2.Send(byt_send);
                                        }
                                        else
                                        {
                                            throw new Exception("AS400ClientFor2 buffer 異常");
                                        }

                                    }
                                    else
                                    {
                                        switch (bytHead)
                                        {
                                            case 0x50://保證金查詢
                                                byt_send = _TI.getPSGREQUEST001(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                                                break;
                                            case 0x05://未平倉資料查詢
                                                //  CURRENCY = "NTT"; //因人民幣需求 未平倉查詢要帶人民幣，所以不能寫死 V1.0.0.15 modified by peter on 20150617
                                                byt_send = _TI.getPSGREQUEST003(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                                                break;
                                            case 0x52://當日損益查詢
                                                byt_send = _TI.getPSGREQUEST005(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                                                break;
                                            case 0x56://即時部位查詢
                                                byt_send = _TI.getPSGREQUEST007(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                                                break;
                                            case 0x58://即時組合部位查詢
                                                byt_send = _TI.getPSGREQUEST009(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                                                break;
                                            case 0x21://當日平蒼損益查詢
                                                CURRENCY = strBody.Substring(14, 3);
                                                byt_send = _TI.getPSGREQUEST013(networkId, SOURCE, FIRM, ACTNO, CURRENCY, strBody.Substring(17, 1), strBody.Substring(18, 7), strBody.Substring(25, 6), strBody.Substring(31, 1), strBody.Substring(32, 9), strBody.Substring(41, 9));
                                                break;
                                            case 0x23://出入金查詢 
                                                string STRDATE = strBody.Substring(17, 8);
                                                string ENDDATE = strBody.Substring(25, 8);

                                                string STRTIME = strBody.Substring(33, 8);
                                                string ENDTIME = strBody.Substring(41, 8);

                                                byt_send = _TI.getPSGREQUEST015(networkId, SOURCE, FIRM, ACTNO, CURRENCY, STRDATE, ENDDATE, STRTIME, ENDTIME);
                                                break;
                                            case 0x24://出入金申請 
                                                AccountSockClientParserFunction.DDSCREQUESTWITHDRAW DDSCREQUESTWITHDRAW = new AccountSockClientParserFunction.DDSCREQUESTWITHDRAW();
                                                AccountSockClientParserFunction.ByteArrayToDDSCREQUESTWITHDRAWStructure(buffer, ref DDSCREQUESTWITHDRAW);

                                                if ((new string(DDSCREQUESTWITHDRAW.TYPE)).Trim() == "2")//取消
                                                {
                                                    networkId = new string(DDSCREQUESTWITHDRAW.SEQNO);
                                                }
                                                byt_send = _TI.getPSGREQUESTWITHDRAW(new string(DDSCREQUESTWITHDRAW.MTYPE), networkId, new string(DDSCREQUESTWITHDRAW.TYPE)
                                                                                    , new string(DDSCREQUESTWITHDRAW.COMPANY), new string(DDSCREQUESTWITHDRAW.ACTNO), new string(DDSCREQUESTWITHDRAW.CURRENCY)
                                                                                    , new string(DDSCREQUESTWITHDRAW.AMT), new string(DDSCREQUESTWITHDRAW.TOCURRENCY), new string(DDSCREQUESTWITHDRAW.TOMTYPE), new string(DDSCREQUESTWITHDRAW.TOAMT)
                                                                                    , new string(DDSCREQUESTWITHDRAW.IP), Properties.Settings.Default.WSOURCE, new string(DDSCREQUESTWITHDRAW.SLIPNO1)
                                                                                    , new string(DDSCREQUESTWITHDRAW.SLIPNO2), new string(DDSCREQUESTWITHDRAW.RCV));
                                                if (new string(DDSCREQUESTWITHDRAW.TYPE) == "2")//取消
                                                {




                                                    SaveDB.UpdateWITHDRAWItemDel item = new SaveDB.UpdateWITHDRAWItemDel();
                                                    
                                                    item.SEQNO = networkId;
                                                    item.TYPE = new string(DDSCREQUESTWITHDRAW.TYPE);
                                                    item.COMPANY = new string(DDSCREQUESTWITHDRAW.COMPANY);
                                                    item.ACTNO = new string(DDSCREQUESTWITHDRAW.ACTNO);
                                                    item.ORDDT = DateTime.Now.ToString("yyyyMMdd");
                                                    item.ORDTM = DateTime.Now.ToString("HHmmss");// 
                                                    item.IP = new string(DDSCREQUESTWITHDRAW.IP);
                                                
                                               
                                                    item.CODE = "";

                                                    mobj_Parent.mobj_SaveDB.PutData2Queue(item);
                                                }
                                                else
                                                {
                                                    string AMT = new string(DDSCREQUESTWITHDRAW.AMT);
                                                    AMT = AMT.Substring(0, 12) + "." + AMT.Substring(12, 2).ToString();
                                                    string TOAMT = new string(DDSCREQUESTWITHDRAW.TOAMT);
                                                    TOAMT = TOAMT.Substring(0, 12) + "." + TOAMT.Substring(12, 2).ToString();
                                                    SaveDB.InsertWITHDRAWItem item = new SaveDB.InsertWITHDRAWItem();
                                                    item.MTYPE = new string(DDSCREQUESTWITHDRAW.MTYPE);
                                                    item.SEQNO = networkId;
                                                    item.TYPE = new string(DDSCREQUESTWITHDRAW.TYPE);
                                                    item.COMPANY = new string(DDSCREQUESTWITHDRAW.COMPANY);
                                                    item.ACTNO = new string(DDSCREQUESTWITHDRAW.ACTNO);
                                                    item.CURRENCY = new string(DDSCREQUESTWITHDRAW.CURRENCY);
                                                    item.AMT = AMT;
                                                    item.TOCURRENCY = new string(DDSCREQUESTWITHDRAW.TOCURRENCY);
                                                    item.TOMTYPE = new string(DDSCREQUESTWITHDRAW.TOMTYPE);
                                                    item.TOAMT = TOAMT;
                                                    item.ORDTM = new string(DDSCREQUESTWITHDRAW.ORDTM);
                                                    item.IP = new string(DDSCREQUESTWITHDRAW.IP);
                                                    item.SOURCE = Properties.Settings.Default.WSOURCE;
                                                    item.ORDDT = new string(DDSCREQUESTWITHDRAW.ORDDT);
                                                    //item.SLIPNO1 = new string(DDSCREQUESTWITHDRAW.SLIPNO1);
                                                    //item.SLIPNO2 = new string(DDSCREQUESTWITHDRAW.SLIPNO2);
                                                    //item.RCV = new string(DDSCREQUESTWITHDRAW.RCV);
                                                    item.CODE = "";
                                                    mobj_Parent.mobj_SaveDB.PutData2Queue(item);
                                                }
                                                break;
                                        }
                                        switch (bytHead)
                                        {
                                            case 0x50://保證金查詢

                                            case 0x05://未平倉資料查詢

                                            case 0x52://當日損益查詢

                                            case 0x56://即時部位查詢

                                            case 0x58://即時組合部位查詢

                                            case 0x21://當日平蒼損益查詢
                                            case 0x23://出入金查詢
                                                if (byt_send != null)
                                                {
                                                    AOBJ_InfoLog.WriteEntryData(ASCIIEncoding.ASCII.GetString(byt_send));
                                                    mobj_Parent.AS400Client.Send(byt_send);
                                                }
                                                else
                                                {
                                                    throw new Exception("AS400Client buffer 異常");
                                                }
                                                break;
                                            case 0x24://出入金申請 

                                                if (byt_send != null)
                                                {
                                                    mobj_Parent.AS400ClientFor3.Send(byt_send);
                                                }
                                                else
                                                {
                                                    throw new Exception("AS400ClientFor3 buffer 異常");
                                                }

                                                break;
                                        }


                                        // rn = mobj_Parent.Vobj_mobc.Mob_iTXSend(201, byt_send, "TAIFEX.QUERY.0x" + BitConverter.ToString(new byte[] { bytHead }) + "." + Properties.Settings.Default.ServerID, "");
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                AOBJ_ErrorLog.WriteEntryData(" Error:" + ex.StackTrace.ToString() + "/" + ex.ToString());
                                mobj_Parent.sendErrorData(strHead, strSeq, mstr_adress);
                            }
                            //if (rn!= (int)MOBC.E_FR.FR_OK)
                            //{
                            //    mobj_Parent.sendErrorData(strHead,strSeq, mstr_adress);
                            //}
                            // string strDesc = Enum.Parse(typeof(MOBC.E_FR), rn.ToString()).ToString();

                            string T2e = DateTime.Now.ToString("HH:mm:ss.fff");
                            //AOBJ_InfoLog.WriteEntryData(strSeq + T2b + T2e + networkId + ":" + strDesc + STR_ReceivedData);

                            //mobj_Parent.displayStatusMsg("MOB TXSend " + networkId + ":" + strDesc);

                            if (bytHead == 0x24)
                            {
                                mobj_Parent.WRNetworkIdFor3.Write(CurrentSerialFor3.ToString());
                            }
                            else
                                mobj_Parent.WRNetworkId.Write(CurrentSerial.ToString());




                        }

                    }

                }
                else
                {
                    lbyt_Data = new byte[lint_Len];
                    STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Head))
                        + new string(Encoding.Default.GetChars(lbyt_Len))
                        + new string(Encoding.Default.GetChars(lbyt_Data));
                    mobj_Parent.displayStatusMsg("資料有誤:" + STR_ReceivedData);
                }
            }
            catch (Exception ex)
            {
                AOBJ_ErrorLog.WriteEntryData(" Error:" + ex.StackTrace.ToString() + "/" + ex.ToString());
                mobj_Parent.displayStatusMsg(m_Tcp.RemoteEndPoint.ToString() + ": Exception:" + ex.StackTrace);
            }
            finally
            {

                if (m_Tcp != null)
                {
                    //儲存使用者離線時間
                    string[] arrPutIPLogoutCmd = new string[1];
                    status = "1";
                    //判斷使用者帶空白,不寫入資料庫 20121012
                    if (mstr_AE.Trim() != "")
                    {
                        arrPutIPLogoutCmd[0] = "UPDATE [dbo].[tblInfoIPLog]"
                          + "SET [logoutTime] ='" + DateTime.Now.ToString("HH:mm:ss") + "',[status] = '" + status + "'"
                        + "WHERE userid='" + mstr_AE + "' and ip='" + mstr_ip + "' and port='" + mstr_port + "' and  logintime ='" + mstr_loginTime + "'";
                        mobj_Parent.mobj_SaveDB.PutData2Queue(arrPutIPLogoutCmd);
                    }
                    m_Tcp.Close();
                    m_Tcp = null;
                }
                this.ConnectionDispose();
            }
        }

        /// <summary>
        /// 資訊傳送
        /// </summary>
        public void SendMessage(string str_Data)
        {
            try
            {
                //判斷連線是否存在
                if (m_Tcp != null && m_Tcp.Connected)
                {




                    //取得頭碼
                    byte byte_TradeFlag = byte.Parse(str_Data.Substring(0, 2));

                    byte byte_EndFlag = byte.Parse("10");

                    string lstr_Msg_No = "";
                    if (str_Data.Length > 3)
                    {
                        lstr_Msg_No = "00";
                        str_Data = str_Data.Substring(2, str_Data.Length - 2);
                    }
                    else
                    {
                        lstr_Msg_No = "00";
                        str_Data = "";
                    }

                    byte[] SendDataBuffer = new byte[500];
                    int lint_Len = 0;
                    Encoding EncodType;
                    EncodType = Encoding.Default;
                    switch (byte_TradeFlag)
                    {
                        //回傳連線確認訊息    
                        case 0x02://格式:" "+長度(4)+分公司(3)+使用者ID(10)+"00"||"99"+內文(?)+" "
                            str_Data = mstr_Company.PadRight(3, ' ') + mstr_AE.PadRight(10, ' ')
                                + (mstr_AE != null ? "00" : "99") + str_Data;

                            break;
                        //回傳連線確認訊息    
                        case 0x04://格式:" "+長度(4)+"00"||"99"+內文(?)+" "

                            break;
                        //回傳行情訊息
                        case 0x0e://格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = lstr_Msg_No + c_Functions.EncodeString(str_Data);

                            break;
                        //回傳alive訊息
                        case 0x13://回傳alive資訊//格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = lstr_Msg_No + str_Data;
                            AOBJ_InfoLog.WriteEntryData("Alive");
                            break;
                        case 0x0b://回傳11資訊//格式:" "+長度(4)+"00"||"99"+內文(?)+" "
                            str_Data = lstr_Msg_No + str_Data;
                            AOBJ_InfoLog.WriteEntryData("11");
                            break;
                        default:
                            break;

                    }
                    lint_Len = c_Functions.getStringLen(str_Data) + 1;
                    //將字串轉成buffer
                    SendDataBuffer = EncodType.GetBytes(" " + lint_Len.ToString().PadLeft(4, '0') + str_Data + " ");
                    //加尾碼
                    SendDataBuffer.SetValue(byte_EndFlag, SendDataBuffer.Length - 1);
                    //將頭碼加在buffer最前面
                    SendDataBuffer.SetValue(byte_TradeFlag, 0);
                    m_Tcp.Send(SendDataBuffer);
                }
            }
            catch (Exception ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.StackTrace.ToString() + "/" + ex.ToString());
            }
        }


        /// <summary>
        /// 外部資訊傳入
        /// </summary>
        public void PutData2Queue(string str_Data)
        {
            lock (((ICollection)m_QueueData).SyncRoot)
            {
                m_QueueData.Enqueue(str_Data);

                syncConnectionEvents.NewItemEvent.Set();
            }
        }

        /// <summary>
        /// 不斷取出Queue資訊
        /// </summary>
        private void execQueueData()
        {
            while (WaitHandle.WaitAny(syncConnectionEvents.EventArray) != 1)
            {
                do
                {
                    string data = "";
                    lock (((ICollection)m_QueueData).SyncRoot)
                    {

                        if (m_QueueData.Count > 0)
                        {
                            //判斷先把DEQ資料放在DATA變數裡
                            data = m_QueueData.Dequeue();
                        }

                    }

                    //等到確定取得資料做送資料動作
                    if (data != "")
                    {
                        SendMessage(data);
                    }
                } while (m_QueueData.Count > 0);

            }
        }


    }
}
