﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace AS400GatewayServer.MYCLS
{
    public partial class WebSocketServer : Component
    {
        private WriterLOG mobj_ErrorLog;
        public Dart.PowerTCP.SslSockets.Server m_SocketServer;
        public string mstr_IP;
        public int mint_Port;
    
        public string mstr_name;
        public WebSocketServer(string name)
        {
            mstr_name = name;
            mobj_ErrorLog = new WriterLOG(mstr_name + "SocketServerError");
            try
            {

                m_SocketServer = new Dart.PowerTCP.SslSockets.Server();
                m_SocketServer.Editor = this.m_SocketServer;
            }
            catch (Exception ex)
            {
                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }
           
            InitializeComponent();
            components.Add(this);
        }

        public WebSocketServer(IContainer container)
        {

            container.Add(this);
            InitializeComponent();
        }
        public void SocketServerStart()
        {
            try
            {
                // 啟動SOCKET

                m_SocketServer.Listen(mstr_IP, mint_Port);

            }
            catch (Exception ex)
            {
                m_SocketServer.Abort();
                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }
        }

        public void SocketServerClose()
        {
            try
            {
                // 中斷SOCKET
                if (m_SocketServer.Active)
                {
                    m_SocketServer.Close();
                }
            }
            catch (Exception ex)
            {

                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }
        }
    }
}
