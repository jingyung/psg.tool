﻿using System;
using System.Collections.Generic;
using System.Text;
using Dart.PowerTCP.SslSockets;
using System.Windows.Forms;

namespace AS400GatewayServer.MYCLS
{

    public class SocketServer  
    {
        private WriterLOG mobj_ErrorLog;
        public  Dart.PowerTCP.SslSockets.Server m_SocketServer;
        public string mstr_IP;
        public int mint_Port;
        public string AS400_IP;
        public int AS400_Port;
        private System.ComponentModel.IContainer components;
        public string mstr_name;
        public SocketServer(string name)
        {
            mstr_name=name ;
            this.components = new System.ComponentModel.Container();
            mobj_ErrorLog = new WriterLOG(mstr_name+"SocketServerError");
            try
            {
 
                m_SocketServer = new Dart.PowerTCP.SslSockets.Server(this.components);
                m_SocketServer.Editor = this.m_SocketServer;
            }
            catch (Exception ex)
            {
                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }

        }

        ~SocketServer()
        {
            SocketServerDispose();
        }

        public void SocketServerDispose()
        {
           
            if (m_SocketServer != null)
            {

                m_SocketServer.Close();
            }
            if (mobj_ErrorLog != null)
            {
                mobj_ErrorLog.Close();
            }
            //AbortThread();
            GC.SuppressFinalize(this);
        }

        public void SocketServerStart()
        {
            try
            {
                // 啟動SOCKET

                m_SocketServer.Listen(mstr_IP, mint_Port);

            }
            catch (Exception ex)
            {
                m_SocketServer.Abort();
                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }
        }

        public void SocketServerClose()
        {
            try
            {
                // 中斷SOCKET
                if (m_SocketServer.Active)
                {
                    m_SocketServer.Close();
                }
            }
            catch (Exception ex)
            {

                mobj_ErrorLog.WriteEntryData("Server Start Error:" + ex.Message.Replace("\r\n", " "));
            }
        }

   
    }
}