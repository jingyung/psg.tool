﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using Dart.PowerTCP.SslSockets;
using System.IO;
using System.Windows.Forms;
using com.ddsc.BI.Account;
using com.ddsc.net;

using com.ddsc.nets;

using com.ddsc.tool;
using com.ddsc.core;
namespace AS400GatewayServer.MYCLS
{
    public class DataAgent : DisplayMsg
    {
        public static string TradeDate = "";
        public static string BASEPATH = "";
        public static string CURRENTPATH = "";

        //V1.0.0.9 Added by peter 20130829
        private object _AS400ReplysLocker = new object();
        Dictionary<string, WriterLOG> _AS400Replys = new Dictionary<string, WriterLOG>();
        private QueuePoolByLock<byte[]> AS400ReplyQ = null;
        private QueuePoolByLock<byte[]> AS400ReplyQ2 = null;
        private QueuePoolByLock<byte[]> AS400ReplyQ3 = null;

        private QueuePoolByLock<string> _WEBFILERequest = null;

        public QueuePoolByLock<string> WEBFILERequest
        {
            get { return _WEBFILERequest; }
            set { _WEBFILERequest = value; }
        }
        private QueuePoolByLock<string> _WEBFILEResponse = null;

        public QueuePoolByLock<string> WEBFILEResponse
        {
            get { return _WEBFILEResponse; }
            set { _WEBFILEResponse = value; }
        }

        private WriterLOG _WebInfoLog = null;
        private WriterLOG _WebReplyLog = null;



        FileWriterReader _WRNetworkId = null;

        public FileWriterReader WRNetworkId
        {
            get { return _WRNetworkId; }
            set { _WRNetworkId = value; }
        }
        FileWriterReader _WRNetworkIdFor3 = null;

        public FileWriterReader WRNetworkIdFor3
        {
            get { return _WRNetworkIdFor3; }
            set { _WRNetworkIdFor3 = value; }
        }
        public com.ddsc.BI.Account.ReplyIntegration _RI;

        private com.ddsc.nets.TcpClient _AS400Client;

        public com.ddsc.nets.TcpClient AS400Client
        {
            get { return _AS400Client; }
            set { _AS400Client = value; }
        }

        private com.ddsc.nets.TcpServer _AS400ReplyServer;

        public com.ddsc.nets.TcpServer AS400ReplyServer
        {
            get { return _AS400ReplyServer; }
            set { _AS400ReplyServer = value; }
        }
        //added by peter V1.0.0.4
        private com.ddsc.nets.TcpClient _AS400ClientFor2;
        //added by peter V1.0.0.4
        public com.ddsc.nets.TcpClient AS400ClientFor2
        {
            get { return _AS400ClientFor2; }
            set { _AS400ClientFor2 = value; }
        }
        //added by peter V1.0.0.4
        private com.ddsc.nets.TcpServer _AS400ReplyServerFor2;
        //added by peter V1.0.0.4
        public com.ddsc.nets.TcpServer AS400ReplyServerFor2
        {
            get { return _AS400ReplyServerFor2; }
            set { _AS400ReplyServerFor2 = value; }
        }

        //added by peter V1.0.0.11
        private com.ddsc.nets.TcpClient _AS400ClientFor3;
        //added by peter V1.0.0.11
        public com.ddsc.nets.TcpClient AS400ClientFor3
        {
            get { return _AS400ClientFor3; }
            set { _AS400ClientFor3 = value; }
        }
        //added by peter V1.0.0.11 出入金
        private com.ddsc.nets.TcpServer _AS400ReplyServerFor3;
        //added by peter V1.0.0.11出入金
        public com.ddsc.nets.TcpServer AS400ReplyServerFor3
        {
            get { return _AS400ReplyServerFor3; }
            set { _AS400ReplyServerFor3 = value; }
        }

        private delegate void parseInfoDataDelegate(string strData);

        private WriterLOG m_obj512InfoLog;


        private bool mbol_MarketInfoSocketRunning;

        private int mint_MarketInfoSocketReConnect;
        /// <summary>
        /// 行情Socket物件
        /// </summary>
        public SocketClient mobj_MarketInfoSocketClient;

        private WriterLOG mobj_dataAgentLog;

        private WriterLOG mobj_AS400ClientLogSend;
        private WriterLOG mobj_AS400ClientLogRcv;
        private WriterLOG mobj_AS400ClientLogError;

        //private WriterLOG mobj_AS400ServerReplyLogSend;
        //private WriterLOG mobj_AS400ServerReplyLogRcv;
        private WriterLOG mobj_AS400ServerReplyLogError;

        private WriterLOG mobj_AS400ClientLogSendFor2;
        private WriterLOG mobj_AS400ClientLogRcvFor2;
        private WriterLOG mobj_AS400ClientLogErrorFor2;

        private WriterLOG mobj_AS400ServerReplyLogSendFor2;
        private WriterLOG mobj_AS400ServerReplyLogRcvFor2;
        private WriterLOG mobj_AS400ServerReplyLogErrorFor2;

        //added by peter V1.0.0.11出入金
        private WriterLOG mobj_AS400ClientLogSendFor3;
        private WriterLOG mobj_AS400ClientLogRcvFor3;
        private WriterLOG mobj_AS400ClientLogErrorFor3;

        private WriterLOG mobj_AS400ServerReplyLogSendFor3;
        private WriterLOG mobj_AS400ServerReplyLogRcvFor3;
        private WriterLOG mobj_AS400ServerReplyLogErrorFor3;



        public DataTable mdt_MappingIp;
        public Dictionary<string, string[]> mobj_SEQMapping;


        /// <summary>
        /// 檢查Socket是否alive的timer
        /// </summary>
        private System.Windows.Forms.Timer mtmr_CheckSocketAlive;

        public SocketServer mobj_TradeSocketServer;
        public SocketServer mobj_ReplySendServer;


        public static WebSocketServer mobj_WebSocketServer;

        public Dictionary<string, Connection> mobj_TradeClientCollection;
        public Dictionary<string, ReplyConnection> mobj_ReplyClientCollection;
        public Dictionary<string, WebConnection> mobj_WebClientCollection;
        public object mobj_serialLock = new object();
        public object mobj_serialLockFor3 = new object();
        public SaveDB mobj_SaveDB;
        private int mint_maxReConnectCount;
        public int mint_CurrentSerial = 0;


        public int mint_CurrentSerialFor3 = 0;
        /// <summary>
        /// 存放期貨商品檔
        /// </summary>
        public DataTable mdt_FutureData;
        /// <summary>
        /// 存放選擇權商品
        /// </summary>
        public DataTable mdt_OptionData;

        public DataTable mdt_I020;
        public DataTable mdt_I060;//added by samantha20160203現貨價
        private bool _AS400Ack = false;
        private bool _AS400For2Ack = false;
        //added by peter V1.0.0.11出入金
        private bool _AS400For3Ack = false;

        public Dictionary<string, string[]> Vobj_SEQMapping
        {
            get
            {
                return mobj_SEQMapping;
            }
            set
            {
                mobj_SEQMapping = value;
            }
        }
        public DataTable Vdt_MappingIp
        {
            get
            {
                return mdt_MappingIp;
            }
            set
            {
                mdt_MappingIp = value;
            }
        }
        public DataAgent()
        {
            mint_maxReConnectCount = 99999;
        }

        ~DataAgent()
        {
            dispose();
        }
        public void dispose()
        {

            try
            {
                if (mobj_MarketInfoSocketClient != null)
                {
                    mobj_MarketInfoSocketClient.SocketClientDispose();
                }
                if (mobj_TradeSocketServer != null)
                {
                    Tcp[] ar = new Tcp[mobj_TradeSocketServer.m_SocketServer.Connections.Count];
                    mobj_TradeSocketServer.m_SocketServer.Connections.CopyTo(ar);
                    foreach (Tcp tcp in ar)
                    {
                        tcp.Close();
                    }
                    mobj_TradeSocketServer.SocketServerClose();
                    mobj_TradeSocketServer.SocketServerDispose();
                }

                if (mobj_ReplySendServer != null)
                {
                    Tcp[] ar = new Tcp[mobj_ReplySendServer.m_SocketServer.Connections.Count];
                    mobj_ReplySendServer.m_SocketServer.Connections.CopyTo(ar);
                    foreach (Tcp tcp in ar)
                    {
                        tcp.Close();
                    }
                    mobj_ReplySendServer.SocketServerClose();
                    mobj_ReplySendServer.SocketServerDispose();
                }
                if (mobj_WebSocketServer != null)
                {
                    Tcp[] ar = new Tcp[mobj_WebSocketServer.m_SocketServer.Connections.Count];
                    mobj_WebSocketServer.m_SocketServer.Connections.CopyTo(ar);
                    foreach (Tcp tcp in ar)
                    {
                        tcp.Close();
                    }
                    mobj_WebSocketServer.Dispose();

                }
                if (mobj_SaveDB != null)
                {
                    mobj_SaveDB.SaveDBDispose();
                }
                if (_WRNetworkId != null)
                    _WRNetworkId.Close();
                if (_WRNetworkIdFor3 != null)
                    _WRNetworkIdFor3.Close();

                if (_WebInfoLog != null)
                    _WebInfoLog.Close(); ;
                if (_WebReplyLog != null)
                    _WebReplyLog.Close();




                if (_WEBFILERequest != null)
                {
                    _WEBFILERequest.Dispose();
                }
                if (_WEBFILEResponse != null)
                {
                    _WEBFILEResponse.Dispose();
                }
                if (mobj_AS400ClientLogSend != null) mobj_AS400ClientLogSend.Close();
                if (mobj_AS400ClientLogRcv != null) mobj_AS400ClientLogRcv.Close();
                if (mobj_AS400ClientLogError != null) mobj_AS400ClientLogError.Close();
                if (mobj_AS400ServerReplyLogError != null) mobj_AS400ServerReplyLogError.Close();
                if (mobj_AS400ClientLogSendFor2 != null) mobj_AS400ClientLogSendFor2.Close();
                if (mobj_AS400ClientLogRcvFor2 != null) mobj_AS400ClientLogRcvFor2.Close();
                if (mobj_AS400ClientLogErrorFor2 != null) mobj_AS400ClientLogErrorFor2.Close();
                if (mobj_AS400ServerReplyLogSendFor2 != null) mobj_AS400ServerReplyLogSendFor2.Close();
                if (mobj_AS400ServerReplyLogRcvFor2 != null) mobj_AS400ServerReplyLogRcvFor2.Close();
                if (mobj_AS400ServerReplyLogErrorFor2 != null) mobj_AS400ServerReplyLogErrorFor2.Close();
                if (mobj_AS400ClientLogSendFor3 != null) mobj_AS400ClientLogSendFor3.Close();
                if (mobj_AS400ClientLogRcvFor3 != null) mobj_AS400ClientLogRcvFor3.Close();
                if (mobj_AS400ClientLogErrorFor3 != null) mobj_AS400ClientLogErrorFor3.Close();
                if (mobj_AS400ServerReplyLogSendFor3 != null) mobj_AS400ServerReplyLogSendFor3.Close();
                if (mobj_AS400ServerReplyLogRcvFor3 != null) mobj_AS400ServerReplyLogRcvFor3.Close();
                if (mobj_AS400ServerReplyLogErrorFor3 != null) mobj_AS400ServerReplyLogErrorFor3.Close();
                if (mobj_dataAgentLog != null) mobj_dataAgentLog.Close();

            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("close Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }



            if (mobj_dataAgentLog != null)
            {
                mobj_dataAgentLog.Close();
            }


            GC.SuppressFinalize(this);
        }
        public int ReadSerial()
        {
            int CurrentSerial = 0;
            try
            {
                DataTable dtData = new DataTable();
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.AccountSQLConnection);

                SqlDataAdapter adp;
                string SqlCommand = "";

                if (Properties.Settings.Default.VIPVersion)
                {
                    SqlCommand = "select serial_current from system_serial WHERE [serial_id] = 'VIPPutSeQ' and convert(char(8),mdate,112)=convert(char(8),getdate(),112)";
                }
                else
                {
                    SqlCommand = "select serial_current from system_serial WHERE [serial_id] = 'WEBPutSeQ' and convert(char(8),mdate,112)=convert(char(8),getdate(),112)";
                }

                adp = new SqlDataAdapter(SqlCommand, conn);

                for (int i = 0; i < Properties.Settings.Default.ReConnectDBCount; i++)
                {
                    try
                    {

                        adp.Fill(dtData);
                        mobj_dataAgentLog.WriteEntryData("ReadSerial OK:" + i.ToString());
                        i = Properties.Settings.Default.ReConnectDBCount;

                    }
                    catch (SqlException sqlex)
                    {
                        mobj_dataAgentLog.WriteEntryData("ReadSerial Fill Error " + i.ToString() + ":" + sqlex.Message + "\r\n" + sqlex.Source + "\r\n" + sqlex.StackTrace);
                        Thread.Sleep(10000);
                    }

                }
                if (dtData.Rows.Count > 0)
                {
                    CurrentSerial = int.Parse(dtData.Rows[0]["serial_current"].ToString());
                }
                else
                {
                    CurrentSerial = int.Parse("00000000");
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("ReadSerial Error:" + ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }

            return CurrentSerial;
        }



        private void init()
        {
            DataAgent.BASEPATH = "";

            DataAgent.BASEPATH = DataAgent.BASEPATH.Trim().Length == 0 ? AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() : DataAgent.BASEPATH;

            int begin = int.Parse(Properties.Settings.Default.ClearDataTime);
            int now = int.Parse(DateTime.Now.ToString("HHmm"));

            if (begin > now)
            {
                CURRENTPATH = DataAgent.TradeDate = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
            }
            else
            {
                CURRENTPATH = DataAgent.TradeDate = DateTime.Now.ToString("yyyyMMdd");
            }


        }


        public void start()
        {
            try
            {
                init();
                _WebInfoLog = new WriterLOG("WebInfoLog");
                _WebReplyLog = new WriterLOG("WebReplyLog");
                mobj_AS400ClientLogSend = new WriterLOG("AS400ClientLogSend");
                mobj_AS400ClientLogRcv = new WriterLOG("AS400ClientLogRcv");
                mobj_AS400ClientLogError = new WriterLOG("AS400ClientLogError");
                //mobj_AS400ServerReplyLogSend = new WriterLOG("AS400ServerReplyLogSend");
                //mobj_AS400ServerReplyLogRcv = new WriterLOG("AS400ServerReplyLogRcv");
                mobj_AS400ServerReplyLogError = new WriterLOG("AS400ServerReplyLogError");


                mobj_AS400ClientLogSendFor2 = new WriterLOG("AS400ClientLogSendFor2");
                mobj_AS400ClientLogRcvFor2 = new WriterLOG("AS400ClientLogRcvFor2");
                mobj_AS400ClientLogErrorFor2 = new WriterLOG("AS400ClientLogErrorFor2");
                mobj_AS400ServerReplyLogSendFor2 = new WriterLOG("AS400ServerReplyLogSendFor2");
                mobj_AS400ServerReplyLogRcvFor2 = new WriterLOG("AS400ServerReplyLogRcvFor2");
                mobj_AS400ServerReplyLogErrorFor2 = new WriterLOG("AS400ServerReplyLogErrorFor2");
                //added by peter V1.0.0.11出入金
                mobj_AS400ClientLogSendFor3 = new WriterLOG("AS400ClientLogSendFor3");
                mobj_AS400ClientLogRcvFor3 = new WriterLOG("AS400ClientLogRcvFor3");
                mobj_AS400ClientLogErrorFor3 = new WriterLOG("AS400ClientLogErrorFor3");
                mobj_AS400ServerReplyLogSendFor3 = new WriterLOG("AS400ServerReplyLogSendFor3");
                mobj_AS400ServerReplyLogRcvFor3 = new WriterLOG("AS400ServerReplyLogRcvFor3");
                mobj_AS400ServerReplyLogErrorFor3 = new WriterLOG("AS400ServerReplyLogErrorFor3");


                mobj_dataAgentLog = new WriterLOG("DataAgent");
                // mobj_T3Log = new WriterLOG("DataAgentT3");
                mobj_TradeClientCollection = new Dictionary<string, Connection>();
                mobj_ReplyClientCollection = new Dictionary<string, ReplyConnection>();
                mobj_WebClientCollection = new Dictionary<string, WebConnection>();
                // mint_CurrentSerial = ReadSerial();

                FileALLReader r = new FileALLReader(CURRENTPATH, "NetWorkId");
                string seq = r.read();
                if (seq != "")
                {
                    seq = seq.Split('\n')[seq.Split('\n').Length - 2];
                }
                mint_CurrentSerial = seq == "" ? 0 : int.Parse(seq);
                r.Close();

                _WRNetworkId = new FileWriterReader(CURRENTPATH, "NetWorkId");

                FileALLReader r3 = new FileALLReader(CURRENTPATH, "NetWorkIdFor3");
                string seq3 = r3.read();
                if (seq3 != "")
                {
                    seq3 = seq3.Split('\n')[seq3.Split('\n').Length - 2];
                }
                mint_CurrentSerialFor3 = seq3 == "" ? int.Parse(Properties.Settings.Default.WSOURCE_SEQ_START) : int.Parse(seq3);
                r3.Close();

                _WRNetworkIdFor3 = new FileWriterReader(CURRENTPATH, "NetWorkIdFor3");

                mdt_I020 = new DataTable();
                mdt_I020.Columns.Add("COMMODITYID");
                mdt_I020.Columns.Add("MatchPrice");
                mdt_I020.Columns.Add("isclose");
                mdt_I020.Columns.Add("HighPrice");
                mdt_I020.Columns.Add("LowPrice");
                mdt_I020.PrimaryKey = new DataColumn[] { mdt_I020.Columns["COMMODITYID"] };

                mdt_I060 = new DataTable();
                mdt_I060.Columns.Add("kindid");
                mdt_I060.Columns.Add("stockprice");
                mdt_I060.PrimaryKey = new DataColumn[] { mdt_I060.Columns["kindid"] };
                mobj_SEQMapping = new Dictionary<string, string[]>();
                mdt_MappingIp = new DataTable();
                mdt_MappingIp.Columns.Add("seq");
                mdt_MappingIp.Columns.Add("oip");
                mdt_MappingIp.Columns.Add("rip");
                DataColumn[] dcs = new DataColumn[] { mdt_MappingIp.Columns["seq"] };
                mdt_MappingIp.PrimaryKey = dcs;

                mobj_SaveDB = new SaveDB();
                getINIData();


                //初始和啟動TradeSocketServer
                mobj_TradeSocketServer = new SocketServer("APOrder");
                mobj_TradeSocketServer.mstr_IP = Properties.Settings.Default.APRegisterSocketServerIP;
                mobj_TradeSocketServer.mint_Port = int.Parse(Properties.Settings.Default.APRegisterSocketServerPort);
                mobj_TradeSocketServer.m_SocketServer.ActiveChanged += new EventHandler(m_TradeSktServer_ActiveChanged);
                mobj_TradeSocketServer.m_SocketServer.Connection += new Dart.PowerTCP.SslSockets.ConnectionEventHandler(m_TradeSktServer_Connection);
                mobj_TradeSocketServer.SocketServerStart();

                //初始和啟動ReplySendServer
                mobj_ReplySendServer = new SocketServer("Reply");
                mobj_ReplySendServer.mstr_IP = Properties.Settings.Default.APSendSocketServerIP;
                mobj_ReplySendServer.mint_Port = int.Parse(Properties.Settings.Default.APSendSocketServerPort);
                mobj_ReplySendServer.m_SocketServer.ActiveChanged += new EventHandler(m_ReplySktServer_ActiveChanged);
                mobj_ReplySendServer.m_SocketServer.Connection += new Dart.PowerTCP.SslSockets.ConnectionEventHandler(m_ReplySktServer_Connection);
                mobj_ReplySendServer.SocketServerStart();

                if (!Properties.Settings.Default.VIPVersion)
                {
                    //初始和啟動ReplySendServer
                    mobj_WebSocketServer = new WebSocketServer("WEB");
                    mobj_WebSocketServer.mstr_IP = Properties.Settings.Default.WebSocketServerIP;
                    mobj_WebSocketServer.mint_Port = int.Parse(Properties.Settings.Default.WebSocketServerPort);
                    mobj_WebSocketServer.m_SocketServer.ActiveChanged += new EventHandler(m_SocketServer_ActiveChanged);
                    mobj_WebSocketServer.m_SocketServer.Connection += new ConnectionEventHandler(m_SocketServer_Connection);
                    mobj_WebSocketServer.SocketServerStart();
                    enabledMarketInfoSocket(true);
                }



                if (!bool.Parse(Properties.Settings.Default.TESTMODE))
                {

                    mtmr_CheckSocketAlive = new System.Windows.Forms.Timer();
                    mtmr_CheckSocketAlive.Interval = 20000;
                    mtmr_CheckSocketAlive.Tick += new System.EventHandler(mtmr_CheckSocketAlive_Tick);
                    mtmr_CheckSocketAlive.Start();


                }

                enableAS400Server(true);
                enableAS400Client(true);
                enableAS400ServerFor2(true);
                enableAS400ClientFor2(true);

                enableAS400ServerFor3(true);
                enableAS400ClientFor3(true);

                _RI = new ReplyIntegration();
                _RI.Receive += new ReplyIntegration.ReceiveEventHandler(_RI_Receive);
                _RI.ReceiveFor2 += new ReplyIntegration.ReceiveEventHandlerFor2(_RI_ReceiveFor2);
                _RI.ReceiveFor3 += new ReplyIntegration.ReceiveEventHandlerFor3(_RI_ReceiveFor3);
                _RI.Error += new ReplyIntegration.ErrorEventHandler(_RI_Error);

                mobj_dataAgentLog.WriteEntryData("4");

                _AS400Ack = bool.Parse(Properties.Settings.Default.AS400Ack);
                _AS400For2Ack = bool.Parse(Properties.Settings.Default.AS400For2Ack);
                _AS400For3Ack = bool.Parse(Properties.Settings.Default.AS400For3Ack);

                AS400ReplyQ = new QueuePoolByLock<byte[]>(1);
                AS400ReplyQ.ParameterExcute += new QueuePoolByLock<byte[]>.ParameterHandler(AS400ReplyQ_ParameterExcute);
                AS400ReplyQ.Go();

                _WEBFILERequest = new QueuePoolByLock<string>(1);
                _WEBFILERequest.ParameterExcute += new QueuePoolByLock<string>.ParameterHandler(_WEBFILERequest_ParameterExcute);
                _WEBFILERequest.Go();

                _WEBFILEResponse = new QueuePoolByLock<string>(1);
                _WEBFILEResponse.ParameterExcute += new QueuePoolByLock<string>.ParameterHandler(_WEBFILEResponse_ParameterExcute);
                _WEBFILEResponse.Go();
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("Start Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }

        }

        void _WEBFILEResponse_ParameterExcute(string ff)
        {
            _WebReplyLog.WriteEntryData(ff);
        }

        void _WEBFILERequest_ParameterExcute(string ff)
        {
            _WebInfoLog.WriteEntryData(ff);
        }

        void AS400ReplyQ_ParameterExcute(byte[] raw)
        {
            _RI.ResolveReceive(raw);
        }




        /// <summary>
        /// 控制行情Socket物件開啟或關閉
        /// </summary>
        public void enabledMarketInfoSocket(bool bol_status)
        {
            try
            {
                if (bol_status)
                {
                    mobj_MarketInfoSocketClient = new SocketClient("MarketInfoSocket", Properties.Settings.Default.MarketInfoIP, int.Parse(Properties.Settings.Default.MarketInfoPort), "000", "admin");
                    mobj_MarketInfoSocketClient.Notifications += new SocketClient.NotificationCallback(MarketInfoSocketHandleTalkerNotifications);

                    mobj_MarketInfoSocketClient.SocketClientStart();
                }
                else
                {
                    if (mobj_MarketInfoSocketClient != null)
                    {
                        mobj_MarketInfoSocketClient.Notifications -= new SocketClient.NotificationCallback(MarketInfoSocketHandleTalkerNotifications);

                        mobj_MarketInfoSocketClient.SocketClientDispose();
                    }
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }

        /// <summary>
        /// 行情Socket異動事件
        /// </summary>
        private void MarketInfoSocketHandleTalkerNotifications(SocketClient.Notification notify, Object data)
        {
            try
            {
                switch (notify)
                {
                    case SocketClient.Notification.ReceivedData:
                        //收行情
                        // Vfrm_Master.Invoke(new parseInfoDataDelegate(parseData), new object[] { data.ToString() });
                        string[] dataArray = data.ToString().Split('|');
                        if (dataArray.Length == 1)
                            parseData(dataArray[0]);
                        else
                        {
                            for (int i = 1; i < dataArray.Length - 1; i++)
                                parseData(dataArray[i]);
                        }

                        break;
                    case SocketClient.Notification.SendDataError:

                        break;
                    case SocketClient.Notification.Error:

                        break;
                    case SocketClient.Notification.ConnectError:
                        displayPicStatus("APInfo", "Disconnected");
                        displayStatusMsg("APInfo:ConnectError");
                        mbol_MarketInfoSocketRunning = false;
                        break;
                    case SocketClient.Notification.End:
                        displayPicStatus("APInfo", "Disconnected");
                        displayStatusMsg("APInfo:Disconnected");
                        mbol_MarketInfoSocketRunning = false;
                        break;
                    case SocketClient.Notification.Disconneted:
                        displayPicStatus("APInfo", "Disconnected");
                        displayStatusMsg("APInfo:Disconnected");
                        mbol_MarketInfoSocketRunning = false;
                        break;
                    case SocketClient.Notification.Conneted:
                        displayPicStatus("APInfo", "Connected");
                        displayStatusMsg("Connect to " + Properties.Settings.Default.MarketInfoIP + ":" + Properties.Settings.Default.MarketInfoPort + " Success!");
                        mbol_MarketInfoSocketRunning = true;

                        break;
                    default:
                        displayPicStatus("APInfo", "Disconnected");
                        displayStatusMsg("APInfo:Disconnected");
                        mbol_MarketInfoSocketRunning = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }




        private void parseData(string strData)
        {
            try
            {
                if (strData.Substring(1, 1) == "1")
                {

                    string[] arrData = strData.Substring(2, strData.Length - 2).Split('@');
                    string COMMODITYID = arrData[0].TrimEnd();
                    lock (mdt_I020)
                    {
                        DataRow drFind = mdt_I020.Rows.Find(COMMODITYID);
                        if (drFind != null)
                        {
                            drFind["MATCHPRICE"] = arrData[2];
                            drFind["isclose"] = "Y";
                        }
                        else
                        {
                            mdt_I020.Rows.Add(new object[] { COMMODITYID, arrData[2], "Y" });

                        }
                    }

                }
                else if (strData.Substring(0, 2) == "33" || strData.Substring(0, 2) == "63")
                {
                    string[] arrData = strData.Substring(2, strData.Length - 2).Split('@');
                    string COMMODITYID = arrData[0].TrimEnd();
                    lock (mdt_I020)
                    {
                        DataRow drFind = mdt_I020.Rows.Find(COMMODITYID);
                        if (drFind != null)
                        {
                            drFind["MATCHPRICE"] = arrData[1];
                        }
                        else
                        {
                            mdt_I020.Rows.Add(new object[] { COMMODITYID, arrData[1] });

                        }
                    }

                    if (strData.Substring(0, 1) == "3")
                    {
                        lock (mdt_FutureData)
                        {
                            DataRow[] drFinds = mdt_FutureData.Select("Commodity_Id='" + COMMODITYID + "'");
                            if (drFinds.Length > 0)
                            {
                                drFinds[0]["closeprice"] = arrData[1];
                            }

                        }
                    }
                    else
                    {
                        lock (mdt_OptionData)
                        {
                            DataRow[] drFinds = mdt_OptionData.Select("Commodity_Id='" + COMMODITYID + "'");
                            if (drFinds.Length > 0)
                            {
                                drFinds[0]["closeprice"] = arrData[1];
                            }

                        }
                    }

                }
                else if (strData.Substring(0, 2) == "25" || strData.Substring(0, 2) == "55")
                {

                    string[] arrData = strData.Substring(2, strData.Length - 2).Split('@');
                    string COMMODITYID = arrData[0].TrimEnd();
                    lock (mdt_I020)
                    {
                        DataRow drFind = mdt_I020.Rows.Find(COMMODITYID);
                        if (drFind != null)
                        {
                            drFind["HighPrice"] = arrData[1];
                            drFind["LowPrice"] = arrData[2];
                        }
                        else
                        {
                            mdt_I020.Rows.Add(new object[] { COMMODITYID, "", "", arrData[1], arrData[2] });

                        }
                    }

                }
                else if (strData.Substring(0, 2) == "15" || strData.Substring(0, 2) == "45")//新增i060處理 added by samantha 20160203
                {
                    string[] arrData = strData.Substring(2, strData.Length - 3).Split('@');
                    string kindid = arrData[0].TrimEnd();
                    lock (mdt_I060)
                    {
                        DataRow drFind = mdt_I060.Rows.Find(kindid);
                        if (drFind != null)
                        {
                            drFind["StockPrice"] = arrData[2];
                        }
                        else
                        {
                            mdt_I060.Rows.Add(new object[] { kindid, arrData[2] });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }


        private void enableAS400Client(bool status)
        {
            if (status)
            {
                _AS400Client = new com.ddsc.nets.TcpClient();
                _AS400Client.HandShakeBuffer = com.ddsc.BI.Account.AccountSockClientParserFunction.getPSGHandShake(Properties.Settings.Default.AS400ClientPort);
                _AS400Client.Disconnected += new com.ddsc.nets.TcpClient.disconnectedHandler(_AS400Client_Disconnected);
                _AS400Client.connected += new com.ddsc.nets.TcpClient.connectedHandler(_AS400Client_connected);
                _AS400Client.Sended += new com.ddsc.nets.TcpClient.SendedHandler(_AS400Client_Sended);
                _AS400Client.Received += new com.ddsc.nets.TcpClient.ReceivedHandler(_AS400Client_Received);
                _AS400Client.Error += new com.ddsc.nets.TcpClient.ErrorHandler(_AS400Client_Error);
                _AS400Client.Connect(Properties.Settings.Default.AS400ClientIP, int.Parse(Properties.Settings.Default.AS400ClientPort));

            }
            else
            {
                if (_AS400Client != null)
                {
                    _AS400Client.Disconnected -= new com.ddsc.nets.TcpClient.disconnectedHandler(_AS400Client_Disconnected);
                    _AS400Client.connected -= new com.ddsc.nets.TcpClient.connectedHandler(_AS400Client_connected);
                    _AS400Client.Sended -= new com.ddsc.nets.TcpClient.SendedHandler(_AS400Client_Sended);
                    _AS400Client.Received -= new com.ddsc.nets.TcpClient.ReceivedHandler(_AS400Client_Received);
                    _AS400Client.Error -= new com.ddsc.nets.TcpClient.ErrorHandler(_AS400Client_Error);

                    _AS400Client.Close();
                }
            }
        }
        private void enableAS400Server(bool status)
        {

            if (status)
            {
                _AS400ReplyServer = new com.ddsc.nets.TcpServer();
                _AS400ReplyServer.Disconnected += new TcpServer.DisconnectedHandler(_AS400ReplyServer_Disconnected);
                _AS400ReplyServer.connected += new com.ddsc.nets.TcpServer.connectedHandler(_AS400ReplyServer_connected);
                _AS400ReplyServer.Actived += new com.ddsc.nets.TcpServer.ActivedHandler(_AS400ReplyServer_Actived);
                _AS400ReplyServer.Error += new com.ddsc.nets.TcpServer.ErrorHandler(_AS400ReplyServer_Error);
                _AS400ReplyServer.Received += new TcpServer.ReceivedHandler(_AS400ReplyServer_Received);
                _AS400ReplyServer.Sended += new com.ddsc.nets.TcpServer.SendedHandler(_AS400ReplyServer_Sended);
                _AS400ReplyServer.Listen(Properties.Settings.Default.AS400ReplyServerIP, int.Parse(Properties.Settings.Default.AS400ReplyServerPort));

            }
            else
            {
                if (_AS400ReplyServer != null)
                {
                    _AS400ReplyServer.Disconnected -= new TcpServer.DisconnectedHandler(_AS400ReplyServer_Disconnected);
                    _AS400ReplyServer.connected -= new com.ddsc.nets.TcpServer.connectedHandler(_AS400ReplyServer_connected);
                    _AS400ReplyServer.Actived -= new com.ddsc.nets.TcpServer.ActivedHandler(_AS400ReplyServer_Actived);
                    _AS400ReplyServer.Error -= new com.ddsc.nets.TcpServer.ErrorHandler(_AS400ReplyServer_Error);
                    _AS400ReplyServer.Received -= new TcpServer.ReceivedHandler(_AS400ReplyServer_Received);
                    _AS400ReplyServer.Sended -= new com.ddsc.nets.TcpServer.SendedHandler(_AS400ReplyServer_Sended);

                    _AS400ReplyServer.Close();
                }
            }
        }



        private void enableAS400ClientFor2(bool status)
        {
            if (status)
            {
                _AS400ClientFor2 = new com.ddsc.nets.TcpClient();
                _AS400ClientFor2.HandShakeBuffer = com.ddsc.BI.Account.AccountSockClientParserFunction.getPSGHandShakeFor2(Properties.Settings.Default.AS400ClientFor2Port);
                _AS400ClientFor2.Disconnected += new com.ddsc.nets.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor2);
                _AS400ClientFor2.connected += new com.ddsc.nets.TcpClient.connectedHandler(_AS400Client_connectedFor2);
                _AS400ClientFor2.Sended += new com.ddsc.nets.TcpClient.SendedHandler(_AS400Client_SendedFor2);
                _AS400ClientFor2.Received += new com.ddsc.nets.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor2);
                _AS400ClientFor2.Error += new com.ddsc.nets.TcpClient.ErrorHandler(_AS400Client_ErrorFor2);
                _AS400ClientFor2.Connect(Properties.Settings.Default.AS400ClientFor2IP, int.Parse(Properties.Settings.Default.AS400ClientFor2Port));

            }
            else
            {
                if (_AS400ClientFor2 != null)
                {
                    _AS400ClientFor2.Disconnected -= new com.ddsc.nets.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor2);
                    _AS400ClientFor2.connected -= new com.ddsc.nets.TcpClient.connectedHandler(_AS400Client_connectedFor2);
                    _AS400ClientFor2.Sended -= new com.ddsc.nets.TcpClient.SendedHandler(_AS400Client_SendedFor2);
                    _AS400ClientFor2.Received -= new com.ddsc.nets.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor2);
                    _AS400ClientFor2.Error -= new com.ddsc.nets.TcpClient.ErrorHandler(_AS400Client_ErrorFor2);

                    _AS400ClientFor2.Close();
                }
            }
        }
        private void enableAS400ServerFor2(bool status)
        {

            if (status)
            {
                _AS400ReplyServerFor2 = new com.ddsc.nets.TcpServer();
                _AS400ReplyServerFor2.Disconnected += new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor2);
                _AS400ReplyServerFor2.connected += new com.ddsc.nets.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor2);
                _AS400ReplyServerFor2.Actived += new com.ddsc.nets.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor2);
                _AS400ReplyServerFor2.Error += new com.ddsc.nets.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor2);
                _AS400ReplyServerFor2.Received += new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor2);
                _AS400ReplyServerFor2.Sended += new com.ddsc.nets.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor2);
                _AS400ReplyServerFor2.Listen(Properties.Settings.Default.AS400ReplyServerFor2IP, int.Parse(Properties.Settings.Default.AS400ReplyServerFor2Port));

            }
            else
            {
                if (_AS400ReplyServerFor2 != null)
                {
                    _AS400ReplyServerFor2.Disconnected -= new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor2);
                    _AS400ReplyServerFor2.connected -= new com.ddsc.nets.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor2);
                    _AS400ReplyServerFor2.Actived -= new com.ddsc.nets.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor2);
                    _AS400ReplyServerFor2.Error -= new com.ddsc.nets.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor2);
                    _AS400ReplyServerFor2.Received -= new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor2);
                    _AS400ReplyServerFor2.Sended -= new com.ddsc.nets.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor2);

                    _AS400ReplyServerFor2.Close();
                }
            }
        }

        //added by peter V1.0.0.11 出入金
        private void enableAS400ClientFor3(bool status)
        {
            if (status)
            {
                _AS400ClientFor3 = new com.ddsc.nets.TcpClient();
                _AS400ClientFor3.HandShakeBuffer = com.ddsc.BI.Account.AccountSockClientParserFunction.getPSGHandShakeFor3(Properties.Settings.Default.AS400ClientFor3Port);
                _AS400ClientFor3.Disconnected += new com.ddsc.nets.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor3);
                _AS400ClientFor3.connected += new com.ddsc.nets.TcpClient.connectedHandler(_AS400Client_connectedFor3);
                _AS400ClientFor3.Sended += new com.ddsc.nets.TcpClient.SendedHandler(_AS400Client_SendedFor3);
                _AS400ClientFor3.Received += new com.ddsc.nets.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor3);
                _AS400ClientFor3.Error += new com.ddsc.nets.TcpClient.ErrorHandler(_AS400Client_ErrorFor3);
                _AS400ClientFor3.Connect(Properties.Settings.Default.AS400ClientFor3IP, int.Parse(Properties.Settings.Default.AS400ClientFor3Port));

            }
            else
            {
                if (_AS400ClientFor3 != null)
                {
                    _AS400ClientFor3.Disconnected -= new com.ddsc.nets.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor3);
                    _AS400ClientFor3.connected -= new com.ddsc.nets.TcpClient.connectedHandler(_AS400Client_connectedFor3);
                    _AS400ClientFor3.Sended -= new com.ddsc.nets.TcpClient.SendedHandler(_AS400Client_SendedFor3);
                    _AS400ClientFor3.Received -= new com.ddsc.nets.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor3);
                    _AS400ClientFor3.Error -= new com.ddsc.nets.TcpClient.ErrorHandler(_AS400Client_ErrorFor3);

                    _AS400ClientFor3.Close();
                }
            }
        }
        //added by peter V1.0.0.11 出入金
        private void enableAS400ServerFor3(bool status)
        {

            if (status)
            {
                _AS400ReplyServerFor3 = new com.ddsc.nets.TcpServer();
                _AS400ReplyServerFor3.Disconnected += new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor3);
                _AS400ReplyServerFor3.connected += new com.ddsc.nets.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor3);
                _AS400ReplyServerFor3.Actived += new com.ddsc.nets.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor3);
                _AS400ReplyServerFor3.Error += new com.ddsc.nets.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor3);
                _AS400ReplyServerFor3.Received += new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor3);
                _AS400ReplyServerFor3.Sended += new com.ddsc.nets.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor3);
                _AS400ReplyServerFor3.Listen(Properties.Settings.Default.AS400ReplyServerFor3IP, int.Parse(Properties.Settings.Default.AS400ReplyServerFor3Port));

            }
            else
            {
                if (_AS400ReplyServerFor3 != null)
                {
                    _AS400ReplyServerFor3.Disconnected -= new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor3);
                    _AS400ReplyServerFor3.connected -= new com.ddsc.nets.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor3);
                    _AS400ReplyServerFor3.Actived -= new com.ddsc.nets.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor3);
                    _AS400ReplyServerFor3.Error -= new com.ddsc.nets.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor3);
                    _AS400ReplyServerFor3.Received -= new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor3);
                    _AS400ReplyServerFor3.Sended -= new com.ddsc.nets.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor3);

                    _AS400ReplyServerFor3.Close();
                }
            }
        }


        private void m_TradeSktServer_ActiveChanged(object sender, System.EventArgs e)
        {
            try
            {
                if (mobj_TradeSocketServer.m_SocketServer.Active)
                {
                    if (mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() == "0.0.0.0")
                        displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[Listening on port " + mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");
                    else
                        displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[Listening on " + mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() + ":" + mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");

                    displayPicStatus(mobj_TradeSocketServer.mstr_name, "Connected");
                }
                else
                {
                    displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":Server not accepting connections...");
                    displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[Closed]");

                    displayPicStatus(mobj_TradeSocketServer.mstr_name, "Disconnected");
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        private void m_TradeSktServer_Connection(object sender, Dart.PowerTCP.SslSockets.ConnectionEventArgs e)
        {
            try
            {
                //取得連結IP
                string id = e.Tcp.RemoteEndPoint.ToString();
                try
                {
                    //顯示client 連線訊息
                    displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  Connection established");
                    //選示連線ID
                    displayAddConnections(mobj_TradeSocketServer.mstr_name + ":" + id);

                    Connection conn = new Connection(e.Tcp, Application.StartupPath, "LogFileName", "Trade", this);
                    lock (mobj_TradeClientCollection)
                    {
                        mobj_TradeClientCollection.Add(id, conn);
                    }
                    conn.Execute();

                }
                catch (Exception ex)
                {
                    mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                    //顯示client 連線訊息
                    displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  " + ex.Message.ToString());
                    e.Tcp.Close();

                }
                finally
                {
                    //顯示client 連線訊息
                    displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  Connection closed");
                    displayRemoveConnections(mobj_TradeSocketServer.mstr_name + ":" + id);
                    lock (mobj_TradeClientCollection)
                    {
                        mobj_TradeClientCollection.Remove(id);
                    }
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        private void m_ReplySktServer_ActiveChanged(object sender, System.EventArgs e)
        {
            try
            {
                if (mobj_ReplySendServer.m_SocketServer.Active)
                {
                    if (mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Address.ToString() == "0.0.0.0")
                        displayStatusMsg("APReply:[Listening on port " + mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");
                    else
                        displayStatusMsg("APReply:[Listening on " + mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Address.ToString() + ":" + mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");

                    displayPicStatus("APReply", "Connected");
                }
                else
                {
                    displayStatusMsg("APReply:Server not accepting connections...");
                    displayStatusMsg("APReply:[Closed]");

                    displayPicStatus("APReply", "Disconnected");
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        private void m_ReplySktServer_Connection(object sender, Dart.PowerTCP.SslSockets.ConnectionEventArgs e)
        {
            try
            {
                //取得連結IP
                string id = e.Tcp.RemoteEndPoint.ToString();
                try
                {
                    //顯示client 連線訊息
                    displayStatusMsg("APReply:[" + id + "]  Connection established");
                    //選示連線ID
                    displayAddConnections("APReply:" + id);

                    ReplyConnection conn = new ReplyConnection(e.Tcp, Application.StartupPath, "LogFileName", "Reply", this);
                    lock (mobj_ReplyClientCollection)
                    {
                        mobj_ReplyClientCollection.Add(id, conn);
                    }
                    conn.Execute();

                }
                catch (Exception ex)
                {
                    mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                    //顯示client 連線訊息
                    displayStatusMsg("APReply:[" + id + "]  " + ex.Message.ToString());
                    e.Tcp.Close();

                }
                finally
                {
                    //顯示client 連線訊息
                    displayStatusMsg("APReply:[" + id + "]  Connection closed");
                    displayRemoveConnections("APReply:" + id);
                    lock (mobj_ReplyClientCollection)
                    {
                        mobj_ReplyClientCollection.Remove(id);
                    }
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        void m_SocketServer_Connection(object sender, ConnectionEventArgs e)
        {
            try
            {

                //取得連結IP
                string id = e.Tcp.RemoteEndPoint.ToString();
                //顯示client 連線訊息
                displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[" + id + "]  Connection established");
                //選示連線ID
                displayAddConnections(mobj_WebSocketServer.mstr_name + ":" + id);

                WebConnection conn = new WebConnection(e.Tcp, Application.StartupPath, "LogFileName", "WEB", this);
                lock (mobj_WebClientCollection)
                {
                    mobj_WebClientCollection.Add(id, conn);
                }
                try
                {


                    conn.Execute();

                }
                catch (Exception ex)
                {
                    mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                    //顯示client 連線訊息
                    displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  " + ex.Message.ToString());
                    e.Tcp.Close();

                }
                finally
                {
                    conn.Dispose();
                    //顯示client 連線訊息
                    displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[" + id + "]  Connection closed");
                    lock (mobj_WebClientCollection)
                    {
                        mobj_WebClientCollection.Remove(id);
                    }
                    displayRemoveConnections(mobj_WebSocketServer.mstr_name + ":" + id);

                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }

        void m_SocketServer_ActiveChanged(object sender, EventArgs e)
        {
            try
            {
                if (mobj_WebSocketServer.m_SocketServer.Active)
                {
                    if (mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() == "0.0.0.0")
                        displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[Listening on port " + mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");
                    else
                        displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[Listening on " + mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() + ":" + mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");

                    displayPicStatus(mobj_WebSocketServer.mstr_name, "Connected");
                }
                else
                {
                    displayStatusMsg(mobj_WebSocketServer.mstr_name + ":Server not accepting connections...");
                    displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[Closed]");

                    displayPicStatus(mobj_WebSocketServer.mstr_name, "Disconnected");
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }


        public void sendMatchPrice(string seq, string networkid, string queryip, string productId)
        {


            byte[] byt_send = new byte[38];
            object Matchprpice = getMatchPrice(productId);

            if (Matchprpice != null)
            {
                if (Matchprpice.ToString().Contains("-"))
                {
                    Array.Copy(Encoding.Default.GetBytes("q" + seq + String.Format("{0:0000.0000}", decimal.Parse(Matchprpice.ToString())).Replace(".", "")), 0, byt_send, 0, 37);
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes("q" + seq + String.Format("{0:00000.0000}", decimal.Parse(Matchprpice.ToString())).Replace(".", "")), 0, byt_send, 0, 37);
                }
            }
            else
            {
                //查詢結算價
                string closeprice = getClosePrice(productId);
                if (closeprice != "")
                {
                    if (closeprice.Contains("-"))
                    {
                        Array.Copy(Encoding.Default.GetBytes("q" + seq + String.Format("{0:0000.0000}", decimal.Parse(closeprice.ToString())).Replace(".", "")), 0, byt_send, 0, 37);
                    }
                    else
                    {
                        Array.Copy(Encoding.Default.GetBytes("q" + seq + String.Format("{0:00000.0000}", decimal.Parse(closeprice.ToString())).Replace(".", "")), 0, byt_send, 0, 37);
                    }
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes("q" + seq + "         "), 0, byt_send, 0, 37);
                }
            }

            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);



            lock (mobj_WebClientCollection)
            {
                mobj_WebClientCollection[queryip].PutData2Queue("14" + Encoding.Default.GetString(byt_send));
            }

            lock (mobj_SEQMapping)
            {
                mobj_SEQMapping.Remove(networkid);
            }



        }
        public void sendHighLowPrice(string seq, string networkid, string queryip, string productId)
        {


            byte[] byt_send = new byte[47];
            string[] returnprice = getHighLowPrice(productId);

            if (returnprice[0] != null)
            {
                if (returnprice[0].Contains("-"))
                {
                    Array.Copy(Encoding.Default.GetBytes("s" + seq + String.Format("{0:0000.0000}", decimal.Parse(returnprice[0])).Replace(".", "")), 0, byt_send, 0, 37);
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes("s" + seq + String.Format("{0:00000.0000}", decimal.Parse(returnprice[0])).Replace(".", "")), 0, byt_send, 0, 37);
                }
            }
            else
            {
                Array.Copy(Encoding.Default.GetBytes("s" + seq + "         "), 0, byt_send, 0, 37);

            }

            if (returnprice[1] != null)
            {
                if (returnprice[1].Contains("-"))
                {
                    Array.Copy(Encoding.Default.GetBytes(String.Format("{0:0000.0000}", decimal.Parse(returnprice[1])).Replace(".", "")), 0, byt_send, 37, 9);
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(returnprice[1])).Replace(".", "")), 0, byt_send, 37, 9);
                }
            }
            else
            {
                Array.Copy(Encoding.Default.GetBytes("         "), 0, byt_send, 37, 9);

            }
            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);



            lock (mobj_WebClientCollection)
            {
                mobj_WebClientCollection[queryip].PutData2Queue("14" + Encoding.Default.GetString(byt_send));
            }

            lock (mobj_SEQMapping)
            {
                mobj_SEQMapping.Remove(networkid);
            }



        }
        public void sendProductInfo(string seq, string networkid, string queryip, string productdata)
        {
            int count = productdata.Length / 10;
            byte[] byt_send = new byte[count * 27 + 29];
            Array.Copy(Encoding.Default.GetBytes("u" + seq), 0, byt_send, 0, 28);
            for (int i = 0; i < count; i++)
            {
                DataRow drFind = null;
                string productId = productdata.Substring(i * 10, 10);
                lock (mdt_I020)
                {

                    drFind = mdt_I020.Rows.Find(productId);
                }
                string Matchprpice = null;
                string HighPrice = null;
                string LowPrice = null;
                if (drFind != null)
                {
                    if (drFind["MATCHPRICE"].ToString().Trim() != "")
                    {
                        Matchprpice = drFind["MATCHPRICE"].ToString();
                    }
                    if (drFind["HighPrice"].ToString().Trim() != "")
                    {
                        HighPrice = drFind["HighPrice"].ToString();
                    }
                    if (drFind["LowPrice"].ToString().Trim() != "")
                    {
                        LowPrice = drFind["LowPrice"].ToString();
                    }
                }
                else
                {
                    Matchprpice = getClosePrice(productId);
                }

                if (Matchprpice != null && Matchprpice != "")
                {
                    if (Matchprpice.Contains("-"))
                    {
                        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:0000.0000}", decimal.Parse(Matchprpice)).Replace(".", "")), 0, byt_send, (28 + i * 27), 9);
                    }
                    else
                    {
                        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(Matchprpice)).Replace(".", "")), 0, byt_send, (28 + i * 27), 9);
                    }
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes("         "), 0, byt_send, (28 + i * 27), 9);
                }
                if (HighPrice != null)
                {
                    if (HighPrice.Contains("-"))
                    {
                        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:0000.0000}", decimal.Parse(HighPrice)).Replace(".", "")), 0, byt_send, (28 + i * 27 + 9), 9);
                    }
                    else
                    {
                        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(HighPrice)).Replace(".", "")), 0, byt_send, (28 + i * 27 + 9), 9);
                    }
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes("         "), 0, byt_send, (28 + i * 27 + 9), 9);
                }

                if (LowPrice != null)
                {
                    if (LowPrice.Contains("-"))
                    {
                        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:0000.0000}", decimal.Parse(LowPrice)).Replace(".", "")), 0, byt_send, (28 + i * 27 + 18), 9);
                    }
                    else
                    {
                        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(LowPrice)).Replace(".", "")), 0, byt_send, (28 + i * 27 + 18), 9);
                    }
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes("         "), 0, byt_send, (28 + i * 27 + 18), 9);
                }
            }


            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);



            lock (mobj_WebClientCollection)
            {
                mobj_WebClientCollection[queryip].PutData2Queue("14" + Encoding.Default.GetString(byt_send));
            }

            lock (mobj_SEQMapping)
            {
                mobj_SEQMapping.Remove(networkid);
            }



        }
        public void sendStockPrice(string seq, string networkid, string queryip, string kindid)//added by samantha20160203現貨價
        {
            byte[] byt_send = new byte[38];
            object stockprpice = getStockPrice(kindid);
            if (stockprpice != null)
            {
                if (stockprpice.ToString().Contains("-"))
                {
                    Array.Copy(Encoding.Default.GetBytes("w" + seq + String.Format("{0:0000.0000}", decimal.Parse(stockprpice.ToString())).Replace(".", "")), 0, byt_send, 0, 37);
                }
                else
                {
                    Array.Copy(Encoding.Default.GetBytes("w" + seq + String.Format("{0:00000.0000}", decimal.Parse(stockprpice.ToString())).Replace(".", "")), 0, byt_send, 0, 37);
                }
            }
            else
            {
                Array.Copy(Encoding.Default.GetBytes("w" + seq + "         "), 0, byt_send, 0, 37);
            }

            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);



            lock (mobj_WebClientCollection)
            {
                mobj_WebClientCollection[queryip].PutData2Queue("14" + Encoding.Default.GetString(byt_send));
            }

            lock (mobj_SEQMapping)
            {
                mobj_SEQMapping.Remove(networkid);
            }



        }
        public void sendErrorData(string strhead, string seq, string queryip)
        {
            try
            {

                string ip = "";
                byte head = Encoding.Default.GetBytes(strhead)[0];

                //用查詢IP去找回應的IP
                ip = getmappingIp(queryip);

                if (ip != "")
                {
                    byte[] byt_send = null;
                    if (head == 0x05)//未平倉格式處理
                    {
                        byt_send = new byte[223];
                        Array.Copy(Encoding.Default.GetBytes("" + seq + "                      00                                     000000  0000000000000000000+00000000000000000000000000000         000000000000000000000000000000000000000000000000000000000000       "), 0, byt_send, 0, 222);
                        byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);
                    }
                    else if (head == 0x56)//即時部位處理
                    {

                        byt_send = new byte[262];
                        Array.Copy(Encoding.Default.GetBytes("W" + seq + "                                         000000000000000000000000000000000000000000+0000.000+000.0000+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00000000000000000000000000000+00000000000000       "), 0, byt_send, 0, 260);


                        byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 2);
                        byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);


                    }
                    else
                    {


                        if (head == 0x52)//當日損益
                        {
                            byt_send = new byte[136];
                            Array.Copy(Encoding.Default.GetBytes("S" + seq + "                          +000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00"), 0, byt_send, 0, 134);
                            byt_send.SetValue(new byte[] { 0x31 }[0], byt_send.Length - 2);
                            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);
                        }
                        else if (head == 0x50)//保證金
                        {
                            byt_send = new byte[482 + 32];
                            Array.Copy(Encoding.Default.GetBytes("Q" + seq + "                                    +00000.0000+000000000000.00+000000000000.00+000000000000.00+000000000000.00-000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+0000000.0000+0000000.0000+0000000.0000+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00              "), 0, byt_send, 0, 480 + 32);
                            byt_send.SetValue(new byte[] { 0x31 }[0], byt_send.Length - 2);
                            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);

                        }
                        else if (head == 0x58)//組合即時部位
                        {
                            byt_send = new byte[152];
                            Array.Copy(Encoding.Default.GetBytes("Y" + seq + "                                                            000000              000000000000000000000000000000000000000000"), 0, byt_send, 0, 150);
                            byt_send.SetValue(new byte[] { 0x31 }[0], byt_send.Length - 2);
                            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);

                        }
                        else if (head == 0x61)//拆組
                        {
                            byt_send = new byte[47];
                            Array.Copy(Encoding.Default.GetBytes("b" + seq + "        00000000  "), 0, byt_send, 0, 46);
                            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);

                        }
                        else if (head == 0x64)//了結
                        {
                            byt_send = new byte[47];
                            Array.Copy(Encoding.Default.GetBytes("e" + seq + "        00000000  "), 0, byt_send, 0, 46);
                            byt_send.SetValue(new byte[] { 0x0a }[0], byt_send.Length - 1);

                        }





                    }

                    if (ip != "N")
                    {
                        lock (mobj_ReplyClientCollection)
                        {
                            mobj_ReplyClientCollection[ip].PutData2Queue("15" + Encoding.Default.GetString(byt_send));
                        }
                    }
                    else
                    {
                        lock (mobj_WebClientCollection)
                        {
                            mobj_WebClientCollection[queryip].PutData2Queue("15" + Encoding.Default.GetString(byt_send));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        private string getmappingIp(string key)
        {
            string ip = "";
            // mobj_dataAgentLog.WriteEntryData("a");
            lock (mdt_MappingIp)
            {
                DataRow[] dr = mdt_MappingIp.Select("oip='" + key + "'");
                if (dr.Length > 0)
                {
                    //if (dr[0]["rip"].ToString() != dr[0]["oip"].ToString())
                    //{
                    ip = dr[0]["rip"].ToString();
                    //}
                }
            }
            //foreach (DataRow  dr in mdt_MappingIp.Rows)
            //{
            //    mobj_dataAgentLog.WriteEntryData(dr["seq"].ToString());
            //    mobj_dataAgentLog.WriteEntryData(dr["oip"].ToString());
            //    mobj_dataAgentLog.WriteEntryData(dr["rip"].ToString());
            //}
            return ip;
        }

        public void close()
        {
            try
            {
                if (mobj_TradeSocketServer != null)
                {
                    mobj_TradeSocketServer.SocketServerDispose();
                }
                if (mobj_ReplySendServer != null)
                {
                    mobj_ReplySendServer.SocketServerDispose();
                }
                if (mobj_WebSocketServer != null)
                {
                    mobj_WebSocketServer.m_SocketServer.Close();
                    mobj_WebSocketServer.Dispose();

                }

                enableAS400Server(false);
                enableAS400Client(false);
                enableAS400ServerFor2(false);
                enableAS400ClientFor2(false);
                //if (mobj_SocketServerAS400 != null)
                //{
                //    mobj_SocketServerAS400.SocketServerDispose();
                //}
                //enabledSocketReceiveClient(false);
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("Server Closed Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }


        private void mtmr_CheckSocketAlive_Tick(object sender, EventArgs e)
        {
            try
            {


                if (!Properties.Settings.Default.VIPVersion)
                {
                    //判斷目前行情是否連線
                    if (!mbol_MarketInfoSocketRunning || (!mobj_MarketInfoSocketClient.abol_isAlive && mobj_MarketInfoSocketClient.abol_isBeginSend))
                    {
                        mint_MarketInfoSocketReConnect++;
                        if (mint_MarketInfoSocketReConnect < mint_maxReConnectCount)
                        {
                            mobj_MarketInfoSocketClient.abol_isBeginSend = false;
                            enabledMarketInfoSocket(false);
                            enabledMarketInfoSocket(true);
                        }
                    }
                    else
                    {
                        mint_MarketInfoSocketReConnect = 0;
                    }
                    if (mobj_MarketInfoSocketClient.abol_isBeginSend)
                    {
                        if (mbol_MarketInfoSocketRunning)
                        {
                            //確保行情連線正常,定時發送19訊號
                            mobj_MarketInfoSocketClient.abol_isAlive = false;
                            mobj_MarketInfoSocketClient.m_ObjTcpSocketSendData("19");
                        }
                    }
                    else
                    {
                        mobj_MarketInfoSocketClient.abol_isAlive = true;
                    }
                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        private void getINIData()
        {

            try
            {
                mdt_FutureData = new DataTable();
                mdt_OptionData = new DataTable();
                //mdt_FBMCOB = new DataTable();
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.ConfigSQLConnection);
                SqlDataAdapter adp;

                //20101021 在抓商品檔的同時join FBMCOM帶出舊代碼.CNTSIZE,減少搜尋

                //期貨商品檔
                //    adp = new SqlDataAdapter("select a.*,b.closeprice,num from (select tblfuture.*, comno,cntsize from tblfuture left join  fbmcob  on class_name=mktcomno)a left join  (select    *, RANK() OVER (PARTITION BY class_id,period order by matchdate desc) num from  VIPMarketInfoDB.dbo.tblClosePrice) b on  a.Commodity_Id=b.Commodity_Id  where isnull(num,'1')='1'", conn);
                //V1.0.0.12
                adp = new SqlDataAdapter(@"select a.*,b.closeprice,num from (select tblfuture.*

,commodity comno,contract_size cntsize from tblfuture left join  P09MF  on class_name=kind_id)a 
left join  
(select    *, RANK() OVER (PARTITION BY class_id,period order by matchdate desc) num 
from  VIPMarketInfoDB.dbo.tblClosePrice) b on  a.Commodity_Id=b.Commodity_Id 
 where isnull(num,'1')='1'
", conn);

                for (int i = 0; i < Properties.Settings.Default.ReConnectDBCount; i++)
                {
                    try
                    {
                        adp.Fill(mdt_FutureData);
                        mobj_dataAgentLog.WriteEntryData("GetFutureData OK:" + i.ToString());
                        i = Properties.Settings.Default.ReConnectDBCount;

                    }
                    catch (SqlException sqlex)
                    {
                        mobj_dataAgentLog.WriteEntryData("GetFutureData Fill Error " + i.ToString() + ":" + sqlex.Message + "\r\n" + sqlex.Source + "\r\n" + sqlex.StackTrace);
                        Thread.Sleep(10000);
                    }
                }


                //選擇權商品檔
                //V1.0.0.12
                adp = new SqlDataAdapter(@"select a.*,b.closeprice,num
 from (select tbloption.* , commodity comno,contract_size cntsize from tbloption 
left join 
 P09M    on class_name=kind_id )a 
left join  
(select    *, RANK() OVER (PARTITION BY class_id,period,cp,strike_price 
order by matchdate desc) num 
from  VIPMarketInfoDB.dbo.tblClosePrice where cp!='') b 
on  a.Commodity_Id=b.Commodity_Id  where isnull(num,'1')='1' ", conn);

                for (int i = 0; i < Properties.Settings.Default.ReConnectDBCount; i++)
                {
                    try
                    {

                        adp.Fill(mdt_OptionData);

                        mobj_dataAgentLog.WriteEntryData("GetOptionData OK:" + i.ToString());
                        i = Properties.Settings.Default.ReConnectDBCount;
                    }
                    catch (SqlException sqlex)
                    {
                        mobj_dataAgentLog.WriteEntryData("GetOptionData Fill Error " + i.ToString() + ":" + sqlex.Message + "\r\n" + sqlex.Source + "\r\n" + sqlex.StackTrace);
                        Thread.Sleep(10000);
                    }
                }


                //20101021 在搜尋table 增加key
                mdt_FutureData.PrimaryKey = new DataColumn[] { mdt_FutureData.Columns["comno"], mdt_FutureData.Columns["Settlement_month"] };
                mdt_OptionData.PrimaryKey = new DataColumn[] { mdt_OptionData.Columns["Class_Name"], mdt_OptionData.Columns["Settlement_month"], mdt_OptionData.Columns["CP"], mdt_OptionData.Columns["Strike_Price"] };


                ////fbmcob
                //adp = new SqlDataAdapter(" select  *  from fbmcob ", conn);
                //adp.Fill(mdt_FBMCOB);


            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("GetData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);

            }

        }
        public string[] getProductId(string ClassId, string Class_Name, string Settlement_month, string CP, string Strike_Price)
        {
            //20101021回傳增加cntsize
            string[] strReturn = new string[] { "", "", "", "" };
            //20101021改用key做搜尋
            DataRow dr = null;
            if (ClassId == "1")
            {
                lock (mdt_FutureData)
                {
                    dr = mdt_FutureData.Rows.Find(new object[] { Class_Name, Settlement_month });
                }
            }
            else
            {
                lock (mdt_OptionData)
                {
                    dr = mdt_OptionData.Rows.Find(new object[] { Class_Name, Settlement_month, CP, Strike_Price });
                }
            }
            if (dr != null)
            {
                strReturn[0] = dr["Commodity_Id"].ToString().Trim();
                strReturn[1] = dr["closeprice"].ToString().Trim();
                strReturn[2] = dr["Class_Description"].ToString().Trim();
                strReturn[3] = dr["cntsize"].ToString().Trim();
            }
            return strReturn;
        }
        //20101021拿掉改從商品檔抓
        //public string getCntsize(string comno)
        //{
        //    string cntsize = "";
        //    DataRow[] drFinds = mdt_FBMCOB.Select("comno='" + comno + "'");
        //    if (drFinds.Length>0)
        //    {
        //        cntsize = drFinds[0]["cntsize"].ToString();
        //    }
        //    return cntsize;
        //}
        public object getMatchPrice(string productId)
        {
            ////取得資料庫中成交價
            //string selectsql = "select top 1 matchprice from dbo.i020 where convert(char(8),mdate,112)=convert(char(8),getdate(),112)  and  commodityid='" + productId + "'";
            //SqlConnection conn1 = new SqlConnection(Properties.Settings.Default.MOBSQLConnection);
            //conn1.Open();
            //SqlCommand command2 =
            //    new SqlCommand(selectsql, conn1);
            //object Matchprpice = command2.ExecuteScalar();
            //conn1.Close();

            object Matchprpice = null;
            lock (mdt_I020)
            {

                DataRow drFind = mdt_I020.Rows.Find(productId);
                if (drFind != null)
                {
                    Matchprpice = drFind["MATCHPRICE"];
                }
                //如果是複式單,要再判斷兩隻腳商品是否有結算價,用結算價去算
                if (productId.Contains("/"))
                {
                    string foot1 = productId.Substring(0, 5);
                    string foot2 = productId.Substring(0, 3) + productId.Substring(6, 2);
                    string price1 = "";
                    string price2 = "";
                    DataRow drFind1 = mdt_I020.Rows.Find(foot1);
                    if (drFind1 != null)
                    {
                        if (drFind1["isclose"].ToString() == "Y")
                        {
                            price1 = drFind1["MATCHPRICE"].ToString();
                        }
                    }
                    DataRow drFind2 = mdt_I020.Rows.Find(foot2);
                    if (drFind2 != null)
                    {
                        if (drFind2["isclose"].ToString() == "Y")
                        {
                            price2 = drFind2["MATCHPRICE"].ToString();
                        }
                    }
                    if (price1 != "" && price2 != "")
                    {
                        Matchprpice = (decimal.Parse(price2) - decimal.Parse(price1)).ToString();
                    }
                }
            }

            return Matchprpice;
        }
        public string getClosePrice(string productId)
        {

            string closeprice = "";
            if (productId.Contains("/"))
            {
                string foot1 = productId.Substring(0, 5);
                string foot2 = productId.Substring(0, 3) + productId.Substring(6, 2);
                lock (mdt_FutureData)
                {
                    string price1 = "";
                    string price2 = "";

                    DataRow[] drFinds1 = mdt_FutureData.Select("Commodity_Id='" + foot1 + "'");
                    if (drFinds1.Length > 0)
                    {
                        price1 = drFinds1[0]["closeprice"].ToString();
                    }
                    DataRow[] drFinds2 = mdt_FutureData.Select("Commodity_Id='" + foot2 + "'");
                    if (drFinds2.Length > 0)
                    {
                        price2 = drFinds2[0]["closeprice"].ToString();
                    }
                    if (price1 != "" && price2 != "")
                    {
                        closeprice = (decimal.Parse(price2) - decimal.Parse(price1)).ToString();
                    }
                }
            }
            else
            {
                if (productId.Trim().Length < 10)
                {
                    lock (mdt_FutureData)
                    {
                        DataRow[] drFinds = mdt_FutureData.Select("Commodity_Id='" + productId + "'");
                        if (drFinds.Length > 0)
                        {
                            closeprice = drFinds[0]["closeprice"].ToString();
                        }

                    }
                }
                else
                {
                    lock (mdt_OptionData)
                    {
                        DataRow[] drFinds = mdt_OptionData.Select("Commodity_Id='" + productId + "'");
                        if (drFinds.Length > 0)
                        {
                            closeprice = drFinds[0]["closeprice"].ToString();
                        }

                    }
                }
            }

            return closeprice;
        }
        public string[] getHighLowPrice(string productId)
        {
            string[] returnPrice = new string[2];
            lock (mdt_I020)
            {

                DataRow drFind = mdt_I020.Rows.Find(productId);
                if (drFind != null)
                {
                    if (drFind["HighPrice"].ToString().Trim() != "")
                    {
                        returnPrice[0] = drFind["HighPrice"].ToString();
                    }
                    if (drFind["LowPrice"].ToString().Trim() != "")
                    {
                        returnPrice[1] = drFind["LowPrice"].ToString();
                    }
                }

            }

            return returnPrice;
        }
        public object getStockPrice(string kindid)//added by samantha20160203現貨價
        {
            object stockprpice = null;
            lock (mdt_I060)
            {

                DataRow drFind = mdt_I060.Rows.Find(kindid);
                if (drFind != null)
                {
                    stockprpice = drFind["stockprice"];
                }
            }

            return stockprpice;
        }
        private void decimaldata(string CODE, string COMMODITYID, ref int dp)
        {
            DataRow[] drfuture;
            DataRow[] droption;
            int decimal_point = 0;

            if (CODE == "2" || CODE == "3")
            {
                drfuture = mdt_FutureData.Select("commodity_id='" + COMMODITYID.Trim() + "'");
                if (drfuture.Length != 0)
                {
                    decimal_point = int.Parse(drfuture[0]["decimal_place"].ToString());
                }
                else
                {
                    decimal_point = 2;
                }
            }
            else if (CODE == "5" || CODE == "6")
            {
                droption = mdt_OptionData.Select("commodity_id='" + COMMODITYID.Trim() + "'");
                if (droption.Length != 0)
                {
                    decimal_point = int.Parse(droption[0]["decimal_place"].ToString());
                }
                else
                {
                    decimal_point = 3;
                }
            }
            if (decimal_point == 3) dp = 1000;
            else if (decimal_point == 2) dp = 100;
            else if (decimal_point == 1) dp = 10;
            else if (decimal_point == 0) dp = 1;
            else
            {
                dp = (int)Math.Pow(10, decimal_point);
            }
        }




        #region AS400帳務



        void _AS400Client_connected(System.Net.Sockets.Socket s)
        {
            displayPicStatus("AS400Client", "Connected");
            displayStatusMsg("AS400Client Connected ");
        }

        void _AS400Client_Received(System.Net.Sockets.Socket s, byte[] buffer)
        {
            try
            {



                byte[] ESCCODE = new byte[1];
                byte[] LENGTH = new byte[4];
                byte[] Data;
                string Type;


                ESCCODE = ReceiveRawBuffer(ESCCODE.Length, s);
                LENGTH = ReceiveRawBuffer(LENGTH.Length, s);
                int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                byte[] raw = new byte[len];
                Data = new byte[len - ESCCODE.Length - LENGTH.Length];
                Data = ReceiveRawBuffer(Data.Length, s);


                Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                Array.Copy(Data, 0, raw, 0 + ESCCODE.Length + LENGTH.Length, Data.Length);


                //s.Receive(ESCCODE, 0, ESCCODE.Length, System.Net.Sockets.SocketFlags.None);
                //s.Receive(LENGTH, 0, LENGTH.Length, System.Net.Sockets.SocketFlags.None);

                //int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                //byte[] raw = new byte[len];
                //Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                //Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                //s.Receive(raw, ESCCODE.Length + LENGTH.Length, len - ESCCODE.Length - LENGTH.Length, System.Net.Sockets.SocketFlags.None);




                mobj_AS400ClientLogRcv.WriteEntryData(ASCIIEncoding.ASCII.GetString(raw));
            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
                //mobj_dataAgentLog.WriteEntryData("_AS400Client_Received Error:" + ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }

        }

        void _AS400Client_Disconnected()
        {
            displayPicStatus("AS400Client", "Disconnected");
            displayStatusMsg("AS400Client Disconnected ");
        }

        void _AS400Client_Sended(byte[] buffer)
        {
            mobj_AS400ClientLogSend.WriteEntryData(ASCIIEncoding.ASCII.GetString(buffer));

        }
        void _AS400Client_Error(string msg)
        {
            mobj_AS400ClientLogError.WriteEntryData(msg);
        }


        void _AS400ReplyServer_connected(System.Net.Sockets.Socket s)
        {

            displayStatusMsg("AS400Reply " + s.RemoteEndPoint.ToString() + "登入");
            // mobj_AS400ServerReplyLogRcv.WriteEntryData("AS400Reply " + s.RemoteEndPoint.ToString() + "登入");


            lock (_AS400ReplysLocker)
            {

                _AS400Replys.Add(s.RemoteEndPoint.ToString(), new WriterLOG("AS400ServerReplyLog" + s.RemoteEndPoint.ToString().Replace(":", ";")));


                if (_AS400Replys.ContainsKey(s.RemoteEndPoint.ToString()))
                {
                    _AS400Replys[s.RemoteEndPoint.ToString()].WriteEntryData("登入");
                }
            }

        }

        void _AS400ReplyServer_Disconnected(Socket s)
        {
            try
            {
                displayStatusMsg("AS400Reply " + s.RemoteEndPoint.ToString() + "離開");
                //  mobj_AS400ServerReplyLogRcv.WriteEntryData("AS400Reply " + s.RemoteEndPoint.ToString() + "離開");

                lock (_AS400ReplysLocker)
                {
                    if (_AS400Replys.ContainsKey(s.RemoteEndPoint.ToString()))
                    {
                        _AS400Replys[s.RemoteEndPoint.ToString()].WriteEntryData("離開");
                        _AS400Replys[s.RemoteEndPoint.ToString()].Close();
                        _AS400Replys.Remove(s.RemoteEndPoint.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        void _AS400ReplyServer_Actived()
        {
            if (_AS400ReplyServer.Active)
            {
                displayPicStatus("AS400Server", "Connected");
                displayStatusMsg("AS400Server Server Start!");

            }
            else
            {
                displayPicStatus("AS400Server", "Disconnected");
                displayStatusMsg("AS400Server Server stop!");

            }
        }
        void _AS400ReplyServer_Sended(byte[] buffer)
        {
            // mobj_AS400ServerReplyLogSend.WriteEntryData(ASCIIEncoding.ASCII.GetString(buffer));
        }

        void _AS400ReplyServer_Received(System.Net.Sockets.Socket s, byte[] buffer)
        {
            // 
            try
            {


                byte[] ESCCODE = new byte[1];
                byte[] LENGTH = new byte[4];
                byte[] Data;
                string Type;


                ESCCODE = ReceiveRawBuffer(ESCCODE.Length, s);
                LENGTH = ReceiveRawBuffer(LENGTH.Length, s);
                int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                byte[] raw = new byte[len];
                Data = new byte[len - ESCCODE.Length - LENGTH.Length];
                Data = ReceiveRawBuffer(Data.Length, s);


                Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                Array.Copy(Data, 0, raw, 0 + ESCCODE.Length + LENGTH.Length, Data.Length);


                //s.Receive(ESCCODE, 0, ESCCODE.Length, System.Net.Sockets.SocketFlags.None);
                //s.Receive(LENGTH, 0, LENGTH.Length, System.Net.Sockets.SocketFlags.None);

                //int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                //byte[] raw = new byte[len];
                //Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                //Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                //s.Receive(raw, ESCCODE.Length + LENGTH.Length, len - ESCCODE.Length - LENGTH.Length, System.Net.Sockets.SocketFlags.None);

                // mobj_AS400ServerReplyLogRcv.WriteEntryData(ASCIIEncoding.ASCII.GetString(raw).Trim());

                lock (_AS400ReplysLocker)
                {
                    if (_AS400Replys.ContainsKey(s.RemoteEndPoint.ToString()))
                        _AS400Replys[s.RemoteEndPoint.ToString()].WriteEntryData(ASCIIEncoding.Default.GetString(raw).Trim());
                }
                //20130729 Added by peter
                if (_AS400Ack)
                    _AS400ReplyServer.Send(s, raw);


                AS400ReplyQ.PutData2Queue(raw);

                // _RI.ResolveReceive(raw);


            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
            }
        }

        void _AS400ReplyServer_Error(string msg)
        {

            mobj_AS400ServerReplyLogError.WriteEntryData(msg);
            //_LM.WriteLog("AS400ServerReplyLogError", msg);
            //_DisplayItem.displayStatusMsg("AS400ServerReply  " + msg);

        }
        void _RI_Receivetest(ReceivedAccountAcion Action, byte[] b)
        {
            try
            {
                if (b == null) return;
                string strData = Encoding.Default.GetString(b);
                string strWriteData = DateTime.Now.ToString("HH:mm:ss.fff") + "原始接收:" + strData + "\n";
                string networkid = strData.Substring(1, 8);
                string ip = "";
                string queryip = "";
                string seq = "";
                lock (mobj_SEQMapping)
                {
                    if (mobj_SEQMapping.ContainsKey(networkid))
                    {
                        seq = mobj_SEQMapping[networkid][0];
                        queryip = mobj_SEQMapping[networkid][1];
                    }
                }
                //用查詢IP去找回應的IP
                ip = getmappingIp(queryip);
                if (ip != "")
                {

                }
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }


        }
        public void _RI_Receive(ReceivedAccountAcion Action, byte[] buffer)
        {
            try
            {

                mobj_dataAgentLog.WriteEntryData("RI_Receive start ");
                string strData = Encoding.Default.GetString(buffer);
                string strWriteData = DateTime.Now.ToString("HH:mm:ss.fff") + "原始接收:" + strData + "\n";

                string networkid = strData.Substring(1, 8).PadRight(10, ' ');
                string ip = "";
                string queryip = "";
                string seq = "";
                lock (mobj_SEQMapping)
                {
                    if (mobj_SEQMapping.ContainsKey(networkid))
                    {
                        seq = mobj_SEQMapping[networkid][0];
                        queryip = mobj_SEQMapping[networkid][1];
                    }
                }
                //mobj_dataAgentLog.WriteEntryData(networkid+":"+ip + ":" + queryip + ":" + seq);
                //用查詢IP去找回應的IP
                ip = getmappingIp(queryip);
                try
                {
                    if (ip != "")
                    {
                        #region 未平倉 即時部位處理

                        if (buffer[0] == 0x59)//未平倉彙總格式處理
                        {
                            if (strData.Substring(9, 1) == "0" || (strData.Substring(9, 1) == "9"))
                            {
                            }
                            else
                            {

                                string FIRM = strData.Substring(10, 7);
                                string ACTNO = strData.Substring(17, 7);
                                string COMMODX = strData.Substring(24, 21);
                                string BS = strData.Substring(45, 1);

                                string COMTYPE1 = strData.Substring(121, 1);
                                string COMYM1 = strData.Substring(122, 6);
                                string STKPRC1 = strData.Substring(128, 9);

                                string CALLPUT1 = strData.Substring(137, 1);
                                string BS1 = strData.Substring(138, 1);

                                string COMTYPE2 = strData.Substring(148, 1);
                                string COMYM2 = strData.Substring(149, 6);
                                string STKPRC2 = strData.Substring(155, 9);
                                string CALLPUT2 = strData.Substring(164, 1);
                                string BS2 = strData.Substring(165, 1);
                                string dsc = "";
                                ProductInfo info = getProductInfoByProductId(COMMODX);

                                dsc = info.ProductShortDsc + "," + info.ProductShortDsc2;

                                string data = Encoding.Default.GetString(buffer);
                                data = data.Substring(0, data.Length - 1) + dsc + data.Substring(data.Length - 1, 1);
                                buffer = Encoding.Default.GetBytes(data);
                            }
                            string strhead = "14";
                            byte[] byt_send = null;
                            try
                            {
                                byt_send = new byte[buffer.Length + 27];

                                Array.Copy(buffer, 0, byt_send, 0, 1);
                                Array.Copy(Encoding.Default.GetBytes(seq), 0, byt_send, 1, 27);
                                Array.Copy(buffer, 1, byt_send, 28, buffer.Length - 1);

                            }
                            catch (Exception ex)
                            {
                                mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);

                                strhead = "15";

                            }
                            if (ip != "N")
                            {
                                lock (mobj_ReplyClientCollection)
                                {
                                    mobj_ReplyClientCollection[ip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                }
                            }
                            else
                            {
                                lock (mobj_WebClientCollection)
                                {
                                    mobj_WebClientCollection[queryip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                }
                            }
                            //mobj_dataAgentLog.WriteEntryData("組好傳送:" + Encoding.Default.GetString(buffer));
                            strWriteData += DateTime.Now.ToString("HH:mm:ss.fff") + "組好傳送:" + Encoding.Default.GetString(byt_send);
                        }
                        else


                            if (buffer[0] == 0x13)//未平倉格式處理
                            {

                                string strhead = "14";
                                byte[] byt_send = null;
                                try
                                {
                                    int as400bodylength = 163 + 15;
                                    int bodycount = (buffer.Length - 25) / as400bodylength;

                                    int bodylength = as400bodylength + 7 + 6 + 6 + 1;


                                    byt_send = new byte[buffer.Length + 27 + (7 + 6 + 6 + 1 * bodycount)];

                                    Array.Copy(buffer, 0, byt_send, 0, 1);
                                    Array.Copy(Encoding.Default.GetBytes(seq), 0, byt_send, 1, 27);

                                    Array.Copy(buffer, 1, byt_send, 28, 25);

                                    for (int i = 0; i < bodycount; i++)
                                    {
                                        int idxStart = 25 + 27 + (i * (bodylength));
                                        Array.Copy(buffer, 25 + (i * as400bodylength), byt_send, idxStart, as400bodylength);

                                        //重商品檔取商品ID和前日結算價
                                        string productId = "";
                                        string closeprice = "";
                                        string[] strReturn = new string[4];
                                        if (strData.Substring(48 + (i * as400bodylength), 1) == "0")
                                        {
                                            strReturn = getProductId("1", strData.Substring(49 + (i * as400bodylength), 7).Trim(), strData.Substring(56 + (i * as400bodylength), 6), "", "");
                                        }
                                        else
                                        {
                                            strReturn = getProductId("2", strData.Substring(49 + (i * as400bodylength), 7).Trim(), strData.Substring(56 + (i * as400bodylength), 6), strData.Substring(68 + (i * as400bodylength), 1), strData.Substring(62 + (i * as400bodylength), 6));
                                        }
                                        //判斷組合總類為複式期貨,需轉成單式
                                        if (strData.Substring(124 + (i * as400bodylength), 1) == "6")
                                        {
                                            Array.Copy(Encoding.Default.GetBytes("7"), 0, byt_send, 124 + 27 + (i * (bodylength)), 1);
                                        }
                                        productId = strReturn[0];
                                        closeprice = strReturn[1];

                                        if (productId != "")
                                        {

                                            //判斷如果是web 查詢商品代碼先轉好回傳 add by samantha 20100625
                                            if (ip == "N")
                                            {
                                                Array.Copy(Encoding.Default.GetBytes(productId.PadRight(10, ' ')), 0, byt_send, idxStart + 24, 10);
                                                Array.Copy(Encoding.Default.GetBytes(strReturn[2].PadRight(10, ' ')), 0, byt_send, idxStart + 34, 10);
                                                // Array.Copy(System.Text.UnicodeEncoding.Unicode.GetBytes(strReturn[2].PadRight(5, ' ')), 0, byt_send, 25 + 27 + (i * (as400bodylength + 27)) + 34, 10);

                                            }

                                            //20101021改由商品檔直接帶

                                            //從記憶體取基價
                                            //string cntsize = getCntsize(strData.Substring(49 + (i * as400bodylength), 7).Trim());
                                            //if (strReturn[3] != "")
                                            //{
                                            //    Array.Copy(Encoding.Default.GetBytes(String.Format("{0:000000000000.000000}", decimal.Parse(strReturn[3])).Replace(".", "")), 0, byt_send, idxStart + as400bodylength, 18);

                                            //}
                                            //else
                                            //{
                                            //    Array.Copy(Encoding.Default.GetBytes("000000000000000000"), 0, byt_send, idxStart + as400bodylength, 18);
                                            //}
                                            //object Matchprpice = null;
                                            //if (!Properties.Settings.Default.VIPVersion)
                                            //{
                                            //    //取得資料庫中成交價
                                            //    strWriteData += "BeginQuery:" + DateTime.Now.ToString("HH:mm:ss.fff");
                                            //    Matchprpice = getMatchPrice(productId);
                                            //    strWriteData += "EndQuery:" + DateTime.Now.ToString("HH:mm:ss.fff") + "\n";
                                            //}
                                            //if (Matchprpice != null)
                                            //{
                                            //    Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(Matchprpice.ToString())).Replace(".", "")), 0, byt_send, idxStart + as400bodylength + 18, 9);
                                            //}
                                            //else
                                            //{
                                            //    //如果沒有成交價抓結算價
                                            //    if (closeprice != "")
                                            //    {
                                            //        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(closeprice)).Replace(".", "")), 0, byt_send, idxStart + as400bodylength + 18, 9);
                                            //    }
                                            //    else
                                            //    {
                                            //        Array.Copy(Encoding.Default.GetBytes("000000000"), 0, byt_send, idxStart + as400bodylength + 18, 9);
                                            //    }

                                            //}

                                        }
                                        //else
                                        //{ //Added by peter 20120315 商品找不到時填入零
                                        //    Array.Copy(Encoding.Default.GetBytes("000000000000000000"), 0, byt_send, idxStart + as400bodylength, 18);
                                        //    Array.Copy(Encoding.Default.GetBytes("000000000"), 0, byt_send, idxStart + as400bodylength + 18, 9);

                                        //}
                                        Array.Copy(Encoding.Default.GetBytes(strData.Substring(49 + (i * as400bodylength), 7 + 6 + 6 + 1).Trim().PadRight(7 + 6 + 6 + 1, ' ')), 0, byt_send, idxStart + as400bodylength, 7 + 6 + 6 + 1);

                                    }

                                }
                                catch (Exception ex)
                                {
                                    mobj_dataAgentLog.WriteEntryData("SendData Error:" + Encoding.Default.GetString(byt_send) + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                                    byt_send = new byte[223];
                                    strhead = "15";
                                    Array.Copy(Encoding.Default.GetBytes("" + seq + "                      00                                     000000  0000000000000000000+00000000000000000000000000000         000000000000000000000000000000000000000000000000000000000000000000000000000       "), 0, byt_send, 0, 222 + 15);

                                }
                                byt_send.SetValue(buffer[buffer.Length - 1], byt_send.Length - 1);
                                if (ip != "N")
                                {
                                    lock (mobj_ReplyClientCollection)
                                    {
                                        mobj_ReplyClientCollection[ip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                    }
                                }
                                else
                                {
                                    lock (mobj_WebClientCollection)
                                    {
                                        mobj_WebClientCollection[queryip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                    }
                                }

                                strWriteData += DateTime.Now.ToString("HH:mm:ss.fff") + "組好傳送:" + Encoding.Default.GetString(byt_send);

                            }
                            else if (buffer[0] == 0x57)//即時部位處理
                            {
                                string strhead = "14";
                                byte[] byt_send = null;
                                try
                                {
                                    byt_send = new byte[buffer.Length + 27 + 7];

                                    Array.Copy(buffer, 0, byt_send, 0, 1);
                                    Array.Copy(Encoding.Default.GetBytes(seq), 0, byt_send, 1, 27);
                                    Array.Copy(buffer, 1, byt_send, 28, buffer.Length - 1);

                                    //重商品檔取商品ID和前日結算價
                                    string productId = "";
                                    string closeprice = "";
                                    string[] strReturn = new string[4];

                                    if (strData.Substring(41, 1) == "N")
                                    {
                                        strReturn = getProductId("1", strData.Substring(28, 7).Trim(), strData.Substring(35, 6), "", "");

                                    }
                                    else
                                    {
                                        strReturn = getProductId("2", strData.Substring(28, 7).Trim(), strData.Substring(35, 6), strData.Substring(41, 1), strData.Substring(42, 6));
                                    }

                                    productId = strReturn[0];
                                    closeprice = strReturn[1];
                                    if (productId != "")
                                    {

                                        //判斷如果是web 查詢商品代碼先轉好回傳 add by samantha 20100625
                                        if (ip == "N")
                                        {
                                            // Array.Copy(Encoding.Default.GetBytes(productId.PadRight(20, ' ')), 0, byt_send,55, 20);
                                            Array.Copy(Encoding.Default.GetBytes(productId.PadRight(10, ' ')), 0, byt_send, 55, 10);
                                            Array.Copy(Encoding.Default.GetBytes(strReturn[2].PadRight(10, ' ')), 0, byt_send, 65, 10);

                                        }

                                        //20101021改由商品檔直接帶

                                        ////從記憶體取基價 
                                        //string cntsize = getCntsize(strData.Substring(28, 7).Trim());

                                        //if (strReturn[3] != "")
                                        //{
                                        //    Array.Copy(Encoding.Default.GetBytes(String.Format("{0:000000000000.000000}", decimal.Parse(strReturn[3])).Replace(".", "")), 0, byt_send, buffer.Length - 2 + 27, 18);

                                        //}
                                        //else
                                        //{
                                        //    Array.Copy(Encoding.Default.GetBytes("000000000000000000"), 0, byt_send, buffer.Length - 2 + 27, 18);
                                        //}
                                        //object Matchprpice = null;
                                        //if (!Properties.Settings.Default.VIPVersion)
                                        //{
                                        //    strWriteData += "BeginQuery:" + DateTime.Now.ToString("HH:mm:ss.fff");
                                        //    Matchprpice = getMatchPrice(productId);
                                        //    strWriteData += "EndQuery:" + DateTime.Now.ToString("HH:mm:ss.fff") + "\n";
                                        //}
                                        //if (Matchprpice != null)
                                        //{
                                        //    Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(Matchprpice.ToString())).Replace(".", "")), 0, byt_send, buffer.Length + 18 - 2 + 27, 9);
                                        //}
                                        //else
                                        //{
                                        //    //如果沒有成交價抓結算價
                                        //    if (closeprice != "")
                                        //    {
                                        //        Array.Copy(Encoding.Default.GetBytes(String.Format("{0:00000.0000}", decimal.Parse(closeprice.ToString())).Replace(".", "")), 0, byt_send, buffer.Length + 18 - 2 + 27, 9);
                                        //    }
                                        //    else
                                        //    {
                                        //        Array.Copy(Encoding.Default.GetBytes("000000000"), 0, byt_send, buffer.Length + 18 - 2 + 27, 9);
                                        //    }

                                        //}
                                    }
                                    Array.Copy(Encoding.Default.GetBytes(strData.Substring(28, 7).Trim().PadRight(7, ' ')), 0, byt_send, buffer.Length + 27 - 2, 7);

                                }
                                catch (Exception ex)
                                {
                                    mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                                    byt_send = new byte[262];
                                    strhead = "15";
                                    Array.Copy(Encoding.Default.GetBytes("W" + seq + "                                         000000000000000000000000000000000000000000+0000.000+000.0000+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00000000000000000000000000000+00000000000000       "), 0, byt_send, 0, 260);


                                }
                                byt_send.SetValue(buffer[buffer.Length - 2], byt_send.Length - 2);
                                byt_send.SetValue(buffer[buffer.Length - 1], byt_send.Length - 1);
                                if (ip != "N")
                                {
                                    lock (mobj_ReplyClientCollection)
                                    {
                                        mobj_ReplyClientCollection[ip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                    }
                                }
                                else
                                {
                                    lock (mobj_WebClientCollection)
                                    {
                                        mobj_WebClientCollection[queryip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                    }
                                }

                                strWriteData += DateTime.Now.ToString("HH:mm:ss.fff") + "組好傳送:" + Encoding.Default.GetString(byt_send);
                            }
                        #endregion
                            else
                            {
                                string strhead = "14";
                                byte[] byt_send = null;
                                try
                                {
                                    byt_send = new byte[buffer.Length + 27];

                                    Array.Copy(buffer, 0, byt_send, 0, 1);
                                    Array.Copy(Encoding.Default.GetBytes(seq), 0, byt_send, 1, 27);
                                    Array.Copy(buffer, 1, byt_send, 28, buffer.Length - 1);
                                }
                                catch (Exception ex)
                                {
                                    mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                                    if (buffer[0] == 0x53)//當日損益
                                    {
                                        byt_send = new byte[136];
                                        strhead = "15";
                                        Array.Copy(Encoding.Default.GetBytes("S" + seq + "                          +000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00"), 0, byt_send, 0, 134);
                                        byt_send.SetValue(buffer[buffer.Length - 2], byt_send.Length - 2);
                                        byt_send.SetValue(buffer[buffer.Length - 1], byt_send.Length - 1);
                                    }
                                    else if (buffer[0] == 0x51)//保證金
                                    {
                                        byt_send = new byte[482 + 32 + 16];
                                        strhead = "15";
                                        Array.Copy(Encoding.Default.GetBytes("Q" + seq + "                                    +00000.0000+000000000000.00+000000000000.00+000000000000.00+000000000000.00-000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+0000000.0000+0000000.0000+0000000.0000+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00+000000000000.00              "), 0, byt_send, 0, 480 + 32 + 16);
                                        byt_send.SetValue(buffer[buffer.Length - 2], byt_send.Length - 2);
                                        byt_send.SetValue(buffer[buffer.Length - 1], byt_send.Length - 1);

                                    }
                                    else if (buffer[0] == 0x59)//組合即時部位
                                    {
                                        byt_send = new byte[152];
                                        strhead = "15";
                                        Array.Copy(Encoding.Default.GetBytes("Y" + seq + "                                                            000000              000000000000000000000000000000000000000000"), 0, byt_send, 0, 150);
                                        byt_send.SetValue(buffer[buffer.Length - 2], byt_send.Length - 2);
                                        byt_send.SetValue(buffer[buffer.Length - 1], byt_send.Length - 1);

                                    }
                                    else if (buffer[0] == 0x62)//拆組
                                    {
                                        byt_send = new byte[47];
                                        strhead = "15";
                                        Array.Copy(Encoding.Default.GetBytes("b" + seq + "        00000000  "), 0, byt_send, 0, 46);
                                        byt_send.SetValue(buffer[buffer.Length - 1], byt_send.Length - 1);

                                    }
                                    else if (buffer[0] == 0x65)//了結
                                    {
                                        byt_send = new byte[47];
                                        strhead = "15";
                                        Array.Copy(Encoding.Default.GetBytes("e" + seq + "        00000000  "), 0, byt_send, 0, 46);
                                        byt_send.SetValue(buffer[buffer.Length - 1], byt_send.Length - 1);

                                    }
                                    else if (buffer[0] == 0x23)//出入金查詢
                                    {
                                        strhead = "15";
                                    }
                                    else if (buffer[0] == 0x24)//出入金申請
                                    {
                                        strhead = "15";
                                    }
                                    else if (buffer[0] == 0x59)//彙總查詢
                                    {
                                        strhead = "15";
                                    }
                                    else if (buffer[0] == 0x60) //高風險查詢 //V1.0.0.19 added by peter on 20151202
                                    {
                                        strhead = "15";
                                    }
                                    else if (buffer[0] == 0x63)   //高風險查詢低於25% //V1.0.0.23 added by peter on 20170110
                                    {
                                        strhead = "15";
                                    }
                                }

                                if (ip != "N")
                                {
                                    lock (mobj_ReplyClientCollection)
                                    {
                                        mobj_ReplyClientCollection[ip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                    }
                                }
                                else
                                {
                                    lock (mobj_WebClientCollection)
                                    {
                                        mobj_WebClientCollection[queryip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                                    }
                                }
                                //mobj_dataAgentLog.WriteEntryData("組好傳送:" + Encoding.Default.GetString(buffer));
                                strWriteData += DateTime.Now.ToString("HH:mm:ss.fff") + "組好傳送:" + Encoding.Default.GetString(byt_send);

                            }
                    }
                }
                catch (Exception ex)
                {
                    mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                }


                //modified by philip 20100507 0x57  0x59 起始末筆判斷不一樣

                if (buffer[0] == 0x62 || buffer[0] == 0x65)
                {
                    if (ip != "N")
                    {
                        lock (mobj_TradeClientCollection)
                        {
                            if (mobj_TradeClientCollection[queryip] != null)
                            {
                                lock (mobj_TradeClientCollection[queryip].mdt_NetWorkIdMappling)
                                {
                                    mobj_TradeClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Find(new object[] { seq, Encoding.Default.GetString(buffer).Substring(13, 4) }).Delete();
                                    if (mobj_TradeClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Count == 0)
                                    {
                                        lock (mobj_SEQMapping)
                                        {
                                            mobj_SEQMapping.Remove(networkid);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                lock (mobj_SEQMapping)
                                {
                                    mobj_SEQMapping.Remove(networkid);
                                }
                            }
                        }
                    }
                    else
                    {
                        lock (mobj_WebClientCollection)
                        {
                            if (mobj_WebClientCollection[queryip] != null)
                            {
                                lock (mobj_WebClientCollection[queryip].mdt_NetWorkIdMappling)
                                {
                                    mobj_WebClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Find(new object[] { seq, Encoding.Default.GetString(buffer).Substring(13, 4) }).Delete();
                                    if (mobj_WebClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Count == 0)
                                    {
                                        lock (mobj_SEQMapping)
                                        {
                                            mobj_SEQMapping.Remove(networkid);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                lock (mobj_SEQMapping)
                                {
                                    mobj_SEQMapping.Remove(networkid);
                                }
                            }
                        }
                    }

                }
                else if (buffer[0] == 0x13)
                {
                    if (buffer[buffer.Length - 1] == 0x0a || buffer[buffer.Length - 1] == 0x0d)
                    {
                        lock (mobj_SEQMapping)
                        {
                            mobj_SEQMapping.Remove(networkid);
                        }
                    }
                }
                else if (buffer[0] == 0x23 || buffer[0] == 0x22 || buffer[0] == 0x59 || buffer[0] == 0x60 || buffer[0] == 0x63)
                {
                }
                else
                {
                    if (buffer[buffer.Length - 2] == 0x31 || buffer[buffer.Length - 2] == 0x39)
                    {
                        lock (mobj_SEQMapping)
                        {
                            mobj_SEQMapping.Remove(networkid);
                        }
                    }
                }




                mobj_dataAgentLog.WriteEntryData(seq + strWriteData + ip);
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }
        void _RI_Error(string msg)
        {
            mobj_dataAgentLog.WriteEntryData("RI_Error Error:" + msg);
        }



        //added by peter V1.0.0.4
        void _RI_ReceiveFor2(ReceivedAccountAcion Action, byte[] b)
        {
            try
            {

                mobj_dataAgentLog.WriteEntryData("_RI_ReceiveFor2 start ");
                string strData = Encoding.Default.GetString(b);
                string strWriteData = DateTime.Now.ToString("HH:mm:ss.fff") + "原始接收:" + strData + "\n";

                string networkid = ASCIIEncoding.ASCII.GetString(b, 6, 8).ToString().PadLeft(8, '0');
                string SEQNO = ASCIIEncoding.ASCII.GetString(b, 18, 4);
                string ip = "";
                string queryip = "";
                string strhead = "14";

                string seq = "";
                byte[] byt_send = null;
                mobj_dataAgentLog.WriteEntryData(networkid + SEQNO + strData);
                lock (mobj_SEQMapping)
                {

                    if (mobj_SEQMapping.ContainsKey(networkid))
                    {

                        seq = mobj_SEQMapping[networkid][0];

                        queryip = mobj_SEQMapping[networkid][1];

                    }
                }

                //1	頭碼	head	X(1)	0x0e
                //2	長度	length	9(4)	
                //3	資料格式	FCODE	X(1)	0x65     ASCII 101
                //4	批號	ADJNO	X(8)	
                //5	總筆數	COUNT	9(4)	
                //6	流水號	SEQNO	9(4)	
                //7	狀態碼	STATUS	X(2) 	成功:00,失敗 :99
                //8	EOR	EOR	X(1)	0x0a
                byt_send = new byte[19 + 27];
                Array.Copy(b, 5, byt_send, 0, 1);
                Array.Copy(Encoding.Default.GetBytes(seq), 0, byt_send, 1, 27);
                Array.Copy(b, 6, byt_send, 28, 18);

                //用查詢IP去找回應的IP
                ip = getmappingIp(queryip);
                mobj_dataAgentLog.WriteEntryData(networkid + ":" + ip + ":" + queryip + ":" + seq);
                try
                {
                    if (ip != "")
                    {
                        if (ip != "N")
                        {
                            lock (mobj_ReplyClientCollection)
                            {
                                mobj_ReplyClientCollection[ip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                            }
                        }
                        else
                        {
                            lock (mobj_WebClientCollection)
                            {
                                mobj_WebClientCollection[queryip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                            }
                        }
                        //mobj_dataAgentLog.WriteEntryData("組好傳送:" + Encoding.Default.GetString(buffer));
                        strWriteData += DateTime.Now.ToString("HH:mm:ss.fff") + "組好傳送:" + Encoding.Default.GetString(byt_send);


                    }
                }
                catch (Exception ex)
                {
                    mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                }



                if (b[5] == 0x62 || b[5] == 0x65)
                {
                    //if (ip != "N")
                    //{
                    //    lock (mobj_TradeClientCollection)
                    //    {
                    //        if (mobj_TradeClientCollection[queryip] != null)
                    //        {
                    //            lock (mobj_TradeClientCollection[queryip].mdt_NetWorkIdMappling)
                    //            {
                    //                mobj_TradeClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Find(new object[] { seq, SEQNO }).Delete();
                    //                if (mobj_TradeClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Count == 0)
                    //                {
                    //                    lock (mobj_SEQMapping)
                    //                    {
                    //                        mobj_SEQMapping.Remove(networkid);
                    //                    }
                    //                }
                    //            }
                    //        }
                    //        else
                    //        {
                    //            lock (mobj_SEQMapping)
                    //            {
                    //                mobj_SEQMapping.Remove(networkid);
                    //            }
                    //        }
                    //    }
                    //}
                    //else
                    //{
                    //    lock (mobj_WebClientCollection)
                    //    {
                    //        if (mobj_WebClientCollection[queryip] != null)
                    //        {
                    //            lock (mobj_WebClientCollection[queryip].mdt_NetWorkIdMappling)
                    //            {
                    //                mobj_WebClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Find(new object[] { seq, SEQNO }).Delete();
                    //                if (mobj_WebClientCollection[queryip].mdt_NetWorkIdMappling.Rows.Count == 0)
                    //                {
                    //                    lock (mobj_SEQMapping)
                    //                    {
                    //                        mobj_SEQMapping.Remove(networkid);
                    //                    }
                    //                }
                    //            }
                    //        }
                    //        else
                    //        {
                    //            lock (mobj_SEQMapping)
                    //            {
                    //                mobj_SEQMapping.Remove(networkid);
                    //            }
                    //        }
                    //    }
                    //}

                }


                mobj_dataAgentLog.WriteEntryData(seq + strWriteData + ip);
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }

        void _AS400Client_connectedFor2(System.Net.Sockets.Socket s)
        {
            displayPicStatus("AS400ClientFor2", "Connected");
            displayStatusMsg("AS400ClientFor2 Connected ");
        }
        //added by peter V1.0.0.4
        void _AS400Client_ReceivedFor2(System.Net.Sockets.Socket s, byte[] buffer)
        {
            try
            {
                byte[] raw = new byte[256];
                raw = ReceiveRawBuffer(256, s);
                mobj_AS400ClientLogRcvFor2.WriteEntryData(ASCIIEncoding.ASCII.GetString(raw));
            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
                //mobj_dataAgentLog.WriteEntryData("_AS400Client_Received Error:" + ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }

        }
        //added by peter V1.0.0.4
        void _AS400Client_DisconnectedFor2()
        {
            displayPicStatus("AS400ClientFor2", "Disconnected");
            displayStatusMsg("AS400ClientFor2 Disconnected ");
        }
        //added by peter V1.0.0.4
        void _AS400Client_SendedFor2(byte[] buffer)
        {
            mobj_AS400ClientLogSendFor2.WriteEntryData(ASCIIEncoding.ASCII.GetString(buffer));
        }
        //added by peter V1.0.0.4
        void _AS400Client_ErrorFor2(string msg)
        {
            mobj_AS400ClientLogErrorFor2.WriteEntryData(msg);
        }

        //added by peter V1.0.0.4
        void _AS400ReplyServer_connectedFor2(System.Net.Sockets.Socket s)
        {

            displayStatusMsg("AS400ReplyFor2 " + s.RemoteEndPoint.ToString() + "登入");
            mobj_AS400ServerReplyLogRcvFor2.WriteEntryData("AS400ReplyFor2 " + s.RemoteEndPoint.ToString() + "登入");



        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_DisconnectedFor2(Socket s)
        {
            displayStatusMsg("AS400ReplyFor2 " + s.RemoteEndPoint.ToString() + "離開");
            mobj_AS400ServerReplyLogRcvFor2.WriteEntryData("AS400ReplyFor2 " + s.RemoteEndPoint.ToString() + "離開");

        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_ActivedFor2()
        {
            if (_AS400ReplyServerFor2.Active)
            {
                displayPicStatus("AS400ServerFor2", "Connected");
                displayStatusMsg("AS400ServerFor2 Server Start!");

            }
            else
            {
                displayPicStatus("AS400ServerFor2", "Disconnected");
                displayStatusMsg("AS400ServerFor2 Server stop!");

            }
        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_SendedFor2(byte[] buffer)
        {
            mobj_AS400ServerReplyLogSendFor2.WriteEntryData(ASCIIEncoding.ASCII.GetString(buffer));
        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_ReceivedFor2(System.Net.Sockets.Socket s, byte[] buffer)
        {
            // 
            try
            {

                byte[] raw = new byte[256];

                raw = ReceiveRawBuffer(raw.Length, s);



                mobj_AS400ServerReplyLogRcvFor2.WriteEntryData(ASCIIEncoding.Default.GetString(raw).Trim());

                //20130729 Added by peter
                if (_AS400For2Ack)
                    _AS400ReplyServerFor2.Send(s, raw);


                _RI.ResolveReceiveFor2(raw);


            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
            }
        }

        void _AS400ReplyServer_ErrorFor2(string msg)
        {

            mobj_AS400ServerReplyLogErrorFor2.WriteEntryData(msg);
            //_LM.WriteLog("AS400ServerReplyLogError", msg);
            //_DisplayItem.displayStatusMsg("AS400ServerReply  " + msg);

        }


        //added by peter V1.0.0.11 出入金
        void _RI_ReceiveFor3(ReceivedAccountAcion Action, byte[] b)
        {
            try
            {

                mobj_dataAgentLog.WriteEntryData("_RI_ReceiveFor3 start ");
                byte[] tmp = new byte[256];
                Array.Copy(b, 4, tmp, 0, 255);


                AccountSockClientParserFunction.PSGRESPONSEWITHDRAW PSGRESPONSEWITHDRAW = new AccountSockClientParserFunction.PSGRESPONSEWITHDRAW();
                AccountSockClientParserFunction.ByteArrayToPSGRESPONSEWITHDRAWStructure(tmp, ref PSGRESPONSEWITHDRAW);

                /*1.出金申請    2.取消
3.國內外互轉申請
4.出金申請(全出)
5.換匯申請(國外期貨only)*/



                if (new string(PSGRESPONSEWITHDRAW.TYPE) == "2") // 取消
                {


                    SaveDB.UpdateWITHDRAWItemDelForReply item = new SaveDB.UpdateWITHDRAWItemDelForReply();

                    item.SEQNO = new string(PSGRESPONSEWITHDRAW.SEQNO);
                    item.TYPE = new string(PSGRESPONSEWITHDRAW.TYPE);
                    item.COMPANY = new string(PSGRESPONSEWITHDRAW.COMPANY);
                    item.ACTNO = new string(PSGRESPONSEWITHDRAW.ACTNO);

                    item.OPDATE = new string(PSGRESPONSEWITHDRAW.MDATE);

                    item.OPTIME = new string(PSGRESPONSEWITHDRAW.MTIME);



                    item.CODE = new string(PSGRESPONSEWITHDRAW.CODE);

                    mobj_SaveDB.PutData2Queue(item);
                }
                else
                {
                    SaveDB.UpdateWITHDRAWItem item = new SaveDB.UpdateWITHDRAWItem();



                    string MAXAMOUNT = new string(PSGRESPONSEWITHDRAW.MAXAMOUNT);
                    MAXAMOUNT = MAXAMOUNT.Substring(0, 12) + "." + MAXAMOUNT.Substring(12, 2).ToString();

                    string NETVALUE = new string(PSGRESPONSEWITHDRAW.NETVALUE);
                    NETVALUE = NETVALUE.Substring(0, 12) + "." + NETVALUE.Substring(12, 2).ToString();


                    string IAMT = new string(PSGRESPONSEWITHDRAW.IAMT);
                    IAMT = IAMT.Substring(0, 12) + "." + IAMT.Substring(12, 2).ToString();

                    string CASHOUT = new string(PSGRESPONSEWITHDRAW.RAMT);
                    CASHOUT = CASHOUT.Substring(0, 12) + "." + CASHOUT.Substring(12, 2).ToString();


                    item.SEQNO = new string(PSGRESPONSEWITHDRAW.SEQNO);

                    item.COMPANY = new string(PSGRESPONSEWITHDRAW.COMPANY);
                    item.ACTNO = new string(PSGRESPONSEWITHDRAW.ACTNO);

                    item.MAXAMOUNT = MAXAMOUNT;

                    item.NETVALUE = (new string(PSGRESPONSEWITHDRAW.SNETVALUE)) == "-" ? "-" : "" + NETVALUE;

                    item.IAMT = IAMT;
                    item.CASHOUT = CASHOUT;

                    item.OUTNO = new string(PSGRESPONSEWITHDRAW.OUTNO);
                    item.INNO = new string(PSGRESPONSEWITHDRAW.TONO);
                    item.OPDATE = new string(PSGRESPONSEWITHDRAW.MDATE);
                    item.CODE = new string(PSGRESPONSEWITHDRAW.CODE);

                    item.OPTIME = new string(PSGRESPONSEWITHDRAW.MTIME);




                    mobj_SaveDB.PutData2Queue(item);
                }


                string strData = Encoding.Default.GetString(b);
                string strWriteData = DateTime.Now.ToString("HH:mm:ss.fff") + "原始接收:" + strData + "\n";

                string networkid = ASCIIEncoding.ASCII.GetString(b, 7, 9).ToString().PadLeft(9, '0');

                string ip = "";
                string queryip = "";
                string strhead = "14";

                string seq = "";
                seq = seq.PadRight(27, ' ');
                byte[] byt_send = null;
                mobj_dataAgentLog.WriteEntryData(networkid + strData);
                lock (mobj_SEQMapping)
                {

                    if (mobj_SEQMapping.ContainsKey(networkid))
                    {

                        seq = mobj_SEQMapping[networkid][0];

                        queryip = mobj_SEQMapping[networkid][1];

                        mobj_SEQMapping.Remove(networkid);

                    }
                }

                //1	頭碼	head	X(1)	0x0e
                //2	長度	length	9(4)	
                //3	資料格式	FCODE	X(1)	0x65     ASCII 101
                //4	批號	ADJNO	X(8)	
                //5	總筆數	COUNT	9(4)	
                //6	流水號	SEQNO	9(4)	
                //7	狀態碼	STATUS	X(2) 	成功:00,失敗 :99
                //8	EOR	EOR	X(1)	0x0a
                byt_send = new byte[254 + 27];
                Array.Copy(b, 5, byt_send, 0, 1);
                Array.Copy(Encoding.Default.GetBytes(seq), 0, byt_send, 1, 27);
                Array.Copy(b, 6, byt_send, 28, 253);

                //用查詢IP去找回應的IP
                ip = getmappingIp(queryip);
                mobj_dataAgentLog.WriteEntryData(networkid + ":" + ip + ":" + queryip + ":" + seq);
                try
                {
                    if (ip != "")
                    {
                        if (ip != "N")
                        {
                            lock (mobj_ReplyClientCollection)
                            {
                                mobj_ReplyClientCollection[ip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                            }
                        }
                        else
                        {
                            lock (mobj_WebClientCollection)
                            {
                                mobj_WebClientCollection[queryip].PutData2Queue(strhead + Encoding.Default.GetString(byt_send));
                            }
                        }
                        //mobj_dataAgentLog.WriteEntryData("組好傳送:" + Encoding.Default.GetString(buffer));
                        strWriteData += DateTime.Now.ToString("HH:mm:ss.fff") + "組好傳送:" + Encoding.Default.GetString(byt_send);


                    }
                }
                catch (Exception ex)
                {
                    mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
                }




                mobj_dataAgentLog.WriteEntryData(seq + strWriteData + ip);
            }
            catch (Exception ex)
            {
                mobj_dataAgentLog.WriteEntryData("SendData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }

        //added by peter V1.0.0.11 出入金
        void _AS400Client_connectedFor3(System.Net.Sockets.Socket s)
        {
            displayPicStatus("AS400ClientFor3", "Connected");
            displayStatusMsg("AS400ClientFor3 Connected ");
        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_ReceivedFor3(System.Net.Sockets.Socket s, byte[] buffer)
        {
            try
            {
                byte[] raw = new byte[256];
                raw = ReceiveRawBuffer(256, s);
                mobj_AS400ClientLogRcvFor3.WriteEntryData(ASCIIEncoding.Default.GetString(raw));


            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
                //mobj_dataAgentLog.WriteEntryData("_AS400Client_Received Error:" + ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }

        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_DisconnectedFor3()
        {
            displayPicStatus("AS400ClientFor3", "Disconnected");
            displayStatusMsg("AS400ClientFor3 Disconnected ");
        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_SendedFor3(byte[] buffer)
        {
            mobj_AS400ClientLogSendFor3.WriteEntryData(ASCIIEncoding.ASCII.GetString(buffer));
        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_ErrorFor3(string msg)
        {
            mobj_AS400ClientLogErrorFor3.WriteEntryData(msg);
        }

        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_connectedFor3(System.Net.Sockets.Socket s)
        {

            displayStatusMsg("AS400ReplyFor3 " + s.RemoteEndPoint.ToString() + "登入");
            mobj_AS400ServerReplyLogRcvFor3.WriteEntryData("AS400ReplyFor3 " + s.RemoteEndPoint.ToString() + "登入");



        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_DisconnectedFor3(Socket s)
        {
            displayStatusMsg("AS400ReplyFor3 " + s.RemoteEndPoint.ToString() + "離開");
            mobj_AS400ServerReplyLogRcvFor3.WriteEntryData("AS400ReplyFor3 " + s.RemoteEndPoint.ToString() + "離開");

        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_ActivedFor3()
        {
            if (_AS400ReplyServerFor3.Active)
            {
                displayPicStatus("AS400ServerFor3", "Connected");
                displayStatusMsg("AS400ServerFor3 Server Start!");

            }
            else
            {
                displayPicStatus("AS400ServerFor3", "Disconnected");
                displayStatusMsg("AS400ServerFor3 Server stop!");

            }
        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_SendedFor3(byte[] buffer)
        {
            mobj_AS400ServerReplyLogSendFor3.WriteEntryData(ASCIIEncoding.ASCII.GetString(buffer));
        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_ReceivedFor3(System.Net.Sockets.Socket s, byte[] buffer)
        {
            // 
            try
            {

                byte[] raw = new byte[256];

                raw = ReceiveRawBuffer(raw.Length, s);



                mobj_AS400ServerReplyLogRcvFor3.WriteEntryData(ASCIIEncoding.Default.GetString(raw).Trim());

                //20130729 Added by peter
                if (_AS400For3Ack)
                    _AS400ReplyServerFor3.Send(s, raw);


                _RI.ResolveReceiveFor3(raw);


            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
            }
        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_ErrorFor3(string msg)
        {

            mobj_AS400ServerReplyLogErrorFor3.WriteEntryData(msg);
            //_LM.WriteLog("AS400ServerReplyLogError", msg);
            //_DisplayItem.displayStatusMsg("AS400ServerReply  " + msg);

        }


        #endregion


        public byte[] ReceiveRawBuffer(int Size, Socket RcvS)
        {
            try
            {
                int total = 0;
                int RcvLength = 0;
                byte[] RcvBuffer = new byte[Size];

                total += RcvS.Receive(RcvBuffer, 0, RcvBuffer.Length, System.Net.Sockets.SocketFlags.None);
                if (total > 0)
                {
                    while (total != RcvBuffer.Length)
                    {
                        total += RcvLength = RcvS.Receive(RcvBuffer, total, RcvBuffer.Length - total, SocketFlags.None);
                        if (RcvLength > 0)
                            continue;
                        else
                            throw new Exception("remote disconnected");
                    }
                }
                else
                    throw new Exception("remote disconnected");
                return RcvBuffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public class ProductInfo
        {

            private string m_ProductClass = "";

            public string ProductClass
            {
                get { return m_ProductClass; }
                set { m_ProductClass = value; }
            }
            private string m_ProductShortDsc = "";

            public string ProductShortDsc
            {
                get { return m_ProductShortDsc; }
                set { m_ProductShortDsc = value; }
            }
            private string m_ProductId = "";

            public string ProductId
            {
                get { return m_ProductId; }
                set { m_ProductId = value; }
            }
            private string m_Period = "";

            public string Period
            {
                get { return m_Period; }
                set { m_Period = value; }
            }
            private string m_Cp = "";

            public string Cp
            {
                get { return m_Cp; }
                set { m_Cp = value; }
            }

            public string CPFullName
            {
                get
                {

                    if (m_Cp.Length > 0)
                        return m_Cp.ToLower() == "c" ? "Call" : "Put";
                    else
                        return "";
                }
            }
            private string m_Strike = "";

            public string Strike
            {
                get { return m_Strike; }
                set { m_Strike = value; }
            }


            private string m_ProductClass2 = "";

            public string ProductClass2
            {
                get { return m_ProductClass2; }
                set { m_ProductClass2 = value; }
            }
            private string m_ProductShortDsc2 = "";

            public string ProductShortDsc2
            {
                get { return m_ProductShortDsc2; }
                set { m_ProductShortDsc2 = value; }
            }
            private string m_ProductId2 = "";

            public string ProductId2
            {
                get { return m_ProductId2; }
                set { m_ProductId2 = value; }
            }
            private string m_Period2 = "";

            public string Period2
            {
                get { return m_Period2; }
                set { m_Period2 = value; }
            }
            private string m_Cp2 = "";

            public string Cp2
            {
                get { return m_Cp2; }
                set { m_Cp2 = value; }
            }

            public string CPFullName2
            {
                get
                {

                    if (m_Cp2.Length > 0)
                        return m_Cp2.ToLower() == "c" ? "Call" : "Put";
                    else
                        return "";
                }
            }
            private string m_Strike2 = "";

            public string Strike2
            {
                get { return m_Strike2; }
                set { m_Strike2 = value; }
            }
            private string m_ProductName = "";

            public string ProductName
            {
                get { return m_ProductName; }
                set { m_ProductName = value; }
            }
            private string m_ProductKind;
            public string ProductKind
            {
                get { return m_ProductKind; }
                set { m_ProductKind = value; }
            }
            private int m_MultipleKind;
            public int MultipleKind
            {
                get { return m_MultipleKind; }
                set { m_MultipleKind = value; }
            }
        }
        public ProductInfo getProductInfoByProductId(string ProductId)
        {

            ProductInfo item = new ProductInfo();

            string CommodityId = ProductId.Trim();
            item.ProductId = CommodityId;
            item.MultipleKind = -1;//V1.0.0.36
            if (CommodityId.Length == 5)
            {

                DataRow[] drs = mdt_FutureData.Select("Commodity_Id='" + CommodityId + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();
                    item.ProductName = drs[0]["Class_Description"].ToString() + "-" + drs[0]["Settlement_month"].ToString();
                }
                item.ProductKind = "1";

            }
            else if (CommodityId.Length == 10)
            {
                DataRow[] drs = mdt_OptionData.Select("Commodity_Id='" + CommodityId + "'");
                if (drs.Length > 0)
                {

                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();
                    item.Cp = drs[0]["CP"].ToString();
                    item.Strike = String.Format("{0:#0.###}", decimal.Parse(drs[0]["strike_price"].ToString()));

                    item.ProductName = drs[0]["Class_Description"].ToString() + "-" + drs[0]["Settlement_month"].ToString() + "-" + item.Strike + "-" + item.Cp;
                }
                item.ProductKind = "2";
            }
            else if (CommodityId.Length == 8)//期貨價差
            {
                string class_name = CommodityId.Substring(0, 3);


                DataRow[] drs = mdt_FutureData.Select("Class_Name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();

                    item.ProductClass2 = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString();

                }

                string period1 = CommodityId.Substring(3, 2);
                string period2 = CommodityId.Substring(6, 2);

                item.MultipleKind = 0;//V1.0.0.36

                item.ProductName = item.ProductShortDsc + item.Period + "/" + item.Period2;
                item.ProductKind = "4";

            }
            //20130627V1.0.0.32 小台短天 added by peter;
            else if (CommodityId.Length == 11)//期貨價差
            {
                string class_name = CommodityId.Substring(0, 3);
                string class_name2 = CommodityId.Substring(6, 3);


                DataRow[] drs = mdt_FutureData.Select("Class_Name='" + class_name + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();

                    item.ProductClass2 = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString();

                }

                drs = mdt_FutureData.Select("Class_Name='" + class_name2 + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass2 = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString();
                    item.Period2 = drs[0]["Settlement_month"].ToString();
                }

                string period1 = CommodityId.Substring(3, 2);
                string period2 = CommodityId.Substring(9, 2);

                item.MultipleKind = 0;//V1.0.0.36

                item.ProductName = item.ProductShortDsc + item.Period + "/" + item.ProductShortDsc2 + item.Period2;
                item.ProductKind = "4";

            }
            else if (CommodityId.Length == 16 && CommodityId.Substring(8, 1) == "/")//價格價差
            {

                string period1 = CommodityId.Substring(14, 2);
                string period2 = period1;
                string Price1 = CommodityId.Substring(3, 5);
                string Price2 = CommodityId.Substring(9, 5);

                DataRow[] drs = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {

                    item.ProductClass = drs[0]["Class_Name"].ToString().Trim();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString().Trim();
                    item.ProductClass2 = drs[0]["Class_Name"].ToString().Trim();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString().Trim();

                }


                item.ProductName = item.ProductShortDsc + item.Strike + "/" + item.Strike2 + item.Cp + item.Period;
                item.ProductKind = "3";
                item.MultipleKind = 1;
            }
            else if (CommodityId.Length == 13 || (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/"))//時間價差、跨式、逆轉換
            {
                string Type = CommodityId.Substring(10, 1);
                string period1 = CommodityId.Substring(8, 2);
                string period2 = CommodityId.Substring(11, 2);
                if (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/")
                {
                    period2 = CommodityId.Substring(14, 2);
                }
                string Price1 = CommodityId.Substring(3, 5);
                string Price2 = Price1;



                DataRow[] drs = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {


                    item.ProductClass = CommodityId.Substring(0, 3);// drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString().Trim();
                    item.ProductClass2 = CommodityId.Substring(0, 3);// drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString().Trim();
                    ;

                }




                if (Type == "/")
                {
                    if (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/")
                    {

                        DataRow[] drfind = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(11, 3) + "'");
                        if (drs.Length > 0)
                        {
                            item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + item.Period + Type + drfind[0]["Class_Description"].ToString().Trim() + item.Period2;
                            item.ProductClass2 = CommodityId.Substring(11, 3);
                            item.ProductShortDsc2 = drfind[0]["Class_Description"].ToString().Trim();
                        }
                    }
                    else
                    {
                        item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + item.Period + Type + item.Period2;
                        //item.ProductClass2 = CommodityId.Substring(11, 3);

                    }
                    item.MultipleKind = 2;
                }
                else
                {
                    item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + Type + item.Cp2 + item.Period;
                    if (Type == ":")
                    {
                        item.MultipleKind = 3;

                    }
                    else { item.MultipleKind = 5; }
                }
                item.ProductKind = "3";
            }
            else if (CommodityId.Length == 18)// 勒式
            {
                string period1 = CommodityId.Substring(8, 2);
                string period2 = CommodityId.Substring(16, 2);
                string Price1 = CommodityId.Substring(3, 5);
                string Price2 = CommodityId.Substring(11, 5);

                DataRow[] drs = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {


                    item.ProductClass = CommodityId.Substring(0, 3);//  drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString().Trim();
                    item.ProductClass2 = CommodityId.Substring(0, 3);// drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString().Trim();


                }



                item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + ":" + item.Strike2 + item.Cp2 + item.Period2;
                item.ProductKind = "3";
                item.MultipleKind = 4;
            }
            return item;
        }

    }


}