﻿namespace AS400GatewayServer
{
    partial class w_start
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該公開 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(w_start));
            this.listBox_SysMsg = new System.Windows.Forms.ListBox();
            this.lblI080Count = new System.Windows.Forms.Label();
            this.label_start = new System.Windows.Forms.Label();
            this.button_ClearSysLog = new System.Windows.Forms.Button();
            this.label_stop = new System.Windows.Forms.Label();
            this.button_close = new System.Windows.Forms.Button();
            this.tabPage_status = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.picAS400Client3 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.picAS400Server3 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.picAS400Client2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picAS400Server2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnTest = new System.Windows.Forms.Button();
            this.picAS400Client = new System.Windows.Forms.PictureBox();
            this.lblAs400Client = new System.Windows.Forms.Label();
            this.picAPInfo = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.picWeb = new System.Windows.Forms.PictureBox();
            this.picAS400Server = new System.Windows.Forms.PictureBox();
            this.lblAs400Server = new System.Windows.Forms.Label();
            this.picAPOrder = new System.Windows.Forms.PictureBox();
            this.lblAPReply = new System.Windows.Forms.Label();
            this.lblAPOrder = new System.Windows.Forms.Label();
            this.picAPReply = new System.Windows.Forms.PictureBox();
            this.pictureBox_server = new System.Windows.Forms.PictureBox();
            this.pictureBox_paused = new System.Windows.Forms.PictureBox();
            this.pictureBox_running = new System.Windows.Forms.PictureBox();
            this.button_start = new System.Windows.Forms.Button();
            this.button_stop = new System.Windows.Forms.Button();
            this.pictureBox_running1 = new System.Windows.Forms.PictureBox();
            this.tabControl_Status = new System.Windows.Forms.TabControl();
            this.tabPage_connections = new System.Windows.Forms.TabPage();
            this.listConnections = new System.Windows.Forms.ListBox();
            this.tabPage_Settings = new System.Windows.Forms.TabPage();
            this.lblI020Count = new System.Windows.Forms.Label();
            this.timer_running = new System.Windows.Forms.Timer(this.components);
            this.server1 = new Dart.PowerTCP.SslSockets.Server(this.components);
            this.tcp1 = new Dart.PowerTCP.SslSockets.Tcp(this.components);
            this.tabPage_status.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Client3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Server3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Client2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Server2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Client)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAPInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWeb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Server)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAPOrder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAPReply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_server)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_paused)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_running)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_running1)).BeginInit();
            this.tabControl_Status.SuspendLayout();
            this.tabPage_connections.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox_SysMsg
            // 
            this.listBox_SysMsg.BackColor = System.Drawing.Color.Pink;
            this.listBox_SysMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox_SysMsg.ItemHeight = 15;
            this.listBox_SysMsg.Location = new System.Drawing.Point(0, 0);
            this.listBox_SysMsg.Margin = new System.Windows.Forms.Padding(4);
            this.listBox_SysMsg.Name = "listBox_SysMsg";
            this.listBox_SysMsg.Size = new System.Drawing.Size(792, 394);
            this.listBox_SysMsg.TabIndex = 2;
            this.listBox_SysMsg.TabStop = false;
            // 
            // lblI080Count
            // 
            this.lblI080Count.AutoSize = true;
            this.lblI080Count.Location = new System.Drawing.Point(780, 166);
            this.lblI080Count.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblI080Count.Name = "lblI080Count";
            this.lblI080Count.Size = new System.Drawing.Size(0, 15);
            this.lblI080Count.TabIndex = 41;
            this.lblI080Count.Visible = false;
            // 
            // label_start
            // 
            this.label_start.Location = new System.Drawing.Point(589, 41);
            this.label_start.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_start.Name = "label_start";
            this.label_start.Size = new System.Drawing.Size(48, 29);
            this.label_start.TabIndex = 34;
            this.label_start.Text = "啟動";
            // 
            // button_ClearSysLog
            // 
            this.button_ClearSysLog.BackColor = System.Drawing.SystemColors.Control;
            this.button_ClearSysLog.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_ClearSysLog.Location = new System.Drawing.Point(643, 64);
            this.button_ClearSysLog.Margin = new System.Windows.Forms.Padding(4);
            this.button_ClearSysLog.Name = "button_ClearSysLog";
            this.button_ClearSysLog.Size = new System.Drawing.Size(125, 30);
            this.button_ClearSysLog.TabIndex = 39;
            this.button_ClearSysLog.Text = "清除系統訊息";
            this.button_ClearSysLog.UseVisualStyleBackColor = false;
            this.button_ClearSysLog.Click += new System.EventHandler(this.button_ClearSysLog_Click);
            // 
            // label_stop
            // 
            this.label_stop.Location = new System.Drawing.Point(589, 101);
            this.label_stop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_stop.Name = "label_stop";
            this.label_stop.Size = new System.Drawing.Size(48, 29);
            this.label_stop.TabIndex = 36;
            this.label_stop.Text = "中止";
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.SystemColors.Control;
            this.button_close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_close.Location = new System.Drawing.Point(643, 26);
            this.button_close.Margin = new System.Windows.Forms.Padding(4);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(125, 30);
            this.button_close.TabIndex = 29;
            this.button_close.Text = "關閉";
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // tabPage_status
            // 
            this.tabPage_status.Controls.Add(this.listBox_SysMsg);
            this.tabPage_status.Location = new System.Drawing.Point(4, 25);
            this.tabPage_status.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage_status.Name = "tabPage_status";
            this.tabPage_status.Size = new System.Drawing.Size(792, 400);
            this.tabPage_status.TabIndex = 2;
            this.tabPage_status.Text = "系統訊息";
            this.tabPage_status.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.picAS400Client3);
            this.splitContainer1.Panel1.Controls.Add(this.label5);
            this.splitContainer1.Panel1.Controls.Add(this.picAS400Server3);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.picAS400Client2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.picAS400Server2);
            this.splitContainer1.Panel1.Controls.Add(this.label4);
            this.splitContainer1.Panel1.Controls.Add(this.btnTest);
            this.splitContainer1.Panel1.Controls.Add(this.picAS400Client);
            this.splitContainer1.Panel1.Controls.Add(this.lblAs400Client);
            this.splitContainer1.Panel1.Controls.Add(this.picAPInfo);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.button2);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.picWeb);
            this.splitContainer1.Panel1.Controls.Add(this.picAS400Server);
            this.splitContainer1.Panel1.Controls.Add(this.lblAs400Server);
            this.splitContainer1.Panel1.Controls.Add(this.picAPOrder);
            this.splitContainer1.Panel1.Controls.Add(this.lblAPReply);
            this.splitContainer1.Panel1.Controls.Add(this.lblAPOrder);
            this.splitContainer1.Panel1.Controls.Add(this.picAPReply);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox_server);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox_paused);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox_running);
            this.splitContainer1.Panel1.Controls.Add(this.button_start);
            this.splitContainer1.Panel1.Controls.Add(this.lblI080Count);
            this.splitContainer1.Panel1.Controls.Add(this.label_start);
            this.splitContainer1.Panel1.Controls.Add(this.button_stop);
            this.splitContainer1.Panel1.Controls.Add(this.button_ClearSysLog);
            this.splitContainer1.Panel1.Controls.Add(this.label_stop);
            this.splitContainer1.Panel1.Controls.Add(this.button_close);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox_running1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl_Status);
            this.splitContainer1.Size = new System.Drawing.Size(800, 764);
            this.splitContainer1.SplitterDistance = 330;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 47;
            // 
            // picAS400Client3
            // 
            this.picAS400Client3.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAS400Client3.Location = new System.Drawing.Point(271, 219);
            this.picAS400Client3.Margin = new System.Windows.Forms.Padding(4);
            this.picAS400Client3.Name = "picAS400Client3";
            this.picAS400Client3.Size = new System.Drawing.Size(47, 42);
            this.picAS400Client3.TabIndex = 77;
            this.picAS400Client3.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(171, 236);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 15);
            this.label5.TabIndex = 76;
            this.label5.Text = "AS4003連線";
            // 
            // picAS400Server3
            // 
            this.picAS400Server3.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAS400Server3.Location = new System.Drawing.Point(271, 269);
            this.picAS400Server3.Margin = new System.Windows.Forms.Padding(4);
            this.picAS400Server3.Name = "picAS400Server3";
            this.picAS400Server3.Size = new System.Drawing.Size(47, 42);
            this.picAS400Server3.TabIndex = 75;
            this.picAS400Server3.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(171, 286);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 15);
            this.label6.TabIndex = 74;
            this.label6.Text = "AS4003接收";
            // 
            // picAS400Client2
            // 
            this.picAS400Client2.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAS400Client2.Location = new System.Drawing.Point(271, 116);
            this.picAS400Client2.Margin = new System.Windows.Forms.Padding(4);
            this.picAS400Client2.Name = "picAS400Client2";
            this.picAS400Client2.Size = new System.Drawing.Size(47, 42);
            this.picAS400Client2.TabIndex = 73;
            this.picAS400Client2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(171, 134);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 15);
            this.label1.TabIndex = 72;
            this.label1.Text = "AS4002連線";
            // 
            // picAS400Server2
            // 
            this.picAS400Server2.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAS400Server2.Location = new System.Drawing.Point(271, 166);
            this.picAS400Server2.Margin = new System.Windows.Forms.Padding(4);
            this.picAS400Server2.Name = "picAS400Server2";
            this.picAS400Server2.Size = new System.Drawing.Size(47, 42);
            this.picAS400Server2.TabIndex = 71;
            this.picAS400Server2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(171, 184);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 15);
            this.label4.TabIndex = 70;
            this.label4.Text = "AS4002接收";
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(536, 146);
            this.btnTest.Margin = new System.Windows.Forms.Padding(4);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(100, 29);
            this.btnTest.TabIndex = 69;
            this.btnTest.Text = "test";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Visible = false;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // picAS400Client
            // 
            this.picAS400Client.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAS400Client.Location = new System.Drawing.Point(271, 16);
            this.picAS400Client.Margin = new System.Windows.Forms.Padding(4);
            this.picAS400Client.Name = "picAS400Client";
            this.picAS400Client.Size = new System.Drawing.Size(47, 42);
            this.picAS400Client.TabIndex = 68;
            this.picAS400Client.TabStop = false;
            // 
            // lblAs400Client
            // 
            this.lblAs400Client.AutoSize = true;
            this.lblAs400Client.Location = new System.Drawing.Point(171, 34);
            this.lblAs400Client.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAs400Client.Name = "lblAs400Client";
            this.lblAs400Client.Size = new System.Drawing.Size(76, 15);
            this.lblAs400Client.TabIndex = 67;
            this.lblAs400Client.Text = "AS400連線";
            // 
            // picAPInfo
            // 
            this.picAPInfo.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAPInfo.Location = new System.Drawing.Point(457, 166);
            this.picAPInfo.Margin = new System.Windows.Forms.Padding(4);
            this.picAPInfo.Name = "picAPInfo";
            this.picAPInfo.Size = new System.Drawing.Size(47, 42);
            this.picAPInfo.TabIndex = 65;
            this.picAPInfo.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(360, 181);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 64;
            this.label3.Text = "行情接收";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(647, 145);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 29);
            this.button2.TabIndex = 63;
            this.button2.Text = "GC";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(349, 124);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 15);
            this.label2.TabIndex = 62;
            this.label2.Text = "Web傳送連線";
            // 
            // picWeb
            // 
            this.picWeb.Image = ((System.Drawing.Image)(resources.GetObject("picWeb.Image")));
            this.picWeb.Location = new System.Drawing.Point(457, 116);
            this.picWeb.Margin = new System.Windows.Forms.Padding(4);
            this.picWeb.Name = "picWeb";
            this.picWeb.Size = new System.Drawing.Size(47, 42);
            this.picWeb.TabIndex = 61;
            this.picWeb.TabStop = false;
            // 
            // picAS400Server
            // 
            this.picAS400Server.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAS400Server.Location = new System.Drawing.Point(271, 66);
            this.picAS400Server.Margin = new System.Windows.Forms.Padding(4);
            this.picAS400Server.Name = "picAS400Server";
            this.picAS400Server.Size = new System.Drawing.Size(47, 42);
            this.picAS400Server.TabIndex = 59;
            this.picAS400Server.TabStop = false;
            // 
            // lblAs400Server
            // 
            this.lblAs400Server.AutoSize = true;
            this.lblAs400Server.Location = new System.Drawing.Point(171, 84);
            this.lblAs400Server.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAs400Server.Name = "lblAs400Server";
            this.lblAs400Server.Size = new System.Drawing.Size(76, 15);
            this.lblAs400Server.TabIndex = 58;
            this.lblAs400Server.Text = "AS400接收";
            // 
            // picAPOrder
            // 
            this.picAPOrder.Image = global::AS400GatewayServer.Properties.Resources.Disconnected;
            this.picAPOrder.Location = new System.Drawing.Point(457, 16);
            this.picAPOrder.Margin = new System.Windows.Forms.Padding(4);
            this.picAPOrder.Name = "picAPOrder";
            this.picAPOrder.Size = new System.Drawing.Size(47, 42);
            this.picAPOrder.TabIndex = 56;
            this.picAPOrder.TabStop = false;
            // 
            // lblAPReply
            // 
            this.lblAPReply.AutoSize = true;
            this.lblAPReply.Location = new System.Drawing.Point(360, 79);
            this.lblAPReply.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAPReply.Name = "lblAPReply";
            this.lblAPReply.Size = new System.Drawing.Size(85, 15);
            this.lblAPReply.TabIndex = 55;
            this.lblAPReply.Text = "AP傳送連線";
            this.lblAPReply.Click += new System.EventHandler(this.lblAPReply_Click);
            // 
            // lblAPOrder
            // 
            this.lblAPOrder.AutoSize = true;
            this.lblAPOrder.Location = new System.Drawing.Point(357, 34);
            this.lblAPOrder.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAPOrder.Name = "lblAPOrder";
            this.lblAPOrder.Size = new System.Drawing.Size(85, 15);
            this.lblAPOrder.TabIndex = 54;
            this.lblAPOrder.Text = "AP註冊連線";
            // 
            // picAPReply
            // 
            this.picAPReply.Image = ((System.Drawing.Image)(resources.GetObject("picAPReply.Image")));
            this.picAPReply.Location = new System.Drawing.Point(457, 66);
            this.picAPReply.Margin = new System.Windows.Forms.Padding(4);
            this.picAPReply.Name = "picAPReply";
            this.picAPReply.Size = new System.Drawing.Size(47, 42);
            this.picAPReply.TabIndex = 53;
            this.picAPReply.TabStop = false;
            this.picAPReply.Click += new System.EventHandler(this.picAPReply_Click);
            // 
            // pictureBox_server
            // 
            this.pictureBox_server.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_server.Image")));
            this.pictureBox_server.Location = new System.Drawing.Point(16, 26);
            this.pictureBox_server.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_server.Name = "pictureBox_server";
            this.pictureBox_server.Size = new System.Drawing.Size(75, 130);
            this.pictureBox_server.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_server.TabIndex = 30;
            this.pictureBox_server.TabStop = false;
            // 
            // pictureBox_paused
            // 
            this.pictureBox_paused.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_paused.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_paused.Image")));
            this.pictureBox_paused.Location = new System.Drawing.Point(84, 96);
            this.pictureBox_paused.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_paused.Name = "pictureBox_paused";
            this.pictureBox_paused.Size = new System.Drawing.Size(52, 49);
            this.pictureBox_paused.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_paused.TabIndex = 31;
            this.pictureBox_paused.TabStop = false;
            // 
            // pictureBox_running
            // 
            this.pictureBox_running.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_running.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_running.Image")));
            this.pictureBox_running.Location = new System.Drawing.Point(84, 96);
            this.pictureBox_running.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_running.Name = "pictureBox_running";
            this.pictureBox_running.Size = new System.Drawing.Size(52, 49);
            this.pictureBox_running.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_running.TabIndex = 32;
            this.pictureBox_running.TabStop = false;
            this.pictureBox_running.Visible = false;
            // 
            // button_start
            // 
            this.button_start.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_start.Image = ((System.Drawing.Image)(resources.GetObject("button_start.Image")));
            this.button_start.Location = new System.Drawing.Point(536, 26);
            this.button_start.Margin = new System.Windows.Forms.Padding(4);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(48, 45);
            this.button_start.TabIndex = 33;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // button_stop
            // 
            this.button_stop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_stop.Image = ((System.Drawing.Image)(resources.GetObject("button_stop.Image")));
            this.button_stop.Location = new System.Drawing.Point(536, 86);
            this.button_stop.Margin = new System.Windows.Forms.Padding(4);
            this.button_stop.Name = "button_stop";
            this.button_stop.Size = new System.Drawing.Size(48, 45);
            this.button_stop.TabIndex = 35;
            this.button_stop.Click += new System.EventHandler(this.button_stop_Click);
            // 
            // pictureBox_running1
            // 
            this.pictureBox_running1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_running1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_running1.Image")));
            this.pictureBox_running1.Location = new System.Drawing.Point(84, 96);
            this.pictureBox_running1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_running1.Name = "pictureBox_running1";
            this.pictureBox_running1.Size = new System.Drawing.Size(52, 49);
            this.pictureBox_running1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_running1.TabIndex = 37;
            this.pictureBox_running1.TabStop = false;
            this.pictureBox_running1.Visible = false;
            // 
            // tabControl_Status
            // 
            this.tabControl_Status.Controls.Add(this.tabPage_status);
            this.tabControl_Status.Controls.Add(this.tabPage_connections);
            this.tabControl_Status.Controls.Add(this.tabPage_Settings);
            this.tabControl_Status.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_Status.Location = new System.Drawing.Point(0, 0);
            this.tabControl_Status.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl_Status.Name = "tabControl_Status";
            this.tabControl_Status.SelectedIndex = 0;
            this.tabControl_Status.Size = new System.Drawing.Size(800, 429);
            this.tabControl_Status.TabIndex = 38;
            // 
            // tabPage_connections
            // 
            this.tabPage_connections.Controls.Add(this.listConnections);
            this.tabPage_connections.Location = new System.Drawing.Point(4, 25);
            this.tabPage_connections.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage_connections.Name = "tabPage_connections";
            this.tabPage_connections.Size = new System.Drawing.Size(792, 400);
            this.tabPage_connections.TabIndex = 1;
            this.tabPage_connections.Text = "已連線資訊";
            this.tabPage_connections.UseVisualStyleBackColor = true;
            // 
            // listConnections
            // 
            this.listConnections.BackColor = System.Drawing.Color.LightSteelBlue;
            this.listConnections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listConnections.ItemHeight = 15;
            this.listConnections.Location = new System.Drawing.Point(0, 0);
            this.listConnections.Margin = new System.Windows.Forms.Padding(4);
            this.listConnections.Name = "listConnections";
            this.listConnections.Size = new System.Drawing.Size(792, 394);
            this.listConnections.TabIndex = 1;
            this.listConnections.TabStop = false;
            // 
            // tabPage_Settings
            // 
            this.tabPage_Settings.Location = new System.Drawing.Point(4, 25);
            this.tabPage_Settings.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage_Settings.Name = "tabPage_Settings";
            this.tabPage_Settings.Size = new System.Drawing.Size(792, 400);
            this.tabPage_Settings.TabIndex = 3;
            this.tabPage_Settings.Text = "系統設定";
            this.tabPage_Settings.UseVisualStyleBackColor = true;
            // 
            // lblI020Count
            // 
            this.lblI020Count.AutoSize = true;
            this.lblI020Count.Location = new System.Drawing.Point(357, 165);
            this.lblI020Count.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblI020Count.Name = "lblI020Count";
            this.lblI020Count.Size = new System.Drawing.Size(0, 15);
            this.lblI020Count.TabIndex = 46;
            this.lblI020Count.Visible = false;
            // 
            // timer_running
            // 
            this.timer_running.Interval = 1000;
            this.timer_running.Tick += new System.EventHandler(this.timer_running_Tick);
            // 
            // server1
            // 
            this.server1.Certificate = null;
            this.server1.Editor = this.server1;
            this.server1.MaxThreads = 1000;
            // 
            // tcp1
            // 
            this.tcp1.Charset = "big5";
            // 
            // w_start
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 764);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.lblI020Count);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "w_start";
            this.Text = "AS400GatewayServer";
            this.Load += new System.EventHandler(this.w_start_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.w_start_FormClosed);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.w_start_FormClosing);
            this.tabPage_status.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Client3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Server3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Client2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Server2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Client)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAPInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWeb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAS400Server)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAPOrder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAPReply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_server)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_paused)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_running)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_running1)).EndInit();
            this.tabControl_Status.ResumeLayout(false);
            this.tabPage_connections.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_server;
        internal System.Windows.Forms.ListBox listBox_SysMsg;
        private System.Windows.Forms.PictureBox pictureBox_paused;
        private System.Windows.Forms.PictureBox pictureBox_running;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Label lblI080Count;
        private System.Windows.Forms.Label label_start;
        private System.Windows.Forms.Button button_stop;
        private System.Windows.Forms.Button button_ClearSysLog;
        private System.Windows.Forms.Label label_stop;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.TabPage tabPage_status;
        private System.Windows.Forms.SplitContainer splitContainer1;
        protected internal System.Windows.Forms.PictureBox picAPOrder;
        private System.Windows.Forms.Label lblAPReply;
        private System.Windows.Forms.Label lblAPOrder;
        protected internal System.Windows.Forms.PictureBox picAPReply;
        private System.Windows.Forms.PictureBox pictureBox_running1;
        private System.Windows.Forms.TabControl tabControl_Status;
        private System.Windows.Forms.TabPage tabPage_connections;
        internal System.Windows.Forms.ListBox listConnections;
        private System.Windows.Forms.TabPage tabPage_Settings;
        private System.Windows.Forms.Label lblI020Count;
        private System.Windows.Forms.Timer timer_running;
        protected internal System.Windows.Forms.PictureBox picAS400Server;
        private System.Windows.Forms.Label lblAs400Server;
        private System.Windows.Forms.Label label2;
        protected internal System.Windows.Forms.PictureBox picWeb;
        private System.Windows.Forms.Button button2;
        protected internal System.Windows.Forms.PictureBox picAPInfo;
        private System.Windows.Forms.Label label3;
        protected internal System.Windows.Forms.PictureBox picAS400Client;
        private System.Windows.Forms.Label lblAs400Client;
        private System.Windows.Forms.Button btnTest;
        protected internal System.Windows.Forms.PictureBox picAS400Client2;
        private System.Windows.Forms.Label label1;
        protected internal System.Windows.Forms.PictureBox picAS400Server2;
        private System.Windows.Forms.Label label4;
        protected internal System.Windows.Forms.PictureBox picAS400Client3;
        private System.Windows.Forms.Label label5;
        protected internal System.Windows.Forms.PictureBox picAS400Server3;
        private System.Windows.Forms.Label label6;
        private Dart.PowerTCP.SslSockets.Server server1;
        private Dart.PowerTCP.SslSockets.Tcp tcp1;
    }
}

