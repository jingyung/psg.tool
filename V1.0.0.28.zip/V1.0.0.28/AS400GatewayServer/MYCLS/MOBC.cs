﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Timers;
using System.Threading;
using System.Collections;
using BYTE = System.Char;
using WORD = System.Int16;
using DWORD = System.Int32;
using CHANNEL = System.Int16;
using System.ComponentModel;
using System.Windows.Forms;

namespace MOBGatewayServer.MYCLS
{
    public class MOBC
    {

        #region DllImport statements
        // Initialize/Deinitialize function
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern bool mob_initialize(Int32 InQueueSize, Int32 OutQueueSize);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern bool mob_initialize(); //KL:20091008 - default constructor has RecvQueue at 2M and SendQueue at 128K
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern void mob_deinitialize();
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern E_FR mob_connect([MarshalAs(UnmanagedType.LPStr)]String host, Int32 port);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern void mob_disconnect();
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern E_FR mob_login([MarshalAs(UnmanagedType.LPStr)]String account, [MarshalAs(UnmanagedType.LPStr)]String psw, [MarshalAs(UnmanagedType.LPStr)]String group);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_bcsend(UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject, Byte[] data, Int32 dlen);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_bcsendLocal(UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject, Byte[] data, Int32 dlen);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_txsend(UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject, [MarshalAs(UnmanagedType.LPStr)]String alias, Byte[] data, Int32 dlen);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_txsendLocal(UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject, [MarshalAs(UnmanagedType.LPStr)]String alias, Byte[] data, Int32 dlen);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_send(CHANNEL_TYPE ctype, UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject, Byte[] data, Int32 dlen);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_recv(ref CHANNEL_TYPE ctype, ref UInt16 channel, StringBuilder subject, Byte[] buf, Int32 bufsize);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_recvEx(ref CHANNEL_TYPE ctype, ref UInt16 channel, StringBuilder subject, StringBuilder alias, Byte[] buf, Int32 bufsize);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_subscribe(CHANNEL_TYPE ctype, UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_unsubscribe(CHANNEL_TYPE ctype, UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_unsubscribeEx(CHANNEL_TYPE ctype, UInt16 channel, [MarshalAs(UnmanagedType.LPArray)]ArrayList subjects);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_getSendBufFree();
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_getSendBufUsed();
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern void mob_clearSendBuf();
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_getRecvBufFree();
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_getRecvBufUsed();
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern void mob_getMobInfo(MOBINFO[] mobinf);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_sendcmd(UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject, Byte[] data, Int32 dlen);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_subscribecmd(UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject);
        [DllImport("mobapips.dll", SetLastError = true)]
        private static extern int mob_unsubscribecmd(UInt16 channel, [MarshalAs(UnmanagedType.LPStr)]String subject);
        #endregion
        #region mobstructs statements
        public enum E_Define
        {
            UNDEFINED_CHANNEL = 65535,
            UNDEFINED_UID = 65535,

            //msn.h
            MSG_CALL_CONNECTED = 1,
            MSG_INCOMING_CALL = 2,
            MSG_DATA = 3,
            MSG_DATA_ACK = 4,
            MSG_CLEAR_INDICATION = 5,
            MSG_CLEAR_CONFIRM = 6,
            MSG_UNKNOWN_PACKET = 11,
            MSNFLG_D_BIT = 0x01,		// flag of data need to be ack
            MNNFLG_P_BIT = 0x02,		// flag of data was packed
            MAXMSNPKTSIZE = (FR_MAXPKTSIZE - 11),

            //ALL_DATA = "0xFFFF",
            FR_MAXSUBJECTSIZE = 255,
            FR_MAXCHANNEL = 65535,
            FR_MAXPKTSIZE = 1200,
            //FR_MAXSUBJECTNO   = 512,
            FR_MAXSUBJECTNO = 5120,
            FR_MAXALIASSIZE = 32,
            //
            //RECV_QUEUE =(1024*1024), //KL:20091008 - according to F1Net2 MOB API doc, recv queue has a max length of 8MB
            RECV_QUEUE = (1024 * 1024 * 8),
            //SEND_QUEUE =(1024*1024), //KL:20091008 - according to F1Net2 MOB API doc, send queue has a max length of 256K
            SEND_QUEUE = (1024 * 256),
            FR_MAXTXSIZE = (FR_MAXPKTSIZE - 34),
            // channel number
            CNO_SYSTEM = (1024 * 1),
            CNO_COMMAND = (1024 * 1),
            CNO_BROADCAST = (1024 * 8),
            CNO_TRANSACTION = (1024 * 8),
            CNO_SESSION = (1024 * 4),
            CNO_LOCAL = (1024 * 4),
            CNO_PUBLIC = (1024 * 8),
            CNO_USER = (1024 * 8),
            CNO_RESERVED = (1024 * 22),
            // channel type
            CHANNEL_SYSTEM = 0,
            CHANNEL_COMMAND = (CHANNEL_SYSTEM + CNO_SYSTEM),
            CHANNEL_BROADCAST = (CHANNEL_COMMAND + CNO_COMMAND),
            CHANNEL_TRANSACTION = (CHANNEL_BROADCAST + CNO_BROADCAST),
            CHANNEL_SESSION = (CHANNEL_TRANSACTION + CNO_TRANSACTION),
            CHANNEL_LOCAL = (CHANNEL_SESSION + CNO_SESSION),
            CHANNEL_PUBLIC = (CHANNEL_LOCAL + CNO_LOCAL),
            CHANNEL_USER = (CHANNEL_PUBLIC + CNO_PUBLIC),
            CHANNEL_RESERVED = (CHANNEL_USER + CNO_USER),
        };

        public enum E_FR : int
        {
            // Error code definition
            FR_OK = 0,
            FR_NODATA = -1000,
            FR_ERR_SUBJECT_INVALIDED = -1,		// 無效的主題
            FR_ERR_SUBJECT_TOO_LONG = -2,	// 主題太長 ( > 255 )
            FR_ERR_BUFFER_TOO_SMALL = -3,	// 準備的緩衝區太小
            FR_ERR_BUFFER_OVERRUN = -4,	// 資料長度大過緩衝區
            FR_ERR_DATA_TOO_LONG = -5,	// 資料長度過長 ( > 1200 )
            FR_ERR_ACCOUNT = -6,	// 帳號驗證失敗
            FR_ERR_PASSWORD = -7,	// 密碼驗證失敗
            FR_ERR_TIMEOUT = -8,	// 連線動作逾時
            FR_ERR_TCP_WSA = -9,	// TCP連線錯誤。呼叫 WSAGetLastError() 取得錯誤代碼
            FR_ERR_TTL = -10,		// 無效的 TTL (time to live) 值
            FR_ERR_DISCONNECT = -11,		// 連線中斷
            FR_ERR_INVALID_CHANNEL = -12,		// 無效的通道(channel)號碼
            FR_ERR_INVALID_CTYPE = -13,		// 無效的通道(channel)型別
            FR_ERR_ALIAS_TOO_LONG = -14,		// Alias 字串長度太長 ( > 32)
            FR_ERR_SUBJECT_OVER_LIMIT = -15,		// 訂閱主題數目超出最大值 ( > 512)
            FR_ERR_REDIRECT = -16,		// 強制導向至新主機
            FR_ERR_GROUP = -17,		// 群組名稱錯誤
            FR_ERR_UNAUTHORIZED = -18,		// 未登入取得授權
            FR_ERR_MULTIUSER = -19,		// ­«½Æµn¤J
            FR_ERR_SEND_QUEUE_FULL = -20,		// ¶Ç°e½w½Ä°Ïº¡·¸,µLªk¼g¤J
            FR_ERR_SERVICE_LEN = -21,		// ¶W¹L Service Name ³Ì¤j¦r¦êªø«× (16¦r¤¸)
            FR_ERR_LINK_LEN = -22,	// ¶W¹L Link Name ³Ì¤j¦r¦êªø«× (32¦r¤¸)
            FR_ERR_ADDHOOK_MULINFO = -23,    //Hook±ø¥ó¤w¸g¦s¦b
            FR_ERR_HOOKINFO_FULL = -24,   //Hook±ø¥ó¤w¸gº¡¤F

            MSN_ERR_LISTEN_CHANNEL = -100,	// Invalid listen channel for a call
            MSN_ERR_UID = -101,	// UID ¤£²Å¦X
            MSN_ERR_UNSPPORTED = -102,	// ¤£¤ä´©¨ç¼Æ
            MSN_ERR_NO_CONNECTION = -103,	// ¨S¦³³s½u
            MSN_ERR_DATA_TOO_LONG = -104,	// ¸ê®Æªø«×¤Óªø
            MSN_ERR_MULTIPLECALL = -105,	// ¨ç¼Æ­«½Æ©I¥s
            MSN_ERR_CALLFULL = -106,	// Server³s½u¼Æ¤wº¡,µLªk¦A±µ¨ü·s³s½u

            FTP_ERR_TIMEOUT = -200,
            FTP_ERR_DISCONNECT = -201,
            FTP_ERR_FTP_NOT_EXIST = -202,
            FTP_ERR_ACCOUNT = -203,
            FTP_ERR_EXCEPTION_CALL = -204,
            FTP_ERR_FILE_NOT_EXIST = -205,
            FTP_ERR_BUSY = -206,
            FTP_ERR_OUT_OF_SERVICE = -207,
            FTP_ERR_UNCOMPLETED = -208,
            FTP_ERR_NEW_FILE = -209,
            FTP_ERR_FILE_RESET = -210,
            FTP_ERR_GET_FILE_FAIL = -211,
            FTP_ERR_ALREADY_LOGIN_FTP = -212,
            FTP_ERR_BUFFER_TOO_SMALL = -213,
            FTP_ERR_FILELIST_NOT_EMPTY = -214,

            FR_ERR_NOTENOUGHSENDBUF = -998, //送出訊息時 buffer不夠寫入
            FR_ERR_INITIALIZE = -999,    //mob_initialize 失敗
        };

        public static class Helper
        {
            public static string GetErrorStr(int errorCode)
            {
                try
                {
                    return Enum.GetName(typeof(E_FR), errorCode);
                }
                catch { return "KL: Unknown"; }
            }
        }

        public enum QOS_TYPE
        {
            HIGHEST = 0,
            HIGHER = 1,
            NORMAL = 2,
            LOW = 3,
        };

        public enum CHANNEL_TYPE
        {
            SYSTEM = 100,
            COMMAND = 101,
            BROADCAST = 102,
            TRANSACTION = 103,
            SESSION = 104,
            LOCAL = 105,
            PUBLIC = 106,
            USER = 107,
            RESERVED = 108,
        };

        public enum MESSAGE_TYPE
        {
            ERROR = 0,
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct MOBINFO
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string version;				// string of version
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string kernel;				// string of 'MOB-Push' or 'MOB-FD'	 
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string ConnectIP;			// Connection address of Push or Fermi Daemon
            public Int32 port;						// Connection port
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string libname;				// string of library name
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string os;					// string of Operation system
            public UInt64 ulRecvBufSize;	// Receive buffer size in bytes
            public UInt64 ulSendBufSize;	// Send buffer size in bytes
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct msnid_t
        {
            public WORD lc;
            public WORD dc;
            public WORD uid;
            public WORD dlen;
        };

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct msnmsg_t
        {
            public WORD msg_type;
            public msnid_t identifier;
            public BYTE flags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)E_Define.MAXMSNPKTSIZE)]
            public string data;
        };

        [StructLayoutAttribute(LayoutKind.Sequential)] //KL:
        public struct FTP_FILE_SIZE_TIME
        {
            public DWORD dw_FileSize;
            public WORD tm_Year;
            public BYTE tm_Month;
            public BYTE tm_Day;
            public BYTE tm_Hour;
            public BYTE tm_Minute;
            public BYTE tm_Second;
        }

        public class Kel_FileInfo : INotifyPropertyChanged
        {
            public event PropertyChangedEventHandler PropertyChanged;

            bool _IsFile = false;
            UInt32 _FileSize = 0;
            DateTime _FileDT = DateTime.MinValue;
            string _FileName = string.Empty;

            public bool IsFile
            {
                get { return _IsFile; }
                set { _IsFile = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("IsFile")); }
            }
            public UInt32 FileSize
            {
                get { return _FileSize; }
                set { _FileSize = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("FileSize")); }
            }
            public DateTime FileDT
            {
                get { return _FileDT; }
                set { _FileDT = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("FileDT")); }
            }
            public string FileName
            {
                get { return _FileName; }
                set { _FileName = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("FileName")); }
            }
        }

        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct FTP_FILE_INFO
        {
            /// BYTE->unsigned char
            public byte byFileType;
            /// FTP_FILE_SIZE_TIME->Anonymous_d9d417fc_92fc_4346_bfe6_3e4ff42e0290
            public FTP_FILE_SIZE_TIME fileInfo;
            /// std::string
            [MarshalAsAttribute(UnmanagedType.LPStr)]
            public string strFileName;
        }

        public class MessageEventArgs : EventArgs
        {
            string _Message; public string Message { get { return _Message; } set { _Message = value; } }
            public MessageEventArgs(string message)
            { this.Message = message; }
        }
        #endregion


        public int Mob_iTXSend(UInt16 _iChannel, byte[] _sBuf, string _sSubject, string _sAlias) //KL:20091008
        {
            mbol_send = true;
            if (Mob_iGetSendBufFree() > _sBuf.Length + 8) return mob_txsend(_iChannel, _sSubject, _sAlias, _sBuf, _sBuf.Length);
            return (int)E_FR.FR_ERR_NOTENOUGHSENDBUF;
        }

        public int Mob_iBCSend(UInt16 _iChannel, string _sBuf, string _sSubject) //KL:20091008
        {
            byte[] buf = new System.Text.ASCIIEncoding().GetBytes(_sBuf);
            if (Mob_iGetSendBufFree() > _sBuf.Length + 8) return mob_bcsend(_iChannel, _sSubject, buf, _sBuf.Length);
            return (int)E_FR.FR_ERR_NOTENOUGHSENDBUF;
        }

        public bool Send(UInt16 channel, string subject, byte[] message)
        {
            if (mob_getSendBufFree() > message.Length + 8)
            {
                //maked by philip 
                // int error = mob_send(CHANNEL_TYPE.USER, channel, subject, message, message.Length);
                int error = mob_send(CHANNEL_TYPE.TRANSACTION, channel, subject, message, message.Length);
                if (error == (int)E_FR.FR_OK)
                    return true;
            }
            return false;
        }


        private int Mob_iGetSendBufFree()
        {
            return mob_getSendBufFree();
        }

        int Mob_iTXSubscribe(UInt16 _iChannel, string _subject) //KL:20091008
        {
            string temp = _iChannel.ToString() + "_" + _subject;
            if (!List_Subscribe.Contains(temp))
            {
                List_Subscribe.Add(temp);
            }

            return mob_subscribe(CHANNEL_TYPE.TRANSACTION, _iChannel, _subject);
        }

        int Mob_iBCSubscribe(UInt16 _iChannel, string _subject) //KL:20091008
        {
            string temp = _iChannel.ToString() + "_" + _subject;
            if (!List_Subscribe.Contains(temp))
            {
                List_Subscribe.Add(temp);
            }

            return mob_subscribe(CHANNEL_TYPE.BROADCAST, _iChannel, _subject);
        }

        int Mob_iTXUnSubscribe(UInt16 _iChannel, string _subject) //KL:20091008
        {
            string temp = _iChannel.ToString() + "_" + _subject;
            if (List_Subscribe.Contains(temp))
            {
                List_Subscribe.Remove(temp);
            }

            return mob_unsubscribe(CHANNEL_TYPE.TRANSACTION, _iChannel, _subject);
        }

        int Mob_iBCUnSubscribe(UInt16 _iChannel, string _subject) //KL:20091008
        {
            string temp = _iChannel.ToString() + "_" + _subject;
            if (List_Subscribe.Contains(temp))
            {
                List_Subscribe.Remove(temp);
            }

            return mob_unsubscribe(CHANNEL_TYPE.BROADCAST, _iChannel, _subject);
        }

        public int Subscribe(CHANNEL_TYPE channeltype, UInt16 channel, string subject)
        {
            return mob_subscribe(channeltype, channel, subject);
        }

        public int UnSubscribe(UInt16 channel, string subject)
        {
            return mob_unsubscribe(CHANNEL_TYPE.USER, channel, subject);
        }


        private E_FR m_iIsConnect = E_FR.FR_ERR_DISCONNECT;
        private E_FR m_iIsLogin = E_FR.FR_ERR_UNAUTHORIZED;

        private string m_sHost = string.Empty;
        private Int32 m_iPort = 0;
        private Int32 m_iConnTryTimes = 0;
     
        private string m_sAccount = string.Empty;
        private string m_sPassword = string.Empty;
        private string m_sGroup = string.Empty;

        private List<string> List_Subscribe = new List<string>(); //KL:200091008 ~ local list of subscriptions, which will be done again upon re-connections
        private volatile bool disposed = false;

        private bool mbol_send = false;
        public bool bol_send
        {
            get
            {
                return mbol_send;
            }
            set
            {
                mbol_send = value;
            }
        }
        public event EventHandler OnDisconnect;
        public event EventHandler OnConnect;

        public delegate
            void receiveDataCallback(receiveDataEventArgs e);

        public event receiveDataCallback _receiveData;

        public class  receiveDataEventArgs
        {
            public UInt16 chanel;
            public string subject;
            public byte[] data; 
        }

        static Thread RecMsgThread = null;

        public MOBC(string Mob_Host, int Mob_Port, int Mob_ConnTryTimes)
        {
            m_sHost = Mob_Host;
            m_iPort = Mob_Port;
            m_iConnTryTimes = Mob_ConnTryTimes;
        }

        #region Dispose pattern
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    // dispose managed resources
                    if (RecMsgThread != null && RecMsgThread.IsAlive)
                        RecMsgThread.Abort();
                }

                mob_deinitialize();
                disposed = true;
            }
        }

        ~MOBC()
        {
            Dispose(false);
        }
        #endregion

        public void Disconnect()
        {
            if (RecMsgThread != null)
            {
                RecMsgThread.Abort();
            }
           
            mob_disconnect();
            m_iIsConnect = E_FR.FR_ERR_DISCONNECT;
            m_iIsLogin = E_FR.FR_ERR_UNAUTHORIZED;
        }

        public void Connect(string _sAccount, string _sPassword, string _sGroup) //KL:20091008
        { 
            m_sAccount = _sAccount;
            m_sPassword = _sPassword;
            m_sGroup = _sGroup;


            E_FR m_iRC = E_FR.FR_NODATA;
            do
            {
                Thread.Sleep(1000);
                m_iRC = Mob_iBegingConnect();
            } while (m_iRC == E_FR.FR_NODATA);

           
            if (m_iRC == E_FR.FR_OK)
            {
                if (OnConnect != null) OnConnect(this, new EventArgs());

                RecMsgThread = new Thread(Recv_Thread);
                RecMsgThread.Start();
            }
        }

        private E_FR Mob_iReConnect()
        {
            //Mob_vDisConnect();
            Disconnect();	//KL:20091008 - due to method name change

            E_FR m_iRC = E_FR.FR_NODATA;
            do
            {
                Thread.Sleep(1000);
                m_iRC = Mob_iBegingConnect();
            } while (m_iRC != E_FR.FR_OK);

            foreach (string temp in List_Subscribe)
            {
                string[] Text = temp.Split('_');
                mob_subscribe(CHANNEL_TYPE.TRANSACTION, ushort.Parse(Text[0]), Text[1]);
            }

            return m_iRC;
        }

        private E_FR Mob_iBegingConnect()
        {
            //if (mob_initialize((Int32)E_Define.RECV_QUEUE, (Int32)E_Define.SEND_QUEUE) == false) return E_FR.FR_ERR_INITIALIZE;
            if (mob_initialize() == false) //KL:20091008 - use default queue length for now...
                return E_FR.FR_ERR_INITIALIZE;

            if (m_iIsConnect == E_FR.FR_ERR_DISCONNECT)
            {
                for (int iTryCount = 0; iTryCount < m_iConnTryTimes; ++iTryCount)
                {
                    m_iIsConnect = mob_connect(m_sHost, m_iPort);
                    if (m_iIsConnect == E_FR.FR_OK)
                        break;
                }
            }

            if (m_iIsConnect != E_FR.FR_OK) return m_iIsConnect;

            m_iIsLogin = mob_login(m_sAccount, m_sPassword, m_sGroup);
            if (m_iIsLogin != E_FR.FR_OK) return m_iIsLogin;

            return E_FR.FR_OK;
        }

      

        void Recv_Thread()
        {
            CHANNEL_TYPE eCType = CHANNEL_TYPE.RESERVED;
            UInt16 iChannel = 0;         
             


            StringBuilder sSubject = new StringBuilder();
            StringBuilder sAlias = new StringBuilder();

        
            string message = "";

            while (!disposed)
            {
                Byte[] Buf = new Byte[(int)E_Define.FR_MAXPKTSIZE];
               
                int dLen   = mob_recvEx(ref eCType, ref iChannel, sSubject, sAlias, Buf, Buf.Length);
                //dLen = mob_recv(ref eCType, ref iChannel,sSubject, Buf, Buf.Length);
              
                if (dLen == (int)E_FR.FR_ERR_DISCONNECT && OnDisconnect != null) //KL:20091008
                {
                    //發event 通知UI
                    if (OnDisconnect != null) OnDisconnect(this, new EventArgs()); //KL:20091119
                    //重新連線
                    Mob_iReConnect();
                    continue; //KL:20091119
                }
                if (dLen > 0)
                {
                    //sb.Remove(0, sb.Length);
                    //sb.Append(System.Text.UTF8Encoding.UTF8.GetString(Buf, 0, dLen));
                    byte[] b = new byte[dLen];
                    Buffer.BlockCopy(Buf, 0, b, 0, dLen);

                   
                    //  FW.WriteLine(System.Text.Encoding.UTF8.GetString(b));
                    //string aaa = System.Text.Encoding.Default.GetString(b);

                    //  MessageBox.Show(System.Text.Encoding.UTF8.GetString(b));
                    receiveDataEventArgs ea = new receiveDataEventArgs();
                    ea.chanel = iChannel;
                    ea.subject = sSubject.ToString();
                    ea.data = b;
                    if(_receiveData!=null) _receiveData(ea);
                    //remark by Delia --RecvQueue.Enqueue(new MOBMessage(iChannel, sSubject.ToString(), b)); //KL:20091119
                }
                else
                {
                    Thread.Sleep(1);

                }

            }
        }

    }
}
