﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Net.Sockets;
using com.ddsc;
using com.ddsc.nets.server;
using com.ddsc.BI;
using com.ddsc.BI.Account;
using com.ddsc.tool;
using System.Net;
using System.IO;
using System.Web;
using System.Data;
using System.Collections;

using System.Data.SqlClient;
using System.Xml;

namespace AS400GatewayServer.MYCLS
{


    public class TradeStringHandler
    {



        string _SrcID = "";
        DataAgent _DataAgent;

        public DataAgent DataAgent
        {
            get { return _DataAgent; }
            set { _DataAgent = value; }
        }


        SeqProvider _WRNetworkId = null;


        SeqProvider _WRAccountSeq = null; //一般帳務查詢序號

        SeqProvider _WRMoneySeq = null;//出入金申請序號

        SeqProvider _WRTRANMoneySeq = null;//拆解組合序號

        SeqProvider _WRSeq = null;

        com.ddsc.BI.Account.TradeIntegration _TI;

        SAEAServer _SAEA;

        public SAEAServer SAEA
        {
            get { return _SAEA; }
            set { _SAEA = value; }
        }
        //AccountCore _AccountCore;
        //public AccountCore AccountCore
        //{
        //    get { return _AccountCore; }
        //    set { _AccountCore = value; }
        //}
        DBTcpClient _DBClient;
        public DBTcpClient DBClient
        {
            set { _DBClient = value; }
            get { return _DBClient; }
        }



        bool _DataEncode = false;
        public bool DataEncode
        {
            set { _DataEncode = value; }
            get { return _DataEncode; }
        }


        SaveDB[] _SaveDB;


        delegate int SignVerifyHandler(string networkid, string data, string Signature, string CertSN, string idno, string IP);
        SignVerifyHandler SignVerifyExcute;



        private DateTime _OrderBeginTime;
        private DateTime _OrderEndTime;

        private string _CloseAccount = "";
        private bool _VerifyFlag = false;

        //AccountQueryCore _OrderCore; //委託

        AccountQueryCore _QueryCore; //報價查詢
        AccountQueryCore _AccountQueryCore; //一般帳務查詢

        AccountQueryCore _MoneyQueryCore;//出入金申請
        AccountQueryCore _TRANMoneyQueryCore;//互轉拆解申請
        //public ActiveReplyCore _ActiveReplyCore;//主動回報


        public TradeStringHandler(AccountCore AccountCore)
        {
            try
            {
                _TI = new TradeIntegration();
                _QueryCore = new AccountQueryCore();
                _AccountQueryCore = new AccountQueryCore();
                _MoneyQueryCore = new AccountQueryCore();
                _TRANMoneyQueryCore = new AccountQueryCore();
                _SAEA = SAEA;


                _WRNetworkId = new SeqProvider("NetWorkId", DataAgent.BASEPATH + "log\\" + DataAgent.CURRENTPATH);

                _WRSeq = new SeqProvider("seq", DataAgent.BASEPATH + "log\\" + DataAgent.CURRENTPATH);

                _WRAccountSeq = new SeqProvider("AccountSeq", DataAgent.BASEPATH + "log\\" + DataAgent.CURRENTPATH);

                _WRMoneySeq = new SeqProvider("MoneySeq", DataAgent.BASEPATH + "log\\" + DataAgent.CURRENTPATH);

                _WRTRANMoneySeq = new SeqProvider("TRANMoneySeq", DataAgent.BASEPATH + "log\\" + DataAgent.CURRENTPATH);






                _SAEA = SAEA;
                //   _AccountCore = AccountCore;






            }
            catch (Exception ex)
            {

                WriteLog("DataAgentLog", "TradeStringHandler:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }



        ~TradeStringHandler()
        {
            Dispose();
        }
        public void Dispose()
        {

            if (_WRNetworkId != null)
                _WRNetworkId.Dispose();
            if (_WRSeq != null)
                _WRSeq.Dispose();
            if (_WRAccountSeq != null)
                _WRAccountSeq.Dispose();

            if (_WRMoneySeq != null)
                _WRMoneySeq.Dispose();

            if (_WRTRANMoneySeq != null)
                _WRTRANMoneySeq.Dispose();
            if (_QueryCore != null)
                _QueryCore.Close();
            if (_AccountQueryCore != null)
                _AccountQueryCore.Close();
            if (_MoneyQueryCore != null)
                _MoneyQueryCore.Close();
            if (_TRANMoneyQueryCore != null)
                _TRANMoneyQueryCore.Close();

            GC.SuppressFinalize(this);
        }


        public void ParseDDSCData(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {


                string RemoteIP = ((System.Net.IPEndPoint)S.AcceptSocket.RemoteEndPoint).Address.ToString();
                switch (buffer[0])
                {
                    case 0xFF:

                        // WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseMA(S, buffer);
                        break;

                    case AccountSockClientParserFunction.DDSCSocketHead.Alive:

                        // WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseAlive(S, buffer);
                        break;

                    case AccountSockClientParserFunction.DDSCSocketHead.Connecting:

                        //WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseConnecting(S, buffer);
                        break;

                    case AccountSockClientParserFunction.DDSCSocketHead.DGWST:
                        // WriteLog("SAEAServerLogRCV" + S.AcceptSocket.RemoteEndPoint.ToString().Replace(":", ";"), buffer);
                        WriteLog("SAEAServerLogRCV" + RemoteIP, buffer);
                        ParseDGWRequest(S, buffer);
                        break;
                    default:



                        WriteLog("DataAgentLog", "ParseDDSCData:" + "length=" + buffer.Length + S.AcceptSocket.RemoteEndPoint.ToString() + "format error!");
                        WriteLog("DataAgentLog", "ParseDDSCData:" + ASCIIEncoding.ASCII.GetString(buffer));
                        _SAEA.CloseClientSocket(S);
                        break;
                }


            }
            catch (Exception ex)
            {

                WriteLog("DataAgentLog", "ParseDDSCData:" + "length=" + buffer.Length + "-" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString() + S.AcceptSocket.RemoteEndPoint.ToString());
                WriteLog("DataAgentLog", "ParseDDSCData:" + ASCIIEncoding.ASCII.GetString(buffer));
                _SAEA.CloseClientSocket(S);
            }
        }

        private void ParseMA(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {
                //AccountSockClientParserFunction.DDSCHead raw = new SockClientParserFunction.DDSCHead();

                //com.ddsc.BI.ParserStruct<SockClientParserFunction.DDSCHead>.ByteArrayToStructure(buffer, ref raw);


                //raw.HEAD = new byte[] { 0xff };

                //string body = "";

                //if (DataAgent.OrderDataQWriter.Running)
                //{
                //    body += DataAgent.OrderDataQWriter.name + "DataQWriter:true\n";
                //}
                //else
                //{
                //    body += DataAgent.OrderDataQWriter.name + "DataQWriter:false\n";
                //}

                //foreach (DataQReader d in DataAgent.RepleDataQReaders)
                //{
                //    if (d.Running)
                //    {
                //        body += d.mstr_name + "DataQReader:true\n";
                //    }
                //    else
                //    {
                //        body += d.mstr_name + "DataQReader:false\n";
                //    }
                //}


                //if (DataAgent.AccountOrderDataQWriter.Running)
                //{
                //    body += DataAgent.AccountOrderDataQWriter.name + "DataQWriter:true\n";
                //}
                //else
                //{
                //    body += DataAgent.AccountOrderDataQWriter.name + "DataQWriter:false\n";
                //}

                //foreach (DataQReader d in DataAgent.AccountRepleDataQReaders)
                //{
                //    if (d.Running)
                //    {
                //        body += d.mstr_name + "DataQReader:true\n";
                //    }
                //    else
                //    {
                //        body += d.mstr_name + "DataQReader:false\n";
                //    }
                //}



                //if (_DBClient.Socket.Connected)
                //    body += "DBClient:true\n";
                //else
                //    body += "DBClient:false\n";
                //if (_SAEA.Active)
                //    body += "SAEAServer:true\n";
                //else
                //    body += "SAEAServer:false\n";
                //foreach (string key in _DataAgent.TransferData.Keys)
                //{
                //    if (_DataAgent.TransferData.ContainsKey(key))
                //        body += key + "TransferData:true\n";
                //    else
                //        body += key + "TransferData:false\n";
                //}

                //Dictionary<string, string> rr = _DataAgent.FlowGroupJobData.GetItem();

                //foreach (string r in rr.Keys)
                //{
                //    body += "FlowGroupJobData:" + r + " " + rr[r] + "\n";
                //}


                //body += "ReOrderFlag:" + Settings.Default.ReOrderFlag + "\n";
                //body += "WorkDayForDomestic:" + _DataAgent.WorkDayForDomestic + "\n";
                //body += "WorkDayForForeign:" + _DataAgent.WorkDayForForeign + "\n";
                //body += "WorkDay:" + _DataAgent.WorkDay + "\n";
                //body += "NextWorkDay:" + _DataAgent.NextWorkDay + "\n";

                //byte[] bytebody = ASCIIEncoding.ASCII.GetBytes(body);

                //raw.LENGTH = BitConverter.GetBytes(Convert.ToUInt16(bytebody.Length));
                //if (BitConverter.IsLittleEndian)
                //{
                //    Array.Reverse(raw.LENGTH);
                //}
                //buffer = SockClientParserFunction.StructureToByteArray(raw);
                //byte[] ret = new byte[buffer.Length + bytebody.Length + 1];
                //Array.Copy(buffer, 0, ret, 0, buffer.Length);
                //Array.Copy(bytebody, 0, ret, buffer.Length, bytebody.Length);
                //ret[ret.Length - 1] = SockClientParserFunction.DDSCSocketHead.End;


                //  SendDataToAP(S, ret);

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseConnecting:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
        }

        private void ParseAlive(SocketAsyncEventArgs S, byte[] buffer)
        {
            try
            {
                //string len = getDDSCRawDataLength(buffer);
                Array.Copy(ASCIIEncoding.Default.GetBytes(DateTime.Now.ToString("HHmmssfff")), 0, buffer, 1, 9);
                // SendDataToAP(S, buffer);
                this._SAEA.SendData(S, buffer);

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseAlive:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }
        }



        private void ParseConnecting(SocketAsyncEventArgs S, byte[] buffer)
        {
            //try
            //{
            //    SockClientParserFunction.DDSCHead raw = new SockClientParserFunction.DDSCHead();

            //    com.ddsc.BI.ParserStruct<SockClientParserFunction.DDSCHead>.ByteArrayToStructure(buffer, ref raw);

            //    string Userid = ASCIIEncoding.ASCII.GetString(raw.USERID).Trim();
            //    string body = ASCIIEncoding.ASCII.GetString(buffer, Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead))
            //        , buffer.Length - Marshal.SizeOf(typeof(SockClientParserFunction.DDSCHead)) - 1);

            //    _AccountCore.AddUser(Userid);
            //    if (_AccountCore.AddSAEA(Userid, S))
            //    {
            //        raw.HEAD = new byte[] { SockClientParserFunction.DDSCSocketHead.Connected };

            //        UserInfo u = _AccountCore.FindUserInfo(S);
            //        byte[] seq = getSeq();

            //        Array.Copy(seq, 0, raw.NEWSEQ, 0, seq.Length);
            //        Array.Copy(seq, 0, raw.OLDSEQ, 0, seq.Length);
            //        raw.LENGTH = BitConverter.GetBytes(UInt16.Parse("0"));
            //        buffer = SockClientParserFunction.StructureToByteArray(raw);
            //        byte[] ret = new byte[buffer.Length + 1];
            //        Array.Copy(buffer, 0, ret, 0, buffer.Length);
            //        ret[ret.Length - 1] = SockClientParserFunction.DDSCSocketHead.End;

            //        //string[] arrPutIPLoginCmd = new string[1];
            //        //arrPutIPLoginCmd[0] = " INSERT INTO [dbo].[TRADEIPLOG] "
            //        //+ "  ([USERID],[IP],[PORT],[LOGINTIME],[STATUS],[LOGDATE])VALUES "
            //        //+ "('" + Userid + "','" + S.AcceptSocket.RemoteEndPoint.ToString().Split(':')[0] + "','" + S.AcceptSocket.RemoteEndPoint.ToString().Split(':')[1] + "','" + u.LoginTime + "','',convert(char(8),getdate(),112))";
            //        //_SaveDB.PutData2Queue(arrPutIPLoginCmd);

            //        SendDataToAP(S, ret);
            //    }
            //    else
            //    {
            //        WriteLog("DataAgentLog", "ParseConnecting:" + "無此帳號:" + Userid);
            //        _SAEA.CloseClientSocket(S);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    WriteLog("DataAgentLog", "ParseConnecting:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            //    throw ex;
            //}
        }




        public void parseAccountReplyData(string ReplyType, string RcvBuffer)
        {

            try
            {
                string T4 = Date.NowTime().ToString("HH:mm:ss.fff");
                ReplyType = ReplyType.Trim();
                string NETWORKID = "";
                byte[] buffer = ASCIIEncoding.Default.GetBytes(RcvBuffer);
                byte head = 0x00;
                //AccountItem SAEA = new AccountItem();
                //SAEA.S = null; SAEA.Protocol = DDSCProtocol.DDSC;
                int TOTALCOUNT = 0;
                string returncode = "0000000";



                //if (SAEA.Protocol == DDSCProtocol.DDSC)
                //{
                //    SendAccountDataToAP(SAEA, head, NETWORKID, buffer);
                //}
                //else if (SAEA.Protocol == DDSCProtocol.DGW)//轉中台格式
                //{
                //    SAEA.T4 = T4;
                //    buffer = SendDGWToAP(ref SAEA, returncode, buffer);
                //    WriteLog("FUN" + SAEA.FUNCTION + "SendLog", ASCIIEncoding.Default.GetString(buffer));
                //}



            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "parseReplyData:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }


        }


        private void ParseDGWRequest(SocketAsyncEventArgs s, byte[] source_buffer)
        {


            try
            {
                AccountSockClientParserFunction.DDSCDGWHead Head = new AccountSockClientParserFunction.DDSCDGWHead();
                AccountSockClientParserFunction.ParserStruct<AccountSockClientParserFunction.DDSCDGWHead>.ByteArrayToStructure(source_buffer, ref Head);
                string body = ASCIIEncoding.Default.GetString(source_buffer, 50, source_buffer.Length - 50 - 1);
                string strHead = body.Substring(0, 1);
                byte bytHead = Encoding.Default.GetBytes(strHead)[0];

                string strBody = body.Substring(1, body.Length - 1);
                byte[] bytBody = Encoding.Default.GetBytes(strBody);
                string networkId;
                byte[] byt_send = null;
                string SOURCE = Properties.Settings.Default.Source;
                string FIRM = "";
                string ACTNO = "";
                string CURRENCY = "NTT";
                string RemoteIP = ((System.Net.IPEndPoint)s.AcceptSocket.RemoteEndPoint).Address.ToString();
                string Port = ((System.Net.IPEndPoint)s.AcceptSocket.RemoteEndPoint).Port.ToString();
                AccountItem S = new AccountItem();
                S.init();
                S.Protocol = DDSCProtocol.DGW;
                S.S = s;
                S.SEQ = ASCIIEncoding.Default.GetString(Head.SEQ);
                S.FUNCTION = ASCIIEncoding.Default.GetString(Head.FUNCTION);
                S.SYSTEMCODE = ASCIIEncoding.Default.GetString(Head.SYSTEMCODE);
                S.T2 = Date.NowTime().ToString("HH:mm:ss.fff");
                S.IP = RemoteIP;
                S.port = Port;

                switch (bytHead)
                {
                    case 0x50://保證金查詢
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        if (CURRENCY == "TWD")
                            CURRENCY = "NTT";


                        byt_send = _TI.getPSGREQUEST001(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "保證金查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x05://未平倉資料查詢
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        if (CURRENCY == "TWD")
                            CURRENCY = "NTT";
                        byt_send = _TI.getPSGREQUEST003(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "未平倉資料查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x52://當日損益查詢
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        if (CURRENCY == "TWD")
                            CURRENCY = "NTT";
                        byt_send = _TI.getPSGREQUEST005(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "當日損益查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x56://即時部位查詢
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        if (CURRENCY == "TWD")
                            CURRENCY = "NTT";
                        byt_send = _TI.getPSGREQUEST007(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "即時部位查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x58://即時組合部位查詢
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        byt_send = _TI.getPSGREQUEST009(networkId, SOURCE, FIRM, ACTNO, CURRENCY);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "即時組合部位查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x21://當日平蒼損益查詢3
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        if (CURRENCY == "TWD")
                            CURRENCY = "NTT";
                        byt_send = _TI.getPSGREQUEST013(networkId, SOURCE, FIRM, ACTNO, CURRENCY, strBody.Substring(17, 1), strBody.Substring(18, 7), strBody.Substring(25, 6), strBody.Substring(31, 1), strBody.Substring(32, 9), strBody.Substring(41, 9));
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "當日平蒼損益查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x59: //未平倉彙總查詢
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        if (CURRENCY == "TWD")
                            CURRENCY = "NTT";
                        string ACTION = strBody.Substring(17, 1);

                        byt_send = _TI.getPSGREQUEST017(networkId, SOURCE, FIRM, ACTNO, ACTION, CURRENCY);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "未平倉彙總查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x60: //高風險查詢 //V1.0.0.19 added by peter on 20151202
                        networkId = getAccountSeq();
                        FIRM = strBody.Substring(0, 7);
                        string AENO = strBody.Substring(7, 6);
                        string strRate = strBody.Substring(13, 4);
                        int rate = 0;
                        if (strRate.Substring(0, 1) == "-")
                        {
                            rate = -1 * int.Parse(strRate.Substring(1, 3));
                        }
                        else
                        {
                            rate = int.Parse(strRate.Substring(1, 3));
                        }

                        byt_send = _TI.getPSGREQUEST019(networkId, SOURCE, FIRM, AENO, rate);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "高風險查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x63: //高風險查詢低於25% //V1.0.0.23 added by peter on 20170110
                        networkId = getAccountSeq();
                        string date = strBody.Substring(0, 8);
                        byt_send = _TI.getPSGREQUEST021(networkId, SOURCE, date);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "高風險查詢低於25%";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x61: //判斷是否為多筆申請
                        networkId = getTRANMoneySeq();
                        AccountSockClientParserFunction.DDSCREQUESTCOMBINE t = new AccountSockClientParserFunction.DDSCREQUESTCOMBINE();
                        AccountSockClientParserFunction.ByteArrayToDDSCREQUESTCOMBINEStructure(bytBody, ref t);
                        byt_send = _TI.getPSGREQUESTCOMBINE(new string(t.TYPE), networkId, new string(t.COUNT)
                                                                                        , new string(t.SEQNO)
                                                                                        , new string(t.COMPANY)
                                                                                        , new string(t.ACTNO)
                                                                                        , new string(t.Comno1)
                                                                                        , new string(t.Comym1)
                                                                                        , new string(t.Stkprc1)
                                                                                        , new string(t.Callput1)
                                                                                        , new string(t.BS1)
                                                                                        , new string(t.Qty1)
                                                                                        , new string(t.Comno2)
                                                                                        , new string(t.Comym2)
                                                                                        , new string(t.Stkprc2)
                                                                                        , new string(t.Callput2)
                                                                                        , new string(t.BS2)
                                                                                        , new string(t.Qty2));
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "拆解";
                        S.NETWORKID = networkId;
                        _TRANMoneyQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400ClientFor2.Send(byt_send);
                        break;
                    case 0x64: //判斷是否為多筆申請
                        networkId = getTRANMoneySeq();
                        AccountSockClientParserFunction.DDSCREQUESTNET DDSCREQUESTNET = new AccountSockClientParserFunction.DDSCREQUESTNET();
                        AccountSockClientParserFunction.ByteArrayToDDSCREQUESTNETStructure(bytBody, ref DDSCREQUESTNET);
                        byt_send = _TI.getPSGREQUESTNET(networkId, new string(DDSCREQUESTNET.COUNT)
                                                                , new string(DDSCREQUESTNET.SEQNO)
                                                                , new string(DDSCREQUESTNET.COMPANY)
                                                                , new string(DDSCREQUESTNET.ACTNO));
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "組合";
                        S.NETWORKID = networkId;
                        _TRANMoneyQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400ClientFor2.Send(byt_send);
                        break;
                    case 0x23://出入金查詢
                        networkId = getAccountSeq();


                        FIRM = strBody.Substring(0, 7);
                        ACTNO = strBody.Substring(7, 7);
                        CURRENCY = strBody.Substring(14, 3);
                        if (CURRENCY == "TWD")
                            CURRENCY = "NTT";
                        string STRDATE = strBody.Substring(17, 8);
                        string ENDDATE = strBody.Substring(25, 8);

                        string STRTIME = strBody.Substring(33, 8);
                        string ENDTIME = strBody.Substring(41, 8);

                        byt_send = _TI.getPSGREQUEST015(networkId, SOURCE, FIRM, ACTNO, CURRENCY, STRDATE, ENDDATE, STRTIME, ENDTIME);
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "出入金查詢";
                        S.NETWORKID = networkId;
                        _AccountQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400Client.Send(byt_send);
                        break;
                    case 0x24://出入金申請 
                        AccountSockClientParserFunction.DDSCREQUESTWITHDRAW DDSCREQUESTWITHDRAW = new AccountSockClientParserFunction.DDSCREQUESTWITHDRAW();
                        AccountSockClientParserFunction.ByteArrayToDDSCREQUESTWITHDRAWStructure(bytBody, ref DDSCREQUESTWITHDRAW);

                        if ((new string(DDSCREQUESTWITHDRAW.TYPE)).Trim() == "2")//取消
                        {
                            networkId = new string(DDSCREQUESTWITHDRAW.SEQNO);
                        }
                        else
                            networkId = getMoneySeq();
                        byt_send = _TI.getPSGREQUESTWITHDRAW(new string(DDSCREQUESTWITHDRAW.MTYPE), networkId, new string(DDSCREQUESTWITHDRAW.TYPE)
                                                            , new string(DDSCREQUESTWITHDRAW.COMPANY), new string(DDSCREQUESTWITHDRAW.ACTNO), new string(DDSCREQUESTWITHDRAW.CURRENCY)
                                                            , new string(DDSCREQUESTWITHDRAW.AMT), new string(DDSCREQUESTWITHDRAW.TOCURRENCY), new string(DDSCREQUESTWITHDRAW.TOMTYPE), new string(DDSCREQUESTWITHDRAW.TOAMT)
                                                            , new string(DDSCREQUESTWITHDRAW.IP), Properties.Settings.Default.WSOURCE, new string(DDSCREQUESTWITHDRAW.SLIPNO1)
                                                            , new string(DDSCREQUESTWITHDRAW.SLIPNO2), new string(DDSCREQUESTWITHDRAW.RCV));
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "出入金申請";
                        S.NETWORKID = networkId;
                        _MoneyQueryCore.AddSAEA(networkId, S);

                        _DataAgent.AS400ClientFor3.Send(byt_send);
                        if ((new string(DDSCREQUESTWITHDRAW.TYPE)).Trim() == "2")//取消
                        {
                            SaveDB.UpdateWITHDRAWItemDel item = new SaveDB.UpdateWITHDRAWItemDel();
                            item.SEQNO = networkId;
                            item.TYPE = new string(DDSCREQUESTWITHDRAW.TYPE);
                            item.COMPANY = new string(DDSCREQUESTWITHDRAW.COMPANY);
                            item.ACTNO = new string(DDSCREQUESTWITHDRAW.ACTNO);
                            item.ORDDT = DateTime.Now.ToString("yyyyMMdd");
                            item.ORDTM = DateTime.Now.ToString("HHmmss");// 
                            item.IP = new string(DDSCREQUESTWITHDRAW.IP);
                            item.CODE = "";
                            _DataAgent.mobj_SaveDB.PutData2Queue(item);
                        }
                        else
                        {

                            string AMT = new string(DDSCREQUESTWITHDRAW.AMT);
                            AMT = AMT.Substring(0, 12) + "." + AMT.Substring(12, 2).ToString();
                            string TOAMT = new string(DDSCREQUESTWITHDRAW.TOAMT);
                            TOAMT = TOAMT.Substring(0, 12) + "." + TOAMT.Substring(12, 2).ToString();
                            SaveDB.InsertWITHDRAWItem item = new SaveDB.InsertWITHDRAWItem();
                            item.MTYPE = new string(DDSCREQUESTWITHDRAW.MTYPE);
                            item.SEQNO = networkId;
                            item.TYPE = new string(DDSCREQUESTWITHDRAW.TYPE);
                            item.COMPANY = new string(DDSCREQUESTWITHDRAW.COMPANY);
                            item.ACTNO = new string(DDSCREQUESTWITHDRAW.ACTNO);
                            item.CURRENCY = new string(DDSCREQUESTWITHDRAW.CURRENCY);
                            item.AMT = AMT;
                            item.TOCURRENCY = new string(DDSCREQUESTWITHDRAW.TOCURRENCY);
                            item.TOMTYPE = new string(DDSCREQUESTWITHDRAW.TOMTYPE);
                            item.TOAMT = TOAMT;
                            item.ORDTM = DateTime.Now.ToString("HHmmss");// new string(DDSCREQUESTWITHDRAW.ORDTM);
                            item.IP = new string(DDSCREQUESTWITHDRAW.IP);
                            item.SOURCE = Properties.Settings.Default.WSOURCE;
                            item.ORDDT = DateTime.Now.ToString("yyyyMMdd");// new string(DDSCREQUESTWITHDRAW.ORDDT);
                            item.CODE = "";
                            //item.SLIPNO1 = new string(DDSCREQUESTWITHDRAW.SLIPNO1);
                            //item.SLIPNO2 = new string(DDSCREQUESTWITHDRAW.SLIPNO2);
                            //item.RCV = new string(DDSCREQUESTWITHDRAW.RCV);

                            _DataAgent.mobj_SaveDB.PutData2Queue(item);
                        }
                        break;
                    case 0x70://MatchPrice
                        networkId = getNetworkId();
                        S.FUNCTION = "MatchPrice";
                        S.NETWORKID = networkId;
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        //keep 查詢資料
                        S.RequestData = strBody;
                        S.ReponsetData = "";
                        _QueryCore.AddSAEA(networkId, S);
                        _DataAgent._SQuotaAPI.QueryItem(networkId, com.ddsc.Quota.Future.MarketParser.RegitemKind.I020, com.ddsc.Quota.Future.MarketParser.ProductKind.Future, strBody);

                        break;
                    case 0x72://HighLowPrice
                        networkId = getNetworkId();
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "HighLowPrice";
                        S.NETWORKID = networkId;
                        _QueryCore.AddSAEA(networkId, S);

                        _DataAgent._SQuotaAPI.QueryItem(networkId, com.ddsc.Quota.Future.MarketParser.RegitemKind.I021, com.ddsc.Quota.Future.MarketParser.ProductKind.Future, strBody);

                        break;
                    case 0x74://ProductInfo
                        networkId = getNetworkId();
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "ProductInfo";
                        S.NETWORKID = networkId;
                        _QueryCore.AddSAEA(networkId, S);

                        _DataAgent._SQuotaAPI.QueryItem(networkId, com.ddsc.Quota.Future.MarketParser.RegitemKind.I060, com.ddsc.Quota.Future.MarketParser.ProductKind.Future, strBody);

                        break;
                    case 0x76://現貨價

                        networkId = getNetworkId();
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "現貨價";
                        S.NETWORKID = networkId;
                        _QueryCore.AddSAEA(networkId, S);

                        _DataAgent._SQuotaAPI.QueryItem(networkId, com.ddsc.Quota.Future.MarketParser.RegitemKind.I060, com.ddsc.Quota.Future.MarketParser.ProductKind.Future, strBody);
                        break;
                    case 0x77://五檔

                        networkId = getNetworkId();
                        S.T3 = Date.NowTime().ToString("HH:mm:ss.fff");
                        S.FUNCTION = "五檔";
                        S.NETWORKID = networkId;
                        _QueryCore.AddSAEA(networkId, S);

                        _DataAgent._SQuotaAPI.QueryItem(networkId, com.ddsc.Quota.Future.MarketParser.RegitemKind.I080, com.ddsc.Quota.Future.MarketParser.ProductKind.Future, strBody);
                        break;

                }

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "ParseDGWRequest:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                throw ex;
            }

        }


        private byte[] SendDGWToAP(ref AccountItem SAEA, string RETURNCODE, byte[] buffer)
        {
            byte[] retBuffer = null;
            try
            {

                AccountSockClientParserFunction.DDSCDGWHead DDSCHead = new AccountSockClientParserFunction.DDSCDGWHead();

                DDSCHead.HEAD = new byte[1] { AccountSockClientParserFunction.DDSCSocketHead.DGWST };
                DDSCHead.MESSAGETIME = ASCIIEncoding.ASCII.GetBytes(DateTime.Now.ToString("HHmmssfff"));
                DDSCHead.SEQ = ASCIIEncoding.ASCII.GetBytes(SAEA.SEQ.PadRight(10, ' '));
                DDSCHead.FUNCTION = ASCIIEncoding.ASCII.GetBytes(SAEA.FUNCTION.PadRight(3, ' '));
                DDSCHead.SYSTEMCODE = ASCIIEncoding.ASCII.GetBytes(SAEA.SYSTEMCODE.PadRight(3, ' '));

                DDSCHead.TMP = ASCIIEncoding.ASCII.GetBytes("".PadLeft(22, ' '));

                byte[] headbyte;
                if (buffer == null)
                {
                    DDSCHead.LENGTH = BitConverter.GetBytes(UInt16.Parse("0"));
                    if (BitConverter.IsLittleEndian)
                        Array.Reverse(DDSCHead.LENGTH);
                    retBuffer = new byte[50 + 1];
                }
                else
                {
                    DDSCHead.LENGTH = BitConverter.GetBytes(UInt16.Parse(buffer.Length.ToString()));
                    if (BitConverter.IsLittleEndian)
                        Array.Reverse(DDSCHead.LENGTH);
                    retBuffer = new byte[50 + buffer.Length + 1];
                }


                headbyte = AccountSockClientParserFunction.StructureToByteArray(DDSCHead);
                Array.Copy(headbyte, 0, retBuffer, 0, headbyte.Length);
                if (buffer != null)
                {
                    Array.Copy(buffer, 0, retBuffer, headbyte.Length, buffer.Length);
                }
                retBuffer[retBuffer.Length - 1] = AccountSockClientParserFunction.DDSCSocketHead.End;


                if (SAEA.S != null)
                {
                    try
                    {
                        this._SAEA.SendData(SAEA.S, retBuffer);
                        SAEA.T5 = Date.NowTime().ToString("HH:mm:ss.fff");
                        if (SAEA.S.AcceptSocket != null)//判斷此連線是否存在 沒有則不寫LOG
                        {

                            WriteLog("SAEAServerLogSend" + SAEA.IP, retBuffer);

                            WriteLog("Log", string.Format("[{0}][{1}][{2}][{3}][{4}][{5}][{6}][{7}][{8}]", SAEA.IP + ":" + SAEA.port, SAEA.SYSTEMCODE, SAEA.FUNCTION, SAEA.SEQ, SAEA.NETWORKID, SAEA.T2, SAEA.T3, SAEA.T4, SAEA.T5));
                        }
                    }
                    catch (Exception ex)
                    {
                        WriteLog("DataAgentLog", "Socket is null:DDSCHead.SEQ" + DDSCHead.SEQ + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                    }


                }

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "SendDGWToAP:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
            finally
            {

            }
            return retBuffer;
        }


        private string getNetworkId()
        {
            string Seq;

            int networkid = _WRAccountSeq.getSeq();


            // Seq = ((int)DateTime.Now.DayOfWeek).ToString() + Int2String(networkid).PadLeft(5, '0');
            Seq = (Properties.Settings.Default.SrcCode + Int2String(networkid));

            return Seq;
        }

        private byte[] getSeq()
        {
            byte[] Seq;


            int seq = _WRSeq.getSeq();

            // seq = 1000000 * (int)DateTime.Now.DayOfWeek + seq;
            //改用交易日期最後一碼 邊序號  可編0~9   
            seq = int.Parse(DataAgent.TradeDate.Substring(7)) + seq;

            Seq = ASCIIEncoding.ASCII.GetBytes((_SrcID + DataAgent.TradeDate.Substring(7) + Int2String(seq).PadLeft(4, '0')).PadRight(9, ' '));


            return Seq;
        }

        private string getAccountSeq()
        {
            string Seq;

            int networkid = _WRAccountSeq.getSeq();


            // Seq = ((int)DateTime.Now.DayOfWeek).ToString() + Int2String(networkid).PadLeft(5, '0');
            Seq = (Properties.Settings.Default.SrcCode + Int2String(networkid).ToString().PadLeft(7, '0')).PadRight(10, ' '); ;



            return Seq;
        }

        private string getMoneySeq()
        {

            string Seq;

            int networkid = _WRMoneySeq.getSeq();

            //周+COUNT AS400開數字六碼和他們是用營業日所以中台不能用系統日去COUNT
            //，避免AS400因為過帳而造成AS400 KEY重複， 
            // Seq = ((int)DateTime.Now.DayOfWeek).ToString() + networkid.ToString().PadLeft(5, '0');
            string key = DataAgent.TradeDate.Substring(3, 1) + DataAgent.TradeDate.Substring(4, 2) + DataAgent.TradeDate.Substring(6, 2);
            Seq = key + (int.Parse(Properties.Settings.Default.WSOURCE_SEQ_START) + networkid).ToString().PadLeft(4, '0');


            return Seq;
        }

        /// <summary>
        /// 猜解組合申請序號
        /// </summary>
        /// <returns></returns>
        private string getTRANMoneySeq()
        {

            string Seq;

            int networkid = _WRTRANMoneySeq.getSeq();

            //周+COUNT AS400開數字六碼和他們是用營業日所以中台不能用系統日去COUNT
            //，避免AS400因為過帳而造成AS400 KEY重複， 
            //  Seq = ((int)DateTime.Now.DayOfWeek).ToString() + networkid.ToString().PadLeft(5, '0');

            Seq = Properties.Settings.Default.SrcCode + Int2String(networkid).ToString().PadLeft(7, '0');
            return Seq;
        }




        private void WriteLog(string key, byte[] data)
        {

            DataAgent._LM.WriteLog(key, data);
        }
        private void WriteLog(string key, string data)
        {
            DataAgent._LM.WriteLog(key, data);
        }



        public static String Int2String(Int64 intValue)
        {
            String strValue = String.Empty;
            String strArr = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            while (intValue != 0)
            {
                int intRem = 0;
                intRem = (int)(intValue % strArr.Length);
                strValue = strArr.Substring(intRem, 1) + strValue;
                intValue /= strArr.Length;
            }
            return strValue;
        }


        public void RI_Receive(ReceivedAccountAcion Action, byte[] buffer, byte[] source_buffer)
        {
            try
            {
                List<byte> ff = new List<byte>();

                string[] strReturn = new string[4];
                string productId = "";
                string closeprice = "";
                string COMNO = "";
                string COMYM = "";
                string CALLPUT = "";
                string STKPRC = "";
                string dsc = "";
                string network = ASCIIEncoding.ASCII.GetString(source_buffer, 8, 10);

                AccountItem item = _AccountQueryCore.FindSAEA(network);
                item.T4 = Date.NowTime().ToString("HH:mm:ss.fff");
                switch (Action)
                {
                    case ReceivedAccountAcion.Received002://保證金查詢回覆 systex Format
                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received004://未平倉資料查詢回覆 systex Format
                        //systex header
                        //ret.FCODE = new char[] { Convert.ToChar(0x53) };
                        //ret.SEQNO = SEQNO.PadLeft(8, '0').ToCharArray();
                        //ret.MTYPE = " ".ToCharArray();
                        //ret.FIRM = "       ".ToCharArray();
                        //ret.ACTNO = "       ".ToCharArray();
                        //ret.BODYCNT = "00".ToCharArray(); 
                        //ret.EOR = new char[] { Convert.ToChar(0x0a) }; <==================== 當26 為0x0a時 代表沒有資料

                        if (buffer[26] == 0x0a)
                        {
                        }
                        else
                        {


                            AccountSockClientParserFunction.MOBRESPONSE0x13 MOBRESPONSE0x13 = new AccountSockClientParserFunction.MOBRESPONSE0x13();
                            AccountSockClientParserFunction.ParserStruct<AccountSockClientParserFunction.MOBRESPONSE0x13>
                                .ByteArrayToStructure(buffer, 0, ref MOBRESPONSE0x13);
                            // 精誠  7:單式期貨 0:單式期權  6:複式期貨 12345:複選期權             

                            //重商品檔取商品ID和前日結算價

                            COMNO = new string(MOBRESPONSE0x13.COMNO).Trim();
                            COMYM = new string(MOBRESPONSE0x13.COMYM).Trim();
                            CALLPUT = new string(MOBRESPONSE0x13.CALLPUT).Trim();
                            STKPRC = new string(MOBRESPONSE0x13.STKPRC).Trim();


                            if (new string(MOBRESPONSE0x13.COMTYPE) == "0") // systex comtype=0 is future
                            {
                                strReturn = _DataAgent.getProductId("1", COMNO, COMYM, "", "");
                            }
                            else
                            {
                                strReturn = _DataAgent.getProductId("2", COMNO, COMYM, CALLPUT, STKPRC);
                            }
                            productId = strReturn[0].PadRight(10, ' ');
                            closeprice = strReturn[1];
                            dsc = strReturn[2].PadRight(10, ' '); ;

                            //byte[] tmp = new byte[20];
                            //Array.Copy(buffer, 49, tmp, 0, 20);
                            //Array.Copy(ASCIIEncoding.Default.GetBytes(productId + dsc), 0, buffer, 49, 20);
                            //ff.AddRange(buffer);
                            //ff.AddRange(tmp);
                            //buffer = ff.ToArray();
                            byte[] tmp = new byte[20 + buffer.Length];
                            Array.Copy(buffer, 0, tmp, 0, buffer.Length);
                            tmp[tmp.Length - 1] = buffer[buffer.Length - 1];
                            Array.Copy(buffer, 49, tmp, tmp.Length - 20 - 1, 20);
                            if (item.SYSTEMCODE != "VIP")
                                Array.Copy(ASCIIEncoding.Default.GetBytes(productId + dsc), 0, tmp, 49, 20);
                            buffer = tmp;
                        }




                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received006://當日損益查詢回覆 systex Format
                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received008://單式即時部位查詢回覆 systex Format
                        if (buffer[26] == 0x0a)
                        {
                        }
                        else
                        {
                            AccountSockClientParserFunction.MOBRESPONSE0x57 MOBRESPONSE0x57 = new AccountSockClientParserFunction.MOBRESPONSE0x57();
                            AccountSockClientParserFunction.ParserStruct<AccountSockClientParserFunction.MOBRESPONSE0x57>
                                .ByteArrayToStructure(buffer, 0, ref MOBRESPONSE0x57);

                            COMNO = new string(MOBRESPONSE0x57.COMNO).Trim();
                            COMYM = new string(MOBRESPONSE0x57.COMYM).Trim();
                            CALLPUT = new string(MOBRESPONSE0x57.CALLPUT).Trim();
                            STKPRC = new string(MOBRESPONSE0x57.STKPRC).Trim();

                            if (CALLPUT == "N") // systex comtype=0 is future
                            {
                                strReturn = _DataAgent.getProductId("1", COMNO, COMYM, "", "");
                            }
                            else
                            {
                                strReturn = _DataAgent.getProductId("2", COMNO, COMYM, CALLPUT, STKPRC);
                            }
                            productId = strReturn[0].PadRight(10, ' ');
                            closeprice = strReturn[1];
                            dsc = strReturn[2].PadRight(10, ' '); ;



                            //byte[] tmp = new byte[20];
                            //Array.Copy(buffer, 28, tmp, 0, 20);
                            //Array.Copy(ASCIIEncoding.Default.GetBytes(productId + dsc), 0, buffer, 28, 20);
                            //ff.AddRange(buffer);
                            //ff.AddRange(tmp);



                            byte[] tmp = new byte[20 + buffer.Length];
                            Array.Copy(buffer, 0, tmp, 0, buffer.Length);
                            tmp[tmp.Length - 1] = buffer[buffer.Length - 1];
                            Array.Copy(buffer, 28, tmp, tmp.Length - 20 - 1, 20);
                            if (item.SYSTEMCODE != "VIP")
                                Array.Copy(ASCIIEncoding.Default.GetBytes(productId + dsc), 0, tmp, 28, 20);
                            buffer = tmp;






                        }
                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received010://即時組合部位查詢回覆 systex Format
                        SendDGWToAP(ref item, "", buffer);
                        break;
                    //case ReceivedAccountAcion.Received012://當日成交資料查詢回覆 systex Format
                    //    SendDGWToAP(ref item, "", buffer);
                    //    break;
                    case ReceivedAccountAcion.Received014://當日平倉資料查詢回覆 psg Format 但有加仿SYSTEX HEAD  ex head +psg

                        SendDGWToAP(ref item, "", buffer);
                        break;

                    case ReceivedAccountAcion.Received016://出入金資料查詢回覆 psg Format  但有加仿SYSTEX HEAD  ex head +psg

                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received018://未平倉彙總查詢 psg Format  但有加仿SYSTEX HEAD  ex head +psg


                        if (buffer[18 + 1] == 0x30) //no data  18 +systex 長度
                        {
                        }
                        else
                        {
                            AccountSockClientParserFunction.PSGRESPONSE018 psg18 = new AccountSockClientParserFunction.PSGRESPONSE018();
                            AccountSockClientParserFunction.ParserStruct<AccountSockClientParserFunction.PSGRESPONSE018>
                                .ByteArrayToStructure(buffer, 1, ref psg18);

                            string COMMODX = new string(psg18.COMMODX).Trim();

                            dsc = "";
                            DataAgent.ProductInfo info = _DataAgent.getProductInfoByProductId(COMMODX);
                            dsc = info.ProductShortDsc + "," + info.ProductShortDsc2;

                            //ff.AddRange(buffer);
                            //ff.AddRange(ASCIIEncoding.Default.GetBytes(dsc));
                            byte[] bytdsc = ASCIIEncoding.Default.GetBytes(dsc);

                            // buffer = ff.ToArray();
                            byte[] tmp = new byte[bytdsc.Length + buffer.Length];

                            Array.Copy(buffer, 0, tmp, 0, buffer.Length);
                            tmp[tmp.Length - 1] = buffer[buffer.Length - 1];
                            Array.Copy(bytdsc, 0, tmp, tmp.Length - bytdsc.Length - 1, bytdsc.Length);

                            buffer = tmp;
                        }




                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received020://高風險查詢 psg Format  但有加仿SYSTEX HEAD  ex head +psg

                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received022://高風險查詢低於25% psg Format  但有加仿SYSTEX HEAD  ex head +psg

                        SendDGWToAP(ref item, "", buffer);
                        break;
                    case ReceivedAccountAcion.Received999://資料異常回覆  但有加仿SYSTEX HEAD  ex head +psg

                        SendDGWToAP(ref item, "", buffer);
                        break;
                }
            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "RI_Receive:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        public void RIFor2_Receive(ReceivedAccountAcion Action, byte[] buffer)
        {
            try
            {
                string networkid = ASCIIEncoding.ASCII.GetString(buffer, 3, 8);

                AccountItem item = _TRANMoneyQueryCore.FindSAEA(networkid);
                item.T4 = Date.NowTime().ToString("HH:mm:ss.fff");
                SendDGWToAP(ref item, "", buffer);
            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "RIFor2_Receive:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }

        public void RIFor3_Receive(ReceivedAccountAcion Action, byte[] buffer)
        {
            try
            {
                string networkid = ASCIIEncoding.ASCII.GetString(buffer, 4, 9);

                byte[] tmp = new byte[256];
                AccountItem item = _MoneyQueryCore.FindSAEA(networkid);
                item.T4 = Date.NowTime().ToString("HH:mm:ss.fff");
                AccountSockClientParserFunction.PSGRESPONSEWITHDRAW PSGRESPONSEWITHDRAW = new AccountSockClientParserFunction.PSGRESPONSEWITHDRAW();
                AccountSockClientParserFunction.ParserStruct<AccountSockClientParserFunction.PSGRESPONSEWITHDRAW>
                    .ByteArrayToStructure(buffer, 1, ref PSGRESPONSEWITHDRAW);

                SendDGWToAP(ref item, "", buffer);
                _MoneyQueryCore.RemoveSAEA(networkid);
                /*1.出金申請    2.取消
3.國內外互轉申請
4.出金申請(全出)
5.換匯申請(國外期貨only)*/

                if (new string(PSGRESPONSEWITHDRAW.TYPE) == "2") // 取消
                {
                    SaveDB.UpdateWITHDRAWItemDelForReply saveitem = new SaveDB.UpdateWITHDRAWItemDelForReply();
                    saveitem.SEQNO = new string(PSGRESPONSEWITHDRAW.SEQNO);
                    saveitem.TYPE = new string(PSGRESPONSEWITHDRAW.TYPE);
                    saveitem.COMPANY = new string(PSGRESPONSEWITHDRAW.COMPANY);
                    saveitem.ACTNO = new string(PSGRESPONSEWITHDRAW.ACTNO);
                    saveitem.OPDATE = new string(PSGRESPONSEWITHDRAW.MDATE);
                    saveitem.OPTIME = new string(PSGRESPONSEWITHDRAW.MTIME);
                    saveitem.CODE = new string(PSGRESPONSEWITHDRAW.CODE);
                    _DataAgent.mobj_SaveDB.PutData2Queue(saveitem);
                }
                else
                {
                    SaveDB.UpdateWITHDRAWItem saveitem = new SaveDB.UpdateWITHDRAWItem();
                    string MAXAMOUNT = new string(PSGRESPONSEWITHDRAW.MAXAMOUNT);
                    MAXAMOUNT = MAXAMOUNT.Substring(0, 12) + "." + MAXAMOUNT.Substring(12, 2).ToString();

                    string NETVALUE = new string(PSGRESPONSEWITHDRAW.NETVALUE);
                    NETVALUE = NETVALUE.Substring(0, 12) + "." + NETVALUE.Substring(12, 2).ToString();


                    string IAMT = new string(PSGRESPONSEWITHDRAW.IAMT);
                    IAMT = IAMT.Substring(0, 12) + "." + IAMT.Substring(12, 2).ToString();

                    string CASHOUT = new string(PSGRESPONSEWITHDRAW.RAMT);
                    CASHOUT = CASHOUT.Substring(0, 12) + "." + CASHOUT.Substring(12, 2).ToString();


                    saveitem.SEQNO = new string(PSGRESPONSEWITHDRAW.SEQNO);

                    saveitem.COMPANY = new string(PSGRESPONSEWITHDRAW.COMPANY);
                    saveitem.ACTNO = new string(PSGRESPONSEWITHDRAW.ACTNO);

                    saveitem.MAXAMOUNT = MAXAMOUNT;

                    saveitem.NETVALUE = (new string(PSGRESPONSEWITHDRAW.SNETVALUE)) == "-" ? "-" : "" + NETVALUE;

                    saveitem.IAMT = IAMT;
                    saveitem.CASHOUT = CASHOUT;

                    saveitem.OUTNO = new string(PSGRESPONSEWITHDRAW.OUTNO);
                    saveitem.INNO = new string(PSGRESPONSEWITHDRAW.TONO);
                    saveitem.OPDATE = new string(PSGRESPONSEWITHDRAW.MDATE);
                    saveitem.CODE = new string(PSGRESPONSEWITHDRAW.CODE);

                    saveitem.OPTIME = new string(PSGRESPONSEWITHDRAW.MTIME);




                    _DataAgent.mobj_SaveDB.PutData2Queue(saveitem);
                }



            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "RIFor3_Receive:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }



        public void SQuotaAPI_FQueryData(string Seq, string Format, string Data)
        {
            try
            {
                AccountItem item = _QueryCore.FindSAEA(Seq.Trim());
                string head = "";
                switch (Format)
                {
                    case "20":
                        head = ASCIIEncoding.Default.GetString(new byte[1] { 0x70 });
                        break;
                    case "21":
                        head = ASCIIEncoding.Default.GetString(new byte[1] { 0x72 });
                        break;
                    case "60":
                        head = ASCIIEncoding.Default.GetString(new byte[1] { 0x76 });
                        break;
                    case "80":
                        head = ASCIIEncoding.Default.GetString(new byte[1] { 0x77 });
                        break;

                }
                item.T4 = Date.NowTime().ToString("HH:mm:ss.fff");
                if (Data.Trim().Length > 0) //判斷是否有資料
                {
                    item.ReponsetData = Data;
                    _QueryCore.AddSAEA(Seq.Trim(), item);
                    SendDGWToAP(ref item, "", ASCIIEncoding.Default.GetBytes(head + Data));
                }
                else
                {
                    if (Format == "20")//v1.0.0.28 added by peter on 20180205 避免查五檔時多回傳@符號
                    {
                        if (item.ReponsetData.Trim().Length == 0)
                        {
                            //TXFK7@13450004@10736@1@115089@58047@57222@13450002@13450004@0@
                            string data = _DataAgent.getClosePrice(item.RequestData);
                            data = item.RequestData.Trim() + "@@" + data + "@@@@@@@";
                            SendDGWToAP(ref item, "", ASCIIEncoding.Default.GetBytes(head + data));
                        }
                    }
                    SendDGWToAP(ref item, "", ASCIIEncoding.Default.GetBytes(head + "0"));

                }

            }
            catch (Exception ex)
            {
                WriteLog("DataAgentLog", "SQuotaAPI_FQueryData:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
    }
}

