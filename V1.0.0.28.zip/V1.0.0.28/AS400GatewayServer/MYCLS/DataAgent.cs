﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Threading;
using System.Net;
using System.Net.Sockets;

using System.IO;
using System.Windows.Forms;
using com.ddsc.BI.Account;
using com.ddsc.net;

using com.ddsc.nets;
using com.ddsc.nets.server;
using com.ddsc.tool;
using com.ddsc.core;
namespace AS400GatewayServer.MYCLS
{
    public class DataAgent : DisplayMsg
    {
        public static LogManager _LM;
        public static string TradeDate = "";
        public static string BASEPATH = "";
        public static string CURRENTPATH = "";
        public SQuotaAPI.SQuotaAPI _SQuotaAPI;
        //V1.0.0.9 Added by peter 20130829
        private object _AS400ReplysLocker = new object();

        private com.ddsc.core.QueuePoolByLock<byte[]> AS400ReplyQ = null;
        private com.ddsc.core.QueuePoolByLock<byte[]> AS400ReplyQ2 = null;
        private com.ddsc.core.QueuePoolByLock<byte[]> AS400ReplyQ3 = null;





        public com.ddsc.BI.Account.ReplyIntegration _RI;

        private com.ddsc.nets.server.TcpClient _AS400Client;

        public com.ddsc.nets.server.TcpClient AS400Client
        {
            get { return _AS400Client; }
            set { _AS400Client = value; }
        }

        private com.ddsc.nets.server.TcpServer _AS400ReplyServer;

        public com.ddsc.nets.server.TcpServer AS400ReplyServer
        {
            get { return _AS400ReplyServer; }
            set { _AS400ReplyServer = value; }
        }
        //added by peter V1.0.0.4
        private com.ddsc.nets.server.TcpClient _AS400ClientFor2;
        //added by peter V1.0.0.4
        public com.ddsc.nets.server.TcpClient AS400ClientFor2
        {
            get { return _AS400ClientFor2; }
            set { _AS400ClientFor2 = value; }
        }
        //added by peter V1.0.0.4
        private com.ddsc.nets.server.TcpServer _AS400ReplyServerFor2;
        //added by peter V1.0.0.4
        public com.ddsc.nets.server.TcpServer AS400ReplyServerFor2
        {
            get { return _AS400ReplyServerFor2; }
            set { _AS400ReplyServerFor2 = value; }
        }

        //added by peter V1.0.0.11
        private com.ddsc.nets.server.TcpClient _AS400ClientFor3;
        //added by peter V1.0.0.11
        public com.ddsc.nets.server.TcpClient AS400ClientFor3
        {
            get { return _AS400ClientFor3; }
            set { _AS400ClientFor3 = value; }
        }
        //added by peter V1.0.0.11 出入金
        private com.ddsc.nets.server.TcpServer _AS400ReplyServerFor3;
        //added by peter V1.0.0.11出入金
        public com.ddsc.nets.server.TcpServer AS400ReplyServerFor3
        {
            get { return _AS400ReplyServerFor3; }
            set { _AS400ReplyServerFor3 = value; }
        }

        private delegate void parseInfoDataDelegate(string strData);


        public SaveDB mobj_SaveDB;

        public int mint_CurrentSerial = 0;


        public int mint_CurrentSerialFor3 = 0;
        /// <summary>
        /// 存放期貨商品檔
        /// </summary>
        public DataTable mdt_FutureData;
        /// <summary>
        /// 存放選擇權商品
        /// </summary>
        public DataTable mdt_OptionData;

        public DataTable mdt_I020;
        public DataTable mdt_I060;//added by samantha20160203現貨價
        private bool _AS400Ack = false;
        private bool _AS400For2Ack = false;
        //added by peter V1.0.0.11出入金
        private bool _AS400For3Ack = false;

        private SAEAServer _SAEAServer;
        TradeStringHandler _T;

        public DataAgent()
        {

        }

        ~DataAgent()
        {
            dispose();
        }
        public void dispose()
        {

            try
            {
               
                if (mobj_SaveDB != null)
                {
                    mobj_SaveDB.SaveDBDispose();
                }
                close();
                if (_T != null)
                {
                    _T.Dispose();
                }

                if (_LM != null)
                {
                    _LM.Dispose();
                }




            }
            catch (Exception ex)
            {
            }




            GC.SuppressFinalize(this);
        }


        private void init()
        {
            _LM = new LogManager();
            DataAgent.BASEPATH = "";

            DataAgent.BASEPATH = DataAgent.BASEPATH.Trim().Length == 0 ? AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() : DataAgent.BASEPATH;

            int begin = int.Parse(Properties.Settings.Default.ClearDataTime);
            int now = int.Parse(DateTime.Now.ToString("HHmm"));

            if (begin > now)
            {
                CURRENTPATH = DataAgent.TradeDate = DateTime.Now.AddDays(-1).ToString("yyyyMMdd");
            }
            else
            {
                CURRENTPATH = DataAgent.TradeDate = DateTime.Now.ToString("yyyyMMdd");
            }


        }


        public void start()
        {
            try
            {
                init();
                _LM.AddFileWriter("DataAgentLog", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "DataAgentLog", ""));

                _LM.AddFileWriter("Log", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "Log", ""));

                _LM.AddFileWriter("AS400ClientLogSend", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogSend", ""));
                _LM.AddFileWriter("AS400ClientLogRcv", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogRcv", ""));
                _LM.AddFileWriter("AS400ClientLogError", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogError", ""));
                _LM.AddFileWriter("AS400ServerReplyLog", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLog", ""));
                _LM.AddFileWriter("AS400ServerReplyLogError", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLogError", ""));

                _LM.AddFileWriter("AS400ClientLogSendFor2", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogSendFor2", ""));
                _LM.AddFileWriter("AS400ClientLogRcvFor2", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogRcvFor2", ""));
                _LM.AddFileWriter("AS400ClientLogErrorFor2", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogErrorFor2", ""));


                _LM.AddFileWriter("AS400ClientLogSendFor3", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogSendFor3", ""));
                _LM.AddFileWriter("AS400ClientLogRcvFor3", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogRcvFor3", ""));
                _LM.AddFileWriter("AS400ClientLogErrorFor3", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ClientLogErrorFor3", ""));




                _LM.AddFileWriter("AS400ServerReplyLogSendFor2", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLogSendFor2", ""));
                _LM.AddFileWriter("AS400ServerReplyLogRcvFor2", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLogRcvFor2", ""));
                _LM.AddFileWriter("AS400ServerReplyLogErrorFor2", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLogErrorFor2", ""));


                _LM.AddFileWriter("AS400ServerReplyLogSendFor3", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLogSendFor3", ""));
                _LM.AddFileWriter("AS400ServerReplyLogRcvFor3", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLogRcvFor3", ""));
                _LM.AddFileWriter("AS400ServerReplyLogErrorFor3", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "AS400ServerReplyLogErrorFor3", ""));

                _LM.AddFileWriter("MarketClient", new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "MarketClient", ""));


                // mint_CurrentSerial = ReadSerial();

                mdt_I020 = new DataTable();
                mdt_I020.Columns.Add("COMMODITYID");
                mdt_I020.Columns.Add("MatchPrice");
                mdt_I020.Columns.Add("isclose");
                mdt_I020.Columns.Add("HighPrice");
                mdt_I020.Columns.Add("LowPrice");
                mdt_I020.PrimaryKey = new DataColumn[] { mdt_I020.Columns["COMMODITYID"] };

                mdt_I060 = new DataTable();
                mdt_I060.Columns.Add("kindid");
                mdt_I060.Columns.Add("stockprice");
                mdt_I060.PrimaryKey = new DataColumn[] { mdt_I060.Columns["kindid"] };

                mobj_SaveDB = new SaveDB();
                getINIData();





                enableAS400Server(true);
                enableAS400Client(true);
                enableAS400ServerFor2(true);
                enableAS400ClientFor2(true);

                enableAS400ServerFor3(true);
                enableAS400ClientFor3(true);

                _RI = new ReplyIntegration();
                _RI.Receive += new ReplyIntegration.ReceiveEventHandler(_RI_Receive);
                _RI.ReceiveFor2 += new ReplyIntegration.ReceiveEventHandlerFor2(_RI_ReceiveFor2);
                _RI.ReceiveFor3 += new ReplyIntegration.ReceiveEventHandlerFor3(_RI_ReceiveFor3);
                _RI.Error += new ReplyIntegration.ErrorEventHandler(_RI_Error);


                _AS400Ack = bool.Parse(Properties.Settings.Default.AS400Ack);
                _AS400For2Ack = bool.Parse(Properties.Settings.Default.AS400For2Ack);
                _AS400For3Ack = bool.Parse(Properties.Settings.Default.AS400For3Ack);

                AS400ReplyQ = new com.ddsc.core.QueuePoolByLock<byte[]>(1);
                AS400ReplyQ.ParameterExcute += new com.ddsc.core.QueuePoolByLock<byte[]>.ParameterHandler(AS400ReplyQ_ParameterExcute);
                AS400ReplyQ.Go();

                try
                {
                    _SAEAServer = new SAEAServer(8196, 8196, 10000);
                    _SAEAServer.Actived += new ActivedEventHandler(_SAEAServer_Actived);
                    _SAEAServer.Disconnected += new DisconnectedEventHandler(_SAEAServer_Disconnected);
                    _SAEAServer.Connected += new ConnectedEventHandler(_SAEAServer_Connected);
                    _SAEAServer.Received += new ReceiveEventHandler(_SAEAServer_Received);
                    _SAEAServer.Error += new SAEAServer.ErrorHandler(_SAEAServer_Error);
                    _SAEAServer.Listen(Properties.Settings.Default.SAEAServerIP, int.Parse(Properties.Settings.Default.SAEAServerPort));
                    //_DisplayItem.displayChangeCount(_SAEAServer.NumberOfConnectedSockets);

                }
                catch (Exception ex)
                {
                    _LM.WriteLog("DataAgentLog", "SAEAServer Start:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
                }


                _T = new TradeStringHandler(null);
                _T.DataAgent = this;
                _T.SAEA = _SAEAServer;

                enabledMarketInfoSocket(true);
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "Start Error:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());

            }

        }

        void _SQuotaAPI_Sent(SQuotaAPI.SQuotaAPI a, byte[] buffer)
        {
            _LM.WriteLog("MarketClient", buffer);
        }

        void _SQuotaAPI_FQueryData(string Seq, string Format, string Data)
        {
            _LM.WriteLog("MarketClient", Seq + " " + Format + " " + Data);
            _T.SQuotaAPI_FQueryData(Seq, Format, Data);
        }

        void _SQuotaAPI_Disconnected(string kind)
        {
            displayPicStatus("APInfo", "Disconnected");
            _LM.WriteLog("MarketClient", "行情連線失敗");

        }

        void _SQuotaAPI_Connected(string kind)
        {
            _LM.WriteLog("MarketClient", "行情連線成功" + kind);

            displayPicStatus("APInfo", "Connected");
            displayStatusMsg("MarketClient Connected on " + Properties.Settings.Default.MarketInfoIP + ":" + Properties.Settings.Default.MarketInfoPort);


        }

        void _SQuotaAPI_Alive()
        {
            _LM.WriteLog("MarketClient", "Alive");
        }
        //===================SAEA===================
        void _SAEAServer_Actived()
        {
            if (_SAEAServer.Active)
            {
                displayPicStatus("SaeaServer", "Connected");
                displayStatusMsg("SaeaServer listen on " + Properties.Settings.Default.SAEAServerIP + ":" + Properties.Settings.Default.SAEAServerPort);
            }
            else
            {
                displayPicStatus("SaeaServer", "Disconnected");

            }
        }
        void _SAEAServer_Disconnected(DisconnectedEventArgs Saea)
        {
            try
            {   //added by peter 20130104 V1.0.0.8
                //UserInfo u = _t.AccountCore.FindUserInfo(Saea.SocketAsyncEventArgs);
                //if (u != null)
                //{
                //    string[] arrPutIPLogoutCmd = new string[1];
                //    arrPutIPLogoutCmd[0] = "UPDATE  [dbo].[tblTradeIPLog]"
                //      + "SET [logoutTime] ='" + DateTime.Now.ToString("HH:mm:ss") + "',[status] = ''  "
                //    + "WHERE userid='" + u.UserId + "' and ip='" + Saea.SocketAsyncEventArgs.AcceptSocket.RemoteEndPoint.ToString().Split(':')[0] + "' and port='" + Saea.SocketAsyncEventArgs.AcceptSocket.RemoteEndPoint.ToString().Split(':')[1] + "' and  logintime ='" + u.LoginTime + "'";
                //    _t.SaveDB.PutData2Queue(arrPutIPLogoutCmd);
                //}

                //_DisplayItem.displayStatusMsg(Saea.Socket.RemoteEndPoint.ToString() + " 離開!");
                //_DisplayItem.displayRemoveConnections(Saea.Socket.RemoteEndPoint.ToString());
                //_LM.CloseWriteLog("SAEAServerLogRCV" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"));
                //_LM.CloseWriteLog("SAEAServerLogSend" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";"));
                ////_LM.CloseWriteLog("SAEAServerLogRCV1" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ""));
                ////_LM.CloseWriteLog("SAEAServerLogRCV2" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ""));
                ////_LM.CloseWriteLog("SAEAServerLogRCV3" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ""));
                //this._AccountCore.RemoveSAEA(Saea.SocketAsyncEventArgs);
                //_DisplayItem.displayChangeCount(_SAEAServer.NumberOfConnectedSockets);

                displayRemoveConnections(Saea.Socket.RemoteEndPoint.ToString());
                displayStatusMsg(Saea.Socket.RemoteEndPoint.ToString() + " 登出!");


                string RemoteIP = (((System.Net.IPEndPoint)Saea.Socket.RemoteEndPoint).Address.ToString());

                _LM.WriteLog("SAEAServerLogRCV" + RemoteIP, Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";") + " disconnected");
                _LM.WriteLog("SAEAServerLogSend" + RemoteIP, Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";") + " disconnected");
            }
            catch (Exception ex)
            {
                // _LM.WriteLog("DataAgentLog", "_SAEAServer_Disconnected" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void _SAEAServer_Connected(ConnectedEventArgs Saea)
        {
            try
            {

                //_DisplayItem.displayAddConnections(Saea.Socket.RemoteEndPoint.ToString());
                //_DisplayItem.displayChangeCount(_SAEAServer.NumberOfConnectedSockets);

                string RemoteIP = (((System.Net.IPEndPoint)Saea.Socket.RemoteEndPoint).Address.ToString());
                if (!_LM.checkFileWriter("SAEAServerLogRCV" + RemoteIP))
                {
                    _LM.AddFileWriter("SAEAServerLogRCV" + RemoteIP, new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "SAEAServerLogRCV" + RemoteIP, @"\connections"));
                    _LM.AddFileWriter("SAEAServerLogSend" + RemoteIP, new FileWriter(DataAgent.BASEPATH, CURRENTPATH, "SAEAServerLogSend" + RemoteIP, @"\connections"));
                }
                ////_LM.AddFileWriter("SAEAServerLogRCV1" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", "")  , new FileWriter("SAEAServerLogRCV1" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", "")  ));
                ////_LM.AddFileWriter("SAEAServerLogRCV2" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ""), new FileWriter("SAEAServerLogRCV2" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", "")));
                ////_LM.AddFileWriter("SAEAServerLogRCV3" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", ""), new FileWriter("SAEAServerLogRCV3" + Saea.Socket.RemoteEndPoint.ToString().Replace(":", "")));
                displayAddConnections(Saea.Socket.RemoteEndPoint.ToString());
                displayStatusMsg(Saea.Socket.RemoteEndPoint.ToString() + " 登入!");
                _LM.WriteLog("SAEAServerLogRCV" + RemoteIP, Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";") + " connected");
                _LM.WriteLog("SAEAServerLogSend" + RemoteIP, Saea.Socket.RemoteEndPoint.ToString().Replace(":", ";") + " connected");

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "_SAEAServer_Connected_" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }
        }
        void _SAEAServer_Received(ReceiveEventArgs Saea)
        {

            try
            {
                _T.ParseDDSCData(Saea.SocketAsyncEventArgs, Saea.ReceiveBytes);
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "_SAEAServer_Received:" + ex.Message + ex.StackTrace.ToString() + ex.Source.ToString());
            }

        }

        void _SAEAServer_Error(string msg)
        {
            _LM.WriteLog("DataAgentLog", "SAEAServer_Error_" + msg);

        }




        void AS400ReplyQ_ParameterExcute(byte[] raw)
        {
            _RI.ResolveReceive(raw);
        }




        /// <summary>
        /// 控制行情Socket物件開啟或關閉
        /// </summary>
        public void enabledMarketInfoSocket(bool bol_status)
        {
            try
            {
                if (bol_status)
                {
                    _SQuotaAPI = new SQuotaAPI.SQuotaAPI();
                    _SQuotaAPI.Alive += new SQuotaAPI.SQuotaAPI.AliveHandler(_SQuotaAPI_Alive);
                    _SQuotaAPI.Connected += new SQuotaAPI.SQuotaAPI.ConnectedHandler(_SQuotaAPI_Connected);
                    _SQuotaAPI.Disconnected += new SQuotaAPI.SQuotaAPI.DisconnectedHandler(_SQuotaAPI_Disconnected);
                    _SQuotaAPI.FQueryData += new SQuotaAPI.SQuotaAPI.QueryDataHandler(_SQuotaAPI_FQueryData);
                    _SQuotaAPI.Sent += new SQuotaAPI.SQuotaAPI.SentEventHandler(_SQuotaAPI_Sent);
                    _SQuotaAPI.FConnect(Properties.Settings.Default.MarketInfoIP, int.Parse(Properties.Settings.Default.MarketInfoPort));
                }
                else
                {
                    if (_SQuotaAPI != null)
                    {

                        _SQuotaAPI.Alive -= new SQuotaAPI.SQuotaAPI.AliveHandler(_SQuotaAPI_Alive);
                        _SQuotaAPI.Connected -= new SQuotaAPI.SQuotaAPI.ConnectedHandler(_SQuotaAPI_Connected);
                        _SQuotaAPI.Disconnected -= new SQuotaAPI.SQuotaAPI.DisconnectedHandler(_SQuotaAPI_Disconnected);
                        _SQuotaAPI.FQueryData -= new SQuotaAPI.SQuotaAPI.QueryDataHandler(_SQuotaAPI_FQueryData);
                        _SQuotaAPI.Sent -= new SQuotaAPI.SQuotaAPI.SentEventHandler(_SQuotaAPI_Sent);
                        _SQuotaAPI.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                //  mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }



        private void enableAS400Client(bool status)
        {
            if (status)
            {
                _AS400Client = new com.ddsc.nets.server.TcpClient();
                _AS400Client.HandShakeBuffer = com.ddsc.BI.Account.AccountSockClientParserFunction.getPSGHandShake(Properties.Settings.Default.AS400ClientPort);
                _AS400Client.Disconnected += new com.ddsc.nets.server.TcpClient.disconnectedHandler(_AS400Client_Disconnected);
                _AS400Client.connected += new com.ddsc.nets.server.TcpClient.connectedHandler(_AS400Client_connected);
                _AS400Client.Sended += new com.ddsc.nets.server.TcpClient.SendedHandler(_AS400Client_Sended);
                _AS400Client.Received += new com.ddsc.nets.server.TcpClient.ReceivedHandler(_AS400Client_Received);
                _AS400Client.Error += new com.ddsc.nets.server.TcpClient.ErrorHandler(_AS400Client_Error);
                _AS400Client.Connect(Properties.Settings.Default.AS400ClientIP, int.Parse(Properties.Settings.Default.AS400ClientPort));

            }
            else
            {
                if (_AS400Client != null)
                {
                    _AS400Client.Disconnected -= new com.ddsc.nets.server.TcpClient.disconnectedHandler(_AS400Client_Disconnected);
                    _AS400Client.connected -= new com.ddsc.nets.server.TcpClient.connectedHandler(_AS400Client_connected);
                    _AS400Client.Sended -= new com.ddsc.nets.server.TcpClient.SendedHandler(_AS400Client_Sended);
                    _AS400Client.Received -= new com.ddsc.nets.server.TcpClient.ReceivedHandler(_AS400Client_Received);
                    _AS400Client.Error -= new com.ddsc.nets.server.TcpClient.ErrorHandler(_AS400Client_Error);

                    _AS400Client.Close();
                }
            }
        }
        private void enableAS400Server(bool status)
        {

            if (status)
            {
                _AS400ReplyServer = new com.ddsc.nets.server.TcpServer();
                _AS400ReplyServer.Disconnected += new TcpServer.DisconnectedHandler(_AS400ReplyServer_Disconnected);
                _AS400ReplyServer.connected += new com.ddsc.nets.server.TcpServer.connectedHandler(_AS400ReplyServer_connected);
                _AS400ReplyServer.Actived += new com.ddsc.nets.server.TcpServer.ActivedHandler(_AS400ReplyServer_Actived);
                _AS400ReplyServer.Error += new com.ddsc.nets.server.TcpServer.ErrorHandler(_AS400ReplyServer_Error);
                _AS400ReplyServer.Received += new TcpServer.ReceivedHandler(_AS400ReplyServer_Received);
                _AS400ReplyServer.Sended += new com.ddsc.nets.server.TcpServer.SendedHandler(_AS400ReplyServer_Sended);
                _AS400ReplyServer.Listen(Properties.Settings.Default.AS400ReplyServerIP, int.Parse(Properties.Settings.Default.AS400ReplyServerPort));

            }
            else
            {
                if (_AS400ReplyServer != null)
                {
                    _AS400ReplyServer.Disconnected -= new TcpServer.DisconnectedHandler(_AS400ReplyServer_Disconnected);
                    _AS400ReplyServer.connected -= new com.ddsc.nets.server.TcpServer.connectedHandler(_AS400ReplyServer_connected);
                    _AS400ReplyServer.Actived -= new com.ddsc.nets.server.TcpServer.ActivedHandler(_AS400ReplyServer_Actived);
                    _AS400ReplyServer.Error -= new com.ddsc.nets.server.TcpServer.ErrorHandler(_AS400ReplyServer_Error);
                    _AS400ReplyServer.Received -= new TcpServer.ReceivedHandler(_AS400ReplyServer_Received);
                    _AS400ReplyServer.Sended -= new com.ddsc.nets.server.TcpServer.SendedHandler(_AS400ReplyServer_Sended);

                    _AS400ReplyServer.Close();
                }
            }
        }



        private void enableAS400ClientFor2(bool status)
        {
            if (status)
            {
                _AS400ClientFor2 = new com.ddsc.nets.server.TcpClient();
                _AS400ClientFor2.HandShakeBuffer = com.ddsc.BI.Account.AccountSockClientParserFunction.getPSGHandShakeFor2(Properties.Settings.Default.AS400ClientFor2Port);
                _AS400ClientFor2.Disconnected += new com.ddsc.nets.server.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor2);
                _AS400ClientFor2.connected += new com.ddsc.nets.server.TcpClient.connectedHandler(_AS400Client_connectedFor2);
                _AS400ClientFor2.Sended += new com.ddsc.nets.server.TcpClient.SendedHandler(_AS400Client_SendedFor2);
                _AS400ClientFor2.Received += new com.ddsc.nets.server.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor2);
                _AS400ClientFor2.Error += new com.ddsc.nets.server.TcpClient.ErrorHandler(_AS400Client_ErrorFor2);
                _AS400ClientFor2.Connect(Properties.Settings.Default.AS400ClientFor2IP, int.Parse(Properties.Settings.Default.AS400ClientFor2Port));

            }
            else
            {
                if (_AS400ClientFor2 != null)
                {
                    _AS400ClientFor2.Disconnected -= new com.ddsc.nets.server.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor2);
                    _AS400ClientFor2.connected -= new com.ddsc.nets.server.TcpClient.connectedHandler(_AS400Client_connectedFor2);
                    _AS400ClientFor2.Sended -= new com.ddsc.nets.server.TcpClient.SendedHandler(_AS400Client_SendedFor2);
                    _AS400ClientFor2.Received -= new com.ddsc.nets.server.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor2);
                    _AS400ClientFor2.Error -= new com.ddsc.nets.server.TcpClient.ErrorHandler(_AS400Client_ErrorFor2);

                    _AS400ClientFor2.Close();
                }
            }
        }
        private void enableAS400ServerFor2(bool status)
        {

            if (status)
            {
                _AS400ReplyServerFor2 = new com.ddsc.nets.server.TcpServer();
                _AS400ReplyServerFor2.Disconnected += new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor2);
                _AS400ReplyServerFor2.connected += new com.ddsc.nets.server.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor2);
                _AS400ReplyServerFor2.Actived += new com.ddsc.nets.server.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor2);
                _AS400ReplyServerFor2.Error += new com.ddsc.nets.server.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor2);
                _AS400ReplyServerFor2.Received += new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor2);
                _AS400ReplyServerFor2.Sended += new com.ddsc.nets.server.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor2);
                _AS400ReplyServerFor2.Listen(Properties.Settings.Default.AS400ReplyServerFor2IP, int.Parse(Properties.Settings.Default.AS400ReplyServerFor2Port));

            }
            else
            {
                if (_AS400ReplyServerFor2 != null)
                {
                    _AS400ReplyServerFor2.Disconnected -= new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor2);
                    _AS400ReplyServerFor2.connected -= new com.ddsc.nets.server.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor2);
                    _AS400ReplyServerFor2.Actived -= new com.ddsc.nets.server.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor2);
                    _AS400ReplyServerFor2.Error -= new com.ddsc.nets.server.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor2);
                    _AS400ReplyServerFor2.Received -= new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor2);
                    _AS400ReplyServerFor2.Sended -= new com.ddsc.nets.server.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor2);

                    _AS400ReplyServerFor2.Close();
                }
            }
        }

        //added by peter V1.0.0.11 出入金
        private void enableAS400ClientFor3(bool status)
        {
            if (status)
            {
                _AS400ClientFor3 = new com.ddsc.nets.server.TcpClient();
                _AS400ClientFor3.HandShakeBuffer = com.ddsc.BI.Account.AccountSockClientParserFunction.getPSGHandShakeFor3(Properties.Settings.Default.AS400ClientFor3Port);
                _AS400ClientFor3.Disconnected += new com.ddsc.nets.server.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor3);
                _AS400ClientFor3.connected += new com.ddsc.nets.server.TcpClient.connectedHandler(_AS400Client_connectedFor3);
                _AS400ClientFor3.Sended += new com.ddsc.nets.server.TcpClient.SendedHandler(_AS400Client_SendedFor3);
                _AS400ClientFor3.Received += new com.ddsc.nets.server.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor3);
                _AS400ClientFor3.Error += new com.ddsc.nets.server.TcpClient.ErrorHandler(_AS400Client_ErrorFor3);
                _AS400ClientFor3.Connect(Properties.Settings.Default.AS400ClientFor3IP, int.Parse(Properties.Settings.Default.AS400ClientFor3Port));

            }
            else
            {
                if (_AS400ClientFor3 != null)
                {
                    _AS400ClientFor3.Disconnected -= new com.ddsc.nets.server.TcpClient.disconnectedHandler(_AS400Client_DisconnectedFor3);
                    _AS400ClientFor3.connected -= new com.ddsc.nets.server.TcpClient.connectedHandler(_AS400Client_connectedFor3);
                    _AS400ClientFor3.Sended -= new com.ddsc.nets.server.TcpClient.SendedHandler(_AS400Client_SendedFor3);
                    _AS400ClientFor3.Received -= new com.ddsc.nets.server.TcpClient.ReceivedHandler(_AS400Client_ReceivedFor3);
                    _AS400ClientFor3.Error -= new com.ddsc.nets.server.TcpClient.ErrorHandler(_AS400Client_ErrorFor3);

                    _AS400ClientFor3.Close();
                }
            }
        }
        //added by peter V1.0.0.11 出入金
        private void enableAS400ServerFor3(bool status)
        {

            if (status)
            {
                _AS400ReplyServerFor3 = new com.ddsc.nets.server.TcpServer();
                _AS400ReplyServerFor3.Disconnected += new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor3);
                _AS400ReplyServerFor3.connected += new com.ddsc.nets.server.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor3);
                _AS400ReplyServerFor3.Actived += new com.ddsc.nets.server.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor3);
                _AS400ReplyServerFor3.Error += new com.ddsc.nets.server.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor3);
                _AS400ReplyServerFor3.Received += new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor3);
                _AS400ReplyServerFor3.Sended += new com.ddsc.nets.server.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor3);
                _AS400ReplyServerFor3.Listen(Properties.Settings.Default.AS400ReplyServerFor3IP, int.Parse(Properties.Settings.Default.AS400ReplyServerFor3Port));

            }
            else
            {
                if (_AS400ReplyServerFor3 != null)
                {
                    _AS400ReplyServerFor3.Disconnected -= new TcpServer.DisconnectedHandler(_AS400ReplyServer_DisconnectedFor3);
                    _AS400ReplyServerFor3.connected -= new com.ddsc.nets.server.TcpServer.connectedHandler(_AS400ReplyServer_connectedFor3);
                    _AS400ReplyServerFor3.Actived -= new com.ddsc.nets.server.TcpServer.ActivedHandler(_AS400ReplyServer_ActivedFor3);
                    _AS400ReplyServerFor3.Error -= new com.ddsc.nets.server.TcpServer.ErrorHandler(_AS400ReplyServer_ErrorFor3);
                    _AS400ReplyServerFor3.Received -= new TcpServer.ReceivedHandler(_AS400ReplyServer_ReceivedFor3);
                    _AS400ReplyServerFor3.Sended -= new com.ddsc.nets.server.TcpServer.SendedHandler(_AS400ReplyServer_SendedFor3);

                    _AS400ReplyServerFor3.Close();
                }
            }
        }


        //private void m_TradeSktServer_ActiveChanged(object sender, System.EventArgs e)
        //{
        //    try
        //    {
        //        if (mobj_TradeSocketServer.m_SocketServer.Active)
        //        {
        //            if (mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() == "0.0.0.0")
        //                displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[Listening on port " + mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");
        //            else
        //                displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[Listening on " + mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() + ":" + mobj_TradeSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");

        //            displayPicStatus(mobj_TradeSocketServer.mstr_name, "Connected");
        //        }
        //        else
        //        {
        //            displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":Server not accepting connections...");
        //            displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[Closed]");

        //            displayPicStatus(mobj_TradeSocketServer.mstr_name, "Disconnected");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //    }
        //}
        //private void m_TradeSktServer_Connection(object sender, Dart.PowerTCP.SslSockets.ConnectionEventArgs e)
        //{
        //    try
        //    {
        //        //取得連結IP
        //        string id = e.Tcp.RemoteEndPoint.ToString();
        //        try
        //        {
        //            //顯示client 連線訊息
        //            displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  Connection established");
        //            //選示連線ID
        //            displayAddConnections(mobj_TradeSocketServer.mstr_name + ":" + id);

        //            Connection conn = new Connection(e.Tcp, Application.StartupPath, "LogFileName", "Trade", this);
        //            lock (mobj_TradeClientCollection)
        //            {
        //                mobj_TradeClientCollection.Add(id, conn);
        //            }
        //            conn.Execute();

        //        }
        //        catch (Exception ex)
        //        {
        //            mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //            //顯示client 連線訊息
        //            displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  " + ex.Message.ToString());
        //            e.Tcp.Close();

        //        }
        //        finally
        //        {
        //            //顯示client 連線訊息
        //            displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  Connection closed");
        //            displayRemoveConnections(mobj_TradeSocketServer.mstr_name + ":" + id);
        //            lock (mobj_TradeClientCollection)
        //            {
        //                mobj_TradeClientCollection.Remove(id);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //    }
        //}
        //private void m_ReplySktServer_ActiveChanged(object sender, System.EventArgs e)
        //{
        //    try
        //    {
        //        if (mobj_ReplySendServer.m_SocketServer.Active)
        //        {
        //            if (mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Address.ToString() == "0.0.0.0")
        //                displayStatusMsg("APReply:[Listening on port " + mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");
        //            else
        //                displayStatusMsg("APReply:[Listening on " + mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Address.ToString() + ":" + mobj_ReplySendServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");

        //            displayPicStatus("APReply", "Connected");
        //        }
        //        else
        //        {
        //            displayStatusMsg("APReply:Server not accepting connections...");
        //            displayStatusMsg("APReply:[Closed]");

        //            displayPicStatus("APReply", "Disconnected");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //    }
        //}
        //private void m_ReplySktServer_Connection(object sender, Dart.PowerTCP.SslSockets.ConnectionEventArgs e)
        //{
        //    try
        //    {
        //        //取得連結IP
        //        string id = e.Tcp.RemoteEndPoint.ToString();
        //        try
        //        {
        //            //顯示client 連線訊息
        //            displayStatusMsg("APReply:[" + id + "]  Connection established");
        //            //選示連線ID
        //            displayAddConnections("APReply:" + id);

        //            ReplyConnection conn = new ReplyConnection(e.Tcp, Application.StartupPath, "LogFileName", "Reply", this);
        //            lock (mobj_ReplyClientCollection)
        //            {
        //                mobj_ReplyClientCollection.Add(id, conn);
        //            }
        //            conn.Execute();

        //        }
        //        catch (Exception ex)
        //        {
        //            mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //            //顯示client 連線訊息
        //            displayStatusMsg("APReply:[" + id + "]  " + ex.Message.ToString());
        //            e.Tcp.Close();

        //        }
        //        finally
        //        {
        //            //顯示client 連線訊息
        //            displayStatusMsg("APReply:[" + id + "]  Connection closed");
        //            displayRemoveConnections("APReply:" + id);
        //            lock (mobj_ReplyClientCollection)
        //            {
        //                mobj_ReplyClientCollection.Remove(id);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //    }
        //}
        //void m_SocketServer_Connection(object sender, ConnectionEventArgs e)
        //{
        //    try
        //    {

        //        //取得連結IP
        //        string id = e.Tcp.RemoteEndPoint.ToString();
        //        //顯示client 連線訊息
        //        displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[" + id + "]  Connection established");
        //        //選示連線ID
        //        displayAddConnections(mobj_WebSocketServer.mstr_name + ":" + id);

        //        WebConnection conn = new WebConnection(e.Tcp, Application.StartupPath, "LogFileName", "WEB", this);
        //        lock (mobj_WebClientCollection)
        //        {
        //            mobj_WebClientCollection.Add(id, conn);
        //        }
        //        try
        //        {


        //            conn.Execute();

        //        }
        //        catch (Exception ex)
        //        {
        //            mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //            //顯示client 連線訊息
        //            displayStatusMsg(mobj_TradeSocketServer.mstr_name + ":[" + id + "]  " + ex.Message.ToString());
        //            e.Tcp.Close();

        //        }
        //        finally
        //        {
        //            conn.Dispose();
        //            //顯示client 連線訊息
        //            displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[" + id + "]  Connection closed");
        //            lock (mobj_WebClientCollection)
        //            {
        //                mobj_WebClientCollection.Remove(id);
        //            }
        //            displayRemoveConnections(mobj_WebSocketServer.mstr_name + ":" + id);

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //    }
        //}

        //void m_SocketServer_ActiveChanged(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (mobj_WebSocketServer.m_SocketServer.Active)
        //        {
        //            if (mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() == "0.0.0.0")
        //                displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[Listening on port " + mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");
        //            else
        //                displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[Listening on " + mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Address.ToString() + ":" + mobj_WebSocketServer.m_SocketServer.LocalEndPoint.Port.ToString() + "]");

        //            displayPicStatus(mobj_WebSocketServer.mstr_name, "Connected");
        //        }
        //        else
        //        {
        //            displayStatusMsg(mobj_WebSocketServer.mstr_name + ":Server not accepting connections...");
        //            displayStatusMsg(mobj_WebSocketServer.mstr_name + ":[Closed]");

        //            displayPicStatus(mobj_WebSocketServer.mstr_name, "Disconnected");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        //    }
        //}

        public void close()
        {
            try
            {
               
                enableAS400Server(false);
                enableAS400Client(false);
                enableAS400ServerFor2(false);
                enableAS400ClientFor2(false);
                enabledMarketInfoSocket(false);
                if (_LM != null)
                {
                    _LM.Dispose();
                }

            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "Server Closed Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
        }


        private void getINIData()
        {

            try
            {
                mdt_FutureData = new DataTable();
                mdt_OptionData = new DataTable();
                //mdt_FBMCOB = new DataTable();
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.ConfigSQLConnection);
                SqlDataAdapter adp;

                //20101021 在抓商品檔的同時join FBMCOM帶出舊代碼.CNTSIZE,減少搜尋

                //期貨商品檔
                //    adp = new SqlDataAdapter("select a.*,b.closeprice,num from (select tblfuture.*, comno,cntsize from tblfuture left join  fbmcob  on class_name=mktcomno)a left join  (select    *, RANK() OVER (PARTITION BY class_id,period order by matchdate desc) num from  VIPMarketInfoDB.dbo.tblClosePrice) b on  a.Commodity_Id=b.Commodity_Id  where isnull(num,'1')='1'", conn);
                //V1.0.0.12
                adp = new SqlDataAdapter(@"select distinct a.*,b.closeprice,num from (select tblfuture.*

,commodity comno,contract_size cntsize from tblfuture left join  P09MF  on class_name=kind_id)a 
left join  
(select    *, RANK() OVER (PARTITION BY class_id,period order by matchdate desc) num 
from  VIPMarketInfoDB.dbo.tblClosePrice) b on  a.Commodity_Id=b.Commodity_Id 
 where isnull(num,'1')='1'
", conn);

                for (int i = 0; i < Properties.Settings.Default.ReConnectDBCount; i++)
                {
                    try
                    {
                        adp.Fill(mdt_FutureData);
                        _LM.WriteLog("DataAgentLog", "GetFutureData:OK:" + i.ToString());


                        i = Properties.Settings.Default.ReConnectDBCount;

                    }
                    catch (SqlException sqlex)
                    {
                        _LM.WriteLog("DataAgentLog", "GetFutureData:OK:Error " + i.ToString() + ":" + sqlex.Message + "\r\n" + sqlex.Source + "\r\n" + sqlex.StackTrace);

                        Thread.Sleep(10000);
                    }
                }


                //選擇權商品檔
                //V1.0.0.12
                adp = new SqlDataAdapter(@"select distinct a.*,b.closeprice,num
 from (select tbloption.* , commodity comno,contract_size cntsize from tbloption 
left join 
 P09M    on class_name=kind_id )a 
left join  
(select    *, RANK() OVER (PARTITION BY class_id,period,cp,strike_price 
order by matchdate desc) num 
from  VIPMarketInfoDB.dbo.tblClosePrice where cp!='') b 
on  a.Commodity_Id=b.Commodity_Id  where isnull(num,'1')='1' ", conn);

                for (int i = 0; i < Properties.Settings.Default.ReConnectDBCount; i++)
                {
                    try
                    {

                        adp.Fill(mdt_OptionData);
                        _LM.WriteLog("DataAgentLog", "GetOptionData:OK:" + i.ToString());


                        i = Properties.Settings.Default.ReConnectDBCount;
                    }
                    catch (SqlException sqlex)
                    {
                        _LM.WriteLog("DataAgentLog", "GetOptionData Fill Error " + i.ToString() + ":" + sqlex.Message + "\r\n" + sqlex.Source + "\r\n" + sqlex.StackTrace);

                        Thread.Sleep(10000);
                    }
                }


                //20101021 在搜尋table 增加key
                mdt_FutureData.PrimaryKey = new DataColumn[] { mdt_FutureData.Columns["comno"], mdt_FutureData.Columns["Settlement_month"] };
                mdt_OptionData.PrimaryKey = new DataColumn[] { mdt_OptionData.Columns["Class_Name"], mdt_OptionData.Columns["Settlement_month"], mdt_OptionData.Columns["CP"], mdt_OptionData.Columns["Strike_Price"] };


                ////fbmcob
                //adp = new SqlDataAdapter(" select  *  from fbmcob ", conn);
                //adp.Fill(mdt_FBMCOB);


            }
            catch (Exception ex)
            {

                _LM.WriteLog("DataAgentLog", "getINIData Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }

        }
        public string[] getProductId(string ClassId, string Class_Name, string Settlement_month, string CP, string Strike_Price)
        {
            //20101021回傳增加cntsize
            string[] strReturn = new string[] { "", "", "", "" };
            //20101021改用key做搜尋
            DataRow dr = null;
            if (ClassId == "1")
            {
                lock (mdt_FutureData)
                {
                    dr = mdt_FutureData.Rows.Find(new object[] { Class_Name, Settlement_month });
                }
            }
            else
            {
                lock (mdt_OptionData)
                {
                    dr = mdt_OptionData.Rows.Find(new object[] { Class_Name, Settlement_month, CP, Strike_Price });
                }
            }
            if (dr != null)
            {
                strReturn[0] = dr["Commodity_Id"].ToString().Trim();
                strReturn[1] = dr["closeprice"].ToString().Trim();
                strReturn[2] = dr["Class_Description"].ToString().Trim();
                strReturn[3] = dr["cntsize"].ToString().Trim();
            }
            return strReturn;
        }
        //20101021拿掉改從商品檔抓
        //public string getCntsize(string comno)
        //{
        //    string cntsize = "";
        //    DataRow[] drFinds = mdt_FBMCOB.Select("comno='" + comno + "'");
        //    if (drFinds.Length>0)
        //    {
        //        cntsize = drFinds[0]["cntsize"].ToString();
        //    }
        //    return cntsize;
        //}
        public object getMatchPrice(string productId)
        {
            ////取得資料庫中成交價
            //string selectsql = "select top 1 matchprice from dbo.i020 where convert(char(8),mdate,112)=convert(char(8),getdate(),112)  and  commodityid='" + productId + "'";
            //SqlConnection conn1 = new SqlConnection(Properties.Settings.Default.MOBSQLConnection);
            //conn1.Open();
            //SqlCommand command2 =
            //    new SqlCommand(selectsql, conn1);
            //object Matchprpice = command2.ExecuteScalar();
            //conn1.Close();

            object Matchprpice = null;
            lock (mdt_I020)
            {

                DataRow drFind = mdt_I020.Rows.Find(productId);
                if (drFind != null)
                {
                    Matchprpice = drFind["MATCHPRICE"];
                }
                //如果是複式單,要再判斷兩隻腳商品是否有結算價,用結算價去算
                if (productId.Contains("/"))
                {
                    string foot1 = productId.Substring(0, 5);
                    string foot2 = productId.Substring(0, 3) + productId.Substring(6, 2);
                    string price1 = "";
                    string price2 = "";
                    DataRow drFind1 = mdt_I020.Rows.Find(foot1);
                    if (drFind1 != null)
                    {
                        if (drFind1["isclose"].ToString() == "Y")
                        {
                            price1 = drFind1["MATCHPRICE"].ToString();
                        }
                    }
                    DataRow drFind2 = mdt_I020.Rows.Find(foot2);
                    if (drFind2 != null)
                    {
                        if (drFind2["isclose"].ToString() == "Y")
                        {
                            price2 = drFind2["MATCHPRICE"].ToString();
                        }
                    }
                    if (price1 != "" && price2 != "")
                    {
                        Matchprpice = (decimal.Parse(price2) - decimal.Parse(price1)).ToString();
                    }
                }
            }

            return Matchprpice;
        }
        public string getClosePrice(string productId)
        {

            string closeprice = "";
            if (productId.Contains("/"))
            {
                string foot1 = productId.Substring(0, 5);
                string foot2 = productId.Substring(0, 3) + productId.Substring(6, 2);
                lock (mdt_FutureData)
                {
                    string price1 = "";
                    string price2 = "";

                    DataRow[] drFinds1 = mdt_FutureData.Select("Commodity_Id='" + foot1 + "'");
                    if (drFinds1.Length > 0)
                    {
                        price1 = drFinds1[0]["closeprice"].ToString();
                    }
                    DataRow[] drFinds2 = mdt_FutureData.Select("Commodity_Id='" + foot2 + "'");
                    if (drFinds2.Length > 0)
                    {
                        price2 = drFinds2[0]["closeprice"].ToString();
                    }
                    if (price1 != "" && price2 != "")
                    {
                        closeprice = (decimal.Parse(price2) - decimal.Parse(price1)).ToString();
                    }
                }
            }
            else
            {
                if (productId.Trim().Length < 10)
                {
                    lock (mdt_FutureData)
                    {
                        DataRow[] drFinds = mdt_FutureData.Select("Commodity_Id='" + productId + "'");
                        if (drFinds.Length > 0)
                        {
                            closeprice = drFinds[0]["closeprice"].ToString();
                        }

                    }
                }
                else
                {
                    lock (mdt_OptionData)
                    {
                        DataRow[] drFinds = mdt_OptionData.Select("Commodity_Id='" + productId + "'");
                        if (drFinds.Length > 0)
                        {
                            closeprice = drFinds[0]["closeprice"].ToString();
                        }

                    }
                }
            }

            return closeprice;
        }
        public string[] getHighLowPrice(string productId)
        {
            string[] returnPrice = new string[2];
            lock (mdt_I020)
            {

                DataRow drFind = mdt_I020.Rows.Find(productId);
                if (drFind != null)
                {
                    if (drFind["HighPrice"].ToString().Trim() != "")
                    {
                        returnPrice[0] = drFind["HighPrice"].ToString();
                    }
                    if (drFind["LowPrice"].ToString().Trim() != "")
                    {
                        returnPrice[1] = drFind["LowPrice"].ToString();
                    }
                }

            }

            return returnPrice;
        }
        public object getStockPrice(string kindid)//added by samantha20160203現貨價
        {
            object stockprpice = null;
            lock (mdt_I060)
            {

                DataRow drFind = mdt_I060.Rows.Find(kindid);
                if (drFind != null)
                {
                    stockprpice = drFind["stockprice"];
                }
            }

            return stockprpice;
        }
        private void decimaldata(string CODE, string COMMODITYID, ref int dp)
        {
            DataRow[] drfuture;
            DataRow[] droption;
            int decimal_point = 0;

            if (CODE == "2" || CODE == "3")
            {
                drfuture = mdt_FutureData.Select("commodity_id='" + COMMODITYID.Trim() + "'");
                if (drfuture.Length != 0)
                {
                    decimal_point = int.Parse(drfuture[0]["decimal_place"].ToString());
                }
                else
                {
                    decimal_point = 2;
                }
            }
            else if (CODE == "5" || CODE == "6")
            {
                droption = mdt_OptionData.Select("commodity_id='" + COMMODITYID.Trim() + "'");
                if (droption.Length != 0)
                {
                    decimal_point = int.Parse(droption[0]["decimal_place"].ToString());
                }
                else
                {
                    decimal_point = 3;
                }
            }
            if (decimal_point == 3) dp = 1000;
            else if (decimal_point == 2) dp = 100;
            else if (decimal_point == 1) dp = 10;
            else if (decimal_point == 0) dp = 1;
            else
            {
                dp = (int)Math.Pow(10, decimal_point);
            }
        }




        #region AS400帳務



        void _AS400Client_connected(System.Net.Sockets.Socket s)
        {
            displayPicStatus("AS400Client", "Connected");
            displayStatusMsg("AS400Client Connected ");
        }

        void _AS400Client_Received(System.Net.Sockets.Socket s, byte[] buffer)
        {
            try
            {



                byte[] ESCCODE = new byte[1];
                byte[] LENGTH = new byte[4];
                byte[] Data;
                string Type;


                ESCCODE = ReceiveRawBuffer(ESCCODE.Length, s);
                LENGTH = ReceiveRawBuffer(LENGTH.Length, s);
                int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                byte[] raw = new byte[len];
                Data = new byte[len - ESCCODE.Length - LENGTH.Length];
                Data = ReceiveRawBuffer(Data.Length, s);


                Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                Array.Copy(Data, 0, raw, 0 + ESCCODE.Length + LENGTH.Length, Data.Length);


                //s.Receive(ESCCODE, 0, ESCCODE.Length, System.Net.Sockets.SocketFlags.None);
                //s.Receive(LENGTH, 0, LENGTH.Length, System.Net.Sockets.SocketFlags.None);

                //int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                //byte[] raw = new byte[len];
                //Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                //Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                //s.Receive(raw, ESCCODE.Length + LENGTH.Length, len - ESCCODE.Length - LENGTH.Length, System.Net.Sockets.SocketFlags.None);


                _LM.WriteLog("AS400ClientLogRcv", ASCIIEncoding.ASCII.GetString(raw));


            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
                //mobj_dataAgentLog.WriteEntryData("_AS400Client_Received Error:" + ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }

        }

        void _AS400Client_Disconnected()
        {
            displayPicStatus("AS400Client", "Disconnected");
            displayStatusMsg("AS400Client Disconnected ");
        }

        void _AS400Client_Sended(byte[] buffer)
        {

            _LM.WriteLog("AS400ClientLogSend", ASCIIEncoding.ASCII.GetString(buffer));
        }
        void _AS400Client_Error(string msg)
        {

            _LM.WriteLog("AS400ClientLogError", msg);
        }


        void _AS400ReplyServer_connected(System.Net.Sockets.Socket s)
        {

            displayStatusMsg("AS400Reply " + s.RemoteEndPoint.ToString() + "登入");
            // mobj_AS400ServerReplyLogRcv.WriteEntryData("AS400Reply " + s.RemoteEndPoint.ToString() + "登入");


            _LM.WriteLog("AS400ServerReplyLog", s.RemoteEndPoint.ToString() + "登入");



        }

        void _AS400ReplyServer_Disconnected(Socket s)
        {
            try
            {
                displayStatusMsg("AS400Reply " + s.RemoteEndPoint.ToString() + "離開");
                //  mobj_AS400ServerReplyLogRcv.WriteEntryData("AS400Reply " + s.RemoteEndPoint.ToString() + "離開");
                _LM.WriteLog("AS400ServerReplyLog", s.RemoteEndPoint.ToString() + "離開");

            }
            catch (Exception ex)
            {
            }
        }

        void _AS400ReplyServer_Actived()
        {
            if (_AS400ReplyServer.Active)
            {
                displayPicStatus("AS400Server", "Connected");
                displayStatusMsg("AS400Server Server Start!");

            }
            else
            {
                displayPicStatus("AS400Server", "Disconnected");
                displayStatusMsg("AS400Server Server stop!");

            }
        }
        void _AS400ReplyServer_Sended(byte[] buffer)
        {
            // mobj_AS400ServerReplyLogSend.WriteEntryData(ASCIIEncoding.ASCII.GetString(buffer));
        }

        void _AS400ReplyServer_Received(System.Net.Sockets.Socket s, byte[] buffer)
        {
            // 
            try
            {


                byte[] ESCCODE = new byte[1];
                byte[] LENGTH = new byte[4];
                byte[] Data;
                string Type;


                ESCCODE = ReceiveRawBuffer(ESCCODE.Length, s);
                LENGTH = ReceiveRawBuffer(LENGTH.Length, s);
                int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                byte[] raw = new byte[len];
                Data = new byte[len - ESCCODE.Length - LENGTH.Length];
                Data = ReceiveRawBuffer(Data.Length, s);


                Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                Array.Copy(Data, 0, raw, 0 + ESCCODE.Length + LENGTH.Length, Data.Length);


                //s.Receive(ESCCODE, 0, ESCCODE.Length, System.Net.Sockets.SocketFlags.None);
                //s.Receive(LENGTH, 0, LENGTH.Length, System.Net.Sockets.SocketFlags.None);

                //int len = int.Parse(ASCIIEncoding.ASCII.GetString(LENGTH, 0, 4));
                //byte[] raw = new byte[len];
                //Array.Copy(ESCCODE, 0, raw, 0, ESCCODE.Length);
                //Array.Copy(LENGTH, 0, raw, 0 + ESCCODE.Length, LENGTH.Length);
                //s.Receive(raw, ESCCODE.Length + LENGTH.Length, len - ESCCODE.Length - LENGTH.Length, System.Net.Sockets.SocketFlags.None);

                // mobj_AS400ServerReplyLogRcv.WriteEntryData(ASCIIEncoding.ASCII.GetString(raw).Trim());




                //20130729 Added by peter
                if (_AS400Ack)
                    _AS400ReplyServer.Send(s, raw);


                AS400ReplyQ.PutData2Queue(raw);

                // _RI.ResolveReceive(raw);
                try
                {
                    _LM.WriteLog("AS400ServerReplyLog", "[" + ((IPEndPoint)s.RemoteEndPoint).Port.ToString() + "]" + ASCIIEncoding.Default.GetString(raw).Trim());
                }
                catch (Exception ex)
                {
                    _LM.WriteLog("DataAgentLog", ex.Message);

                }

            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
            }
        }

        void _AS400ReplyServer_Error(string msg)
        {

            _LM.WriteLog("AS400ServerReplyLogError", msg);

            //_LM.WriteLog("AS400ServerReplyLogError", msg);
            //_DisplayItem.displayStatusMsg("AS400ServerReply  " + msg);

        }
        void _RI_Receivetest(ReceivedAccountAcion Action, byte[] b)
        {
            try
            {
                if (b == null) return;
                string strData = Encoding.Default.GetString(b);
                string strWriteData = DateTime.Now.ToString("HH:mm:ss.fff") + "原始接收:" + strData + "\n";
                string networkid = strData.Substring(1, 8);
                string ip = "";
                string queryip = "";
                string seq = "";


                if (ip != "")
                {

                }
            }
            catch (Exception ex)
            {
                _LM.WriteLog("DataAgentLog", "_RI_Receivetest Error:" + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }


        }
        public void _RI_Receive(ReceivedAccountAcion Action, byte[] buffer, byte[] source_buffer)
        {

            _T.RI_Receive(Action, buffer, source_buffer);
            return;

        }
        void _RI_Error(string msg)
        {

            _LM.WriteLog("DataAgentLog", "RI_Error Error:" + msg);

        }



        //added by peter V1.0.0.4
        void _RI_ReceiveFor2(ReceivedAccountAcion Action, byte[] b)
        {

            _T.RIFor2_Receive(Action, b);
            return;

        }

        void _AS400Client_connectedFor2(System.Net.Sockets.Socket s)
        {
            displayPicStatus("AS400ClientFor2", "Connected");
            displayStatusMsg("AS400ClientFor2 Connected ");
        }
        //added by peter V1.0.0.4
        void _AS400Client_ReceivedFor2(System.Net.Sockets.Socket s, byte[] buffer)
        {
            try
            {
                byte[] raw = new byte[256];
                raw = ReceiveRawBuffer(256, s);
                _LM.WriteLog("AS400ClientLogRcvFor2", ASCIIEncoding.ASCII.GetString(raw));

            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
                //mobj_dataAgentLog.WriteEntryData("_AS400Client_Received Error:" + ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }

        }
        //added by peter V1.0.0.4
        void _AS400Client_DisconnectedFor2()
        {
            displayPicStatus("AS400ClientFor2", "Disconnected");
            displayStatusMsg("AS400ClientFor2 Disconnected ");
        }
        //added by peter V1.0.0.4
        void _AS400Client_SendedFor2(byte[] buffer)
        {
            _LM.WriteLog("AS400ClientLogSendFor2", ASCIIEncoding.ASCII.GetString(buffer));
        }
        //added by peter V1.0.0.4
        void _AS400Client_ErrorFor2(string msg)
        {
            _LM.WriteLog("AS400ClientLogErrorFor2", msg);
        }

        //added by peter V1.0.0.4
        void _AS400ReplyServer_connectedFor2(System.Net.Sockets.Socket s)
        {

            displayStatusMsg("AS400ReplyFor2 " + s.RemoteEndPoint.ToString() + "登入");


            _LM.WriteLog("AS400ServerReplyLogRcvFor2", s.RemoteEndPoint.ToString() + "登入");

        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_DisconnectedFor2(Socket s)
        {
            displayStatusMsg("AS400ReplyFor2 " + s.RemoteEndPoint.ToString() + "離開");

            _LM.WriteLog("AS400ServerReplyLogRcvFor2", s.RemoteEndPoint.ToString() + "離開");

        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_ActivedFor2()
        {
            if (_AS400ReplyServerFor2.Active)
            {
                displayPicStatus("AS400ServerFor2", "Connected");
                displayStatusMsg("AS400ServerFor2 Server Start!");

            }
            else
            {
                displayPicStatus("AS400ServerFor2", "Disconnected");
                displayStatusMsg("AS400ServerFor2 Server stop!");

            }
        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_SendedFor2(byte[] buffer)
        {

            _LM.WriteLog("AS400ServerReplyLogSendFor2", ASCIIEncoding.ASCII.GetString(buffer));
        }
        //added by peter V1.0.0.4
        void _AS400ReplyServer_ReceivedFor2(System.Net.Sockets.Socket s, byte[] buffer)
        {
            // 
            try
            {

                byte[] raw = new byte[256];

                raw = ReceiveRawBuffer(raw.Length, s);


                _LM.WriteLog("AS400ServerReplyLogRcvFor2", ASCIIEncoding.ASCII.GetString(raw));


                //20130729 Added by peter
                if (_AS400For2Ack)
                    _AS400ReplyServerFor2.Send(s, raw);


                _RI.ResolveReceiveFor2(raw);


            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
            }
        }

        void _AS400ReplyServer_ErrorFor2(string msg)
        {

            _LM.WriteLog("AS400ServerReplyLogErrorFor2", msg);
        }


        //added by peter V1.0.0.11 出入金
        void _RI_ReceiveFor3(ReceivedAccountAcion Action, byte[] b)
        {

            _T.RIFor3_Receive(Action, b);
            return;

        }

        //added by peter V1.0.0.11 出入金
        void _AS400Client_connectedFor3(System.Net.Sockets.Socket s)
        {
            displayPicStatus("AS400ClientFor3", "Connected");
            displayStatusMsg("AS400ClientFor3 Connected ");
        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_ReceivedFor3(System.Net.Sockets.Socket s, byte[] buffer)
        {
            try
            {
                byte[] raw = new byte[256];
                raw = ReceiveRawBuffer(256, s);


                _LM.WriteLog("AS400ClientLogRcvFor3", ASCIIEncoding.Default.GetString(raw));
            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
                //mobj_dataAgentLog.WriteEntryData("_AS400Client_Received Error:" + ex.Message + "\r\n" + ex.Source + "\r\n" + ex.StackTrace);
            }

        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_DisconnectedFor3()
        {
            displayPicStatus("AS400ClientFor3", "Disconnected");
            displayStatusMsg("AS400ClientFor3 Disconnected ");
        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_SendedFor3(byte[] buffer)
        {
            _LM.WriteLog("AS400ClientLogSendFor3", ASCIIEncoding.Default.GetString(buffer));
        }
        //added by peter V1.0.0.11 出入金
        void _AS400Client_ErrorFor3(string msg)
        {
            _LM.WriteLog("AS400ClientLogErrorFor3", msg);
        }

        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_connectedFor3(System.Net.Sockets.Socket s)
        {

            displayStatusMsg("AS400ReplyFor3 " + s.RemoteEndPoint.ToString() + "登入");

            _LM.WriteLog("AS400ServerReplyLogRcvFor3", s.RemoteEndPoint.ToString() + "登入");

        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_DisconnectedFor3(Socket s)
        {
            displayStatusMsg("AS400ReplyFor3 " + s.RemoteEndPoint.ToString() + "離開");

            _LM.WriteLog("AS400ServerReplyLogRcvFor3", s.RemoteEndPoint.ToString() + "離開");
        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_ActivedFor3()
        {
            if (_AS400ReplyServerFor3.Active)
            {
                displayPicStatus("AS400ServerFor3", "Connected");
                displayStatusMsg("AS400ServerFor3 Server Start!");

            }
            else
            {
                displayPicStatus("AS400ServerFor3", "Disconnected");
                displayStatusMsg("AS400ServerFor3 Server stop!");

            }
        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_SendedFor3(byte[] buffer)
        {

            _LM.WriteLog("AS400ServerReplyLogSendFor3", ASCIIEncoding.ASCII.GetString(buffer));
        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_ReceivedFor3(System.Net.Sockets.Socket s, byte[] buffer)
        {
            // 
            try
            {

                byte[] raw = new byte[256];

                raw = ReceiveRawBuffer(raw.Length, s);



                _LM.WriteLog("AS400ServerReplyLogRcvFor3", ASCIIEncoding.ASCII.GetString(raw));


                //20130729 Added by peter
                if (_AS400For3Ack)
                    _AS400ReplyServerFor3.Send(s, raw);


                _RI.ResolveReceiveFor3(raw);


            }
            catch (Exception ex)
            {
                throw ex; //丟給 Socket error event
            }
        }
        //added by peter V1.0.0.11 出入金
        void _AS400ReplyServer_ErrorFor3(string msg)
        {
            _LM.WriteLog("AS400ServerReplyLogErrorFor3", msg);


            //_LM.WriteLog("AS400ServerReplyLogError", msg);
            //_DisplayItem.displayStatusMsg("AS400ServerReply  " + msg);

        }


        #endregion


        public byte[] ReceiveRawBuffer(int Size, Socket RcvS)
        {
            try
            {
                int total = 0;
                int RcvLength = 0;
                byte[] RcvBuffer = new byte[Size];

                total += RcvS.Receive(RcvBuffer, 0, RcvBuffer.Length, System.Net.Sockets.SocketFlags.None);
                if (total > 0)
                {
                    while (total != RcvBuffer.Length)
                    {
                        total += RcvLength = RcvS.Receive(RcvBuffer, total, RcvBuffer.Length - total, SocketFlags.None);
                        if (RcvLength > 0)
                            continue;
                        else
                            throw new Exception("remote disconnected");
                    }
                }
                else
                    throw new Exception("remote disconnected");
                return RcvBuffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public class ProductInfo
        {

            private string m_ProductClass = "";

            public string ProductClass
            {
                get { return m_ProductClass; }
                set { m_ProductClass = value; }
            }
            private string m_ProductShortDsc = "";

            public string ProductShortDsc
            {
                get { return m_ProductShortDsc; }
                set { m_ProductShortDsc = value; }
            }
            private string m_ProductId = "";

            public string ProductId
            {
                get { return m_ProductId; }
                set { m_ProductId = value; }
            }
            private string m_Period = "";

            public string Period
            {
                get { return m_Period; }
                set { m_Period = value; }
            }
            private string m_Cp = "";

            public string Cp
            {
                get { return m_Cp; }
                set { m_Cp = value; }
            }

            public string CPFullName
            {
                get
                {

                    if (m_Cp.Length > 0)
                        return m_Cp.ToLower() == "c" ? "Call" : "Put";
                    else
                        return "";
                }
            }
            private string m_Strike = "";

            public string Strike
            {
                get { return m_Strike; }
                set { m_Strike = value; }
            }


            private string m_ProductClass2 = "";

            public string ProductClass2
            {
                get { return m_ProductClass2; }
                set { m_ProductClass2 = value; }
            }
            private string m_ProductShortDsc2 = "";

            public string ProductShortDsc2
            {
                get { return m_ProductShortDsc2; }
                set { m_ProductShortDsc2 = value; }
            }
            private string m_ProductId2 = "";

            public string ProductId2
            {
                get { return m_ProductId2; }
                set { m_ProductId2 = value; }
            }
            private string m_Period2 = "";

            public string Period2
            {
                get { return m_Period2; }
                set { m_Period2 = value; }
            }
            private string m_Cp2 = "";

            public string Cp2
            {
                get { return m_Cp2; }
                set { m_Cp2 = value; }
            }

            public string CPFullName2
            {
                get
                {

                    if (m_Cp2.Length > 0)
                        return m_Cp2.ToLower() == "c" ? "Call" : "Put";
                    else
                        return "";
                }
            }
            private string m_Strike2 = "";

            public string Strike2
            {
                get { return m_Strike2; }
                set { m_Strike2 = value; }
            }
            private string m_ProductName = "";

            public string ProductName
            {
                get { return m_ProductName; }
                set { m_ProductName = value; }
            }
            private string m_ProductKind;
            public string ProductKind
            {
                get { return m_ProductKind; }
                set { m_ProductKind = value; }
            }
            private int m_MultipleKind;
            public int MultipleKind
            {
                get { return m_MultipleKind; }
                set { m_MultipleKind = value; }
            }
        }
        public ProductInfo getProductInfoByProductId(string ProductId)
        {

            ProductInfo item = new ProductInfo();

            string CommodityId = ProductId.Trim();
            item.ProductId = CommodityId;
            item.MultipleKind = -1;//V1.0.0.36
            if (CommodityId.Length == 5)
            {

                DataRow[] drs = mdt_FutureData.Select("Commodity_Id='" + CommodityId + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();
                    item.ProductName = drs[0]["Class_Description"].ToString() + "-" + drs[0]["Settlement_month"].ToString();
                }
                item.ProductKind = "1";

            }
            else if (CommodityId.Length == 10)
            {
                DataRow[] drs = mdt_OptionData.Select("Commodity_Id='" + CommodityId + "'");
                if (drs.Length > 0)
                {

                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();
                    item.Cp = drs[0]["CP"].ToString();
                    item.Strike = String.Format("{0:#0.###}", decimal.Parse(drs[0]["strike_price"].ToString()));

                    item.ProductName = drs[0]["Class_Description"].ToString() + "-" + drs[0]["Settlement_month"].ToString() + "-" + item.Strike + "-" + item.Cp;
                }
                item.ProductKind = "2";
            }
            else if (CommodityId.Length == 8)//期貨價差
            {
                string class_name = CommodityId.Substring(0, 3);


                DataRow[] drs = mdt_FutureData.Select("Class_Name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();

                    item.ProductClass2 = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString();

                }

                string period1 = CommodityId.Substring(3, 2);
                string period2 = CommodityId.Substring(6, 2);

                item.MultipleKind = 0;//V1.0.0.36

                item.ProductName = item.ProductShortDsc + item.Period + "/" + item.Period2;
                item.ProductKind = "4";

            }
            //20130627V1.0.0.32 小台短天 added by peter;
            else if (CommodityId.Length == 11)//期貨價差
            {
                string class_name = CommodityId.Substring(0, 3);
                string class_name2 = CommodityId.Substring(6, 3);


                DataRow[] drs = mdt_FutureData.Select("Class_Name='" + class_name + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString();
                    item.Period = drs[0]["Settlement_month"].ToString();

                    item.ProductClass2 = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString();

                }

                drs = mdt_FutureData.Select("Class_Name='" + class_name2 + "'");
                if (drs.Length > 0)
                {
                    item.ProductClass2 = drs[0]["Class_Name"].ToString();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString();
                    item.Period2 = drs[0]["Settlement_month"].ToString();
                }

                string period1 = CommodityId.Substring(3, 2);
                string period2 = CommodityId.Substring(9, 2);

                item.MultipleKind = 0;//V1.0.0.36

                item.ProductName = item.ProductShortDsc + item.Period + "/" + item.ProductShortDsc2 + item.Period2;
                item.ProductKind = "4";

            }
            else if (CommodityId.Length == 16 && CommodityId.Substring(8, 1) == "/")//價格價差
            {

                string period1 = CommodityId.Substring(14, 2);
                string period2 = period1;
                string Price1 = CommodityId.Substring(3, 5);
                string Price2 = CommodityId.Substring(9, 5);

                DataRow[] drs = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {

                    item.ProductClass = drs[0]["Class_Name"].ToString().Trim();
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString().Trim();
                    item.ProductClass2 = drs[0]["Class_Name"].ToString().Trim();
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString().Trim();

                }


                item.ProductName = item.ProductShortDsc + item.Strike + "/" + item.Strike2 + item.Cp + item.Period;
                item.ProductKind = "3";
                item.MultipleKind = 1;
            }
            else if (CommodityId.Length == 13 || (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/"))//時間價差、跨式、逆轉換
            {
                string Type = CommodityId.Substring(10, 1);
                string period1 = CommodityId.Substring(8, 2);
                string period2 = CommodityId.Substring(11, 2);
                if (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/")
                {
                    period2 = CommodityId.Substring(14, 2);
                }
                string Price1 = CommodityId.Substring(3, 5);
                string Price2 = Price1;



                DataRow[] drs = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {


                    item.ProductClass = CommodityId.Substring(0, 3);// drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString().Trim();
                    item.ProductClass2 = CommodityId.Substring(0, 3);// drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString().Trim();
                    ;

                }




                if (Type == "/")
                {
                    if (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/")
                    {

                        DataRow[] drfind = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(11, 3) + "'");
                        if (drs.Length > 0)
                        {
                            item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + item.Period + Type + drfind[0]["Class_Description"].ToString().Trim() + item.Period2;
                            item.ProductClass2 = CommodityId.Substring(11, 3);
                            item.ProductShortDsc2 = drfind[0]["Class_Description"].ToString().Trim();
                        }
                    }
                    else
                    {
                        item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + item.Period + Type + item.Period2;
                        //item.ProductClass2 = CommodityId.Substring(11, 3);

                    }
                    item.MultipleKind = 2;
                }
                else
                {
                    item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + Type + item.Cp2 + item.Period;
                    if (Type == ":")
                    {
                        item.MultipleKind = 3;

                    }
                    else { item.MultipleKind = 5; }
                }
                item.ProductKind = "3";
            }
            else if (CommodityId.Length == 18)// 勒式
            {
                string period1 = CommodityId.Substring(8, 2);
                string period2 = CommodityId.Substring(16, 2);
                string Price1 = CommodityId.Substring(3, 5);
                string Price2 = CommodityId.Substring(11, 5);

                DataRow[] drs = mdt_OptionData.Select(" Class_name='" + CommodityId.Substring(0, 3) + "'");
                if (drs.Length > 0)
                {


                    item.ProductClass = CommodityId.Substring(0, 3);//  drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc = drs[0]["Class_Description"].ToString().Trim();
                    item.ProductClass2 = CommodityId.Substring(0, 3);// drs[0]["abbr"].ToString().Trim(); V1.0.0.36
                    item.ProductShortDsc2 = drs[0]["Class_Description"].ToString().Trim();


                }



                item.ProductName = item.ProductShortDsc + item.Strike + item.Cp + ":" + item.Strike2 + item.Cp2 + item.Period2;
                item.ProductKind = "3";
                item.MultipleKind = 4;
            }
            return item;
        }

    }


}