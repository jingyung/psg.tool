﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Net.Sockets;
namespace AS400GatewayServer.MYCLS
{
    public class c_Functions
    {
        /// <summary>
        /// 讀取網路流資訊
        /// </summary>
        public static int TCP_ByteRead(Socket tcp, byte[] buffer, int start, int length)
        {
            int lint_total = 0;
            int lint_read = 0;
            int lint_count = 0;

            do
            {
                int s = tcp.Receive(buffer, start + lint_total, length - lint_total, System.Net.Sockets.SocketFlags.None);
               
                lint_total += lint_read;
                lint_count++;
            } while ((lint_total < length) && (lint_count < 100));
            return lint_total;
        }
        /// <summary>
        /// 將字串轉成byte取長度
        /// </summary>
        public static int getStringLen(string STR_Data)
        {
            byte[] bString = System.Text.Encoding.Default.GetBytes(STR_Data);
            return bString.Length;
        }
        public class SyncEvents
        {
            public SyncEvents()
            {

                _newItemEvent = new AutoResetEvent(false);
                _exitThreadEvent = new ManualResetEvent(false);
                _eventArray = new WaitHandle[2];
                _eventArray[0] = _newItemEvent;
                _eventArray[1] = _exitThreadEvent;
            }

            public EventWaitHandle ExitThreadEvent
            {
                get { return _exitThreadEvent; }
            }
            public EventWaitHandle NewItemEvent
            {
                get { return _newItemEvent; }
            }
            public WaitHandle[] EventArray
            {
                get { return _eventArray; }
            }

            private EventWaitHandle _newItemEvent;


            private EventWaitHandle _exitThreadEvent;
            private WaitHandle[] _eventArray;
        }







        public static string EncodeString(string pwd)
        {
            if (Boolean.Parse(Properties.Settings.Default.EnDeCode))
            {

                byte[] encbuff = System.Text.Encoding.Default.GetBytes(pwd);
                return Convert.ToBase64String(encbuff);
            }
            else
                return pwd;
        }


        public static string DecodeString(string pwd)
        {
            if (Boolean.Parse(Properties.Settings.Default.EnDeCode))
            {
                byte[] decbuff = Convert.FromBase64String(pwd);
                return System.Text.Encoding.Default.GetString(decbuff);
            }
            else
                return pwd;
        }
    }
}
