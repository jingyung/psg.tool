﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Collections;
using System.Data;
using System.Data.SqlClient;

namespace AS400GatewayServer.MYCLS
{
    public class SaveDB : DataAgent
    {
        public struct UpdateWITHDRAWItemDel
        {
            public string ORDDT;
            public string SEQNO;

            public string TYPE;
            public string COMPANY;
            public string ACTNO;
            public string ORDTM;
            public string IP;


            public string CODE;

        }
        public struct UpdateWITHDRAWItemDelForReply
        {
            public string OPDATE;
            public string SEQNO;

            public string TYPE;
            public string COMPANY;
            public string ACTNO;
            public string OPTIME;


            public string CODE;

        }


        public struct InsertWITHDRAWItem
        {
            public string ORDDT;
            public string SEQNO;
            public string MTYPE;
            public string TYPE;
            public string COMPANY;
            public string ACTNO;
            public string CURRENCY;
            public string AMT;
            public string TOCURRENCY;
            public string TOMTYPE;
            public string TOAMT;
            public string ORDTM;
            public string IP;
            public string SOURCE;
            public string CODE;
            public string MAXAMOUNT;
            public string NETVALUE;
            public string IAMT;
            public string CASHOUT;
            public string OUTNO;
            public string INNO;
            public string OPDATE;
            public string OPTIME;
        }

        public struct UpdateWITHDRAWItem
        {
            public string SEQNO;

            public string COMPANY;
            public string ACTNO;

            public string CODE;
            public string MAXAMOUNT;
            public string NETVALUE;
            public string IAMT;
            public string CASHOUT;
            public string OUTNO;
            public string INNO;
            public string OPDATE;
            public string OPTIME;
        }

        int _ConnectCount = 0;
        const int MAXCONNECTCOUNT = 999;

        /// <summary>
        /// 錯誤訊息
        /// </summary>
        private WriterLOG AOBJ_ErrorLog;
        /// <summary>
        /// 執行訊息
        /// </summary>
        private WriterLOG AOBJ_InfoLog;
        /// <summary>
        /// 負責暫存行情資訊記憶體
        /// </summary>
        private Queue<object> m_QueueData = new Queue<object>();
        /// <summary>
        /// 負責處理行情資訊thread
        /// </summary>
        private System.Threading.Thread m_objTrdSaveDB;
        private static c_Functions.SyncEvents syncConnectionEvents = new c_Functions.SyncEvents();

        SqlConnection sqlConn, sqlConn1;


        SqlCommand sqlcmdUpdateWITHDRAWDel;


        SqlCommand sqlcmdUpdateWITHDRAWDelForReply;


        SqlCommand sqlcmdInsertWITHDRAW;

        SqlCommand sqlcmdUpdateWITHDRAW;


        /// <summary>
        /// 物件初始化
        /// </summary>
        public SaveDB()
        {


            AOBJ_ErrorLog = new WriterLOG("SaveDBError");
            AOBJ_InfoLog = new WriterLOG("SaveDBInfo");


            sqlConn = new SqlConnection(Properties.Settings.Default.AccountSQLConnection);
            sqlConn1 = new SqlConnection(Properties.Settings.Default.AccountSQLConnection2);


            initInsertWITHDRAW();
            //
            sqlcmdInsertWITHDRAW.CommandText = getInsertWITHDRAWsqlcmd();
            sqlcmdInsertWITHDRAW.Connection = sqlConn;

            initUpdateWITHDRAWDel();

            initUpdateWITHDRAWDelForReply();
            //
            sqlcmdUpdateWITHDRAWDel.CommandText = getUpdateWITHDRAWDelsqlcmd();
            sqlcmdUpdateWITHDRAWDel.Connection = sqlConn;

            sqlcmdUpdateWITHDRAWDelForReply.CommandText = getUpdateWITHDRAWDelsqlcmdForReply();
            sqlcmdUpdateWITHDRAWDelForReply.Connection = sqlConn;


            initUpdateWITHDRAW();
            //
            sqlcmdUpdateWITHDRAW.CommandText = getUpdateWITHDRAWsqlcmd();
            sqlcmdUpdateWITHDRAW.Connection = sqlConn;

            execStartThread();
        }
        ~SaveDB()
        {
            SaveDBDispose();
        }
        /// <summary>
        /// 啟動thread
        /// </summary>
        private void execStartThread()
        {
            if (m_objTrdSaveDB != null)
            {
                m_objTrdSaveDB.Abort();
            }
            m_objTrdSaveDB = new System.Threading.Thread(new ThreadStart(execQueueData));
            m_objTrdSaveDB.Start();
        }
        /// <summary>
        /// 終止thread
        /// </summary>
        private void AbortThread()
        {
            if (AOBJ_ErrorLog != null)
            {
                AOBJ_ErrorLog.Close();
            }

            if (AOBJ_InfoLog != null)
            {
                AOBJ_InfoLog.Close();
            }
            if (m_objTrdSaveDB != null)
            {
                m_objTrdSaveDB.Abort();
            }
        }

        public void SaveDBDispose()
        {
            AbortThread();

            GC.SuppressFinalize(this);

        }
        public void saveNetworkId(string networkId)
        {
            try
            {
                string[] arrCmd = new string[2];
                if (Properties.Settings.Default.VIPVersion)
                {
                    arrCmd[0] = "INSERT INTO [system_serial]([serial_date],[serial_id],[serial_current],[serial_data],[mnote],[muser],[mdate]) VALUES"
                                           + "(Getdate(),'VIPPutSeQ','" + networkId + "','','insert','tradeSocketServer',getdate());";
                    arrCmd[1] = "UPDATE [system_serial]   SET [serial_date] = getdate() ,[serial_id] = 'VIPPutSeQ' ,[serial_current] = '" + networkId + "' ,[mnote] = 'Update' ,[muser] ='tradeSocketServer',[mdate] = getdate() "
                                           + "WHERE [serial_id] = 'VIPPutSeQ' and convert(char(8),mdate,112)=convert(char(8),getdate(),112)";
                }
                else
                {
                    arrCmd[0] = "INSERT INTO [system_serial]([serial_date],[serial_id],[serial_current],[serial_data],[mnote],[muser],[mdate]) VALUES"
                       + "(Getdate(),'WEBPutSeQ','" + networkId + "','','insert','tradeSocketServer',getdate());";
                    arrCmd[1] = "UPDATE [system_serial]   SET [serial_date] = getdate() ,[serial_id] = 'WEBPutSeQ' ,[serial_current] = '" + networkId + "' ,[mnote] = 'Update' ,[muser] ='tradeSocketServer',[mdate] = getdate() "
                                           + "WHERE [serial_id] = 'WEBPutSeQ' and convert(char(8),mdate,112)=convert(char(8),getdate(),112)";

                }
                PutData2Queue(arrCmd);
            }
            catch (Exception ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.StackTrace.ToString() + "/" + ex.ToString());
            }
        }
        /// <summary>
        /// 外部資訊傳入
        /// </summary>
        public void PutData2Queue(object data)
        {
            try
            {
                lock (m_QueueData)
                {
                    m_QueueData.Enqueue(data);
                    //   syncConnectionEvents.NewItemEvent.Set();
                    Monitor.Pulse(m_QueueData);
                }
            }
            catch (Exception ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.StackTrace.ToString() + "/" + ex.ToString());
            }
        }

        /// <summary>
        /// 不斷取出Queue資訊
        /// </summary>
        private void execQueueData()
        {
            try
            {
                while (true)
                {
                    try
                    {


                        object o = null;
                        lock (m_QueueData)
                        {
                            while (m_QueueData.Count == 0) Monitor.Wait(m_QueueData);
                            if (m_QueueData.Count > 0)
                            {
                                //判斷先把DEQ資料放在DATA變數裡
                                o = m_QueueData.Dequeue();
                            }

                        }

                        //等到確定取得資料做送寫資料
                        if (o != null)
                        {
                            bool isOK = false;
                            if (o is InsertWITHDRAWItem)
                            {
                                InsertWITHDRAWItem item = (InsertWITHDRAWItem)o;
                                execInsertWITHDRAW(item);
                            }
                            else if (o is UpdateWITHDRAWItemDel)
                            {
                                UpdateWITHDRAWItemDel item = (UpdateWITHDRAWItemDel)o;
                                execUpdateWITHDRAWDel(item);
                            }
                            else if (o is UpdateWITHDRAWItemDelForReply)
                            {
                                UpdateWITHDRAWItemDelForReply item = (UpdateWITHDRAWItemDelForReply)o;
                                execUpdateWITHDRAWDelForReply(item);
                            }

                            else if (o is UpdateWITHDRAWItem)
                            {
                                UpdateWITHDRAWItem item = (UpdateWITHDRAWItem)o;
                                execUpdateWITHDRAW(item);
                            }
                            else if (o == typeof(string))
                            {

                                string[] data = (string[])o;

                                if (data.Length == 2)
                                {

                                    isOK = execDB(Properties.Settings.Default.AccountSQLConnection, data[1], data[0]);
                                }
                                else
                                {
                                    isOK = execDB(Properties.Settings.Default.AccountSQLConnection, data[0]);

                                }
                            }
                            else
                            {
                                string[] data = (string[])o;

                                if (data.Length == 2)
                                {

                                    isOK = execDB(Properties.Settings.Default.AccountSQLConnection, data[1], data[0]);
                                }
                                else
                                {
                                    isOK = execDB(Properties.Settings.Default.AccountSQLConnection, data[0]);

                                }
                            }
                            //AOBJ_InfoLog.WriteEntryData(isOK.ToString());
                        }
                    }
                    catch (Exception ex)
                    {
                        AOBJ_ErrorLog.WriteEntryData(ex.StackTrace.ToString() + "/" + ex.ToString());
                    }

                }


            }
            catch (Exception ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.StackTrace.ToString() + "/" + ex.ToString());
            }
        }

        private bool execDB(string str_SQLconn, string str_SQLCMD)
        {
            bool blnSuccess = false;
            SqlConnection sqlConn;
            SqlCommand sqlcmd;
            sqlConn = new SqlConnection(str_SQLconn);
            sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlConn;
            sqlConn.Open();
            try
            {
                sqlcmd.CommandText = str_SQLCMD;
                sqlcmd.ExecuteNonQuery();
                blnSuccess = true;
            }
            catch (SqlException ex)
            {
                AOBJ_ErrorLog.WriteEntryData("SaveDB Error:SQL CMd:" + str_SQLCMD + ex.StackTrace.ToString() + "/" + ex.ToString());
                blnSuccess = false;
            }
            finally
            {
                sqlConn.Close();
            }
            return blnSuccess;
        }
        private bool execDB(string str_SQLconn, string str_UpDateCmd, string str_InsertDateCmd)
        {
            bool blnSuccess = false;
            SqlConnection sqlConn;
            SqlCommand sqlcmd;
            sqlConn = new SqlConnection(str_SQLconn);
            sqlcmd = new SqlCommand();
            sqlcmd.Connection = sqlConn;
            sqlConn.Open();
            try
            {
                sqlcmd.CommandText = str_UpDateCmd;
                if (sqlcmd.ExecuteNonQuery() == 0)
                {
                    sqlcmd.CommandText = str_InsertDateCmd;
                    sqlcmd.ExecuteNonQuery();
                }
                blnSuccess = true;
            }
            catch (SqlException ex)
            {
                AOBJ_ErrorLog.WriteEntryData("SaveDB Error:SQL Insert:" + str_InsertDateCmd + " Sql Update: " + str_InsertDateCmd + ex.StackTrace.ToString() + "/" + ex.ToString());
                blnSuccess = false;
            }
            finally
            {
                sqlConn.Close();
            }
            return blnSuccess;
        }




        private void initInsertWITHDRAW()
        {

            sqlcmdInsertWITHDRAW = new SqlCommand();
            sqlcmdInsertWITHDRAW.Parameters.Add("@ORDDT", SqlDbType.VarChar, 8);
            sqlcmdInsertWITHDRAW.Parameters.Add("@SEQNO", SqlDbType.VarChar, 9);
            sqlcmdInsertWITHDRAW.Parameters.Add("@MTYPE", SqlDbType.VarChar, 1);
            sqlcmdInsertWITHDRAW.Parameters.Add("@TYPE", SqlDbType.VarChar, 1);
            sqlcmdInsertWITHDRAW.Parameters.Add("@COMPANY", SqlDbType.VarChar, 7);
            sqlcmdInsertWITHDRAW.Parameters.Add("@ACTNO", SqlDbType.VarChar, 7);
            sqlcmdInsertWITHDRAW.Parameters.Add("@CURRENCY", SqlDbType.VarChar, 3);
            sqlcmdInsertWITHDRAW.Parameters.Add("@AMT", SqlDbType.Decimal, 14);
            sqlcmdInsertWITHDRAW.Parameters["@AMT"].Precision = 14;
            sqlcmdInsertWITHDRAW.Parameters["@AMT"].Scale = 2;

            sqlcmdInsertWITHDRAW.Parameters.Add("@TOCURRENCY", SqlDbType.VarChar, 3);
            sqlcmdInsertWITHDRAW.Parameters.Add("@TOMTYPE", SqlDbType.VarChar, 1);
            sqlcmdInsertWITHDRAW.Parameters.Add("@TOAMT", SqlDbType.Decimal, 14);
            sqlcmdInsertWITHDRAW.Parameters["@TOAMT"].Precision = 14;
            sqlcmdInsertWITHDRAW.Parameters["@TOAMT"].Scale = 2;

            sqlcmdInsertWITHDRAW.Parameters.Add("@ORDTM", SqlDbType.VarChar, 6);
            sqlcmdInsertWITHDRAW.Parameters.Add("@IP", SqlDbType.VarChar, 15);
            sqlcmdInsertWITHDRAW.Parameters.Add("@SOURCE", SqlDbType.VarChar, 1);
            sqlcmdInsertWITHDRAW.Parameters.Add("@CODE", SqlDbType.VarChar, 4);

            //sqlcmdInsertWITHDRAW.Parameters.Add("@MAXAMOUNT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["MAXAMOUNT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["MAXAMOUNT"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@NETVALUE", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["NETVALUE"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["NETVALUE"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@IAMT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["IAMT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["IAMT"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@CASHOUT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["CASHOUT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["CASHOUT"].Scale = 2;
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OUTNO", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@INNO", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OPDATE", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OPTIME", SqlDbType.VarChar, 6);




        }


        private void initUpdateWITHDRAWDel()
        {

            sqlcmdUpdateWITHDRAWDel = new SqlCommand();
            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@ORDDT", SqlDbType.VarChar, 8);
            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@SEQNO", SqlDbType.VarChar, 9);

            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@TYPE", SqlDbType.VarChar, 1);
            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@COMPANY", SqlDbType.VarChar, 7);
            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@ACTNO", SqlDbType.VarChar, 7);


            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@ORDTM", SqlDbType.VarChar, 6);
            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@IP", SqlDbType.VarChar, 15);

            sqlcmdUpdateWITHDRAWDel.Parameters.Add("@CODE", SqlDbType.VarChar, 4);

            //sqlcmdInsertWITHDRAW.Parameters.Add("@MAXAMOUNT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["MAXAMOUNT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["MAXAMOUNT"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@NETVALUE", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["NETVALUE"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["NETVALUE"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@IAMT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["IAMT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["IAMT"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@CASHOUT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["CASHOUT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["CASHOUT"].Scale = 2;
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OUTNO", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@INNO", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OPDATE", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OPTIME", SqlDbType.VarChar, 6);




        }

        private void initUpdateWITHDRAWDelForReply()
        {

            sqlcmdUpdateWITHDRAWDelForReply = new SqlCommand();
            sqlcmdUpdateWITHDRAWDelForReply.Parameters.Add("@OPDATE", SqlDbType.VarChar, 8);
            sqlcmdUpdateWITHDRAWDelForReply.Parameters.Add("@SEQNO", SqlDbType.VarChar, 9);

            sqlcmdUpdateWITHDRAWDelForReply.Parameters.Add("@TYPE", SqlDbType.VarChar, 1);
            sqlcmdUpdateWITHDRAWDelForReply.Parameters.Add("@COMPANY", SqlDbType.VarChar, 7);
            sqlcmdUpdateWITHDRAWDelForReply.Parameters.Add("@ACTNO", SqlDbType.VarChar, 7);


            sqlcmdUpdateWITHDRAWDelForReply.Parameters.Add("@OPTIME", SqlDbType.VarChar, 6);


            sqlcmdUpdateWITHDRAWDelForReply.Parameters.Add("@CODE", SqlDbType.VarChar, 4);

            //sqlcmdInsertWITHDRAW.Parameters.Add("@MAXAMOUNT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["MAXAMOUNT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["MAXAMOUNT"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@NETVALUE", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["NETVALUE"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["NETVALUE"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@IAMT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["IAMT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["IAMT"].Scale = 2;


            //sqlcmdInsertWITHDRAW.Parameters.Add("@CASHOUT", SqlDbType.Decimal, 14);
            //sqlcmdInsertWITHDRAW.Parameters["CASHOUT"].Precision = 14;
            //sqlcmdInsertWITHDRAW.Parameters["CASHOUT"].Scale = 2;
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OUTNO", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@INNO", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OPDATE", SqlDbType.VarChar, 8);
            //sqlcmdInsertWITHDRAW.Parameters.Add("@OPTIME", SqlDbType.VarChar, 6);




        }

        private void initUpdateWITHDRAW()
        {

            sqlcmdUpdateWITHDRAW = new SqlCommand();
            // sqlcmdUpdateWITHDRAW.Parameters.Add("@ORDDT", SqlDbType.VarChar, 8);
            sqlcmdUpdateWITHDRAW.Parameters.Add("@SEQNO", SqlDbType.VarChar, 9);
            // sqlcmdUpdateWITHDRAW.Parameters.Add("@MTYPE", SqlDbType.VarChar, 1);
            //  sqlcmdUpdateWITHDRAW.Parameters.Add("@TYPE", SqlDbType.VarChar, 1);
            sqlcmdUpdateWITHDRAW.Parameters.Add("@COMPANY", SqlDbType.VarChar, 7);
            sqlcmdUpdateWITHDRAW.Parameters.Add("@ACTNO", SqlDbType.VarChar, 7);
            //sqlcmdUpdateWITHDRAW.Parameters.Add("@CURRENCY", SqlDbType.VarChar, 3);
            //sqlcmdUpdateWITHDRAW.Parameters.Add("@AMT", SqlDbType.Decimal, 14);
            //sqlcmdUpdateWITHDRAW.Parameters["AMT"].Precision = 14;
            //sqlcmdUpdateWITHDRAW.Parameters["AMT"].Scale = 2;

            //sqlcmdUpdateWITHDRAW.Parameters.Add("@TOCURRENCY", SqlDbType.VarChar, 3);
            //sqlcmdUpdateWITHDRAW.Parameters.Add("@TOMTYPE", SqlDbType.VarChar, 1);
            //sqlcmdUpdateWITHDRAW.Parameters.Add("@TOAMT", SqlDbType.Decimal, 14);
            //sqlcmdUpdateWITHDRAW.Parameters["TOAMT"].Precision = 14;
            //sqlcmdUpdateWITHDRAW.Parameters["TOAMT"].Scale = 2;

            //sqlcmdUpdateWITHDRAW.Parameters.Add("@ORDTM", SqlDbType.VarChar, 6);
            //sqlcmdUpdateWITHDRAW.Parameters.Add("@IP", SqlDbType.VarChar, 15);
            //sqlcmdUpdateWITHDRAW.Parameters.Add("@SOURCE", SqlDbType.VarChar, 1);
            sqlcmdUpdateWITHDRAW.Parameters.Add("@CODE", SqlDbType.VarChar, 4);

            sqlcmdUpdateWITHDRAW.Parameters.Add("@MAXAMOUNT", SqlDbType.Decimal, 14);
            sqlcmdUpdateWITHDRAW.Parameters["@MAXAMOUNT"].Precision = 14;
            sqlcmdUpdateWITHDRAW.Parameters["@MAXAMOUNT"].Scale = 2;


            sqlcmdUpdateWITHDRAW.Parameters.Add("@NETVALUE", SqlDbType.Decimal, 14);
            sqlcmdUpdateWITHDRAW.Parameters["@NETVALUE"].Precision = 14;
            sqlcmdUpdateWITHDRAW.Parameters["@NETVALUE"].Scale = 2;


            sqlcmdUpdateWITHDRAW.Parameters.Add("@IAMT", SqlDbType.Decimal, 14);
            sqlcmdUpdateWITHDRAW.Parameters["@IAMT"].Precision = 14;
            sqlcmdUpdateWITHDRAW.Parameters["@IAMT"].Scale = 2;


            sqlcmdUpdateWITHDRAW.Parameters.Add("@CASHOUT", SqlDbType.Decimal, 14);
            sqlcmdUpdateWITHDRAW.Parameters["@CASHOUT"].Precision = 14;
            sqlcmdUpdateWITHDRAW.Parameters["@CASHOUT"].Scale = 2;
            sqlcmdUpdateWITHDRAW.Parameters.Add("@OUTNO", SqlDbType.VarChar, 8);
            sqlcmdUpdateWITHDRAW.Parameters.Add("@INNO", SqlDbType.VarChar, 8);
            sqlcmdUpdateWITHDRAW.Parameters.Add("@OPDATE", SqlDbType.VarChar, 8);
            sqlcmdUpdateWITHDRAW.Parameters.Add("@OPTIME", SqlDbType.VarChar, 6);




        }


        private string getUpdateWITHDRAWDelsqlcmd()
        {
            string sql = "";

            sql = @"UPDATE  [dbo].[WITHDRAW]
   SET  
         [ORDDT] = @ORDDT
  
  ,[TYPE] = @TYPE
       ,[CODE] = @CODE
      ,[IP] =@IP
      ,[ORDTM] = @ORDTM
 
      ,[muser] = 'SYS'
      ,[mdate] = getdate()
 WHERE    [SEQNO] = @SEQNO and [COMPANY] = @COMPANY and [ACTNO] = @ACTNO
            ";
            return sql;
        }

        private string getUpdateWITHDRAWDelsqlcmdForReply()
        {
            string sql = "";

            sql = @"UPDATE  [dbo].[WITHDRAW]
   SET  
         [OPDATE] = @OPDATE
  
  ,[TYPE] = @TYPE
       ,[CODE] = @CODE
     
      ,[OPTIME] = @OPTIME
 
      ,[muser] = 'SYS'
      ,[mdate] = getdate()
 WHERE    [SEQNO] = @SEQNO and [COMPANY] = @COMPANY and [ACTNO] = @ACTNO
            ";
            return sql;
        }



        private string getInsertWITHDRAWsqlcmd()
        {
            string sql = "";

            sql = @"INSERT INTO  [dbo].[WITHDRAW]
           ([ORDDT]
           ,[SEQNO]
           ,[MTYPE]
           ,[TYPE]
           ,[COMPANY]
           ,[ACTNO]
           ,[CURRENCY]
           ,[AMT]
           ,[TOCURRENCY]
           ,[TOMTYPE]
           ,[TOAMT]
           ,[ORDTM]
           ,[IP]
           ,[SOURCE]
           ,[CODE]
 
           ,[muser]
           ,[mdate])
     VALUES
           (
            @ORDDT
           ,@SEQNO
           ,@MTYPE
           ,@TYPE
           ,@COMPANY
           ,@ACTNO
           ,@CURRENCY
           ,@AMT
           ,@TOCURRENCY
           ,@TOMTYPE
           ,@TOAMT
           ,@ORDTM
           ,@IP
           ,@SOURCE
           ,@CODE
 
           ,'SYS'
           ,getdate()
            )";
            return sql;
        }


        private string getUpdateWITHDRAWsqlcmd()
        {
            string sql = "";

            sql = @"

declare  @tmpoptime as varchar(6)

declare @twday as varchar(1)
declare @closedate as varchar(8)
declare @closetime as varchar(6)
 
declare @bTime  as varchar(4)
declare @eTime as varchar(4)
declare @topTime as varchar(4)
declare @type as varchar(1)

set @opdate=convert(varchar,GETDATE(),112)
set @twday=''
set @tmpoptime=   REPLACE(CONVERT(varchar(5), GETDATE(), 108), ':', '')
 

 set @closedate= @opdate

  select @type=type from [dbo].[WITHDRAW]  WHERE    [SEQNO] = @SEQNO and [COMPANY] = @COMPANY and [ACTNO] = @ACTNO

 while(1=1)--
 begin
   SELECT  @twday=  twday  FROM [DDSCAccountDB].[dbo].[TWHOLIDAY_SET] where HOLIDAY_DATE=@closedate
	print @twday
	print @closedate
   if (@twday<>'Y'  )
   begin
   break
   end
   else
   begin
    set @twday=''
	set @closedate= CONVERT(CHAR(10),DATEADD(day,1, convert(datetime, @closedate)),112)
	end
 end  
 select @bTime=btime,@eTime=etime ,@topTime=( select top 1 etime from WITHDRAWTIME  where  type  = (case when @type='3' then    '3'  else '1'   end) ) from WITHDRAWTIME   
     where  type  = (case when @type='3' then    '3'  else '1'   end)
 and  (cast(@tmpoptime as int )>=cast(btime as int) and cast(@tmpoptime as int)<cast(etime as int)) 
  order by seq 
print @bTime+','+ @eTime+','+@topTime

if (@eTime!='9999')  
begin
	set  @closetime=@eTime
end
else if ( @closedate =@opdate)
begin

set @closedate= CONVERT(CHAR(10),DATEADD(day,1, convert(datetime, @closedate)),112)
 while(1=1)--
 begin
   SELECT  @twday=  twday  FROM [DDSCAccountDB].[dbo].[TWHOLIDAY_SET] where HOLIDAY_DATE=@closedate
 
   if (@twday<>'Y'  )
   begin
   break
   end
   else
   begin
    set @twday=''
	set @closedate= CONVERT(CHAR(10),DATEADD(day,1, convert(datetime, @closedate)),112)
	end

 end 



set  @closetime=@topTime
end
 
if ( @closedate!=@opdate)
begin
set  @closetime=@topTime
end
 
  

 print @closedate +','+@closetime


UPDATE  [dbo].[WITHDRAW]
   SET  
       
       [CODE] = @CODE
      ,[MAXAMOUNT] =@MAXAMOUNT
      ,[NETVALUE] = @NETVALUE
      ,[IAMT] = @IAMT
      ,[CASHOUT] = @CASHOUT
      ,[OUTNO] = @OUTNO
      ,[INNO] = @INNO
      ,[OPDATE] =@OPDATE
      ,[OPTIME] = @OPTIME
      ,CloseDate=@closedate
        ,CloseTime=@closetime
      ,[muser] = 'SYS'
      ,[mdate] = getdate()
 WHERE    [SEQNO] = @SEQNO and [COMPANY] = @COMPANY and [ACTNO] = @ACTNO
            ";
            return sql;
        }



        private bool execInsertWITHDRAW(InsertWITHDRAWItem Item)
        {

            bool blnSuccess = false;

            try
            {

                OpenConnection(sqlcmdInsertWITHDRAW.Connection);

                sqlcmdInsertWITHDRAW.Parameters["@ORDDT"].Value = Item.ORDDT;
                sqlcmdInsertWITHDRAW.Parameters["@SEQNO"].Value = Item.SEQNO;
                sqlcmdInsertWITHDRAW.Parameters["@MTYPE"].Value = Item.MTYPE;
                sqlcmdInsertWITHDRAW.Parameters["@TYPE"].Value = Item.TYPE;
                sqlcmdInsertWITHDRAW.Parameters["@COMPANY"].Value = Item.COMPANY;
                sqlcmdInsertWITHDRAW.Parameters["@ACTNO"].Value = Item.ACTNO;
                sqlcmdInsertWITHDRAW.Parameters["@CURRENCY"].Value = Item.CURRENCY;
                sqlcmdInsertWITHDRAW.Parameters["@AMT"].Value = Item.AMT;


                sqlcmdInsertWITHDRAW.Parameters["@TOCURRENCY"].Value = Item.TOCURRENCY;
                sqlcmdInsertWITHDRAW.Parameters["@TOMTYPE"].Value = Item.TOMTYPE;
                sqlcmdInsertWITHDRAW.Parameters["@TOAMT"].Value = Item.TOAMT;


                sqlcmdInsertWITHDRAW.Parameters["@ORDTM"].Value = Item.ORDTM;
                sqlcmdInsertWITHDRAW.Parameters["@IP"].Value = Item.IP;
                sqlcmdInsertWITHDRAW.Parameters["@SOURCE"].Value = Item.SOURCE;
                sqlcmdInsertWITHDRAW.Parameters["@CODE"].Value = Item.CODE;


                if (sqlcmdInsertWITHDRAW.ExecuteNonQuery() > 0)
                    blnSuccess = true;
                else
                    blnSuccess = false;

                CloseConnection(sqlcmdInsertWITHDRAW.Connection);

                if (sqlConn1 != null)
                {
                  
                    sqlcmdInsertWITHDRAW.Connection = sqlConn1;
                    OpenConnection(sqlcmdInsertWITHDRAW.Connection);
                    if (sqlcmdInsertWITHDRAW.ExecuteNonQuery() > 0)
                        blnSuccess = true;
                    else
                        blnSuccess = false;
                    CloseConnection(sqlcmdInsertWITHDRAW.Connection);
                    sqlcmdInsertWITHDRAW.Connection = sqlConn;
                }

            }
            catch (SqlException ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.Message + "SQL CMd execInsertWITHDRAW:" + Item.ORDDT + " SEQNO:" + Item.SEQNO + "COMPANY:" + Item.COMPANY + "ACTNO:" + Item.ACTNO);

                blnSuccess = false;
            }
            finally
            {
            }
            return blnSuccess;
        }

        private bool execUpdateWITHDRAW(UpdateWITHDRAWItem Item)
        {
            bool blnSuccess = false;

            try
            {

                OpenConnection(sqlcmdUpdateWITHDRAW.Connection);
                sqlcmdUpdateWITHDRAW.Parameters["@SEQNO"].Value = Item.SEQNO;

                sqlcmdUpdateWITHDRAW.Parameters["@COMPANY"].Value = Item.COMPANY;
                sqlcmdUpdateWITHDRAW.Parameters["@ACTNO"].Value = Item.ACTNO;

                sqlcmdUpdateWITHDRAW.Parameters["@CODE"].Value = Item.CODE;
                sqlcmdUpdateWITHDRAW.Parameters["@MAXAMOUNT"].Value = Item.MAXAMOUNT;
                sqlcmdUpdateWITHDRAW.Parameters["@NETVALUE"].Value = Item.NETVALUE;
                sqlcmdUpdateWITHDRAW.Parameters["@IAMT"].Value = Item.IAMT;
                sqlcmdUpdateWITHDRAW.Parameters["@CASHOUT"].Value = Item.CASHOUT;

                sqlcmdUpdateWITHDRAW.Parameters["@OUTNO"].Value = Item.OUTNO;
                sqlcmdUpdateWITHDRAW.Parameters["@INNO"].Value = Item.INNO;
                sqlcmdUpdateWITHDRAW.Parameters["@CODE"].Value = Item.CODE;

                sqlcmdUpdateWITHDRAW.Parameters["@OPDATE"].Value = Item.OPDATE;
                sqlcmdUpdateWITHDRAW.Parameters["@OPTIME"].Value = Item.OPTIME;
                if (sqlcmdUpdateWITHDRAW.ExecuteNonQuery() > 0)
                    blnSuccess = true;
                else
                    blnSuccess = false;
                CloseConnection(sqlcmdUpdateWITHDRAW.Connection);
                if (sqlConn1 != null)
                {
                 
                    sqlcmdUpdateWITHDRAW.Connection = sqlConn1;
                    OpenConnection(sqlcmdUpdateWITHDRAW.Connection);
                    if (sqlcmdUpdateWITHDRAW.ExecuteNonQuery() > 0)
                        blnSuccess = true;
                    else
                        blnSuccess = false;
                    CloseConnection(sqlcmdUpdateWITHDRAW.Connection);
                    sqlcmdUpdateWITHDRAW.Connection = sqlConn;
                }

            }
            catch (SqlException ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.Message + "SQL CMd execUpdateWITHDRAW:" + Item + " SEQNO:" + Item.SEQNO + "COMPANY:" + Item.COMPANY + "ACTNO:" + Item.ACTNO);

                blnSuccess = false;
            }
            finally
            {
            }
            return blnSuccess;
        }

        private bool execUpdateWITHDRAWDel(UpdateWITHDRAWItemDel Item)
        {
            bool blnSuccess = false;

            try
            {

                OpenConnection(sqlcmdUpdateWITHDRAWDel.Connection);
                sqlcmdUpdateWITHDRAWDel.Parameters["@ORDDT"].Value = Item.ORDDT;

                sqlcmdUpdateWITHDRAWDel.Parameters["@SEQNO"].Value = Item.SEQNO;
                sqlcmdUpdateWITHDRAWDel.Parameters["@TYPE"].Value = Item.TYPE;

                sqlcmdUpdateWITHDRAWDel.Parameters["@COMPANY"].Value = Item.COMPANY;
                sqlcmdUpdateWITHDRAWDel.Parameters["@ACTNO"].Value = Item.ACTNO;
                sqlcmdUpdateWITHDRAWDel.Parameters["@ORDTM"].Value = Item.ORDTM;
                sqlcmdUpdateWITHDRAWDel.Parameters["@IP"].Value = Item.IP;
                sqlcmdUpdateWITHDRAWDel.Parameters["@CODE"].Value = Item.CODE;


                if (sqlcmdUpdateWITHDRAWDel.ExecuteNonQuery() > 0)
                    blnSuccess = true;
                else
                    blnSuccess = false;

                CloseConnection(sqlcmdUpdateWITHDRAWDel.Connection);
                if (sqlConn1 != null)
                {
                  
                    sqlcmdUpdateWITHDRAWDel.Connection = sqlConn1;
                    OpenConnection(sqlcmdUpdateWITHDRAWDel.Connection);
                    if (sqlcmdUpdateWITHDRAWDel.ExecuteNonQuery() > 0)
                        blnSuccess = true;
                    else
                        blnSuccess = false;
                    CloseConnection(sqlcmdUpdateWITHDRAWDel.Connection);
                    sqlcmdUpdateWITHDRAWDel.Connection = sqlConn;
                }

            }
            catch (SqlException ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.Message + "SQL CMd sqlcmdUpdateWITHDRAWDel:" + Item + " SEQNO:" + Item.SEQNO + "COMPANY:" + Item.COMPANY + "ACTNO:" + Item.ACTNO);

                blnSuccess = false;
            }
            finally
            {
            }
            return blnSuccess;
        }


        private bool execUpdateWITHDRAWDelForReply(UpdateWITHDRAWItemDelForReply Item)
        {
            bool blnSuccess = false;

            try
            {

                OpenConnection(sqlcmdUpdateWITHDRAWDelForReply.Connection);
                sqlcmdUpdateWITHDRAWDelForReply.Parameters["@OPDATE"].Value = Item.OPDATE;

                sqlcmdUpdateWITHDRAWDelForReply.Parameters["@SEQNO"].Value = Item.SEQNO;
                sqlcmdUpdateWITHDRAWDelForReply.Parameters["@TYPE"].Value = Item.TYPE;

                sqlcmdUpdateWITHDRAWDelForReply.Parameters["@COMPANY"].Value = Item.COMPANY;
                sqlcmdUpdateWITHDRAWDelForReply.Parameters["@ACTNO"].Value = Item.ACTNO;
                sqlcmdUpdateWITHDRAWDelForReply.Parameters["@OPTIME"].Value = Item.OPTIME;
                sqlcmdUpdateWITHDRAWDelForReply.Parameters["@CODE"].Value = Item.CODE;


                if (sqlcmdUpdateWITHDRAWDelForReply.ExecuteNonQuery() > 0)
                    blnSuccess = true;
                else
                    blnSuccess = false;

                CloseConnection(sqlcmdUpdateWITHDRAWDelForReply.Connection);

                if (sqlConn1 != null)
                {
                  
                    sqlcmdUpdateWITHDRAWDelForReply.Connection = sqlConn1;
                    OpenConnection(sqlcmdUpdateWITHDRAWDelForReply.Connection);
                    if (sqlcmdUpdateWITHDRAWDelForReply.ExecuteNonQuery() > 0)
                        blnSuccess = true;
                    else
                        blnSuccess = false;
                    CloseConnection(sqlcmdUpdateWITHDRAWDelForReply.Connection);
                    sqlcmdUpdateWITHDRAWDelForReply.Connection = sqlConn;
                }

            }
            catch (SqlException ex)
            {
                AOBJ_ErrorLog.WriteEntryData(ex.Message + "SQL CMd execUpdateWITHDRAWDelForReply:" + Item + " SEQNO:" + Item.SEQNO + "COMPANY:" + Item.COMPANY + "ACTNO:" + Item.ACTNO);

                blnSuccess = false;
            }
            finally
            {
            }
            return blnSuccess;
        }

        private void OpenConnection_()
        {
        connect:
            try
            {
                if (sqlConn.State != ConnectionState.Open)
                {
                    sqlConn.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto connect;
                }
                else
                {
                    throw ex;
                }
            }
        }

        private void OpenConnection1_()
        {
        connect1:
            try
            {
                if (sqlConn1.State != ConnectionState.Open)
                {
                    sqlConn1.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto connect1;
                }
                else
                {
                    throw ex;
                }
            }
        }





        private void OpenConnection(SqlConnection pSqlconn)
        {
        connect:
            try
            {
                if (pSqlconn.State != ConnectionState.Open)
                {
                    pSqlconn.Open();
                    _ConnectCount = 0;
                }
            }
            catch (Exception ex)
            {
                if (_ConnectCount <= MAXCONNECTCOUNT)
                {
                    _ConnectCount++;
                    goto connect;
                }
                else
                {
                    throw ex;
                }
            }
        }

        private void CloseConnection(SqlConnection pSqlconn)
        {

            try
            {

                pSqlconn.Close();

            }
            catch (Exception ex)
            {

            }
        }
    }
}
