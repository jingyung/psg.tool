﻿using System;
using System.IO;
using System.Text;
namespace AS400GatewayServer.MYCLS
{
    /// <summary>
    /// WriterLOG 的摘要描述。
    /// </summary>
    public class WriterLOG
    {
        StreamWriter sw_Log;
        public string ASTR_FileName = null;
        public string ASTR_FolderName = null;
        public static string CURRENTPATH = "";
        public WriterLOG(string STR_FileName)
        {
            try
            {
                CURRENTPATH = DataAgent.TradeDate;
                ASTR_FileName = STR_FileName;
                ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd()
                     + "\\Log\\" + CURRENTPATH;
                if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log"))
                {
                    Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log");
                }
                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                string str_path = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\"
                    + CURRENTPATH + "\\" + ASTR_FileName + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                if (File.Exists(str_path))
                {
                    sw_Log = File.AppendText(str_path);
                }
                else
                {
                    sw_Log = File.CreateText(str_path);
                }
                sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff") + " -->:" + "Open Log File");
                sw_Log.Flush();
            }
            catch (Exception ex)
            {
                string test = ex.ToString();
            }
        }
        ~WriterLOG()
        {
            Close();
        }
        public void Close()
        {
            try
            {
                if (sw_Log != null)
                {
                    sw_Log.Close();
                }
            }
            catch (Exception ex)
            {
            }
        }
        public void WriteError(string source, string errorLine, string message, System.Diagnostics.EventLogEntryType logentrytype)
        {

            string str_DateTimeNow = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            message = message.Replace("\r\n", "");
            string str_MessageEventLog = "日期：" + str_DateTimeNow + ", 訊息來源：" + source + ",訊息來源行數：" + errorLine + " , 訊息類型：" + logentrytype.ToString() + " , 訊息明細：" + message.Trim();
            WriteEntryData(str_MessageEventLog);
            //MessageBox.Show(str_MessageEventLog);
        }
        public void WriteEntryData(string l_strLogData)
        {
            //			sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss -->:" + l_strLogData.Replace("'"," ")));
            try
            {
                sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff") + " -->:" + l_strLogData);
                sw_Log.Flush();
            }
            catch
            {
            }
        }
    }

    public class FileDate
    {
        public void delfile(int FileDate)
        {
            if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log"))
            {
                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log");
            }
            string[] dir = Directory.GetDirectories(AppDomain.CurrentDomain.BaseDirectory.ToString().Trim() + "Log");
            string[] dt = new string[dir.Length];
            int chk_day = int.Parse((DateTime.Now.AddDays(-(FileDate - 1))).ToString("yyyyMMdd"));

            for (int i = 0; i < dir.Length; i++)
            {
                dt[i] = (Directory.GetLastWriteTime(dir[i])).ToString("yyyyMMdd");
                if (int.Parse(dt[i]) < chk_day)
                {
                    Directory.Delete(dir[i], true);
                }
            }
        }
    }
}
