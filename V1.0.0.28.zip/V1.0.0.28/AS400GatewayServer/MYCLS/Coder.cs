using System;
using System.IO;
using System.Text;

namespace AS400GatewayServer.MYCLS
{
	/// <summary>
	/// Coder ���K�n�y�z�C
	/// </summary>
	public class Coder
	{
		public static void DE_PACK_BCD(byte[] code_byte,ref string code_string,bool code_bin)//�Ѷ}DE_PACK_BCD���Y�{��
		{
            code_string = "";
			int len=code_byte.Length;
			byte[] solve=new byte[len*2];
			int j=0;

			if(code_bin==true)
			{ 
				solve[0]=(code_byte[0]&=0x0F);
				code_string +=Convert.ToString(solve[0]);
				j+=1;
				len -=1;
			}

			for(int i=0;i<len*2;i+=2)
			{
				solve[i]=Convert.ToByte(code_byte[j]>>4);//���e4��bit
				solve[i+1]=(code_byte[j]&=0x0F);//����4��bit
				j+=1;
					
				code_string += Convert.ToString(solve[i])+Convert.ToString(solve[i+1]);			
			}
		}
	}
}
