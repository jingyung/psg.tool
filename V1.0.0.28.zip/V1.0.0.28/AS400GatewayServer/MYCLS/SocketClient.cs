﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.IO.Compression;

using com.ddsc.tool;
namespace AS400GatewayServer.MYCLS
{
    public class SocketClient
    {
        /// <summary>
        /// 使用Socket物件
        /// </summary>
        public Socket m_Socket;

        /// <summary>
        /// remoteIP
        /// </summary>
        private string m_strIP;
        /// <summary>
        /// remote Port
        /// </summary>
        private int m_intPort;
        /// <summary>
        /// 使用者ID
        /// </summary>
        private string m_strUserId;

        private string m_strCompany;
        /// <summary>
        /// 錯誤LOG
        /// </summary>
        public WriterLOG mobj_ErrorLog;
        private static string m_strlocalip;
        private static string m_strlocalport;
        public string strlocalip
        {
            get
            {
                return m_strlocalip;
            }
            set
            {
                m_strlocalip = value;
            }
        }
        public string strlocalport
        {
            get
            {
                return m_strlocalport;
            }
            set
            {
                m_strlocalport = value;
            }
        }
        public delegate
            void NotificationCallback(Notification notify, Object data);
        public event NotificationCallback Notifications;
        public bool abol_isBeginSend = false;
        public bool abol_isAlive = true;
        public enum Notification
        {
            Initialized = 1,//初始化
            Conneted,//連線成功
            ConnectError,//連線失敗
            Disconneted,//連線中斷
            DisconnectError,//連線中斷異常
            ConnectedError,//連線異常斷線
            ThreadAbort,//處理中斷
            ReceivedData,//            
            ReceiveAbort,//接收中斷
            SendDataError,
            End,
            Error,
            ReceivedErrorData,//接收錯誤資料
            AddMapping,//GW有加到Mapping table
        }

        /// <summary>
        /// 初始化物件
        /// </summary>
        public SocketClient(string logid, string name, string ip, int port, string company, string userId)
        {
            try
            {
               
                m_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                m_strIP = ip;
                m_intPort = port;
                m_strUserId = userId;
                m_strCompany = company;

                //資料傳送nodelay add by samantha20100527
                m_Socket.NoDelay = true;

            }
            catch (Exception ex)
            {
                mobj_ErrorLog.WriteError(ex.Source, "初始化失敗:" + ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

            }

        }
        /// <summary>
        /// 啟動
        /// </summary>
        public void SocketClientStart()
        {
            try
            {
                m_Socket.BeginConnect(m_strIP, m_intPort, new AsyncCallback(ConnectCallback), m_Socket);
            }
            catch (Exception ex)
            {
                if (Notifications != null)
                {
                    Notifications(Notification.ConnectError, "連線失敗");
                }
                mobj_ErrorLog.WriteError("連線失敗:" + ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

            }
        }
        private void ConnectCallback(IAsyncResult ar)
        {
            try
            {

                Socket client = (Socket)ar.AsyncState;
                //20110817 Modified by peter
                client.SendBufferSize = 16 * 1024 * 1024;
                client.ReceiveBufferSize = 16 * 1024 * 1024;
                m_ObjTcpSocket_ConnectedChangedEx(client, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Notifications(Notification.DisconnectError, "連線中斷異常" + ex.Message.ToString());
            }
        }
        public void SocketClientDispose()
        {
            GC.SuppressFinalize(this);

            if (mobj_ErrorLog != null)
            {
                mobj_ErrorLog.Close();

            }


            if (m_Socket != null)
            {
                m_Socket.Shutdown(SocketShutdown.Both);
                m_Socket.Close();

            }


        }

        /// <summary>
        /// Socket物件有連線異動觸發事件
        /// </summary>
        private void m_ObjTcpSocket_ConnectedChangedEx(object sender, EventArgs e)
        {
            try
            {
                if (m_Socket.Connected)
                {
                    try
                    {
                        m_strlocalip = ((System.Net.IPEndPoint)(m_Socket.LocalEndPoint)).Address.ToString();
                        m_strlocalport = ((IPEndPoint)(m_Socket.LocalEndPoint)).Port.ToString();
                        m_ObjTcpSocketSendData("01" + DateTime.Now.ToString("yyyyMMddHHmmss")
                            + m_strCompany.PadRight(7, ' ') + m_strUserId.PadRight(20, ' ') + " ");
                        abol_isBeginSend = true;

                        m_ObjTcpSocket_Receive();
                        if (Notifications != null)
                        {
                            Notifications(Notification.Disconneted, "連線已關閉");
                        }
                        mobj_ErrorLog.WriteEntryData("m_ObjTcpSocket_ConnectedChangedEx:連線已關閉");
                    }
                    catch (Exception ex)
                    {
                        if (Notifications != null)
                        {
                            Notifications(Notification.SendDataError, "資訊傳遞錯誤" +
                                    ex.ToString());
                        }
                        mobj_ErrorLog.WriteError(ex.Source, "m_ObjTcpSocket_ConnectedChangedEx:連線已關閉:" + ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

                    }

                }
                else
                {
                    if (Notifications != null)
                    {
                        Notifications(Notification.Disconneted,
                                 "連線已關閉");
                    }
                    mobj_ErrorLog.WriteEntryData("m_ObjTcpSocket_ConnectedChangedEx:Connected=false 連線已關閉");
                }
            }
            catch (Exception ex)
            {

                mobj_ErrorLog.WriteError(ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

            }

        }
        /// <summary>
        /// 接收資料處理
        /// </summary>
        private void m_ObjTcpSocket_Receive()
        {
            try
            {
                while (m_Socket.Connected)
                {
                    try
                    {
                        byte[] lbyt_Head = new byte[1];
                        byte[] lbyt_Len = new byte[4];
                        byte[] lbyt_Data;
                        int lint_Len = 0;
                        string STR_ReceivedData = "";


                        try
                        {


                            bool blnBreakLoop = true;
                            do
                            {
                                lbyt_Head = ReceiveRawBuffer(1, m_Socket);
                                switch (lbyt_Head[0])
                                {
                                    case 0x02:
                                        blnBreakLoop = false;
                                        break;
                                    case 0x0e:
                                        blnBreakLoop = false;
                                        break;
                                    case 0x13:
                                        blnBreakLoop = false;
                                        mobj_ErrorLog.WriteEntryData("ok");
                                        break;
                                    case 0x0b:
                                        blnBreakLoop = false;
                                        break;
                                    case 0x00://判斷如果沒收到資料就break 迴圈
                                        blnBreakLoop = false;
                                        break;
                                    case 0x1e:
                                        blnBreakLoop = false;
                                        break;
                                    default:

                                        break;
                                }

                            } while (blnBreakLoop);

                            lbyt_Len = ReceiveRawBuffer(4, m_Socket);
                            lint_Len = int.Parse(new string(Encoding.Default.GetChars(lbyt_Len)));
                            if (lint_Len > 5000)
                            {
                                lint_Len = 0;
                            }
                            lbyt_Data = new byte[lint_Len];

                        }
                        catch (Exception ex)
                        {
                            if (Notifications != null)
                            {
                                Notifications(Notification.Error, ex.Message.ToString());
                            }
                            mobj_ErrorLog.WriteError(ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

                            lbyt_Data = new byte[1024];
                            //						MessageBox.Show(new string(Encoding.Default.GetChars(lbyt_Head)) + ";"
                            //							+ new string(Encoding.Default.GetChars(lbyt_Len)) + ";"
                            //							+ new string(Encoding.Default.GetChars(lbyt_Data)) + ";");

                        }

                        if (lint_Len > 1)
                        {
                            lbyt_Data = ReceiveRawBuffer(lint_Len, m_Socket);
                            if (lbyt_Head[0] != 0x1e)
                            {
                                STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Head))
                                    + new string(Encoding.Default.GetChars(lbyt_Len))
                                    + new string(Encoding.Default.GetChars(lbyt_Data));
                            }
                            if (lbyt_Head[0] == 0x13)
                            {
                                //收到server ack時
                                //表示收到
                                abol_isAlive = true;
                                mobj_ErrorLog.WriteEntryData("ALIVE!");

                            }
                            else if (lbyt_Head[0] == 0x02)
                            {
                                if (Notifications != null)
                                {
                                    Notifications(Notification.Conneted, "連線成功");
                                }
                                if (STR_ReceivedData.Substring(18, 2) == "00")
                                {
                                    //MessageBox.Show("Socket 連線確認 !!");
                                }
                                else
                                {
                                    //setSocketInfoStatus("系統行情連線失敗,即將關閉", true);
                                }
                            }
                            else if (lbyt_Head[0] == 0x0b)
                            {


                                mobj_ErrorLog.WriteEntryData("GW Mapping!");
                                if (Notifications != null)
                                {
                                    Notifications(Notification.AddMapping, "GW Mapping");
                                }
                            }
                            else
                            {
                                switch (lbyt_Head[0])
                                {
                                    case 0x0e:

                                        //表示收到
                                        abol_isAlive = true;
                                        if (STR_ReceivedData.Substring(5, 2) == "00")
                                        {
                                            if (Notifications != null)
                                            {
                                                Notifications(Notification.ReceivedData, STR_ReceivedData.Substring(7, STR_ReceivedData.Length - 7));
                                            }
                                        }
                                        else
                                        {
                                            if (Notifications != null)
                                            {
                                                Notifications(Notification.ReceivedErrorData, STR_ReceivedData.Substring(7, STR_ReceivedData.Length - 7));
                                            }
                                        }
                                        //mobj_ErrorLog.WriteEntryData(STR_ReceivedData.Substring(7, STR_ReceivedData.Length - 7));
                                        break;
                                    case 0x1e: //V1.0.0.42 added by peter新增壓縮FLAG
                                        lbyt_Data = Decompress(lbyt_Data);
                                        lbyt_Head[0] = 0x0e;
                                        STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Head))
                            + new string(Encoding.Default.GetChars(lbyt_Len))
                            + new string(Encoding.Default.GetChars(lbyt_Data));


                                        //表示收到
                                        abol_isAlive = true;
                                        if (STR_ReceivedData.Substring(5, 2) == "00")
                                        {
                                            if (Notifications != null)
                                            {
                                                Notifications(Notification.ReceivedData, STR_ReceivedData.Substring(7, STR_ReceivedData.Length - 7));
                                            }
                                        }
                                        else
                                        {
                                            if (Notifications != null)
                                            {
                                                Notifications(Notification.ReceivedErrorData, STR_ReceivedData.Substring(7, STR_ReceivedData.Length - 7));
                                            }
                                        }

                                        //mobj_ErrorLog.WriteEntryData(STR_ReceivedData.Substring(7, STR_ReceivedData.Length - 7));
                                        break;
                                    default:
                                        // setSocketInfoStatus("Switch Defautl Data:" + STR_ReceivedData, true);
                                        break;

                                }
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        if (Notifications != null)
                        {
                            Notifications(Notification.Error, ex.Message.ToString());
                        }
                        mobj_ErrorLog.WriteError(ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

                    }
                }
            }
            catch (Exception ex)
            {
                if (Notifications != null)
                {
                    Notifications(Notification.ReceiveAbort, "接收中斷" + ex.Message.ToString());
                }
                mobj_ErrorLog.WriteError(ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

            }
        }
        /// <summary>
        /// 讀取網路流資料
        /// </summary>
        //private int TCP_ByteRead(System.Net.Sockets.NetworkStream Obj_Stream, byte[] buffer, int start, int length)
        //{
        //    int lint_total = 0;
        //    int lint_read = 0;
        //    int lint_count = 0;

        //    do
        //    {
        //        lint_read = Obj_Stream.Read(buffer, start + lint_total, length - lint_total);
        //        lint_total += lint_read;
        //        lint_count++;
        //    } while ((lint_total < length) && (lint_count < 100));
        //    return lint_total;
        //}

        /// <summary>
        /// 傳送資料
        /// </summary>
        public void m_ObjTcpSocketSendData(string str_Data)
        {
            try
            {
                if (m_Socket != null && m_Socket.Connected)
                {

                    //取得頭碼
                    byte byte_TradeFlag = byte.Parse(str_Data.Substring(0, 2));

                    byte byte_EndFlag = byte.Parse("10");


                    if (str_Data.Length > 3)
                    {
                        str_Data = str_Data.Substring(2, str_Data.Length - 2);
                    }
                    else
                    {
                        str_Data = "";
                    }

                    byte[] SendDataBuffer = new byte[4906];
                    int lint_Len = 0;
                    Encoding EncodType;
                    EncodType = Encoding.Default;

                    lint_Len = getStringLen(str_Data) + 1;
                    //將字串轉成buffer
                    SendDataBuffer = EncodType.GetBytes(" " + lint_Len.ToString().PadLeft(4, '0') + str_Data + " ");
                    //加尾碼
                    SendDataBuffer.SetValue(byte_EndFlag, SendDataBuffer.Length - 1);
                    //將頭碼加在buffer最前面
                    SendDataBuffer.SetValue(byte_TradeFlag, 0);
                    m_Socket.Send(SendDataBuffer);
                }
            }
            catch (Exception ex)
            {
                if (Notifications != null)
                {
                    Notifications(Notification.SendDataError, "資訊傳遞錯誤" +
                            ex.ToString());
                }
                mobj_ErrorLog.WriteError(ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

            }

        }
        /// <summary>
        /// 取字串轉byte後長度
        /// </summary>
        private static int getStringLen(string STR_Data)
        {
            byte[] bString = System.Text.Encoding.Default.GetBytes(STR_Data);
            return bString.Length;


        }
        public byte[] ReceiveRawBuffer(int Size, Socket RcvS)
        {
            try
            {
                int total = 0;
                int RcvLength = 0;
                byte[] RcvBuffer = new byte[Size];

                total += RcvS.Receive(RcvBuffer, 0, RcvBuffer.Length, System.Net.Sockets.SocketFlags.None);
                if (total > 0)
                {
                    while (total != RcvBuffer.Length)
                    {
                        total += RcvLength = RcvS.Receive(RcvBuffer, total, RcvBuffer.Length - total, SocketFlags.None);
                        if (RcvLength > 0)
                            continue;
                        else
                            throw new Exception("remote disconnected");
                    }
                }
                else
                    throw new Exception("remote disconnected");
                return RcvBuffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        //V1.0.0.42 added by peter新增壓縮FLAG
        public static byte[] Decompress(byte[] compressed)
        {
            using (MemoryStream ms = new MemoryStream(compressed))
            {
                using (GZipStream zip = new GZipStream(ms, CompressionMode.Decompress))
                using (BinaryReader sr = new BinaryReader(zip, Encoding.UTF8))
                {
                    return sr.ReadBytes(10000);
                }

            }

        }
    }
}
