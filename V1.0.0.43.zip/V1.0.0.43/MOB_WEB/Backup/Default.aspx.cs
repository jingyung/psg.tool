﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

//public partial class _Default : BasePage 
public partial class _Default : System.Web.UI.Page
{
    /// <summary>
    /// 起始必須接收; COMP_ID
    /// </summary>
    private const string _COMP_ID = "COMP_ID";
    /// <summary>
    /// 起始必須接收; ACCT_ID
    /// </summary>
    private const string _ACCT_ID = "ACCT_ID";
    /// <summary>
    /// 決定導向哪一功能頁面
    /// </summary>
    private const string _PROG_ID = "PROG_ID";

    protected void Page_Load(object sender, EventArgs e)
    {
        Response.AddHeader("P3P", "CP=CAO PSA OUR");

        if (this.IsPostBack)
        {
        }
        else
        {


            //取得參數
            if (Request.Cookies["PARAM"] != null)
            {
                //驗證通過 允許移轉功能頁面
                System.Web.Security.FormsAuthentication.SetAuthCookie("wwww", false);

            }
            else if ((Request.QueryString["PARAM"] != null) && (Request.QueryString["PARAM"].Length > 0))
            {
                if (Request.QueryString["PARAM"] == "MOBQ080a.aspx" || Request.QueryString["PARAM"] == "MOBQ081a.aspx")
                {
                    string url = "~/MOB/" + Request.QueryString["PARAM"] + "?";
                    string accid = Request.QueryString["accid"];
                    string date1 = Request.QueryString["date1"];

                    string date2 = Request.QueryString["date2"];

                    string comid = Request.QueryString["comid"];
                    string sort = Request.QueryString["sort"];



                    string param = "date1=" + date1 + "&date2=" + date2 + "&sort=" + sort + "&accid=" + accid + "&comid=" + comid;

                    System.Web.Security.FormsAuthentication.SetAuthCookie(accid, false);
                    Response.Redirect(url + param, false);


                }
                else
                {
                    string AfterRedirectTime = System.Configuration.ConfigurationSettings.AppSettings["AfterRedirectTime"];
                    string AfterRedirectUrl = System.Configuration.ConfigurationSettings.AppSettings["AfterRedirectUrl"];

                    int NowTime = int.Parse(DateTime.Now.ToString("HHmmss"));

                    int Time;
                    if (AfterRedirectTime.Trim().Length > 0)
                    {
                        Time = int.Parse(AfterRedirectTime.Replace(":", ""));

                        if (Time < NowTime)
                        {

                            int pos = Request.RawUrl.ToUpper().IndexOf("&ASPXAUTO");
                            string url = Request.RawUrl;
                            if (pos > -1)
                            {
                                url = url.Substring(0, pos); 
                            }
                            Response.Redirect(AfterRedirectUrl +url, false);
                            return;
                        }
                    }

                    string rawURL = Request.RawUrl;
                    string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=




                    Int32 cookiePos = param_str.ToUpper().IndexOf("&ASPXAUTO");
                    if (cookiePos > -1)
                    {
                        param_str = param_str.Substring(0, cookiePos);
                    }

                    //Response.Write(param_str);

                    FunctionHandler fh = new FunctionHandler();
                    string decodeParam = fh.fh_EncString(param_str);
                    string[] param = decodeParam.Split('&');
                    if (decodeParam.Contains("LEVEL"))
                        ForMessage(param, fh);
                    else
                        ForAccount(param, fh);
                }
            }
            else
            {
                System.Web.Security.FormsAuthentication.SignOut();
                Session.Clear();
                Session.Abandon();
                //close window
                this.ClientScript.RegisterStartupScript(this.GetType(), "NO_Q", "NoQ_Close('NO_PARAM');", true);
                return;
            }




        }
    }


    private void ForAccount(string[] param, FunctionHandler fh)
    {
        string comp_id = "";
        string acct_id = "";
        string prog_id = "";
        string c_no = "";
        string checkNo = "";

        for (Int32 idx = 0; idx < param.Length; idx++)
        {
            if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
            {
                comp_id = (param[idx].Split('='))[1];
            }
            if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
            {
                acct_id = (param[idx].Split('='))[1];
            }
            if (param[idx].ToUpper().IndexOf("PROG_ID") > -1)
            {
                prog_id = (param[idx].Split('='))[1];
            }
            if (param[idx].ToUpper().IndexOf("C_NO") > -1)
            {
                c_no = (param[idx].Split('='))[1];
            }
        }

        //COMP_ID和ACCT_ID要有,否則關閉

        //if ((Request.QueryString[_COMP_ID] != null) && (Request.QueryString[_COMP_ID].Length > 0) && (Request.QueryString[_ACCT_ID] != null) && (Request.QueryString[_ACCT_ID].Length > 0))
        if ((comp_id != "") && (acct_id != ""))
        {
            //
            ////BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //////if (_Emp != null)
            //////{
            ////    _Emp.ACCT_ID = Request.QueryString[_ACCT_ID];
            ////    _Emp.COMP_ID = Request.QueryString[_COMP_ID];
            ////    Session["OnUser"] = _Emp;
            //////}

            //----
            //string COMP_ID = Request.QueryString[_COMP_ID];
            //string ACCT_ID = Request.QueryString[_ACCT_ID];
            //----
            //if (Request.QueryString[_PROG_ID] != null && Request.QueryString[_PROG_ID].Length > 0)
            if (c_no != fh.fh_GetCheckNo(acct_id))
            {
                //Response.Write("c_no=" + c_no + "--acct_id=" + acct_id + "--ccc=" + fh.fh_GetCheckNo(acct_id));
                System.Web.Security.FormsAuthentication.SignOut();
                Session.Clear();
                Session.Abandon();
                //close window
                this.ClientScript.RegisterStartupScript(this.GetType(), "NO_Q", "NoQ_Close('CHECK_NO_ERROR');", true);
                return;
            }
            else
            {
                if (prog_id != "")
                {
                    try
                    {

                        /*
                        System.Xml.XmlDocument _XmlDoc = new System.Xml.XmlDocument();
                        _XmlDoc.Load(Server.MapPath("~/MOBQ.xml"));

                        System.Xml.XmlNodeList nodeList;
                        System.Xml.XmlNode root = _XmlDoc.DocumentElement;

                        nodeList = root.SelectNodes("MOBQFunction");

                        foreach (System.Xml.XmlNode itemNode in nodeList)
                        {
                            try
                            {
                                if (itemNode.Attributes["PROG_ID"].Value.Equals(Request.QueryString[_PROG_ID]))
                                {
                                    //驗證通過 允許移轉功能頁面
                                    System.Web.Security.FormsAuthentication.SetAuthCookie(Request.QueryString[_ACCT_ID], false);

                                    string _URL = itemNode.Attributes["DIRECTORY"].Value;
                                    if (Request["TEST_CASE"] == "RUN")
                                    {
                                        Response.Redirect(_URL + "?TEST_CASE=RUN&TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") +"&COMP_ID="+COMP_ID+"&ACCT_ID="+ACCT_ID , false);
                                    }
                                    else
                                    {
                                        Response.Redirect(_URL + "?TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + COMP_ID + "&ACCT_ID=" + ACCT_ID, false);
                                        
                                        
                                    }
                                    return;
                                }
                            }
                            catch (Exception Exc_x)
                            {
                                Response.Write(Exc_x.Message);
                                throw Exc_x;
                            }
                        }
                        */

                        string _URL = "";
                        //System.Web.Security.FormsAuthentication.SignOut();

                        if (prog_id.IndexOf("MOBQ010") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            Response.Write("XXXX");
                            _URL = "~/MOB/MOBQ010.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ020") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ020.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ030") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ030.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ040") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ040.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ041") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ041.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ050") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ050.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ060") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ060.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ070") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ070.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ071") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ071.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ080") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ080.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ081") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ081.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ090") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ090.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ100") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ100.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ110") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ110.aspx";
                        }

                        if (prog_id.IndexOf("MOBQ120") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ120.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ130") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ130.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ140") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ140.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ150") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ150.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ160") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ160.aspx";
                        }
                        if (prog_id.IndexOf("MOBQ170") > -1)
                        {
                            //驗證通過 允許移轉功能頁面
                            System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                            _URL = "~/MOB/MOBQ170.aspx";
                        }
                        string urlParam = "";

                        //if (Request["TEST_CASE"] == "RUN")
                        //{
                        //    urlParam = "TEST_CASE=RUN&TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + comp_id + "&ACCT_ID=" + acct_id;
                        //    urlParam = fh.fh_EncString(urlParam);
                        //    //Response.Redirect(_URL + "?TEST_CASE=RUN&TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + COMP_ID + "&ACCT_ID=" + ACCT_ID, false);

                        //}
                        //else
                        //{
                        urlParam = "TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + comp_id + "&ACCT_ID=" + acct_id;
                        urlParam = fh.fh_EncString(urlParam);
                        //Response.HeaderEncoding = System.Text.Encoding.GetEncoding("big5");
                        //Response.ContentEncoding = System.Text.Encoding.GetEncoding("big5");

                        //  Response.Write("<meta http-equiv=Content-Type content=text/html;charset=big5 />"); 
                        //Response.Redirect(_URL + "?TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + COMP_ID + "&ACCT_ID=" + ACCT_ID, false);


                        Response.Redirect(Request.Url.Scheme + "://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam, false);
                        //Response.Redirect("http://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam, false);

                        // Response.Write("http://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam);

                        //                          Response.Redirect(String.Format("{0}?ReturnUrl={1}",
                        //System.Web.Security.FormsAuthentication.LoginUrl, 
                        //"http://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam),false );
                        return;

                    }
                    catch (Exception Exc)
                    {

                        Response.Write(Exc.Message);
                        //throw;
                    }
                }
                else
                {
                    Response.Write("==未指定變數PROG_ID==");
                    return;
                }
            }
        }
        else
        {

            System.Web.Security.FormsAuthentication.SignOut();
            Session.Clear();
            Session.Abandon();
            //close window
            this.ClientScript.RegisterStartupScript(this.GetType(), "NO_Q", "NoQ_Close('NO_PARAM');", true);
            return;
        }
    }


    private void ForMessage(string[] param, FunctionHandler fh)
    {
        string LEVEL = "";
        string comp_id = "";
        string acct_id = "";
        string PROG_ID = "";
        string C_NO = "";
        string checkNo = "";

        for (Int32 idx = 0; idx < param.Length; idx++)
        {
            if (param[idx].ToUpper().Contains("LEVEL"))
            {
                LEVEL = (param[idx].Split('='))[1];
            }
            if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
            {
                comp_id = (param[idx].Split('='))[1];
            }
            if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
            {
                acct_id = (param[idx].Split('='))[1];
            }
            if (param[idx].ToUpper().Contains("PROG_ID"))
            {
                PROG_ID = (param[idx].Split('='))[1];
            }
            //if (param[idx].ToUpper().Contains("C_NO")  )
            //{
            //    C_NO = (param[idx].Split('='))[1];
            //}
        }

        //COMP_ID和ACCT_ID要有,否則關閉

        //if ((Request.QueryString[_COMP_ID] != null) && (Request.QueryString[_COMP_ID].Length > 0) && (Request.QueryString[_ACCT_ID] != null) && (Request.QueryString[_ACCT_ID].Length > 0))
        if ((LEVEL != "") && (acct_id != ""))
        {

            //if (C_NO != fh.fh_GetCheckNo(acct_id))
            //{
            //    //Response.Write("c_no=" + c_no + "--acct_id=" + acct_id + "--ccc=" + fh.fh_GetCheckNo(acct_id));
            //    System.Web.Security.FormsAuthentication.SignOut();
            //    Session.Clear();
            //    Session.Abandon();
            //    //close window
            //    this.ClientScript.RegisterStartupScript(this.GetType(), "NO_Q", "NoQ_Close('CHECK_NO_ERROR');", true);
            //    return;
            //}
            //else
            //{
            if (PROG_ID != "")
            {
                try
                {


                    string _URL = "";

                    if (PROG_ID.IndexOf("MSGM010") > -1)
                    {
                        //驗證通過 允許移轉功能頁面
                        System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                        _URL = "~/MSG/MSGM010.aspx";
                    }
                    if (PROG_ID.IndexOf("MSGM020") > -1)
                    {
                        //驗證通過 允許移轉功能頁面
                        System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                        _URL = "~/MSG/MSGM020.aspx";
                    }
                    if (PROG_ID.IndexOf("MSGQ010") > -1)
                    {
                        //驗證通過 允許移轉功能頁面
                        System.Web.Security.FormsAuthentication.SetAuthCookie(acct_id, false);
                        _URL = "~/MSG/MSGQ010.aspx";
                    }
                    string urlParam = "";

                    //if (Request["TEST_CASE"] == "RUN")
                    //{
                    //    urlParam = "TEST_CASE=RUN&TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + comp_id + "&ACCT_ID=" + acct_id;
                    //    urlParam = fh.fh_EncString(urlParam);
                    //    //Response.Redirect(_URL + "?TEST_CASE=RUN&TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + COMP_ID + "&ACCT_ID=" + ACCT_ID, false);

                    //}
                    //else
                    //{
                    urlParam = "TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&LEVEL=" + LEVEL + "&COMP_ID=" + comp_id + "&ACCT_ID=" + acct_id;
                    urlParam = fh.fh_EncString(urlParam);
                    //Response.HeaderEncoding = System.Text.Encoding.GetEncoding("big5");
                    //Response.ContentEncoding = System.Text.Encoding.GetEncoding("big5");

                    //  Response.Write("<meta http-equiv=Content-Type content=text/html;charset=big5 />"); 
                    //Response.Redirect(_URL + "?TIME=" + DateTime.Now.ToString("yyyyMMddHHmmss") + "&COMP_ID=" + COMP_ID + "&ACCT_ID=" + ACCT_ID, false);




                    Response.Redirect(Request.Url.Scheme + "://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam, false);

                    //Response.Redirect("http://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam, false);

                    // Response.Write("http://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam);

                    //                          Response.Redirect(String.Format("{0}?ReturnUrl={1}",
                    //System.Web.Security.FormsAuthentication.LoginUrl, 
                    //"http://" + Request.Url.Authority + Request.Url.Segments[0] + Request.Url.Segments[1] + _URL.Substring(2) + "?PARAM=" + urlParam),false );
                    return;

                }
                catch (Exception Exc)
                {
                    Response.Write(Exc.Message);
                    //throw;
                }
            }
            else
            {
                Response.Write("==未指定變數PROG_ID==");
                return;
            }
            //}
        }
        else
        {

            System.Web.Security.FormsAuthentication.SignOut();
            Session.Clear();
            Session.Abandon();
            //close window
            this.ClientScript.RegisterStartupScript(this.GetType(), "NO_Q", "NoQ_Close('NO_PARAM');", true);
            return;
        }
    }

}
