﻿
using System;
using System.Web.Services;
using System.Data;
using Newtonsoft.Json;
using System.Web.UI.WebControls;


public partial class MSG_MSGQ010 : BasePage
{

    public string Message_IP  ;
    public string Message_PORT ;
    protected void Page_Load(object sender, EventArgs e)
    {

          Message_IP = System.Configuration.ConfigurationSettings.AppSettings["Message_IP"];
          Message_PORT = System.Configuration.ConfigurationSettings.AppSettings["Message_PORT"];

        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string LEVEL = "";
            string COMP_ID = "";
            string ACCT_ID = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("LEVEL") > -1)
                {
                    LEVEL = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    COMP_ID = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    ACCT_ID = (param[idx].Split('='))[1];
                }
            }
            //------------------------





            if (User.Identity.Name.Trim() != ACCT_ID)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.txtLEVEL.Value = LEVEL;
                this.txtCompany.Value = COMP_ID;
                this.txtACC_ID.Value = ACCT_ID;


                //  this.company.Value = comp_id;
                //  this.account.Value = acct_id;
            }



        }
    }



    [WebMethod()]
    public static string MSGQ010_PUBLIC(string UserLevel, string MessageType
          , string LoginId
        , string LoginCompany
        , int p
        , int max
        )
    {

        string ErMsg = string.Empty;
        string JSON = string.Empty;
        FunctionHandler fh = new FunctionHandler();


        try
        {

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = ws.WS_UserPublicMessage(UserLevel, MessageType
          , LoginId
          , LoginCompany
          , p, max
        );


            JSON = fh.DataSetToJSON(ds);



        }
        catch (Exception ex)
        {

        }
        return JSON;

    }


    [WebMethod()]
    public static string MSGQ010_PRIVATE(string UserLevel, string MessageType
          , string LoginId
        , string LoginCompany
        , int p
        , int max
        )
    {

        string ErMsg = string.Empty;
        string JSON = string.Empty;
        FunctionHandler fh = new FunctionHandler();


        try
        {

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = ws.WS_UserPrivateMessage(UserLevel, MessageType
          , LoginId
          , LoginCompany
          , p, max
        );


            JSON = fh.DataSetToJSON(ds);



        }
        catch (Exception ex)
        {

        }
        return JSON;

    }
}
