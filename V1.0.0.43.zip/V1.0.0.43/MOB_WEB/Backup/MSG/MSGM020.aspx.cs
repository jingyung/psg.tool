﻿
using System;
using System.Web.Services;
using System.Data;
using Newtonsoft.Json;
using System.Web.UI.WebControls;

public partial class MSG_MSGM020 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string LEVEL = "";
            string COMP_ID = "";
            string ACCT_ID = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("LEVEL") > -1)
                {
                    LEVEL = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    COMP_ID = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    ACCT_ID = (param[idx].Split('='))[1];
                }
            }
            //------------------------





            if (User.Identity.Name.Trim() != ACCT_ID)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.txtLEVEL.Value = LEVEL;
                this.txtCompany.Value = COMP_ID;
                this.txtACC_ID.Value = ACCT_ID;

                this.txtACCTQ.Style.Add("display", "none");

                switch (LEVEL)
                {

                    case "1": //admin

                        SetMessageOption(LEVEL);

                        this.spManagerQ.Style.Add("display", "");
                        this.spAEQ.Style.Add("display", "none");

                        this.spManager.Style.Add("display", "");
                        this.spAE.Style.Add("display", "none");

                        this.trOrder.Style.Add("display", "");

                        this.thOrder.Style.Add("display", "");
                        
                        break;
                    case "2": //Superviser
                        SetMessageOption(LEVEL);

                        this.spManagerQ.Style.Add("display", "");
                        this.spAEQ.Style.Add("display", "none");
                        this.spManager.Style.Add("display", "");
                        this.spAE.Style.Add("display", "none");

                        this.trOrder.Style.Add("display", "none");
                        this.thOrder.Style.Add("display", "none");

                        break;
                    default: //AE
                        SetMessageOption(LEVEL);
                        this.spManagerQ.Style.Add("display", "none");
                        this.spAEQ.Style.Add("display", "");

                        this.spManager.Style.Add("display", "none");
                        this.spAE.Style.Add("display", "");

                        this.trOrder.Style.Add("display", "none");
                        this.thOrder.Style.Add("display", "none");
                        break;

                }
                SetTime_St(LEVEL);
                SetTime_Ed(LEVEL);
                //  this.company.Value = comp_id;
                //  this.account.Value = acct_id;
            }



        }
    }
    private void SetTime_St(string Level)
    {
        DateTime dt = new DateTime(1, 9, 1, 0, 0, 0, 0);

        for (int i = 0; i < 1440; i++)
        {

            this.drpTime_St.Items.Add(new ListItem(dt.ToString("HH:mm"), dt.ToString("HHmm")));
            dt = dt.AddMinutes(1);
        }
        drpTime_St.SelectedIndex = 0;

        //
    }
    private void SetTime_Ed(string Level)
    {
        DateTime dt = new DateTime(1, 9, 1, 0, 0, 0, 0);

        for (int i = 0; i < 1440; i++)
        {

            this.drpTime_Ed.Items.Add(new ListItem(dt.ToString("HH:mm"), dt.ToString("HHmm")));
            dt = dt.AddMinutes(1);
        }

        drpTime_Ed.SelectedIndex = 1440 - 1;
        //
    }
    private void SetMessageOption(string Level)
    {
        switch (Level)
        {
            case "1":
                this.drpMessageOptionQ.Items.Add(new ListItem("公共訊息", "0"));
                this.drpMessageOptionQ.Items.Add(new ListItem("營業員訊息", "1"));
                this.drpMessageOptionQ.Items.Add(new ListItem("客戶訊息", "2"));


                this.drpMessageOption.Items.Add(new ListItem("公共訊息", "0"));
                this.drpMessageOption.Items.Add(new ListItem("營業員訊息", "1"));
                this.drpMessageOption.Items.Add(new ListItem("客戶訊息", "2"));
                break;
            case "2":

                this.drpMessageOptionQ.Items.Add(new ListItem("公共訊息", "0"));
                this.drpMessageOptionQ.Items.Add(new ListItem("營業員訊息", "1"));
                this.drpMessageOptionQ.Items.Add(new ListItem("客戶訊息", "2"));

                this.drpMessageOption.Items.Add(new ListItem("公共訊息", "0"));
                this.drpMessageOption.Items.Add(new ListItem("營業員訊息", "1"));
                this.drpMessageOption.Items.Add(new ListItem("客戶訊息", "2"));
                break;
            default:

                this.drpMessageOptionQ.Items.Add(new ListItem("公共訊息", "0"));

                this.drpMessageOptionQ.Items.Add(new ListItem("客戶訊息", "2"));

                this.drpMessageOption.Items.Add(new ListItem("公共訊息", "0"));

                this.drpMessageOption.Items.Add(new ListItem("客戶訊息", "2"));
                break;


        }

    }




    [WebMethod()]
    public static string MSGM020COUNT(string UserLevel, string MessageType, string MessageOption
        , string GroupID, string ID
        , string DateStart
         , string DateEnd
          , string LoginId
        , string LoginCompany
 
        )
    {

        string ErMsg = string.Empty;
        string JSON = string.Empty;
        FunctionHandler fh = new FunctionHandler();


        try
        {

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = ws.WS_SelectCountMessage(UserLevel, MessageType, MessageOption, GroupID, ID

        , DateStart
         , DateEnd
          , LoginId
    , LoginCompany
        );


            JSON = fh.DataSetToJSON(ds);



        }
        catch (Exception ex)
        {

        }
        return JSON;

    }


    [WebMethod()]
    public static string MSGM020(string UserLevel, string MessageType, string MessageOption
        , string GroupID, string ID
        , string DateStart
         , string DateEnd
          , string LoginId
        ,string LoginCompany
        , int p
        , int max
        )
    {

        string ErMsg = string.Empty;
        string JSON = string.Empty;
        FunctionHandler fh = new FunctionHandler();


        try
        {

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = ws.WS_SelectMessage(UserLevel, MessageType, MessageOption, GroupID, ID

        , DateStart
         , DateEnd
          , LoginId, LoginCompany

          , p, max
        );


            JSON = fh.DataSetToJSON(ds);



        }
        catch (Exception ex)
        {

        }
        return JSON;

    }



    [WebMethod()]
    public static string MSGM020_DEL(string UserLevel, string Seq,
            string LoginId
        , string LoginCompany
        )
    {

        string ErMsg = string.Empty;
        string JSON = string.Empty;
        FunctionHandler fh = new FunctionHandler();


        try
        {

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = ws.WS_DelMessage(UserLevel, Seq, LoginId, LoginCompany

        );


            JSON = fh.DataSetToJSON(ds);



        }
        catch (Exception ex)
        {

        }
        return JSON;

    }




    [WebMethod()]
    public static string MSGM020_DELALL(string UserLevel, string[] Seq,
            string LoginId
        , string LoginCompany

        )
    {

        string ErMsg = string.Empty;
        string JSON = string.Empty;
        FunctionHandler fh = new FunctionHandler();


        try
        {

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = ws.WS_DelALLMessage(UserLevel, Seq, LoginId, LoginCompany

        );


            JSON = fh.DataSetToJSON(ds);



        }
        catch (Exception ex)
        {

        }
        return JSON;

    }


    [WebMethod]
    public static string MSGM020UPD(string UserLevel, string MessageType, string MessageOption, string GroupID, string ID, string Message
        , string HyperLink
        , string Color
        , string DateStart
         , string DateEnd
        , string TimeStart
         , string TimeEnd
         , string DataOrder
        , string Seq
          , string LoginId
        , string LoginCompany
        )
    {

        string ErMsg = string.Empty;
        string JSON = string.Empty;
        FunctionHandler fh = new FunctionHandler();


        try
        {
  WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataTable dt = ws.WS_UpdMessage(UserLevel, MessageType, MessageOption, GroupID, ID, Message
        , HyperLink
        , Color
        , DateStart
         , DateEnd
        , TimeStart
         , TimeEnd
         , DataOrder
         , Seq
          , LoginId
          , LoginCompany
        );


            JSON = fh.DT_To_JSON(dt);
 


        }
        catch (Exception ex)
        {

        }
        return JSON;
    }
}
