﻿var UserLevel="";
var COMP_ID="";
var ACCT_ID="";
 
$(document).ready(init);
function init()
{
	
	

    $("#btnEnter").bind("click",btnEnter_click);

 
    $("#drpMessageOption").bind("change",drpMessageOption_Change);
    $('#txtDate_Ed').val(fh_GetNowDate());
    $('#txtDate_St').val(fh_GetNowDate());
     UserLevel=$("#txtLEVEL").val(); 
     COMP_ID= $("#txtCompany").val()
   ACCT_ID= $("#txtACC_ID").val()
   
   
    var colors =[
            '000000', '993300', '333300', '000080', '333399', '333333', '800000', 'FF6600',
            '808000', '008000', '008080', '0000FF', '666699', '808080', 'FF0000', 'FF9900',
            '99CC00', '339966', '33CCCC', '3366FF', '800080', '999999', 'FF00FF', 'FFCC00',
            'FFFF00', '00FF00', '00FFFF', '00CCFF', '993366', 'C0C0C0', 'FF99CC', 'FFCC99',
            'FFFF99', 'CCFFFF', '99CCFF', 'FFFFFF']
            
    for (var i=0;i<colors.length;i++)
    {
        var option=document.createElement("option");
         $(option).val(colors[i]);
           $(option).text(colors[i]);
          $(option).css({"background-color": "#"+colors[i]});
        $("#drpColor").append(option);
    }
   
   
}

function drpMessageOption_Change(o)
{
  $("#txtACCT").val("");
    switch($("#drpMessageOption").val())
    {
        case "0":
          
            $("#txtACCT").hide();
            if (UserLevel=="1"||UserLevel=="2")
            {
               $("#spAE").hide();
               $("#spManager").show();
            }
            else
            {
                $("#spAE").show ();
               $("#spManager").hide();
            }
        break;
        case "1":
               $("#txtACCT").show();
            $("#spAE").hide();
            $("#spManager").hide();
        break;
        case "2":
              $("#txtACCT").show();
            $("#spAE").hide();
            $("#spManager").hide();
        break;
    }
 
}

function checkall()
{
    var UserLevel=$("#txtLEVEL").val(); 
    if ($("#drpMessageOption").val()!="0")
    {
        if($("#txtACCT").val().fulltrim() == "")
        {
            alert ("帳號為必輸欄位")  
            return false;
        }
    }
    else
    {
     switch(UserLevel)
     {
         case "1":
         case "2":
     
                if (!$("#chkAE").attr("checked")&&!$("#chkCUSTOMER").attr("checked"))
                {
                 alert ("必須勾選客戶或營業員")  
                return false;
                } 
          
         break;
         default:
     
                if (!$("#rdoALL").attr("checked") )  
                {
                    if ( $("#txtGroupID").val().fulltrim() == "")
                    {
                    alert ("群組為必輸欄位")  
                    return false;
                    }
                }
         break;
     }
        
    }
    if($("#txtContent").val() == "")
    {
        alert ("訊息內容為必輸欄位")  
        return false;
    }
   else
   {
       if ($("#txtContent").val().replace(/[^\x00-\xff]/g,"xx").length>600) 
       {
       alert ("訊息內容最多300個中文字或600個英數字體")  
        return false;
        }
 
   }
//    if($("#txtHyperLink").val() != "")
//    {
//        if (!checkURL(JSON_Trim($("#txtHyperLink").val())))
//        {
//           alert('超連結請輸入完整URL，例如http://www.yahoo.com.tw');           
//        return false;
//        }
//    }
   
    var objStartDate = $('#txtDate_St').datepicker("getDate");
    var objEndDate = $('#txtDate_Ed').datepicker("getDate");
    if (objStartDate == null) 
    {
        alert('起始日期為必輸欄位');           
        return false;
    }
    if (objEndDate == null) 
    {
        alert('結束日期為必輸欄位');           
        return false;
    }
    if (objStartDate != null & objEndDate != null) 
    {
        if (objStartDate > objEndDate) 
        {
            alert('起始日期不可大於結束日期');
            return false;
        }
        else
        {
            if ($("#drpTime_St").val()>$("#drpTime_Ed").val())
            {
                alert('起始時間不可大於結束時間');
                return false;
            }
        
        }
    }

    
    return true;
}

function getMessageOption()
{
     var UserLevel=$("#txtLEVEL").val(); 
     var MessageOption=$("#drpMessageOption").val();
 
     switch(UserLevel)
     {
     case "1":
        if (MessageOption=="0")
        {
              if ($("#chkAE").attr("checked")&&$("#chkCUSTOMER").attr("checked")) return "C";
            else if ($("#chkAE").attr("checked") ) return "A";
           else  if ($("#chkCUSTOMER").attr("checked") ) return "B";
          
        }
        else if (MessageOption=="1") return "D";
        else if (MessageOption=="2") return "E";
     break;
     case "2":
        if (MessageOption=="0")
        {
         if ($("#chkAE").attr("checked")&&$("#chkCUSTOMER").attr("checked")) return "H";
           else if ($("#chkAE").attr("checked") ) return "F";
           else if ($("#chkCUSTOMER").attr("checked") ) return "G";
           
        }
        else if (MessageOption=="1") return "I";
        else if (MessageOption=="2") return "J";
     break;
     default:
        if (MessageOption=="0")
        {
            if ($("#rdoALL").attr("checked") ) return "K";
            else return "L";
          
        }    
        else if (MessageOption=="2") return "M";
     break;
     }
     
     
}

function btnEnter_click()
{
     
    if (!checkall()) return false;
    
    
    var MessageType=$("#drpMessageType").val();
    var MessageOption=getMessageOption();
    var GroupID=JSON_Trim($("#txtGroupID").val());
    var ID=JSON_Trim($("#txtACCT").val());
    var Content=JSON_Trim($("#txtContent").val());
    
    var HyperLink=JSON_Trim($("#txtHyperLink").val());//  .replace(/\//ig, "");
  if (HyperLink!="")
    {

        if (HyperLink.toLowerCase().indexOf("http://") !== -1  )
        {
        
        }
        else 
        {
            if (HyperLink.toLowerCase().indexOf("https://") !== -1 )
            {
            
            }
            else
                HyperLink="http://"+HyperLink;
        }
      
    }
    
    var Color =JSON_Trim($("#drpColor").val().replace(/\#/ig, ""));
    var Date_St=$("#txtDate_St").val().replace(/\//ig, "");
    var Time_St=$("#drpTime_St").val();
    var Date_Ed=$("#txtDate_Ed").val().replace(/\//ig, "");
    var Time_Ed=$("#drpTime_Ed").val();
    var Order=JSON_Trim($("#txtOrder").val());
  
        var tParam = fh_GenParam();
    var m_WhereParm = {  
                        UserLevel:  UserLevel
                        ,MessageType:MessageType
                        ,MessageOption:MessageOption
                        ,GroupID:GroupID
                        ,ID:ID
                        ,Message:Content
                        ,HyperLink:HyperLink
                        ,Color:Color
                        ,DateStart:Date_St
                        ,DateEnd:Date_Ed
                        ,TimeStart:Time_St
                        ,TimeEnd:Time_Ed
                        ,DataOrder:Order
                        ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                     };
    var m_objJSON = fh_CallWebMethod("MSGM010", "MSGM010?uri="+tParam , m_WhereParm , false);
    
    if (m_objJSON.length>0)
    {
        if (m_objJSON[0].ReturnCode=="000")
        {
        alert(m_objJSON[0].ReturnMessage)
        }
        else
        {
         alert(m_objJSON[0].ReturnMessage)
        }
    }
}
 

$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#txtDate_St').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#txtDate_Ed').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});


$(document).ready(function() {
    $('#txtDate_Ed').focus(function() {
        $('#txtDate_Ed').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#EndDate').keyup(function() {
    //        $('#EndDate').val('');
    //    });
    $('#txtDate_Ed').change(function() {
        checkDate(this);
    });
    $('#txtDate_St').focus(function() {
        $('#txtDate_St').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#StartDate').keyup(function() {
    //        $('#StartDate').val('');
    //    });
    $('#txtDate_St').change(function() {
        checkDate(this);
    });
});


 