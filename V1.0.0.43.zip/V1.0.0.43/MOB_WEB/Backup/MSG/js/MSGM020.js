﻿var _dt;
var UserLevel="";
var COMP_ID="";
var ACCT_ID="";
var Action="";
var Seq="";
var p=0;
var max=100;
var  TotalCount=0;
$(document).ready(init);
function init()
{
  $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
      $('#txtDate_StQ').datepicker({
        showButtonPanel: true
    });
    $('#txtDate_EdQ').datepicker({
        showButtonPanel: true
    });
    $('#txtDate_EdQ').focus(function() {
        $('#txtDate_EdQ').datepicker("show");
        $(this).blur(function() { });
    });
    $('#txtDate_EdQ').change(function() {
        checkDate(this);
    });
    $('#txtDate_StQ').focus(function() {
        $('#txtDate_StQ').datepicker("show");
        $(this).blur(function() { });
    });
    $('#txtDate_StQ').change(function() {
        checkDate(this);
    });
 
    $("#drpMessageOptionQ").bind("change",drpMessageOptionQ_Change);
    $("#btnEnterQ").bind("click" ,function (){btnEnterQ_click("");});
    $('#txtDate_EdQ').val(fh_GetNowDate());
    $('#txtDate_StQ').val(fh_GetNowDate());
    
    //-------M
    $('#txtDate_St').datepicker({
        showButtonPanel: true
    });
    $('#txtDate_Ed').datepicker({
        showButtonPanel: true
    });
    $('#txtDate_Ed').focus(function() {
        $('#txtDate_Ed').datepicker("show");
        $(this).blur(function() { });
    });
    $('#txtDate_Ed').change(function() {
        checkDate(this);
    });
    $('#txtDate_St').focus(function() {
        $('#txtDate_St').datepicker("show");
        $(this).blur(function() { });
    });
    $('#txtDate_St').change(function() {
        checkDate(this);
    });
    $("#btnEnter").bind("click",btnEnter_click);
        $("#btnCancel").bind("click",btnCancel_click);

 
    $("#drpMessageOption").bind("change",drpMessageOption_Change);
    $('#txtDate_Ed').val(fh_GetNowDate());
    $('#txtDate_St').val(fh_GetNowDate());

    $("#btnDelAll").bind("click",btnDelAll_click);
    $("#chkAll").bind("click",chkAll_click);
    UserLevel=$("#txtLEVEL").val(); 
       COMP_ID= $("#txtCompany").val()
   ACCT_ID= $("#txtACC_ID").val()
   
    
      $("#btnPageUp").bind("click",btnPageUp_click);
    $("#btnPageDown").bind("click",btnPageDown_click);
    
    
       
    var colors =[
            '000000', '993300', '333300', '000080', '333399', '333333', '800000', 'FF6600',
            '808000', '008000', '008080', '0000FF', '666699', '808080', 'FF0000', 'FF9900',
            '99CC00', '339966', '33CCCC', '3366FF', '800080', '999999', 'FF00FF', 'FFCC00',
            'FFFF00', '00FF00', '00FFFF', '00CCFF', '993366', 'C0C0C0', 'FF99CC', 'FFCC99',
            'FFFF99', 'CCFFFF', '99CCFF', 'FFFFFF']
            
    for (var i=0;i<colors.length;i++)
    {
        var option=document.createElement("option");
         $(option).val(colors[i]);
           $(option).text(colors[i]);
          $(option).css({"background-color": "#"+colors[i]});
        $("#drpColor").append(option);
    }
   
  
}
function btnPageUp_click()
{
    p = p - max;
    if (p < 0) p = 0;
    btnEnterQ_click("UP");
}
function btnPageDown_click()
{
    if (TotalCount < (p + max)) return false;
    p = p + max;
    btnEnterQ_click("DOWN");
}
function drpMessageOptionQ_Change(o)
{
  $("#txtACCTQ").val("");
    switch($("#drpMessageOptionQ").val())
    {
        case "0":
           
            $("#txtACCTQ").hide();
            if (UserLevel=="1"||UserLevel=="2")
            {
               $("#spAEQ").hide();
               $("#spManagerQ").show();
            }
            else
            {
                $("#spAEQ").show ();
               $("#spManagerQ").hide();
            }
  
            
        break;
        case "1":
           $("#txtACCTQ").show();
           $("#spAEQ").hide();
           $("#spManagerQ").hide();
        break;
        case "2":
          $("#txtACCTQ").show();
          $("#spAEQ").hide();
          $("#spManagerQ").hide();
        break;
    }
 
}
function drpMessageOption_Change(o)
{
  $("#txtACCT").val("");
    switch($("#drpMessageOption").val())
    {
        case "0":
            $("#txtACCT").val("");
            $("#txtACCT").hide();
            if (UserLevel=="1"||UserLevel=="2")
            {
               $("#spAE").hide();
               $("#spManager").show();
            }
            else
            {
                $("#spAE").show ();
               $("#spManager").hide();
            }
        break;
        case "1":
           $("#txtACCT").show();
               $("#spAE").hide();
           $("#spManager").hide();
        break;
        case "2":
          $("#txtACCT").show();
              $("#spAE").hide();
          $("#spManager").hide();
        break;
    }
 
}

function checkall()
{
    var UserLevel=$("#txtLEVEL").val(); 
    if ($("#drpMessageOption").val()!="0")
    {
        if($("#txtACCT").val().fulltrim() == "")
        {
            alert ("帳號為必輸欄位")  
            return false;
        }
    }
    else
    {
     switch(UserLevel)
     {
         case "1":
         case "2":
     
                if (!$("#chkAE").attr("checked")&&!$("#chkCUSTOMER").attr("checked"))
                {
                 alert ("必須勾選客戶或營業員")  
                return false;
                } 
          
         break;
         default:
     
                if (!$("#rdoALL").attr("checked") )  
                {
                    if ( $("#txtGroupID").val().fulltrim() == "")
                    {
                    alert ("群組為必輸欄位")  
                    return false;
                    }
                }
         break;
     }
        
    }
    if($("#txtContent").val() == "")
    {
        alert ("訊息內容為必輸欄位")  
        return false;
    }
   else
   {
       if ($("#txtContent").val().replace(/[^\x00-\xff]/g,"xx").length>600) 
       {
       alert ("訊息內容最多300個中文字或600個英數字體")  
        return false;
        }
 
   }
//       if($("#txtHyperLink").val() != "")
//    {
//        if (!checkURL(JSON_Trim($("#txtHyperLink").val())))
//        {
//           alert('超連結請輸入完整URL，例如http://www.yahoo.com.tw');           
//        return false;
//        }
//    }
    var objStartDate = $('#txtDate_St').datepicker("getDate");
    var objEndDate = $('#txtDate_Ed').datepicker("getDate");
    if (objStartDate == null) 
    {
        alert('起始日期為必輸欄位');           
        return false;
    }
    if (objEndDate == null) 
    {
        alert('結束日期為必輸欄位');           
        return false;
    }
    if (objStartDate != null & objEndDate != null) 
    {
        if (objStartDate > objEndDate) 
        {
            alert('起始日期不可大於結束日期');
            return false;
        }
        else
        {
            if ($("#drpTime_St").val()>$("#drpTime_Ed").val())
            {
                alert('起始時間不可大於結束時間');
                return false;
            }
        
        }
    }

    
    return true;
}
function btnEnterQ_click(o)
{
    if ( o=="")
     {  p=0;
     }
  
    var MessageType=$("#drpMessageTypeQ").val();
     var MessageOption=getMessageOption($("#drpMessageOptionQ"),$("#chkAEQ"),$("#chkCUSTOMERQ"),$("#rdoALLQ"));
     var GroupID=JSON_Trim($("#txtGroupIDQ").val());
    var ID=JSON_Trim($("#txtACCTQ").val());
    
    var Date_St=$("#txtDate_StQ").val().replace(/\//ig, "");
 
    var Date_Ed=$("#txtDate_EdQ").val().replace(/\//ig, "");
    
    if ($("#chkDateAll").attr("checked"))
    {
        Date_St="";
        Date_Ed="";
    }
 
     var tParam = fh_GenParam();
     var m_WhereParm = {  
                         UserLevel:  UserLevel
                        ,MessageType:MessageType
                        ,MessageOption:MessageOption
                        ,GroupID:GroupID
                        ,ID:ID
                        ,DateStart:Date_St
                        ,DateEnd:Date_Ed
                              ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                        ,p:p
                        ,max:max
                     };
    var  JSON = fh_CallWebMethod("MSGM020", "MSGM020?uri="+tParam , m_WhereParm , false);
    if (JSON.PageInfo[0].ReturnCode=="000")
    {
    
         var m_WhereParmCount = {  
                         UserLevel:  UserLevel
                        ,MessageType:MessageType
                        ,MessageOption:MessageOption
                        ,GroupID:GroupID
                        ,ID:ID
                        ,DateStart:Date_St
                        ,DateEnd:Date_Ed
                               ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                
                     };
                      
                    if ( o=="")
                     {   
       JSONCount = fh_CallWebMethod("MSGM020", "MSGM020COUNT?uri="+tParam , m_WhereParmCount , false);
    if (JSONCount.PageInfo[0].ReturnCode=="000")
    {
        TotalCount=  JSONCount.TableRows[0].count;
    }
    else TotalCount=0;
        $("#lblTotalCount").text(TotalCount);
    }
      
       _dt=JSON.TableRows;
        databind(JSON.TableRows)
    }
    else
    {
        $("#dgvMain").find('tbody').remove();
        alert("查無資料");
    }

}
function chkAll_click()
{
       $("tbody tr  input[type=checkbox]", $("#dgvMain")).each(function(key)
       {
           if ( $("#chkAll") .attr("checked")) 
           {
            $(this) .attr("checked","true")
           }
           else 
           {
            $(this) .attr("checked","")
           }
          
       });
}
function btnDelAll_click()
{
      var  Arr =new Array();
       
                var tParam = fh_GenParam();
       $("tbody tr  input[type=checkbox]", $("#dgvMain")).each(function(key)
       {
            if ( $(this) .attr("checked"))
            {
                 Arr.push(_dt[key ].SEQ)
            }
            
        });
        
 
       var    m_WhereParm = {  
                        UserLevel:  UserLevel
                        ,Seq: Arr
                        ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                     };
    var  JSON = fh_CallWebMethod("MSGM020", "MSGM020_DELALL?uri="+tParam , m_WhereParm , false);
    if (JSON.PageInfo[0].ReturnCode=="000")
    {
        btnEnterQ_click("");
        alert("刪除成功")
    }
    else
        alert("刪除失敗")
}
 
function btn_click(key,action)
{



    var UserLevel=$("#txtLEVEL").val();
    var LoginId=$("#txtLOGINID").val();
    var m_WhereParm;
    var tParam = fh_GenParam();
    Seq=_dt[key].SEQ;
    if (action=="del")
    {
        m_WhereParm = {  
                            UserLevel:  UserLevel
                            ,Seq: _dt[key].SEQ
                                    ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                    
                         };
        var  JSON = fh_CallWebMethod("MSGM020", "MSGM020_DEL?uri="+tParam , m_WhereParm , false);
        if (JSON.PageInfo[0].ReturnCode=="000")
        {
            btnEnterQ_click("");
            alert("刪除成功")
        }
        else
            alert("刪除失敗")
    }
    else if(action=="upd")
    {
        
          $("#txtTitle").text("修改公告訊息")
          Action="upd";
   
        LoadUpdData(key);
        
    }
    else if(action=="copy")
    {
      $("#txtTitle").text("複製公告訊息")
      Action="copy";
      
        LoadUpdData(key);
    }
}
function LoadUpdData(key)
{
  $("#divUpd").show();
   $("#divQuery").hide();
   $("#divMaintain")  .hide();
// 
//_dt[key].MessageOption
//_dt[key].GroupID
//_dt[key].ID
//_dt[key].Message
//_dt[key].HyperLink
//_dt[key].Color
//_dt[key].DateStart
//_dt[key].DateEnd
//_dt[key].TimeStart
//_dt[key].TimeEnd
//_dt[key].DataOrder

    $("#drpMessageType").val(_dt[key].MessageType);
   // var MessageOption=getMessageOption();
  SetMessageOption($("#drpMessageOption"),$("#chkAE"),$("#chkCUSTOMER"),$("#rdoALL"),_dt[key].MessageOption);
     $("#txtGroupID").val(_dt[key].GroupID) ;
 $("#txtACCT").val(_dt[key].ID) ;
    $("#txtContent").val(_dt[key].Message) ;
    
    $("#txtHyperLink").val(_dt[key].HyperLink) ;//  .replace(/\//ig, "");
 
 $("#drpColor").val( _dt[key].Color) ;
   
 $("#txtDate_St").val(_dt[key].DateStart) ;
 $("#drpTime_St").val(_dt[key].TimeStart);
   $("#txtDate_Ed").val(_dt[key].DateEnd)  ;
 $("#drpTime_Ed").val(_dt[key].TimeEnd);
   $("#txtOrder").val(_dt[key].DataOrder) ;
}

function databind(dt)
{ 
  
    var count=0;
    $("#dgvMain").find('tbody').remove();
    var _blood="";
    _blood += '<tbody>';
    $.each(dt,function(key,item)
    {
    count++;
        _blood+=" <tr class=\"contentStyle\">";
        _blood+=" <td >";

        _blood+=" <input id=\"Button2\" type=\"button\" value=\"修改\" onclick=\"btn_click("+key+",'upd')\" /> ";
        _blood+=" <input id=\"Button3\" type=\"button\" value=\"刪除\" onclick=\"btn_click("+key+",'del')\" /> ";
        _blood+=" <input id=\"Button11\" type=\"button\" value=\"複製\" onclick=\"btn_click("+key+",'copy')\" /> ";
        _blood+=" </td >";

        _blood+=" <td >";

        _blood+="    <input  type=\"checkbox\" /> ";

        _blood+=" </td >"; 
 
        if ($("#thOrder").css("display")!="none")
        {
          _blood+=" <td >"; 
        _blood+= item.DataOrder;
        _blood+=" </td >"; 
}
        _blood+=" <td >"; 
        _blood+= item.ID;
        _blood+=" </td >"; 

 
                    _blood+=" <td >"; 
        _blood+= item.Message;
        _blood+=" </td >";  
        
                _blood+=" <td > <a href='"+item.HyperLink+"' target='_blank'  > ";
        _blood+= item.HyperLink;
        _blood+="</a> </td >"; 
        


                 _blood+=" <td >"; 
        _blood+= fh_TransferDateFor(item.DateStart)+" " +fh_TransferDateForTime(item.TimeStart);
        _blood+=" </td >"; 


        _blood+=" <td >"; 
        _blood+= fh_TransferDateFor(item.DateEnd)+" " +fh_TransferDateForTime(item.TimeEnd);
        _blood+=" </td >"; 
            _blood+=" <td >"; 
        _blood+= item.MessageType=="0"?"一般":"緊急";
        _blood+=" </td >"; 

        _blood+=" <td >"; 
        _blood+= item.crt_id;
        _blood+=" </td >"; 
        _blood+=" </tr >";
    }
);
    
     _blood += '</tbody>';
      $("#lblCount").text((p + 1) + "-" + (p + count).toString());
      $('#dgvMain').append(_blood);
    
}
function btnEnter_click()
{
     
    if (!checkall()) return false;
    
    var UserLevel=$("#txtLEVEL").val();
    var MessageType=$("#drpMessageType").val();
    var MessageOption=getMessageOption($("#drpMessageOption"),$("#chkAE"),$("#chkCUSTOMER"),$("#rdoALL"));
    var GroupID=JSON_Trim($("#txtGroupID").val());
    var ID=JSON_Trim($("#txtACCT").val());
    var Content=JSON_Trim($("#txtContent").val());
    
    var HyperLink=JSON_Trim($("#txtHyperLink").val());//  .replace(/\//ig, "");
    
        
    if (HyperLink!="")
    {

        if (HyperLink.toLowerCase().indexOf("http://") !== -1  )
        {
        
        }
        else 
        {
            if (HyperLink.toLowerCase().indexOf("https://") !== -1 )
            {
            
            }
            else
                HyperLink="http://"+HyperLink;
        }
      
    }
    
    
    var Color =JSON_Trim($("#drpColor").val().replace(/\#/ig, ""));
    var Date_St=$("#txtDate_St").val().replace(/\//ig, "");
    var Time_St=$("#drpTime_St").val();
    var Date_Ed=$("#txtDate_Ed").val().replace(/\//ig, "");
    var Time_Ed=$("#drpTime_Ed").val();
    var Order=JSON_Trim($("#txtOrder").val());
 //   var LoginId=$("#txtLOGINID").val();
    var tParam = fh_GenParam();
    var m_objJSON     ;
    var m_WhereParm;
    if (Action=="copy")      
    {
           
      m_WhereParm = {  
                        UserLevel:  UserLevel
                        ,MessageType:MessageType
                        ,MessageOption:MessageOption
                        ,GroupID:GroupID
                        ,ID:ID
                        ,Message:Content
                        ,HyperLink:HyperLink
                        ,Color:Color
                        ,DateStart:Date_St
                        ,DateEnd:Date_Ed
                        ,TimeStart:Time_St
                        ,TimeEnd:Time_Ed
                        ,DataOrder:Order
                                ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                     };       
      m_objJSON = fh_CallWebMethod("MSGM010", "MSGM010?uri="+tParam , m_WhereParm , false);
      }
      else if  (Action=="upd")      
      { 
      m_WhereParm = {  
                        UserLevel:  UserLevel
                        ,MessageType:MessageType
                        ,MessageOption:MessageOption
                        ,GroupID:GroupID
                        ,ID:ID
                        ,Message:Content
                        ,HyperLink:HyperLink
                        ,Color:Color
                        ,DateStart:Date_St
                        ,DateEnd:Date_Ed
                        ,TimeStart:Time_St
                        ,TimeEnd:Time_Ed
                        ,DataOrder:Order
                        ,Seq:Seq
                                ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                        
                     };       
      m_objJSON = fh_CallWebMethod("MSGM020", "MSGM020UPD?uri="+tParam , m_WhereParm , false);
      }
    
    if (m_objJSON.length>0)
    {
        if (m_objJSON[0].ReturnCode=="000")
        {

        alert(m_objJSON[0].ReturnMessage)
                btnCancel_click();
          btnEnterQ_click("");
        }
        else
        {
         alert(m_objJSON[0].ReturnMessage)
        }
    }
}
function btnCancel_click()
{
    $("#divUpd").hide();
    $("#divQuery").show();
    $("#divMaintain")  .show();
}
function btnSelectColor_click(o)
{
  window.open("ColorPicker.html");
}

 function getMessageOption(drpMessageOption,chkAE,chkCUSTOMER,rdoALL)
{
     var UserLevel=$("#txtLEVEL").val(); 
     var MessageOption=drpMessageOption.val();
 
     switch(UserLevel)
     {
     case "1":
        if (MessageOption=="0")
        {
           if (chkAE.attr("checked")&&chkCUSTOMER.attr("checked")) return "C";
           else if (chkAE.attr("checked") ) return "A";
           else if (chkCUSTOMER.attr("checked") ) return "B";
          
        }
        else if (MessageOption=="1") return "D";
        else if (MessageOption=="2") return "E";
     break;
     case "2":
        if (MessageOption=="0")
        {
            if (chkAE.attr("checked")&&chkCUSTOMER.attr("checked")) return "H";
            else if (chkAE.attr("checked") ) return "F";
            else if (chkCUSTOMER.attr("checked") ) return "G";
           
        }
        else if (MessageOption=="1") return "I";
        else if (MessageOption=="2") return "J";
     break;
     default:
        if (MessageOption=="0")
        {
            if (rdoALL.attr("checked") ) return "K";
            else  return "L";
          
        }    
        else if (MessageOption=="2") return "M";
     break;
     }
     
     
}


 function SetMessageOption(drpMessageOption,chkAE,chkCUSTOMER,rdoALL,Value)
{
     var UserLevel=UserLevel; 
     var MessageOption=drpMessageOption.val();
 
 switch(Value)
{
    case"A":
      case"F":
        chkAE.attr("checked",true);
        drpMessageOption.val("0");
    break;
    case"B":
      case"G":
        chkCUSTOMER.attr("checked",true);
        drpMessageOption.val("0");
    break;
    case"C":
      case"H":
        chkAE.attr("checked",true );
        chkCUSTOMER.attr("checked",true);
        drpMessageOption.val("0");
    break;
    case"K":
    rdoALL.attr("checked",true) ;;
    drpMessageOption.val("0");
    break;
    case"L":
    break;
     case"D":
     case"I":
        drpMessageOption.val("1");
    break;
     case"E":
     case"J":
     case"M":
        drpMessageOption.val("2");
    break;
 }
  
     drpMessageOption_Change("")
     
}