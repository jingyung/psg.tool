﻿var UserLevel="";
var COMP_ID="";
var ACCT_ID="";

$(document).ready(init);
function init()
{

    UserLevel=$("#txtLEVEL").val(); 
    COMP_ID= $("#txtCompany").val()
    ACCT_ID= $("#txtACC_ID").val()

    $("#btnRefresh").bind("click",btnRefresh_click);

    btnRefresh_click();
    
    try
    { 
    	
        document.getElementById("DDSCMessageCom").UserLevel=UserLevel;
        document.getElementById("DDSCMessageCom").Company=COMP_ID;
        document.getElementById("DDSCMessageCom").UserId=ACCT_ID;
   
        document.getElementById("DDSCMessageCom").conn($("#hnIP").val(),$("#hnPort").val()) ;
        
//        var activeObject= new ActiveXObject("MessageControl.DDSCMessageCom");
//        activeObject.UserLevel=UserLevel;
//        activeObject.Company=COMP_ID;
//        activeObject.UserId=ACCT_ID;
//        activeObject.conn($("#hnIP").val(),$("#hnPort").val()) ;
//        
//        
           document.getElementById("DDSCMessageCom").attachEvent('MessageEvent', function(msg,color) { btnRefresh_click(); });
	         
        $(window).unload( function () {    document.getElementById("DDSCMessageCom").close(); } );

	}
	catch (ex)
	{

	alert("請安裝ActiveX元件DDSCMessageCom，才能正常使用!"+ex.message );
	}
}
function btnRefresh_click()
{
  
  
getPublicData();
getPrivateData();
}
function bindPublicData(dt)
{
 $("#dgvPublic").find('tbody').remove();
if (dt==null)return;

    var _blood="";
    _blood += '<tbody>';
    $.each(dt,function(key,item)
    {
        _blood+=" <tr class=\"contentStyle\">";
 
           _blood+=" <td class=\"left   contentStyle\" >" ; 
        _blood+= item.MessageType=="0"?"一般":"緊急";
        _blood+=" </td >";
        _blood+=" <td class=\"right   contentStyle\"  style=\"color:#"+item.Color+";cursor:hand;\"  onclick=javascript:window.open('"+item.HyperLink+"')  >"; 
        _blood+= item.Message;
        _blood+=" </td >"; 
      
   _blood+=" </tr >"; 
    }
);
    
     _blood += '</tbody>';
     
      $('#dgvPublic').append(_blood);

}
function bindPrivateData(dt)
{
  $("#dgvPrivate").find('tbody').remove();
    if (dt==null)return;
  
    var _blood="";
    _blood += '<tbody>';
    $.each(dt,function(key,item)
    {
        _blood+=" <tr class=\"contentStyle\">";
 
           _blood+=" <td class=\"left   contentStyle\" >"; 
        _blood+= item.MessageType=="0"?"一般":"緊急";
        _blood+=" </td >";
        _blood+=" <td class=\"right   contentStyle\"   style=\"color:#"+item.Color+"\" >"; 
        _blood+= item.Message;
        _blood+=" </td >"; 
      
    _blood+=" </tr >"; 
    }
);
    
     _blood += '</tbody>';
     
      $('#dgvPrivate').append(_blood);
}


function getPublicData()
{

    var MessageType= "";
    if ($("#rdoALL").attr("checked") ) MessageType="";
    if ($("#rdoNor").attr("checked") ) MessageType="0";
    if ($("#rdoWar").attr("checked") ) MessageType="1";
  
     var tParam = fh_GenParam();
     var m_WhereParm = {  
                         UserLevel:  UserLevel
                        ,MessageType:MessageType                   
                             ,LoginId:ACCT_ID
                        ,LoginCompany:COMP_ID
                        ,p:0
                        ,max:30
                     };
    var  JSON = fh_CallWebMethod("MSGQ010", "MSGQ010_PUBLIC?uri="+tParam , m_WhereParm , false);
    if (JSON.PageInfo[0].ReturnCode=="000")
    {
        bindPublicData(JSON.TableRows);
       
    }
    else
    {
          bindPublicData(null);
    }

}
function getPrivateData()
{
    var MessageType= "";
    if ($("#rdoALL").attr("checked") ) MessageType="";
    if ($("#rdoNor").attr("checked") ) MessageType="0";
    if ($("#rdoWar").attr("checked") ) MessageType="1";
  
     var tParam = fh_GenParam();
     var m_WhereParm = {  
                         UserLevel:  UserLevel
                        ,MessageType:MessageType                   
                        ,LoginId:ACCT_ID
                          ,LoginCompany:COMP_ID
                        ,p:0
                        ,max:30
                     };
    var  JSON = fh_CallWebMethod("MSGQ010", "MSGQ010_PRIVATE?uri="+tParam , m_WhereParm , false);
    if (JSON.PageInfo[0].ReturnCode=="000")
    {
       bindPrivateData( JSON.TableRows);
       
    }
    else
    {
          bindPrivateData( null);
    }

}