﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RunTest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //驗證通過 允許移轉功能頁面
        System.Web.Security.FormsAuthentication.SetAuthCookie("9811139", false);

    }
}
