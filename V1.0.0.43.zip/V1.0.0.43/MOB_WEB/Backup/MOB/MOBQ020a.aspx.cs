﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
public partial class MOB_MOBQ020a : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        DataTable dtHistory = null;
        try
        {
            BOSDataParse objBOS = new BOSDataParse();
            //合計
            DataTable UnLiquidationMain = null;
            DataTable _UnLiquidationMain = null;
            string JSON_UnLiquidationMain = string.Empty;
            //明細
            DataTable UnLiquidationDetail = null;
            DataTable _UnLiquidationDetail = null;
            string JSON_UnLiquidationDetail = string.Empty;
            //群組
            DataTable UnLiquidationGroup = null;
            DataTable _UnLiquidationGroup = null;

            DataSet dsReturn = new DataSet();
            var Full = Request["Full"];
            var productKind = Request["productKind"];
            var ACCT_ID = Request["ACCT_ID"];
            var COMP_ID = Request["COMP_ID"];
            var currency = Request["currency"];
            var sort = Request["SORT"];

            string[] _productKind = productKind.Split(',');
            string filterProductKind = string.Empty;
            foreach (string itemS in _productKind)
            {
                filterProductKind += "'" + itemS + "',";
            }
            if (filterProductKind != string.Empty)
            {
                filterProductKind = filterProductKind.Remove(filterProductKind.Length - 1, 1);
            }

            bool displayGroupflag = true;
            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = "";
            DataSet ds1 = new DataSet();
            if (productKind == "1,2")
                ss = ws.WS_getReal_TotalUnLiquidation(COMP_ID, ACCT_ID, "1", currency, sort == "StrikePrice"?"":"CP").OuterXml;
            if (productKind == "3,4")
                ss = ws.WS_getReal_TotalUnLiquidation(COMP_ID, ACCT_ID, "2", currency, sort == "StrikePrice" ? "" : "CP").OuterXml;
            if (productKind == "")
                ss = ws.WS_getReal_TotalUnLiquidation(COMP_ID, ACCT_ID, "3", currency, sort == "StrikePrice" ? "" : "CP").OuterXml;
            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds1.ReadXml(xml);





            if (productKind == "")
            {
                if (sort == "StrikePrice")
                    ss = ws.WS_getReal_CombineUnLiquidation(COMP_ID, ACCT_ID, currency).OuterXml;
                else
                    ss = ws.WS_getReal_CombineUnLiquidationSortByCP(COMP_ID, ACCT_ID, currency).OuterXml;
            }
            else
            {
                if (sort == "StrikePrice")
                    ss = ws.WS_getReal_UnLiquidation(COMP_ID, ACCT_ID, currency).OuterXml;
                else
                    ss = ws.WS_getReal_UnLiquidationSortByCP(COMP_ID, ACCT_ID, currency).OuterXml;
            }
     xml = new System.IO.StringReader(ss);
            dsReturn.ReadXml(xml);
            ;


            if (dsReturn.Tables.Count > 0)
            {

                UnLiquidationMain = ds1.Tables["UnLiquidationMain"];
                UnLiquidationDetail = dsReturn.Tables["UnLiquidationDetail"];


                ////處理合計 Main
                if (UnLiquidationMain != null && UnLiquidationMain.Rows.Count > 0)
                {
                    if (filterProductKind != string.Empty)
                    {
                        DataRow[] foundRows = null;
                        if (productKind == "")
                        {
                            foundRows = UnLiquidationMain.Select("");
                        }
                        else
                        {
                            foundRows = UnLiquidationMain.Select("productKind IN (" + filterProductKind + ") ");
                        }
                        _UnLiquidationMain = UnLiquidationMain.Clone();
                        if (foundRows != null && foundRows.Length > 0)
                        {
                            //_UnLiquidationMain = UnLiquidationMain.Clone();
                            foreach (DataRow itemR in foundRows)
                            {

                                if (productKind == "3,4" && itemR["productid"].ToString().IndexOf("*") > -1)
                                    displayGroupflag = false;
                                _UnLiquidationMain.ImportRow(itemR);
                            }
                        }
                    }
                    else
                    {
                        //_UnLiquidationMain = UnLiquidationMain.Copy();
                        _UnLiquidationMain = UnLiquidationMain.Clone();
                    }
                }
                else
                {
                    if (UnLiquidationMain != null)
                    {
                        //_UnLiquidationMain = UnLiquidationMain.Copy();
                        _UnLiquidationMain = UnLiquidationMain.Clone();
                    }
                    else
                    {
                        _UnLiquidationMain = new DataTable();
                    }
                }

                ////處理明細 Detail
                if (UnLiquidationDetail != null && UnLiquidationDetail.Rows.Count > 0)
                {
                    if (filterProductKind != string.Empty)
                    {
                        DataRow[] foundRows = null;
                        if (productKind == "")
                        {
                            foundRows = UnLiquidationDetail.Select("");
                        }
                        else
                        {
                            foundRows = UnLiquidationDetail.Select("productKind IN (" + filterProductKind + ") ");
                        }
                        _UnLiquidationDetail = UnLiquidationDetail.Clone();
                        if (foundRows != null && foundRows.Length > 0)
                        {
                            foreach (DataRow itemR in foundRows)
                            {
                                _UnLiquidationDetail.ImportRow(itemR);
                            }
                        }
                    }
                    else
                    {
                        //_UnLiquidationDetail = UnLiquidationDetail.Copy();
                        _UnLiquidationDetail = UnLiquidationDetail.Clone();
                    }
                }
                else
                {
                    if (UnLiquidationDetail != null)
                    {
                        //_UnLiquidationDetail = UnLiquidationDetail.Copy();
                        _UnLiquidationDetail = UnLiquidationDetail.Clone();
                    }
                    else
                    {
                        _UnLiquidationDetail = new DataTable();
                    }
                }
                // WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
                //string spread = "";
                //if (productKind == "3,4")
                //{
                //    spread = "Y";
                //}
                //else
                //{
                //    spread = "N";
                //}
                // DataSet ds = ws.WS_getUnLiquidation(COMP_ID, ACCT_ID, spread);


                //_UnLiquidationDetail = ds.Tables[0] ;
                //_UnLiquidationMain = ds.Tables[1] ;

                //群組小計
                _UnLiquidationGroup = new DataTable();
                _UnLiquidationGroup.Columns.Add("comtype");
                _UnLiquidationGroup.Columns.Add("B");
                _UnLiquidationGroup.Columns.Add("S");
                _UnLiquidationGroup.Columns.Add("RefTotalPL");
                _UnLiquidationGroup.Columns.Add("FEE");
                _UnLiquidationGroup.Columns.Add("TAX");
                _UnLiquidationGroup.Columns.Add("EQUITY");
                DataRow drFuture = _UnLiquidationGroup.NewRow();
                drFuture["comtype"] = "期貨";

                DataRow drOption = _UnLiquidationGroup.NewRow();
                drOption["comtype"] = "選擇權";

                DataRow drTotal = _UnLiquidationGroup.NewRow();
                drTotal["comtype"] = "合計";



                decimal totalFuture_RefTotalPL = 0;
                decimal totalFuture_FEE = 0;
                decimal totalFuture_TAX = 0;
                decimal totalFuture_EQUITY = 0;

                int totalFuture_B = 0;
                int totalFuture_S = 0;

                decimal totalOption_RefTotalPL = 0;
                decimal totalOption_FEE = 0;
                decimal totalOption_TAX = 0;
                decimal totalOption_EQUITY = 0;

                int totalOption_B = 0;
                int totalOption_S = 0;


                decimal total_RefTotalPL = 0;
                decimal total_FEE = 0;
                decimal total_TAX = 0;
                decimal total_EQUITY = 0;

                int total_B = 0;
                int total_S = 0;
                foreach (DataRow dr in _UnLiquidationMain.Rows)
                {
                    decimal RefTotalPL = 0;
                    decimal FEE = 0;
                    decimal TAX = 0;
                    decimal EQUITY = 0;

                    int B = 0;
                    int S = 0;


                    decimal.TryParse(dr["RefTotalPL"].ToString(), out RefTotalPL);
                    decimal.TryParse(dr["FEE"].ToString(), out FEE);
                    decimal.TryParse(dr["TAX"].ToString(), out TAX);
                    decimal.TryParse(dr["EQUITY"].ToString(), out EQUITY);

                    if (dr["BS"].ToString().Trim().ToUpper() == "B")
                    {
                        int.TryParse(dr["totalOTQTY"].ToString(), out B);
                    }
                    else
                    {
                        int.TryParse(dr["totalOTQTY"].ToString(), out S);

                    }
                     


                    if (dr["productKind"].ToString() == "1" || dr["productKind"].ToString() == "4")//期貨
                    {
                        totalFuture_RefTotalPL += RefTotalPL;
                        totalFuture_FEE += FEE;
                        totalFuture_TAX += TAX;
                        totalFuture_EQUITY += EQUITY;
                        totalFuture_B += B;
                        totalFuture_S += S;
                    }
                    else//選擇權
                    {
                        totalOption_RefTotalPL += RefTotalPL;
                        totalOption_FEE += FEE;
                        totalOption_TAX += TAX;
                        totalOption_EQUITY += EQUITY;
                        totalOption_B += B;
                        totalOption_S += S;
                    }
                    total_RefTotalPL += RefTotalPL;
                    total_FEE += FEE;
                    total_TAX += TAX;
                    total_EQUITY += EQUITY;
                    total_B += B;
                    total_S += S;
                } if (displayGroupflag)
                {
                    drFuture["B"] = totalFuture_B;
                    drFuture["S"] = totalFuture_S;

                    drFuture["RefTotalPL"] = totalFuture_RefTotalPL.ToString("#,##0.##");
                    drFuture["FEE"] = totalFuture_FEE.ToString("#,##0.##");
                    drFuture["TAX"] = totalFuture_TAX.ToString("#,##0.##");
                    drFuture["EQUITY"] = totalFuture_EQUITY.ToString("#,##0.##");


                    drOption["B"] = totalOption_B;
                    drOption["S"] = totalOption_S;

                    drOption["RefTotalPL"] = totalOption_RefTotalPL.ToString("#,##0.##");
                    drOption["FEE"] = totalOption_FEE.ToString("#,##0.##");
                    drOption["TAX"] = totalOption_TAX.ToString("#,##0.##");
                    drOption["EQUITY"] = totalOption_EQUITY.ToString("#,##0.##");

                    drTotal["B"] = total_B;
                    drTotal["S"] = total_S;
                    drTotal["RefTotalPL"] = total_RefTotalPL.ToString("#,##0.##");
                    drTotal["FEE"] = total_FEE.ToString("#,##0.##");
                    drTotal["TAX"] = total_TAX.ToString("#,##0.##");
                    drTotal["EQUITY"] = total_EQUITY.ToString("#,##0.##");
                }
                _UnLiquidationGroup.Rows.Add(drFuture);
                _UnLiquidationGroup.Rows.Add(drOption);
                _UnLiquidationGroup.Rows.Add(drTotal);
            }

            if (UnLiquidationDetail == null)
            {
                string strJs = "<script>alert('查無資料');window.close();</script>";
                Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
                return;
            }
            //dtHistory = dsReturn.Tables[0]








            if (UnLiquidationDetail.Rows.Count == 0)
            {
                string strJs = "<script>alert('查無資料');window.close();</script>";
                Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
                return;
            }
            else
            {
                if (Full == "1")
                {

                    if (productKind == "1,2" || productKind == "")
                    {
                        ExportExcel020010("MOBQ020", _UnLiquidationMain, _UnLiquidationGroup, _UnLiquidationDetail);
                    }
                    else
                    {
                        ExportExcel020020("MOBQ020", _UnLiquidationMain, _UnLiquidationGroup, _UnLiquidationDetail);
                    }
                }
                else
                {
                    if (productKind == "1,2" || productKind == "")
                    {
                        ExportExcel020030("MOBQ020", _UnLiquidationMain, _UnLiquidationGroup, _UnLiquidationDetail);
                    }
                    else
                    {
                        ExportExcel020040("MOBQ020", _UnLiquidationMain, _UnLiquidationGroup, _UnLiquidationDetail);
                    }
                }



            }
        }
        catch (Exception ex)
        {
            //  throw;
        }


    }


    public void ExportExcel020010(string strExportFileName, DataTable UnLiquidationMain, DataTable UnLiquidationGroup, DataTable UnLiquidationDetail)
    {

        try
        {
            this.Response.Clear();

            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "big5";
            Response.Cache.SetCacheability(HttpCacheability.Public);
            Response.ContentType = "application/vnd.xls";
            Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
            //  StringBuilder szHtml = new StringBuilder();
            string szHtml = "";
            szHtml = @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                     
                                            <th class='style23'>
                                                買賣別
                                            </th>
                                            <th class='style5'>
                                                商品內容
                                            </th>
                                            <th class='style14'>
                                                總留倉口數
                                            </th>
                                            
                                            
                                            <th class='style13'>
                                                成交均價
                                            </th>
                                            <th class='style18'>
                                                即時價位
                                            </th>
                                            <th class='style5'>
                                                參考浮動損益
                                            </th>
                                               <th class='style21'>
                                                期交稅
                                            </th>
                                                   <th class='style20'>
                                                手續費
                                            </th>
                                            <th class='style_realPrice'>
                                                淨損益
                                            </th>
                                        </tr>
                                           </thead>
                                    <tbody>";

            foreach (DataRow dr in UnLiquidationMain.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["BS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TotalOTQTY"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["AvgMatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["realPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";



            szHtml += @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                        <th class='style5'>
                                                 &nbsp
                                            </th>
<th class='style21'>
                                                買進口數
                                            </th>
                                               <th class='style21'>
                                               賣出口數
                                            </th>
                                      <th class='style5'>
                                                參考浮動損益
                                            </th>
                                               <th class='style21'>
                                                期交稅
                                            </th>
                                                   <th class='style20'>
                                                手續費
                                            </th>
                                            <th class='style_realPrice'>
                                                淨損益
                                            </th>
                                        </tr>
                                           </thead>
                                    <tbody>";


            foreach (DataRow dr in UnLiquidationGroup.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["comtype"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["B"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["S"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";

            szHtml += @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                 
                                            <th class='style15'>
                                                成交日期
                                            </th>
                                            <th class='style17'>
                                                成交單號
                                            </th>
                                            <th class='style16'>
                                                買賣別
                                            </th>
                                            <th class='style_ProductId'>
                                                商品內容
                                            </th>
                                             <th class='style11'>
                                                留倉口數
                                            </th>
                                            <th class='style12'>
                                                成交價
                                            </th>
                                            <th class='style_realPrice'>
                                                即時價位
                                            </th>
                                           
                                            <th class='style10'>
                                                參考浮動損益
                                            </th>
                                            <th class='style8'>
                                                當沖
                                            </th>
                                                <th class='style21'>
                                                期交稅
                                            </th>
                                                   <th class='style22'>
                                                手續費
                                            </th>
                                            <th class='style_realPrice'>
                                                淨損益
                                            </th>
                                        </tr>
                                           </thead>
                                    <tbody>";

            foreach (DataRow dr in UnLiquidationDetail.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["tradedate"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["orderNo"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["BS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["OTQTY"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["MatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefRealPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefPL"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["DTOVER"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";

            Response.Write(szHtml.ToString());

            Response.End();

        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public void ExportExcel020020(string strExportFileName, DataTable UnLiquidationMain, DataTable UnLiquidationGroup, DataTable UnLiquidationDetail)
    {

        try
        {
            this.Response.Clear();

            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "big5";
            Response.Cache.SetCacheability(HttpCacheability.Public);
            Response.ContentType = "application/vnd.xls";
            Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
            //  StringBuilder szHtml = new StringBuilder();
            string szHtml = "";
            szHtml = @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                      <th class='style23'>
                                        買賣別
                                    </th>
                                    <th class='style24'>
                                        商品內容
                                    </th>
                                    <th class='style_TotalOTQTY'>
                                        總留倉口數
                                    </th>
                               
                                    <th class='style_AvgMatchPrice'>
                                        成交均價
                                    </th>
                                  
                                    <th class='style_realPrice'>
                                        即時價位
                                    </th>
                                         <th class='style32'>
                                        參考浮動損益
                                    </th>
                                    <th class='style_ProductId'>
                                        複式商品代碼
                                    </th>
                                    <th class='style31'>
                                        複式商品買賣別
                                    </th>
                                    <th class='style30'>
                                        複式各腳價位
                                    </th>
                                         <th class='style21'>
                                        期交稅
                                    </th>
                                           <th class='style22'>
                                        手續費
                                    </th>
                                    <th class='style_realPrice'>
                                        淨損益
                                    </th>
                                        </tr>
                                           </thead>
                                    <tbody>";

            foreach (DataRow dr in UnLiquidationMain.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["BS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TotalOTQTY"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["AvgMatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["realPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["multiplecomno"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["multipleBS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["footMatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";

                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";



            szHtml += @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                        <th class='style5'>
                                                 &nbsp
                                            </th>
                                      <th class='style5'>
                                                參考浮動損益
                                            </th>
                                               <th class='style21'>
                                                期交稅
                                            </th>
                                                   <th class='style20'>
                                                手續費
                                            </th>
                                            <th class='style_realPrice'>
                                                淨損益
                                            </th>
                                        </tr>
                                           </thead>
                                    <tbody>";


            foreach (DataRow dr in UnLiquidationGroup.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["comtype"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";

            szHtml += @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                  
                                    <th class='style11'>
                                        成交日期
                                    </th>
                                    <th class='style26'>
                                        成交單號
                                    </th>
                                    <th class='style25'>
                                        買賣別
                                    </th>
                                    <th class='style_ProductId'>
                                        商品內容
                                    </th>
                                     <th class='style_OTQTY'>
                                        留倉口數
                                    </th>
                                    <th class='style26'>
                                        成交價
                                    </th>
                                    <th class='style33'>
                                        即時價位
                                    </th>
                                   
                                    <th class='style34'>
                                        參考浮動損益
                                    </th>
                                    <th class='style27'>
                                        當沖
                                    </th>
                                    <th class='style_multiplecomno'>
                                        複式商品代碼
                                    </th>
                                    <th class='style28'>
                                        複式商品買賣別
                                    </th>
                                      <th class='style29'>
                                        複式各腳價位
                                    </th>
                                         <th class='style21'>
                                        期交稅
                                    </th>
                                           <th class='style22'>
                                        手續費
                                    </th>
                                    <th class='style_realPrice'>
                                        淨損益
                                    </th>
                                        </tr>
                                           </thead>
                                    <tbody>";

            foreach (DataRow dr in UnLiquidationDetail.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["tradedate"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["orderNo"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["BS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["OTQTY"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["MatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefRealPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefPL"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["DTOVER"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["multiplecomno"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["multipleBS"].ToString();
                szHtml += "</td>";


                szHtml += "<td>" + dr["footMatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";

            Response.Write(szHtml.ToString());

            Response.End();
        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }


    public void ExportExcel020030(string strExportFileName, DataTable UnLiquidationMain, DataTable UnLiquidationGroup, DataTable UnLiquidationDetail)
    {

        try
        {
            this.Response.Clear();

            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "big5";
            Response.Cache.SetCacheability(HttpCacheability.Public);
            Response.ContentType = "application/vnd.xls";
            Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
            //  StringBuilder szHtml = new StringBuilder();
            string szHtml = "";
            szHtml = @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                 
                                    <th class='style23'>
                                        買賣別
                                    </th>
                                    <th class='style_ProductId'>
                                        商品內容
                                    </th>
                                    <th class='style15'>
                                        留倉口數
                                    </th>
                                    <th class='style37'>
                                        未平倉損益
                                    </th>
                                         <th class='style21'>
                                        期交稅
                                    </th>
                                           <th class='style22'>
                                        手續費
                                    </th>
                                    <th class='style_realPrice'>
                                        淨損益
                                    </th>
                                        </tr>
                                           </thead>
                                    <tbody>";

            foreach (DataRow dr in UnLiquidationMain.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["BS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TotalOTQTY"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["realPrice"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";



            szHtml += @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                         <th class='style23'>
                                                
                                            </th>
                                          
                                            <th class='style5'>
                                                參考浮動損益
                                            </th>
                                               <th class='style21'>
                                                期交稅
                                            </th>
                                                   <th class='style20'>
                                                手續費
                                            </th>
                                            <th class='style_realPrice'>
                                                淨損益
                                            </th>
                                        </tr>
                                           </thead>
                                    <tbody>";


            foreach (DataRow dr in UnLiquidationGroup.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["comtype"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";


            Response.Write(szHtml.ToString());

            Response.End();
        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public void ExportExcel020040(string strExportFileName, DataTable UnLiquidationMain, DataTable UnLiquidationGroup, DataTable UnLiquidationDetail)
    {

        try
        {
            this.Response.Clear();

            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "big5";
            Response.Cache.SetCacheability(HttpCacheability.Public);
            Response.ContentType = "application/vnd.xls";
            Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
            //  StringBuilder szHtml = new StringBuilder();
            string szHtml = "";
            szHtml = @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                <th class='style16'>
                                        買賣別
                                    </th>
                                    <th class='style_ProductId'>
                                        商品內容
                                       
                                    </th>
                                    <th class='style15'>
                                        留倉口數
                                    </th>
                                    <th class='style36'>
                                        未平倉損益
                                    </th>
                                    <th class='style_multiplecomno'>
                                        複式商品代碼
                                    </th>
                                    <th class='style35'>
                                        複式商品買賣別
                                    </th>
                                      <th class='style32'>
                                        複式各腳價位
                                    </th>
                                         <th class='style21'>
                                        期交稅
                                    </th>
                                           <th class='style22'>
                                        手續費
                                    </th>
                                    <th class='style_realPrice'>
                                        淨損益
                                    </th>
                                        </tr>
                                           </thead>
                                    <tbody>";

            foreach (DataRow dr in UnLiquidationMain.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["BS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TotalOTQTY"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["multiplecomno"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["multipleBS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["footMatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";



            szHtml += @"     <table class='titleStyle tableStyle' border=1 id='T_02011'>
                                       <thead >
                                        <tr>
                                         <th class='style23'>
                                                
                                            </th>
                                          
                                            <th class='style5'>
                                                參考浮動損益
                                            </th>
                                               <th class='style21'>
                                                期交稅
                                            </th>
                                                   <th class='style20'>
                                                手續費
                                            </th>
                                            <th class='style_realPrice'>
                                                淨損益
                                            </th>
                                        </tr>
                                           </thead>
                                    <tbody>";


            foreach (DataRow dr in UnLiquidationGroup.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["comtype"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TAX"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["FEE"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["EQUITY"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";


            Response.Write(szHtml.ToString());

            Response.End();
        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }

}


