﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web;
using System.Web.Services;
public partial class MOB_MOBQ130 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";
            string id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }

            }




            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
                DataRow dr = GetID(comp_id, acct_id);
                if (dr != null)
                {
                    this.ID.Value = dr["IDNO"].ToString();// "F128764398";//
                    this.spActno.InnerText = dr["ACTNO"].ToString();
                    this.spName.InnerText = dr["ACTNAME"].ToString();
                }
            }
            this.IP.Value = this.Page.Request.UserHostAddress;
            this.lblTime.InnerText = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            string cno = GetCheckNo(acct_id);
            string s = "";
            s = "comp_id=" + comp_id.Trim() + "&acct_id=" + acct_id.Trim() + "&prog_id=MOBQ170.aspx&c_no=" + cno;
            txtURL.Value= "/MOB_WEB" + "/default.aspx?param=" + EncString(s);
        }
    }

    private string GetCheckNo(string acct)
    {
        string s = acct;
        int len = s.Length;
        int idx = 1;
        Int32 total = 0;
        string checkNo = "";

        for (idx = 1; idx <= len; idx++)
        {
            total += idx * Convert.ToInt32(s.Substring(idx - 1, 1));

        }

        for (idx = total.ToString().Length; idx > 0; idx--)
        {
            checkNo += total.ToString().Substring(idx - 1, 1);
        }
        return checkNo;
    }
    //編碼
    private string EncString(string pwd)
    {
        Int32 i = 0;
        string encPwd = "";
        try
        {
            if (pwd != "")
            {
                for (i = 0; i < pwd.Length; i++)
                {
                    encPwd = encPwd + Convert.ToChar(159 - ((int)Convert.ToChar(pwd.Substring(i, 1)))).ToString();
                }
            }
        }
        catch (Exception ex)
        {

        }
        return encPwd;
    }
    [WebMethod()]
    public static string GetCloseTime(string type)
    {
        string ret = "";
        try
        {
            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = new DataSet();


            try
            {
                string[] weeks = { "日", "一", "二", "三", "四", "五" };
                string date = ws.WS_getCASHOUTTIME(type);
                //XXXX年XX月XX日星期X 上午10:00點整
                string week = date.Split(',')[0];
                string time = date.Split(',')[1];
                string year = time.Substring(0, 4);
                string month = time.Substring(4, 2);
                string day = time.Substring(6, 2);
                string hour = time.Substring(8, 2);
                string min = time.Substring(10, 2);
                ret = string.Format("{0}年{1}月{2}日星期{3} {4}:{5}點整", year, month, day, weeks[int.Parse(week)], hour, min);
            }
            catch (Exception ex)
            {
            }
           
            
        }
        catch (Exception ex)
        {
          
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";

        return ret;
       
    }

    public DataRow GetID(string company, string actno)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {
            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = new DataSet();


            try
            {
                string[] weeks = { "日", "一", "二", "三", "四", "五", "六" };
                string date = ws.WS_getCASHOUTTIME("1");
                //XXXX年XX月XX日星期X 上午10:00點整
                string week = date.Split(',')[0];
                string time = date.Split(',')[1];
                string year = time.Substring(0, 4);
                string month = time.Substring(4, 2);
                string day = time.Substring(6, 2);
                string hour = time.Substring(8, 2);
                string min = time.Substring(10, 2);
                this.spDate.InnerText = string.Format("{0}年{1}月{2}日星期{3} {4}:{5}點整", year, month, day, weeks[int.Parse(week)], hour, min);
            }
            catch (Exception ex)
            {
            }
            string ss = ws.WS_getKEY(company, actno).OuterXml;
            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                ds.Tables[0].Rows[0]["IDNO"] = fh.fh_EncString(ds.Tables[0].Rows[0]["IDNO"].ToString());
                return ds.Tables[0].Rows[0];
            }
            else
            {
                return null;
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return null;
    }

    [WebMethod()]
    public static string checkSubmitTime(string chktime)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {
            FunctionHandler fh = new FunctionHandler();

            string now = DateTime.Now.ToString("yyyyMMddHHmm00");

            string s1 = DateTime.Now.ToString("yyyyMMdd") + "090000";
            string s2 = DateTime.Now.ToString("yyyyMMdd") + "100000";

            string s3 = DateTime.Now.ToString("yyyyMMdd") + "140000";
            if (long.Parse(chktime) < long.Parse(s1))
            {
                if (long.Parse(now) < long.Parse(s1))
                {
                    return "1";
                }
            }
            else if (long.Parse(chktime) < long.Parse(s2) && long.Parse(chktime) > long.Parse(s1))
            {
                if (long.Parse(now) < long.Parse(s2) && long.Parse(now) > long.Parse(s1))
                {
                    return "1";
                }
            }
            else if (long.Parse(chktime) < long.Parse(s3) && long.Parse(chktime) > long.Parse(s2))
            {
                if (long.Parse(now) < long.Parse(s3) && long.Parse(now) > long.Parse(s2))
                {
                    return "1";
                }
            }
            else if (long.Parse(chktime) > long.Parse(s3))
            {
                if (long.Parse(now) > long.Parse(s3))
                {
                    return "1";
                }
            }


            return "0";





        }
        catch (Exception ex)
        {
            return "0";
        }

        return "0";
    }



    [WebMethod()]
    public static string QueryMOBQ130(string SignData, string Data, string IP)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {
            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = new DataSet();

            string ss = ws.WS_getOrderWithdrawCA(SignData, Data, IP).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"Withdraw\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }



    [WebMethod()]
    public static string WS_CheckWithdrawPassword(string company, string actno, string password, string IP)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {
            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = new DataSet();

            string ss = ws.WS_CheckWithdrawPassword(company, actno, password, IP).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"MSG\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }

    [WebMethod()]
    public static string WS_ChangePassword(string company, string actno, string password, string changepassword)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {
            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = new DataSet();

            string ss = ws.WS_ChangePassword(company, actno, password, changepassword).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"MSG\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }

    [WebMethod()]
    public static string QueryBank(string FIRM, string ACTNO, string CURRENCY)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            string ss = ws.WS_getBANK400(FIRM, ACTNO, CURRENCY).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"Bank\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }

}
