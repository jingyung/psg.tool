﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Configuration;
public partial class MOB_MOBQ050 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------
            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}
            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
            }
        }
          
        this.btnMonth1.Value = DateTime.Now.ToString("yyyy/MM");
        this.btnMonth2.Value = DateTime.Now.AddMonths(-1).ToString("yyyy/MM");
        this.btnMonth3.Value = DateTime.Now.AddMonths(-2).ToString("yyyy/MM");
        this.btnMonth4.Value = DateTime.Now.AddMonths(-3).ToString("yyyy/MM");
        this.btnMonth5.Value = DateTime.Now.AddMonths(-4).ToString("yyyy/MM");
        this.btnMonth6.Value = DateTime.Now.AddMonths(-5).ToString("yyyy/MM");
    }
    [WebMethod()]
    public static string QueryMOBQ050(string SourceType, string company, string account, string begin_date, string end_date, string currency, string customerID) 
    {
        string ErMsg = string.Empty;
        string JSON_HistoryMargin = string.Empty;
        try
        {
           
            FunctionHandler fh = new FunctionHandler();
            BOSDataParse objBOS = new BOSDataParse();

            DataTable HistoryMargin = null;

            DataSet dsReturn = new DataSet();
            dsReturn = objBOS.getHistoryMargin(SourceType, company, account, begin_date.Replace("/", string.Empty), end_date.Replace("/", string.Empty), currency, customerID);
            if (dsReturn.Tables[0].Rows.Count > 0)
            {
                JSON_HistoryMargin = "{}";
                ErMsg = dsReturn.Tables[0].Rows[0]["Error"].ToString();
            }
            else
            {
                HistoryMargin = dsReturn.Tables[1];
                try
                {
                    JSON_HistoryMargin = fh.DT_To_JSON(HistoryMargin);
                }
                catch (Exception mExc)
                {
                    JSON_HistoryMargin = "{}";
                    ErMsg = "WSError:" + mExc.Message;
                }
              
            }
        }
        catch (Exception ex)
        {
            JSON_HistoryMargin = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"HM\":" + JSON_HistoryMargin + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }
}
