﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web;
using System.Web.Services;

public partial class MOB_MOBQ170 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";
            string id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }

            }




            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
                //DataRow dr = GetID(comp_id, acct_id);
                //if (dr != null)
                //{
                //    this.ID.Value = dr["IDNO"].ToString();// "F128764398";//
                //    this.spActno.InnerText = dr["ACTNO"].ToString();
                //    this.spName.InnerText = dr["ACTNAME"].ToString();
                //}
            }
            //this.IP.Value = this.Page.Request.UserHostAddress;
            //this.lblTime.InnerText = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

        }
    }
}
