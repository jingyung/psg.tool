﻿using System;
using System.Collections;
using System.Web.Services;
using Newtonsoft.Json;
using System.Data;
using System.Configuration;

public partial class MOB_MOBQ070 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.hnAction_Timeout.Value = ConfigurationManager.AppSettings["Action_Timeout"].ToString();
        if (this.IsPostBack)
        {
            //
        }
        else
        { 
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------


            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}
            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
            }
        }
    }

    [WebMethod()]
    public static string QueryMOBQ070(  string rsCount, string tbDetail, string ACCT_ID, string COMP_ID, string PARAM)
    {
        string ErMsg = string.Empty;
        string JSON_MOBCombineResut;
        try
        {
            
            string TYPE = "3";
            ArrayList aryCombineData = new ArrayList();
            FunctionHandler fh = new FunctionHandler();
            DataTable dtResult = new DataTable();

            dtResult.Columns.Add("SN");
            dtResult.Columns.Add("SEQNO");
            dtResult.Columns.Add("PRODUCT");
            dtResult.Columns.Add("CP");
            dtResult.Columns.Add("BS");
            dtResult.Columns.Add("QTY");
            dtResult.Columns.Add("STATUS");
            if (TYPE == "3")
            {
                DataTable dtDetail = JsonConvert.DeserializeObject<DataTable>(tbDetail);





                int rowCount = int.Parse(rsCount);
                int rowSeqNo = 0;
                for (int rs = 0; rs < rowCount; rs++)
                {
                    DataRow[] drA = dtDetail.Select("rs='" + rs.ToString() + "' AND rsc='0'", "QTY desc");
                    DataRow[] drB = dtDetail.Select("rs='" + rs.ToString() + "' AND rsc='1'", "QTY desc");


                    
                    if (drA.Length > 0 && drB.Length  > 0)
                    {
                        rowSeqNo += 1;
                        string SEQNO = rowSeqNo.ToString().PadLeft(4, '0');
                        string COMPANY = COMP_ID.PadLeft(7, '0');
                        string ACTNO = ACCT_ID.PadLeft(7, '0');


                    
                        //商品代號1	Comno1	X(7)    
                        string Comno1 = drA[0]["comno"].ToString().Trim().PadRight(7, ' ');                          
                        //商品年月1	Comym1	X(6)   
                        string Comym1 = drA[0]["comym"].ToString().Trim().PadRight(6, ' ');  
                        //履約價1	Stkprc1	9(5)V9(4)
                        decimal ds1 = 0;
                        decimal.TryParse(drA[0]["Stkprc"].ToString().Trim(), out ds1);
                        string Stkprc1 =ds1.ToString("00000.0000").Replace(".","").PadLeft(9, '0');  
                        //CALL/PUT1	Callput1	X(1) 
                        string cp1 = drA[0]["cp"].ToString().Trim().PadRight(1, ' ');  
                        //買賣別1	BS1	X(1)         
                        string BS1 = drA[0]["bs"].ToString().Trim().PadRight(1, ' ');  
                        //數量1	Qty1	9(5)     
                        string Qty1 = drA[0]["productQTY"].ToString().Trim().PadLeft(5, '0');
                        //商品代號2	Comno2	X(7)    
                        string Comno2 = drB[0]["comno"].ToString().Trim().PadRight(7, ' ');
                        //商品年月2	Comym2	X(6)   
                        string Comym2 = drB[0]["comym"].ToString().Trim().PadRight(6, ' ');
                        //履約價2	Stkprc2	9(5)V9(4)
                        decimal ds2 = 0;
                        decimal.TryParse(drB[0]["Stkprc"].ToString().Trim(), out ds2);
                        string Stkprc2 = ds2.ToString("00000.0000").Replace(".", "").PadLeft(9, '0');  
                        //CALL/PUT2	Callput2	X(1) 
                        string cp2 = drB[0]["cp"].ToString().Trim().PadRight(1, ' ');
                        //買賣別2	BS2	X(1)         
                        string BS2 = drB[0]["bs"].ToString().Trim().PadRight(1, ' ');
                        //數量1	Qty2	9(5)     
                        string Qty2 = drB[0]["productQTY"].ToString().Trim().PadLeft(5, '0');

                        string text = SEQNO + COMPANY + ACTNO + Comno1 + Comym1 + Stkprc1 + cp1 + BS1 + Qty2 + Comno2 + Comym2 + Stkprc2 + cp2 + BS2 + Qty2;
                        aryCombineData.Add(text);

                        DataRow rw = dtResult.NewRow();
                        rw["SN"] = (rs + 1).ToString();

                        rw["SEQNO"]  = SEQNO + "<br/>";
                        rw["PRODUCT"]  = drA[0]["productName"].ToString() + "," + drB[0]["productName"].ToString() + "<br/>";
                        rw["CP"]  = drA[0]["CP"].ToString() + "," + drB[0]["CP"].ToString() + "<br/>";
                        rw["BS"] = drA[0]["BS"].ToString() + "," + drB[0]["BS"].ToString() + "<br/>";
                        rw["QTY"] = drA[0]["productQTY"].ToString() + "<br/>";

                        dtResult.Rows.Add(rw);
                    }
                     
                    //DataRow[] drsFirst = (drA.Length > drB.Length ? drB : drA);
                    //DataRow[] drsSecond = (drA.Length <= drB.Length ? drB : drA);

                    //DataRow rw = dtResult.NewRow();
                    //rw["SN"] = (rs + 1).ToString();

                    //foreach (DataRow drFirst in drsFirst)
                    //{
                    //    foreach (DataRow drSecond in drsSecond)
                    //    {
                    //        int A_QTY = int.Parse(drFirst["QTY"].ToString());
                    //        int B_QTY = int.Parse(drSecond["QTY"].ToString());

                    //        if (A_QTY == 0)
                    //            break;
                    //        if (B_QTY == 0)
                    //            continue;

                    //        rowSeqNo += 1;

                    //        string SEQNO = rowSeqNo.ToString().PadLeft(4, '0');
                    //        string COMPANY = COMP_ID.PadLeft(7, '0');
                    //        string ACTNO = ACCT_ID.PadLeft(7, '0');
                    //        string ORDDT = DateTime.Now.ToString("yyyy/MM/dd");
                    //        string ORDTM = DateTime.Now.ToString("HHmmss");
                    //        string TRDDT1 = drFirst["tradedate"].ToString();
                    //        string ORDNO1 = drFirst["orderNo"].ToString();
                    //        string TRDDT2 = drSecond["tradedate"].ToString();
                    //        string ORDNO2 = drSecond["orderNo"].ToString();
                    //        int QTY = 0;

                    //        if (A_QTY >= B_QTY)
                    //        {
                    //            QTY = B_QTY;
                    //            drFirst["QTY"] = A_QTY - B_QTY;
                    //            drSecond["QTY"] = "0";
                    //        }
                    //        else if (A_QTY < B_QTY)
                    //        {
                    //            QTY = A_QTY;
                    //            drFirst["QTY"] = "0";
                    //            drSecond["QTY"] = B_QTY - A_QTY;
                    //        }

                    //        string text = SEQNO + COMPANY + ACTNO + ORDDT + ORDTM + TRDDT1 + ORDNO1 + TRDDT2 + ORDNO2 + QTY.ToString().PadLeft(4, '0');

                    //        aryCombineData.Add(text);

                    //        rw["SEQNO"] += SEQNO + "<br/>";
                    //        rw["PRODUCT"] += drFirst["productName"].ToString() + "," + drSecond["productName"].ToString() + "<br/>";
                    //        rw["CP"] += drFirst["CP"].ToString() + "," + drSecond["CP"].ToString() + "<br/>";
                    //        rw["BS"] += drFirst["BS"].ToString() + "," + drSecond["BS"].ToString() + "<br/>";
                    //        rw["QTY"] += QTY.ToString() + "<br/>";
                    //    }
                    //}
                
                }


                string COUNT = aryCombineData.Count.ToString().PadLeft(4, '0');

                for (int c_idx = 0; c_idx < aryCombineData.Count; c_idx++)
                {
                    DataRow rw = dtResult.NewRow();

                    aryCombineData[c_idx] = TYPE + COUNT + aryCombineData[c_idx];


                }
            }
            else if (TYPE == "0")
            {
                string COMPANY = COMP_ID.PadLeft(7, '0');
                string ACTNO = ACCT_ID.PadLeft(7, '0');
                string ORDDT = DateTime.Now.ToString("yyyy/MM/dd");
                string ORDTM = DateTime.Now.ToString("HHmmss");
                string text = "0001" + COMPANY + ACTNO +"             000000000  00000             000000000  00000";

                aryCombineData.Add(TYPE + "0001" + text);

                DataRow rw = dtResult.NewRow();
                rw["SN"] = "1";
                rw["SEQNO"] += "0001<br/>";
                rw["PRODUCT"] += "<br/>";
                rw["CP"] += "<br/>";
                rw["BS"] += "<br/>";
                rw["QTY"] += "<br/>";
                dtResult.Rows.Add(rw);
            }

            //-----加入log記錄元件----
            //WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
            //WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());

            string[] combineData = aryCombineData.ToArray(typeof(string)) as string[];

            //MobDataParse mobData = new MobDataParse();

            //string[] ResultData;


            ////ResultData[0] = " 123456780003000100         123456780003000100 ";
            ////ResultData[1] = " 123456780003000200         123456780003000200 ";
            ////ResultData[2] = " 123456780003000300         123456780003000300 ";

            //try
            //{
            //     ResultData = fh.getMOB_Combine(ACCT_ID, COMP_ID, combineData, mobj_T1Log, mobj_T4Log);

            //    mobData.parseMobInfoData(ResultData);


            //    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
            //    Int32 idx = 0;
            //    for (idx = 0; idx < ResultData.Length; idx++)
            //    {
            //        mobj_T4Log.WriteEntryData(ResultData[idx].Substring(1, 27) + mobj_T4Log.T4b + T4e + ResultData[idx]);
            //    }

            //    mobj_T1Log.WriteEntryData("=======" + PARAM);
            //}
            //catch (Exception ex)
            //{

            //}
            //finally
            //{
            //    mobj_T1Log.Close();
            //    mobj_T4Log.Close();
            //}

            //DataTable MOBCombineData = mobData.GetMOBCombineDT();
            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = ws.WS_getMOB_Combine(COMP_ID, ACCT_ID, combineData).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                DataTable MOBCombineData = ds.Tables[0];
                if (MOBCombineData.Columns.Contains("error"))
                {
                    JSON_MOBCombineResut = "{}";
                    ErMsg = MOBCombineData.Rows[0]["error"].ToString();
                }
                else
                {
                     
                    foreach (DataRow drCombine in dtResult.Rows)
                    {
                        string[] seqs = drCombine["SEQNO"].ToString().Split(new string[] { "<br/>" }, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string strSeq in seqs)
                        {
                            DataRow[] drsCombine = MOBCombineData.Select("SEQNO='" + strSeq + "'");
                            if (drsCombine.Length > 0)
                            {
                                drCombine["STATUS"] += drsCombine[0]["STATUS"].ToString() + "<br/>";
                            }

                        }
                    }

                    JSON_MOBCombineResut = fh.DT_To_JSON(dtResult);
                }
            }
            else
            {
                JSON_MOBCombineResut = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON_MOBCombineResut = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        return "{\"MOBCombineResult\":" + JSON_MOBCombineResut + ",\"ErMsg\":\"" + ErMsg + "\"}";

    }
    [WebMethod()]
    public static string QueryMOBQ070_a( string ACCT_ID, string COMP_ID, string PARAM)
    {
        string ErMsg = string.Empty;
        string JSON_MOBCombineResut;
        try
        {
          
            ArrayList aryCombineData = new ArrayList();
            FunctionHandler fh = new FunctionHandler();
            DataTable dtResult = new DataTable();

            dtResult.Columns.Add("SN");
            dtResult.Columns.Add("SEQNO");
            dtResult.Columns.Add("PRODUCT");
            dtResult.Columns.Add("CP");
            dtResult.Columns.Add("BS");
            dtResult.Columns.Add("QTY");
            dtResult.Columns.Add("STATUS");
            string COMPANY = COMP_ID.PadLeft(7, '0');
            string ACTNO = ACCT_ID.PadLeft(7, '0');
            string ORDDT = DateTime.Now.ToString("yyyy/MM/dd");
            string ORDTM = DateTime.Now.ToString("HHmmss");
            string text = "0001" + COMPANY + ACTNO + "             000000000  00000             000000000  00000";

            aryCombineData.Add("00001" + text);

            DataRow rw = dtResult.NewRow();
            rw["SN"] = "1";
            rw["SEQNO"] += "0001<br/>";
            rw["PRODUCT"] += "<br/>";
            rw["CP"] += "<br/>";
            rw["BS"] += "<br/>";
            rw["QTY"] += "<br/>";
            dtResult.Rows.Add(rw);
            //-----加入log記錄元件----
            //WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
            //WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());

            string[] combineData = aryCombineData.ToArray(typeof(string)) as string[];

            //MobDataParse mobData = new MobDataParse();

            //string[] ResultData;


            ////ResultData[0] = " 123456780003000100         123456780003000100 ";
            ////ResultData[1] = " 123456780003000200         123456780003000200 ";
            ////ResultData[2] = " 123456780003000300         123456780003000300 ";

            //try
            //{
            //    ResultData = fh.getMOB_Combine(ACCT_ID, COMP_ID, combineData, mobj_T1Log, mobj_T4Log);

            //    mobData.parseMobInfoData(ResultData);


            //    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
            //    Int32 idx = 0;
            //    for (idx = 0; idx < ResultData.Length; idx++)
            //    {
            //        mobj_T4Log.WriteEntryData(ResultData[idx].Substring(1, 27) + mobj_T4Log.T4b + T4e + ResultData[idx]);
            //    }

            //    mobj_T1Log.WriteEntryData("=======" + PARAM);
            //}
            //catch (Exception ex)
            //{

            //}
            //finally
            //{
            //    mobj_T1Log.Close();
            //    mobj_T4Log.Close();
            //}

            //DataTable MOBCombineData = mobData.GetMOBCombineDT();
            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = ws.WS_getMOB_Combine(COMP_ID, ACCT_ID, combineData).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                DataTable MOBCombineData = ds.Tables[0];
                if (MOBCombineData.Columns.Contains("error"))
                {
                    JSON_MOBCombineResut = "{}";
                    ErMsg = MOBCombineData.Rows[0]["error"].ToString();
                }
                else
                {
                   
                    foreach (DataRow drCombine in dtResult.Rows)
                    {
                        string[] seqs = drCombine["SEQNO"].ToString().Split(new string[] { "<br/>" }, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string strSeq in seqs)
                        {
                            DataRow[] drsCombine = MOBCombineData.Select("SEQNO='" + strSeq + "'");
                            if (drsCombine.Length > 0)
                            {
                                drCombine["STATUS"] += drsCombine[0]["STATUS"].ToString() + "<br/>";
                            }

                        }
                        drCombine["PRODUCT"] = "全組";
                    }

                    JSON_MOBCombineResut = fh.DT_To_JSON(dtResult);
                }
            }
            else
            {
                JSON_MOBCombineResut = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON_MOBCombineResut = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        return "{\"MOBCombineResult\":" + JSON_MOBCombineResut + ",\"ErMsg\":\"" + ErMsg + "\"}";
        

    }

    [WebMethod()]
    public static string QueryMOBQ070_b(string ACCT_ID, string COMP_ID, string PARAM)
    {
        string ErMsg = string.Empty;
        string JSON_MOBCombineResut;
        try
        {
            
            ArrayList aryCombineData = new ArrayList();
            FunctionHandler fh = new FunctionHandler();
            DataTable dtResult = new DataTable();

            dtResult.Columns.Add("SN");
            dtResult.Columns.Add("SEQNO");
            dtResult.Columns.Add("PRODUCT");
            dtResult.Columns.Add("CP");
            dtResult.Columns.Add("BS");
            dtResult.Columns.Add("QTY");
            dtResult.Columns.Add("STATUS");
            string COMPANY = COMP_ID.PadLeft(7, '0');
            string ACTNO = ACCT_ID.PadLeft(7, '0');



            aryCombineData.Add("200010001" + COMPANY + ACTNO );

            DataRow rw = dtResult.NewRow();
            rw["SN"] = "1";
            rw["SEQNO"] += "0001<br/>";
            rw["PRODUCT"] += "<br/>";
            rw["CP"] += "<br/>";
            rw["BS"] += "<br/>";
            rw["QTY"] += "<br/>";
            dtResult.Rows.Add(rw);
            //-----加入log記錄元件----
            //WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
            //WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());

            string[] combineData = aryCombineData.ToArray(typeof(string)) as string[];

            //MobDataParse mobData = new MobDataParse();

            //string[] ResultData;


            ////ResultData[0] = " 123456780003000100         123456780003000100 ";
            ////ResultData[1] = " 123456780003000200         123456780003000200 ";
            ////ResultData[2] = " 123456780003000300         123456780003000300 ";

            //try
            //{
            //    ResultData = fh.getMOB_Net(ACCT_ID, COMP_ID, combineData, mobj_T1Log, mobj_T4Log);

            //    mobData.parseMobInfoData(ResultData);


            //    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
            //    Int32 idx = 0;
            //    for (idx = 0; idx < ResultData.Length; idx++)
            //    {
            //        mobj_T4Log.WriteEntryData(ResultData[idx].Substring(1, 27) + mobj_T4Log.T4b + T4e + ResultData[idx]);
            //    }

            //    mobj_T1Log.WriteEntryData("=======" + PARAM);
            //}
            //catch (Exception ex)
            //{

            //}
            //finally
            //{
            //    mobj_T1Log.Close();
            //    mobj_T4Log.Close();
            //}

            //DataTable MOBCombineData = mobData.GetMOBCombineDT();

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = ws.WS_getMOB_Net(COMP_ID, ACCT_ID, combineData).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                DataTable MOBCombineData = ds.Tables[0];
                if (MOBCombineData.Columns.Contains("error"))
                {
                    JSON_MOBCombineResut = "{}";
                    ErMsg = MOBCombineData.Rows[0]["error"].ToString();
                }
                else
                {
                    

                    foreach (DataRow drCombine in dtResult.Rows)
                    {
                        string[] seqs = drCombine["SEQNO"].ToString().Split(new string[] { "<br/>" }, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string strSeq in seqs)
                        {
                            DataRow[] drsCombine = MOBCombineData.Select("SEQNO='" + strSeq + "'");
                            if (drsCombine.Length > 0)
                            {
                                drCombine["STATUS"] += drsCombine[0]["STATUS"].ToString() + "<br/>";
                            }

                        }
                        drCombine["PRODUCT"] = "全部了結";
                    }

                    JSON_MOBCombineResut = fh.DT_To_JSON(dtResult);
                }
            }
            else
            {
                JSON_MOBCombineResut = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON_MOBCombineResut = "{}";
            ErMsg = "WSError:" + ex.Message;
        }


        return "{\"MOBCombineResult\":" + JSON_MOBCombineResut + ",\"ErMsg\":\"" + ErMsg + "\"}";

    }
}
