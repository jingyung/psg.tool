﻿//定義目前日期
var date = new Date();
var d = date.getDate();
var m = date.getMonth();
var y = date.getFullYear();
var tempyear;
//定義行事曆是否load過
var loaded = false;
//存放點選日期儲存格
var clickday;
//存放點選日期yyyy-MM-dd
var eventtime;

//存放假日和備註的資料陣列
var holiday;
//存放備註陣列
var noteevents;

$(document).ready(function() {
    //產生假期年月下拉式
    QueryYear();

    $("#drpYears").val(y);
    Query(y);
    //建立行事曆
    setup();


});

function QueryYear() {
    var tParam = fh_GenParam();
    var dt;
    var m_WhereParm = {}

    var m_objJSON = fh_CallWebMethod("MOBQ160", "Get_Years?uri=" + tParam, m_WhereParm, false);

    if (m_objJSON != null) {

        if (m_objJSON.HOLIDAY == undefined) return;
        dt = m_objJSON.HOLIDAY;

        if (m_objJSON.ErMsg != "") {
            fh_AlertMsg(m_objJSON.ErMsg);
        }
        else {
          
        
            $.each(eval(dt), function(key, item) {
            var opt = document.createElement("OPTION"); opt.value = item.Holiday_Year; opt.text = item.Holiday_Year;
                $("#drpYears")[0].options.add(opt)

            });
            //產生查詢結果

        }
    }
}
function Query(year) {
    var tParam = fh_GenParam();
    var dt;
    var m_WhereParm = { year: year };

    var m_objJSON = fh_CallWebMethod("MOBQ160", "Query?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
        if (m_objJSON.HOLIDAY == undefined) return;
        dt = m_objJSON.HOLIDAY;
        holiday = new Array();
        if (m_objJSON.ErMsg != "") {
            fh_AlertMsg(m_objJSON.ErMsg);
        }
        else {
            holiday = new Array();
            tempyear = year;
            $.each(eval(dt), function(key, item) {
            
     
                holiday.push({ ACTION_TYPE: "", HOLIDAY_DATE: item.HOLIDAY_DATE, NOTE: item.NOTE, TWDAY: item.TWDAY  });

            });
            //產生查詢結果

        }
    }
 
}
function btn_searchs_click(e) {

    Query($("#drpYears").val());
    if ($("#drpYears").val() != y) {
        $('#calendar').fullCalendar('gotoDate', $("#drpYears").val());
    }
    else {
        $('#calendar').fullCalendar('gotoDate', date);
    }
    display_holiday();

}
function btn_year_click(e) {
    if ($('#divYear').css('display') != 'none')
        return false;

    //開啟對話視窗
    show_div('divYear');
}

//行事曆
function setup() {
    if (loaded)
        return;
    loaded = true;

    $('#calendar').fullCalendar({

        editable: true,
        weekMode: 'liquid', //動態顯示週的行數 20131220
        buttonText: {
            prev: '&nbsp;&lt;&nbsp;',  // left triangle
            next: '&nbsp;&gt;&nbsp;',  // right triangle
            prevYear: '&nbsp;&lt;&lt;&nbsp;', // <<
            nextYear: '&nbsp;&gt;&gt;&nbsp;', // >>
            today: '今日',
            month: '月',
            week: '週',
            day: '日'
        },
        columnFormat: {
            month: 'ddd',    // Mon
            week: 'M/d ddd', // Mon 9/7
            day: 'M/d dddd'  // Monday 9/7
        },
        axisFormat: 'h(:mm) tt',
        allDayText: '全日',
        titleFormat: {
            month: 'yyyy-MM',                             // 2011-03
            week: "yyyy-MM d[ yyyy]{ '&#8212;'[ MM] d}", // 2011-03 6 — 12
            day: 'yyyy-MM-d dddd'                  // 2011-03-9 星期三
        },
        monthNames: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
        monthNamesShort: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'],
        dayNames: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
        dayNamesShort: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
        header: {
            left: 'prev,next', // today',
            center: 'title',
            right: 'month'//,agendaWeek,agendaDay'
        },
        events:
            noteevents,
        //顯示月曆觸發
        viewDisplay: function(view) {
            if (tempyear != undefined && tempyear != $('#calendar').fullCalendar('getDate').format("yyyy")) {
                Query($('#calendar').fullCalendar('getDate').format("yyyy"));

            }
            display_holiday();
            $(".fc-other-month .fc-day-number").hide(); //隱藏非該月的日期20131220
        },
        //空白日期按下處理程式
        dayClick: function(date, allDay, jsEvent, view) {
            if (tempyear == $('#calendar').fullCalendar('getDate').format("yyyy")) {
                clickday = $(this);

                eventtime = date.format("yyyy-MM-dd");
                showadder();
            }
            else {
                alert('請先產生' + $('#calendar').fullCalendar('getDate').format("yyyy") + '年度假日資料');
            }
        },
        eventRender: function(event, element, view) {//隱藏非該月的事件20131220
            if (event.start.getMonth() != view.start.getMonth()) {
                if ($("#calendar td[data-date^='" + event.start.format("yyyy-MM-dd") + "']").length > 0) {


                    $("#calendar td[data-date^='" + event.start.format("yyyy-MM-dd") + "']").css('background-color', 'white');
                    $("#calendar td[data-date^='" + event.start.format("yyyy-MM-dd") + "']").attr('lang', '');
                }
                return false;
            }
        }

    });
}
//顯示行事曆
function display_holiday() {
    //清除事件陣列內容
    noteevents = new Array();
    //從holiday陣列內容更新到目前年月行事曆上
    if (holiday != undefined    ) {
        jQuery.each(holiday, function(i, JsonObj) {
            //搜尋為假日的儲存格,添加lang屬性和改顏色
            if ($("#calendar td[data-date^='" + JsonObj.HOLIDAY_DATE + "']").length > 0) {
                //備註是否假日,和改變背景色
                if (JsonObj.TWDAY == "Y") {
                    $("#calendar td[data-date^='" + JsonObj.HOLIDAY_DATE + "']").attr('lang', 'Y');
                    $("#calendar td[data-date^='" + JsonObj.HOLIDAY_DATE + "']").css('background-color', "#DDDDDD");
                }
                //如事件不是空白,新增
                if (JsonObj.NOTE != "") {
                    noteevents.push({ allDay: true, id: JsonObj.HOLIDAY_DATE, title: JsonObj.NOTE, start: JsonObj.HOLIDAY_DATE });
                }
            }

        });
        //清除行事曆事件
        $('#calendar').fullCalendar('removeEvents');
        //重填事件
        $('#calendar').fullCalendar('addEventSource', noteevents);
    }
}

function showadder() {
    if ($('#adder').css('display') != 'none')
        return false;
    //判斷lang是否為Y,如果是為假日
    if (clickday.attr('lang') == "Y") {
        document.getElementById("rdoY").checked = true;
    }
    else {
        document.getElementById("rdoN").checked = true;
    }
    //判斷該日是否有事件
    if ($('#calendar').fullCalendar('clientEvents', eventtime).length > 0) {
        //取得事件內容,填入備註中
        $('#title').val($('#calendar').fullCalendar('clientEvents', eventtime)[0].title);
    }
    else {
        //清除備註內容
        $('#title').val('');
    }
    //開啟對話視窗
    show_div('adder');
}




//關閉對話視窗
function close_div(divName) {
    $('#' + divName).animate({ opacity: "hide" }, "fase", function() { $('#' + divName).css('display', 'none'); });
}
//開啟對話視窗
function show_div(divName) {
    //對話視窗style
    $('#' + divName).css('left', (document.documentElement.clientWidth - $('#' + divName).width()) / 2);
    $('#' + divName).css('top', (document.documentElement.clientHeight - $('#' + divName).height()) / 2);
    $('#' + divName).animate({ opacity: "show" }, "fase", function() {  });
}



function btnGenerate_click(e) {

    if ($('#txtYear').val().length > 0) {
        var tParam = fh_GenParam();
        var dt;
        var m_WhereParm = { year: $('#txtYear').val() };

        var m_objJSON = fh_CallWebMethod("MOBQ160", "Generate_Holiday?uri=" + tParam, m_WhereParm, false);

        if (m_objJSON != null) {
            if (m_objJSON.HOLIDAY == undefined) return;
            dt = m_objJSON.HOLIDAY;

            if (m_objJSON.ErMsg != "") {
                fh_AlertMsg(m_objJSON.ErMsg);
            }
            else {
            alert("建立成功")
               QueryYear();
  close_div('divYear');
  $("#btn_searchs").click();
                } 
                //產生查詢結果

             
        }
      
    }
    return false;
}



function submit_click(e) {
   
    //刪除該日期原本event
    $('#calendar').fullCalendar('removeEvents', eventtime);
    //判斷有輸入備註,才需要增加事件  
    
    //判斷是假日才需改色,和改lang屬性
    if (document.getElementById("rdoY").checked) {
        //更新holiday內容
        var bolFind = false;
        jQuery.each(holiday, function(i, JsonObj) {
            //搜尋為假日的儲存格,添加lang屬性和改顏色
            if (JsonObj.HOLIDAY_DATE == eventtime) {
                //確實有改變的才做資料庫更新
                if (JsonObj.TWDAY != "Y" || JsonObj.NOTE != $('#title').val()) {
                    JsonObj.TWDAY = "Y";
                    JsonObj.ACTION_TYPE = "UPD";
              
                }
                bolFind = true;
            }
        });
        if (!bolFind) {
            holiday.push({ ACTION_TYPE: "ADD", HOLIDAY_DATE: eventtime , TWDAY: "Y" });
        }
        clickday.css('background-color', "#DDDDDD");
        clickday.attr('lang', 'Y');
    }
    else {
        //更新holiday內容
        var bolFind = false;
        jQuery.each(holiday, function(i, JsonObj) {
            //搜尋為假日的儲存格,添加lang屬性和改顏色
            if (JsonObj.HOLIDAY_DATE == eventtime) {
                //確實有改變的才做資料庫更新
                if (JsonObj.TWDAY != "N" || JsonObj.NOTE != $('#title').val()) {
                    JsonObj.TWDAY = "N";
                
                    JsonObj.ACTION_TYPE = "UPD";
                    
                }
                bolFind = true;
            }
        });
        if (!bolFind) {
            holiday.push({ ACTION_TYPE: "ADD", HOLIDAY_DATE: eventtime , TWDAY: "N" });
        }
        clickday.css('background-color', '#6BAEDE');
        clickday.attr('lang', '');
    }
    //還原值
    clickday = null;
    eventtime = null;

    //關閉div
    close_div('adder');

    return false;
}



//存檔
function Maintain_Save(p_Status) {
    try {
        //檢查覆核時,使用者不得與Maker同人

        if (tempyear == undefined) {
            alert('請先產生假期資料');
            return;
        }

        var tParam = fh_GenParam();
        var dt;
        var m_WhereParm = { holiday: holiday };

        var m_objJSON = fh_CallWebMethodEX("MOBQ160", "Maintain_Save?uri=" + tParam, m_WhereParm, false);
        if (m_objJSON != null) {

            if (m_objJSON.HOLIDAY == undefined) return;
            dt = m_objJSON.HOLIDAY;
            holiday = new Array();
            if (m_objJSON.ErMsg != "") {
                alert(m_objJSON.ErMsg);
            }
            else {
                 alert("建立成功")
              
 
  $("#btn_searchs").click();

                
                //產生查詢結果

            }
        }
       
       
    }
    catch (e) {
        alert(e.message);
    }
}
