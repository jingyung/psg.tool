﻿

$(document).ready(function() {
    $('#btnSearch').click(
            function(event) {
            var objStartDate = $('#txtStartDate').datepicker("getDate");
        var objEndDate = $('#txtEndDate').datepicker("getDate");
        if (objStartDate == null) {
            alert('起始日期需要輸入');
            
            return;
        }
        if (objEndDate == null) {
            alert('結束日期需要輸入');
            
            return;
        }
        if (objStartDate != null & objEndDate != null) {
            if (objStartDate > objEndDate) {
                alert('起始日期不可大於結束日期');
              
                return;
            }
        }

        var now = new Date();

 
         var day=(objEndDate-objStartDate )/(1000*60*60*24); 
         if (day>31 ) {
            alert('查詢區間最多1個月!');
           
            $('#txtStartDate').focus();
            return;
        } 
            
            
            
            
            
                
                setTimeout('GetServerDataAjax_MOBQ140()', 999);
               
            }
            )
});


function GetServerDataAjax_MOBQ140()
{
    var tParam = fh_GenParam();
var dt;
    var m_WhereParm = { company: $('#company').attr('value'),  account: $('#account').attr('value'),begin_date: $('#txtStartDate').val(), end_date: $('#txtEndDate').val() , type: $('#selType').val() }

    var m_objJSON = fh_CallWebMethod("MOBQ140", "QueryMOBQ140?uri=" + tParam, m_WhereParm, false);

        if (m_objJSON != null) {
         
         f (m_objJSON.WITHDRAW == undefined) return;
     dt = m_objJSON.WITHDRAW;

      if(m_objJSON.ErMsg!="")
            {
            fh_AlertMsg2(m_objJSON.ErMsg);
            }
            else
            {
       
        //產生查詢結果
        Render_div_QueryList(dt);
        }
    }
}


function Render_div_QueryList(dt)
{

     var _blood="" ;
     var NOMSG="";
     
   _blood += '<tbody>';
    try 
    {
        $.each(eval(dt), function(key, item) {
            _blood += '<tr style=\"height:30px\">';
            NOMSG="";
             
            if (item.OUTNO != undefined)
            {
                if (item.OUTNO.fulltrim().length >0) 
                  NOMSG+="\\n出金單號："+item.OUTNO;
            }
            
            if (item.INNO != undefined)
            {
                if (item.INNO.fulltrim().length >0) 
                  NOMSG+="\\n入金單號："+item.INNO;
            }
            
           
         //  
         
            var y="";
            
            if (NOMSG.length>0)
            y= " style=\"color:Blue; cursor:pointer\" onclick=\"alert(\'"+NOMSG+"\');\"";

            if (item.SEQNO == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.SEQNO.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += "<td class=\'contentStyle\' "+y+"   >" + item.SEQNO + "</td>"; }
            
            if (item.TYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.TYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.TYPE_NAME + '</td>'; }
            
         /*   if (item.MTYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.MTYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.MTYPE_NAME + '</td>'; }

            
            if (item.TOMTYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.TOMTYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.TOMTYPE_NAME + '</td>'; }

*/
          if (item.CURRENCY == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.CURRENCY.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.CURRENCY + '</td>'; }
            
            
         /*   if (item.TOCURRENCY == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.TOCURRENCY.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle  align="right\'>' + item.TOCURRENCY + '</td>'; }
         */
                     
            if (item.AMT == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.AMT.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\' align=\'right\' >' + item.AMT + '</td>'; }        
         
                  
            if (item.OPDATE == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.OPDATE.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.OPDATE) + '</td>'; }
            
            
                       if (item.CODE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.CODE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.CODE_NAME + '</td>'; }
            
                        
                       if (item.OPDATE == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.OPDATE.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.OPDATE) + '</td>'; }
            
                        
                       if (item.OPTIME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.OPTIME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateForTimeH(item.OPTIME) + '</td>'; }
            
                          if (item.REMARK == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.REMARK.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.REMARK + '</td>'; }
            
            if (item.REMARK=="尚未處理" )
            {
               _blood += '<td class=\'contentStyle\'><input type=\"button\" value=\"取消\"  onclick=\"btnCancel_Click(\''+item.SEQNO+'\',\''+item.AMT+'\');\" /></td>';
            }
            else
            {
            _blood += '<td class=\'contentStyle\'>&nbsp;</td>';
            }
            
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
 
 
 
 
   $('#tb140').find('tbody').remove();
        $('#tb140').append(_blood);
}


function btnCancel_Click(o,amt)
{
    GetServerDataAjax_MOBQ130(o,amt);
}


function GetServerDataAjax_MOBQ130(seqno,amt) 
{
  

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
 
    //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(8)
    var COMPANY=$('#company').val();
    COMPANY=padRight(COMPANY," ",7);
    var ACTNO= $('#account').val();
    
    ACTNO=padRight(ACTNO," ",7);
    
    var TYPE="2";//取消
    var AMT=amt;

    AMT=padLeft(AMT.split('.')[0],"0",12)+ padRight(   AMT.split('.')[1],"0",2);
    var CURRENCY="NTT"
    var TOCURRENCY="NTT"
    var Data=COMPANY+ACTNO+TYPE+AMT+CURRENCY+TOCURRENCY+seqno;
    var SignData;
    var signid=$("#ID").val();
    SignData = capiobj.FSCAPISignEx2(Data, "PSCNET", "OU = PSCNET\nCN=" + GetNativeNatureCN(signid), "", "", "", 0x00044012, 0x0080);

	var rtn = capiobj.GetErrorCode();

	if (rtn != 0) 
	{
		alert(fnJSLanguageVer("簽章失敗！錯誤代碼：", "Sign fail![Error No]")+ GetErrorMessage(rtn) );return;
	} 
	else 
	{
		//alert(fnJSLanguageVer("簽章成功！", "sign correct!")); 
	}
   
   
   
    var m_WhereParm = { SignData:SignData , Data: Data, IP:$('#IP').val(),PARAM:tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ130", "QueryMOBQ130?uri="+tParam , m_WhereParm, false);
    if (m_objJSON != null )
    {
        
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg2(m_objJSON.ErMsg);
       }
       else
       {
            if(m_objJSON.Withdraw!=null && m_objJSON.Withdraw.length > 0)
            {
            
         
                if (m_objJSON.Withdraw[0].CODE != null && m_objJSON.Withdraw[0].CODE != undefined) 
                {
                    if (m_objJSON.Withdraw[0].CODE == "D000")
                    { alert("此筆出金取消成功");GetServerDataAjax_MOBQ140();}
                    else
                        alert(m_objJSON.Withdraw[0].CODE_NAME);
                   
                }
                else
                    alert ("申請失敗");
               
              }
              else { alert('申請異常'); }
        }
       
    }
   // btnCancel_Click();
    
   
}






$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#txtStartDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#txtEndDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});


$(document).ready(function() {
    $('#txtEndDate').focus(function() {
        $('#txtEndDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#EndDate').keyup(function() {
    //        $('#EndDate').val('');
    //    });
    $('#txtEndDate').change(function() {
        checkDate(this);
    });
    $('#txtStartDate').focus(function() {
        $('#txtStartDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#StartDate').keyup(function() {
    //        $('#StartDate').val('');
    //    });
    $('#txtStartDate').change(function() {
        checkDate(this);
    });
});



function padLeft(str, pad, count) 
{
    if (str==undefined)
    {
        str="";
    }
    while(str.length<count)
        str=pad+str;
    return str;
}

function padRight(str, pad, count) 
{
    if (str==undefined)
    {
        str="";
    }
    while(str.length<count)
        str=str+pad;
    return str;
}
