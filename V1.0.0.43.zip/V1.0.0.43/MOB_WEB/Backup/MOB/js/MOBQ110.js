﻿$('#txtAccount').val($('#account').val());


$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#txtDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});

$(document).ready(function() {
$('#txtDate').focus(function() {
$('#txtDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#txtDate').keyup(function() {
    //        $('#txtDate').val('');
    //    });
    $('#txtDate').change(function() {
        checkDate(this);
    });
});

$(document).ready(function() {
    $('#btnSearch').click(function(event) {
        var qYear = $('#txtDate').val().substr(0, 4);
        var qMonth = $('#txtDate').val().substr(5, 2);
        var qDay = $('#txtDate').val().substr(8, 2);
        var account = $('#txtAccount').val();
     //   account = "80001111141";
        var qAccount = account.substr(account.length - 7, 7);

        var qFolder = "I" + $('#txtDate').val();
        var qFile = "D" + qYear.substr(2, 2) + qMonth + qDay + qAccount + "_I.html";

        var url = "http://172.16.16.173/FutureBill/" + qFolder + "/" + qFile;
      //  var url = "http://61.66.195.173/FutureBill/O2010/06/11/D1006111111141_O.html";
        $('#ifrmResult').attr("src", url);
        $('#ifrmResult').attr("height", document.documentElement.offsetHeight-70);

    })
});
