﻿var sysdate = fh_GetNowDate();
$(document).ready(init);
function init()
{
    $("#btnSubmit").bind("click", btnSubmit_Click);
    $("#btnChangePassword").bind("click", btnChangePassword_Click);
    $("#btnClosePassword").bind("click", btnClosePassword_Click);
$("#btnEnter").bind("click",btnEnter_Click);
$("#btnCancel").bind("click", btnCancel_Click);
$("#selTye").bind("change", selTyel_change);

$("#sbTab1").bind("click", sbTab1_Click);
$("#sbTab2").bind("click", sbTab2_Click);

$('#txtStartDate').val(sysdate);$('#txtEndDate').val(sysdate);
$("#selSource").bind("change", selSource_Change);

QueryBANK();

}


function QueryBANK() {
    var tParam = fh_GenParam();
    var dt;
    var COMPANY = $('#company').val();
    COMPANY = padRight(COMPANY, " ", 7);
    var ACTNO = $('#account').val();
    var CURRENCY = $("#selSource").val();

    var m_WhereParm = { FIRM: COMPANY, ACTNO: ACTNO, CURRENCY: CURRENCY }
    
   

    var m_objJSON = fh_CallWebMethod("MOBQ130", "QueryBank?uri=" + tParam, m_WhereParm, false);

    if (m_objJSON != null) {

        if (m_objJSON.Bank == undefined) return;
        dt = m_objJSON.Bank;
        $('#selbank').empty(); ;
        if (m_objJSON.ErMsg != "") {
            fh_AlertMsg(m_objJSON.ErMsg);
        }
        else {
            $.each(eval(dt), function(key, item) {
            var opt = document.createElement("OPTION"); opt.value = item.BANKID2 + "-"+item.BANKID3; opt.text = item.BANKNAME;
                $("#selbank")[0].options.add(opt)

            });
            //產生查詢結果

        }
    }
}


function selSource_Change() {
    GetServerDataAjax_MOBQ010();
    QueryBANK();
}

function sbTab1_Click() {

    $("#sbTab1").attr("class","selectedTab");
    $("#sbTab2").attr("class","unselectedTab");
    $("#divTab1").show();
    $("#divTab2").hide();
}
function sbTab2_Click() {
    $("#sbTab1").attr("class", "unselectedTab");
    $("#sbTab2").attr("class", "selectedTab");
    $("#divTab2").show();
    $("#divTab1").hide();
    $('#txtStartDate').val(sysdate); $('#txtEndDate').val(sysdate);
    setTimeout('GetServerDataAjax_MOBQ140()', 999);
    
}


$(document).ready(function() {
    
     GetServerDataAjax_MOBQ010();
 });

 function selTyel_change() {
     $("#txtAmt").val("");
     if ($("#selTye").val() == "4") {
         $("#txtAmt").attr("readonly", "true");
         $("#txtAmt").attr("disabled", "true");
     }
     else {
         $("#txtAmt").attr("readonly", "");
         $("#txtAmt").attr("disabled", "");
     }

     var tParam = fh_GenParam();

     var type = $("#selTye").val();

     if (type == "1" || type == "4") {
         type = "1";
     }
     if (type == "3" || type == "C") {
         type = "3";
     }
     var m_WhereParm = { type: type, PARAM: tParam }
     var m_objJSON = fh_CallWebMethodToString("MOBQ130", "GetCloseTime?uri=" + tParam, m_WhereParm, false);
     $("#spDate").text(m_objJSON);
     
 }
 function btnChangePassword_Click() {

     var t0b = fh_GetNowTime();
     var tParam = fh_GenParam();

     //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(8)
     var COMPANY = $('#company').val();
     COMPANY = padRight(COMPANY, " ", 7);
     var ACTNO = $('#account').val();

     ACTNO = padRight(ACTNO, " ", 7);

     var OriPassoword = $('#txtOriPassoword').val();
     var NewPassoword = $('#txtNewPassoword').val();
     var ConfirmPassoword = $('#txtConfirmPassoword').val();
     if (OriPassoword.length == 0) {
         alert("請輸入密碼!"); return;
     }
     if (NewPassoword.length == 0) {
         alert("請輸入密碼!"); return;
     }
     if (ConfirmPassoword.length == 0) {
         alert("請輸入密碼!"); return;
     }

     if (NewPassoword == OriPassoword) {
         alert("新設密碼不可與原密碼相同!"); return;
     }
     if (NewPassoword != ConfirmPassoword) {
         alert("新密碼與確認密碼不符!");return;
     }
     var m_WhereParm = { company: COMPANY, actno: ACTNO, password: OriPassoword, changepassword: ConfirmPassoword, PARAM: tParam }
     var m_objJSON = fh_CallWebMethod("MOBQ130", "WS_ChangePassword?uri=" + tParam, m_WhereParm, false);
     if (m_objJSON != null) {

         if (m_objJSON.ErMsg != "") {
             fh_AlertMsg(m_objJSON.ErMsg);
         }
         else {
             if (m_objJSON.MSG != null && m_objJSON.MSG.length > 0) {


                 if (m_objJSON.MSG[0].msg != null && m_objJSON.MSG[0].msg != undefined) {
                     if (m_objJSON.MSG[0].msg == "00000") {
                         alert("更改密碼成功");
                         btnClosePassword_Click();
                         return true;
                     }
                     else if (m_objJSON.MSG[0].msg == "-1218")
                         alert("-1218 出金密碼錯誤");
                     else if (m_objJSON.MSG[0].msg == "-1221")
                         alert("-1221 出金密碼已被鎖定");
                     else if (m_objJSON.MSG[0].msg == "-1226")
                         alert("-1226 網路出金功能已暫停");
                     else if (m_objJSON.MSG[0].msg == "-1219") {

                       
                     }
                     else
                         alert("更改密碼失敗");

                 }
                 else
                     alert("更改密碼失敗");

             }
             else { alert('更改密碼失敗'); }
         }

     }
   
 }
 function btnClosePassword_Click() {
  $('#txtOriPassoword').val("");
      $('#txtNewPassoword').val("");
    $('#txtConfirmPassoword').val("");
     close_div('divPasswordConfirm')
 }
function btnSubmit_Click() {
    

     if (!checkType())return;
    if (!checkAmt())return;

    var CURRENCY = $("#selSource").val();
    if (CURRENCY == "CNY") {
        $("#spCurrency_name").text("人民幣");

    }
    else if (CURRENCY == "USD") {
    $("#spCurrency_name").text("美金");
    }
    else {
        $("#spCurrency_name").text("新台幣");
    }
    
       $("#divMain").hide();
    $("#divEnterPassword").show();
    $("#spAmt").text($("#txtAmt").val());
    //checkCA();
   
    
}
function btnEnter_Click()
{
     if (!checkPassword()){$('#txtPassword').val(""); btnCancel_Click();  return;}
     GetServerDataAjax_MOBQ130("000000000");
}
function btnCancel_Click()
{
        $("#divMain").show();
    $("#divEnterPassword").hide();
    $('#txtAmt').val("");
    $('#txtPassword').val("");
}

function checkAmt()
{
     var text =$('#txtAmt').val();
    

    try 
    {
        if ($("#selTye").val()=="4") 
        {
                 if (!confirm("是否全出"))return false;
                
                 $('#txtAmt').val($('#spRemainAmt').text());
        }
        else
        {
            if (text =="")
            {
                alert("請輸入申請金額!");return false ;
            }
            if (isNaN(text))  {alert("申請金額格式錯誤!");return false;}
            if ( text==0 ) 
            {   
                if ($("#selTye").val()=="3") 
                {
                    alert("申請金額必須大於零");return false;
                }
            }

   
        }
         
    }
    catch(ex)
    {
     alert("申請金額格式錯誤!");return false;
    }
    return true;
}
function checkType()
{
    /* if ($("#selTye").val()=="1") 
    {
        if ($("#selDestion").val()=="NTD")
        {
            alert("國內出金，出金幣別請選擇NTT");return  false;
        }
    }
   else if ($("#selTye").val()=="3") 
    {
        if ($("#selDestion").val()=="NTT")
        {
            alert("國內轉國外，出金幣別請選擇NTD");return  false;
        }
    }*/
    
    return true;
}

function checkSum(userid) {
 
var UserLen = userid.length;
var checkSUM = 0;
for(var i = 0; i < UserLen ; i++) {
    var tmpChr = userid.charCodeAt(i);
    if( tmpChr == '\r' || tmpChr == '\n' || tmpChr == ' ' ) {
        continue;
    }
    checkSUM += tmpChr;
}
checkSUM = checkSUM * 7;
return checkSUM;
}
function checkPassword()
{
 
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
 
    //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(8)
    var COMPANY=$('#company').val();
    COMPANY=padRight(COMPANY," ",7);
    var ACTNO= $('#account').val();
    
    ACTNO=padRight(ACTNO," ",7);
    

 
   
   
    var m_WhereParm = { company:COMPANY , actno: ACTNO,password:$('#txtPassword').val(), IP:$('#IP').val(),PARAM:tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ130", "WS_CheckWithdrawPassword?uri="+tParam , m_WhereParm, false);
    if (m_objJSON != null )
    {
        
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
            if(m_objJSON.MSG!=null && m_objJSON.MSG.length > 0)
            {
            
         
                if (m_objJSON.MSG[0].msg != null && m_objJSON.MSG[0].msg != undefined) 
                {
                    if (m_objJSON.MSG[0].msg == "00000") {
                        alert("密碼驗證成功");
                        return true;
                    }
                    else if (m_objJSON.MSG[0].msg == "-1218")
                        alert("-1218 出金密碼錯誤");
                    else if (m_objJSON.MSG[0].msg == "-1221")
                        alert("-1221 出金密碼已被鎖定");
                    else if (m_objJSON.MSG[0].msg == "-1226")
                        alert("-1226 網路出金功能已暫停");
                    else if (m_objJSON.MSG[0].msg == "-1219") {

                    alert("-1219 申請出金第一次需修改密碼");
//                    COMPANY = COMPANY.replace(/S/g, "").replace(/F00/g, "");
//                    var chkSUM = checkSum(COMPANY + ACTNO);
//                    window.location = "https://trade.pscnet.com.tw/otherAP/cashOut/cash_out_chgPwd.jsp?BranchID=" + COMPANY + "&CustomerID=" + ACTNO + "&chksum=" + chkSUM + " ";
                    //                    //window.open("https://trade.pscnet.com.tw/otherAP/cashOut/cash_out_chgPwd.jsp?BranchID=" + COMPANY + "&CustomerID=" + ACTNO + "&chksum=" + chkSUM + " ");
//                    if ($('#divPasswordConfirm').css('display') == 'none')
//                        show_div('divPasswordConfirm');
                    //                    return false;
                    window.location = $('#txtURL').val();
                    }
                    else
                        alert("密碼驗證失敗");
                   
                }
                else
                    alert ("密碼驗證失敗");
               
              }
              else { alert('密碼驗證異常'); }
        }
       
    }
        
    return false;
}

function checkCA()
{
var signid=$("#ID").val();
         var  SignData = capiobj.FSCAPISignEx2("Trtert", "PSCNET", "OU = PSCNET\nCN=" + GetNativeNatureCN(signid), "", "", "", 0x00044012, 0x0080);

	var rtn = capiobj.GetErrorCode();

	if (rtn != 0) {
		alert(fnJSLanguageVer("簽章失敗！錯誤代碼：", "Sign fail![Error No]")+ GetErrorMessage(rtn) );
 
	} else {
		alert(fnJSLanguageVer("簽章成功！", "sign correct!"));
       
	 
	}
}

function GetServerDataAjax_MOBQ130(seqno) 
{
    if (!checkType())return ;

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
    var selbank = $("#selbank").val();
    selbank = padRight(selbank, " ", 50);
    
    //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(8)+(50)
    var COMPANY=$('#company').val();
    COMPANY=padRight(COMPANY," ",7);
    var ACTNO= $('#account').val();
    
    ACTNO=padRight(ACTNO," ",7);
    
    var TYPE= $("#selTye").val();
    var AMT  ="0";

    if ($("#selTye").val() == "4") {
        AMT = "0";
    }
    else {
        AMT = $("#txtAmt").val();
    }
    AMT=padLeft(AMT.split('.')[0],"0",12)+ padRight(   AMT.split('.')[1],"0",2);
    var CURRENCY=$("#selSource").val();
    var TOCURRENCY=$("#selDestion").val();
    var Data = COMPANY + ACTNO + TYPE + AMT + CURRENCY + TOCURRENCY + seqno + selbank;
    var SignData;
    var signid=$("#ID").val();
    SignData = capiobj.FSCAPISignEx2(Data, "PSCNET", "OU = PSCNET\nCN=" + GetNativeNatureCN(signid), "", "", "", 0x00044012, 0x0080);

	var rtn = capiobj.GetErrorCode();

	if (rtn != 0) 
	{
		alert(fnJSLanguageVer("簽章失敗！錯誤代碼：", "Sign fail![Error No]")+ GetErrorMessage(rtn) );return;
	} 
	else 
	{
		//alert(fnJSLanguageVer("簽章成功！", "sign correct!")); 
	}
   
   
   
    var m_WhereParm = { SignData:SignData , Data: Data, IP:$('#IP').val(),PARAM:tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ130", "QueryMOBQ130?uri="+tParam , m_WhereParm, false);
    if (m_objJSON != null )
    {
        
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
            if(m_objJSON.Withdraw!=null && m_objJSON.Withdraw.length > 0)
            {
            
         
                if (m_objJSON.Withdraw[0].CODE != null && m_objJSON.Withdraw[0].CODE != undefined) 
                { 
                    if  (m_objJSON.Withdraw[0].CODE=="D000")
                    alert ("申請成功");
                    else
                        alert(m_objJSON.Withdraw[0].CODE_NAME);
                   
                }
                else
                    alert ("申請失敗");
               
              }
              else { alert('申請異常'); }
        }
       
    }
    btnCancel_Click();
    
   
}






function GetServerDataAjax_MOBQ010() {

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
    //var m_WhereParm = { Currency: $('#DropDownList2').attr('value'), ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value') }
    var m_WhereParm = { Currency: $('#selSource').attr('value'), ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM:tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ010", "QueryMOBQ010?uri="+tParam , m_WhereParm, false);
    if (m_objJSON != null )
    {
        
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
            if(m_objJSON.Margin!=null && m_objJSON.Margin.length > 0)
            {
                try 
                {
                    if (m_objJSON.Margin[0].ORDCEXCESS != null && m_objJSON.Margin[0].ORDCEXCESS != undefined) 
                    {
                        $('#spRemainAmt').text(m_objJSON.Margin[0].ORDCEXCESS);
                        $('#spAMT').text(m_objJSON.Margin[0].ORDCEXCESS); 
                    }
                    else { $('#spRemainAmt').text(0); $('#spAMT').text(0); }
                }
                catch (mExc) { $('#spRemainAmt').text(0); $('#spAMT').text(0); }
                
              }
              else { alert('查無資料'); }
        }
        //$('#DivBlock').unblock();
    }


    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);



}








//==MOBQ140=====



$(document).ready(function() {
    $('#btnSearch').click(
            function(event) {
            var objStartDate = $('#txtStartDate').datepicker("getDate");
        var objEndDate = $('#txtEndDate').datepicker("getDate");
        if (objStartDate == null) {
            alert('起始日期需要輸入');
            
            return;
        }
        if (objEndDate == null) {
            alert('結束日期需要輸入');
            
            return;
        }
        if (objStartDate != null & objEndDate != null) {
            if (objStartDate > objEndDate) {
                alert('起始日期不可大於結束日期');
              
                return;
            }
        }

        var now = new Date();

 
         var day=(objEndDate-objStartDate )/(1000*60*60*24); 
         if (day>31 ) {
            alert('查詢區間最多1個月!');
           
            $('#txtStartDate').focus();
            return;
        } 
            
            
            
            
            
                
                setTimeout('GetServerDataAjax_MOBQ140()', 999);
               
            }
            )
});


function GetServerDataAjax_MOBQ140()
{
    var tParam = fh_GenParam();
var dt;
    var m_WhereParm = { company: $('#company').attr('value'),  account: $('#account').attr('value'),begin_date: $('#txtStartDate').val(), end_date: $('#txtEndDate').val() , type: $('#selType').val() }

    var m_objJSON = fh_CallWebMethod("MOBQ140", "QueryMOBQ140?uri=" + tParam, m_WhereParm, false);

        if (m_objJSON != null)
         {
     dt = m_objJSON.WITHDRAW;

      if(m_objJSON.ErMsg!="")
            {
            fh_AlertMsg(m_objJSON.ErMsg);
            }
            else
            {
       
        //產生查詢結果
        Render_div_QueryList(dt);
        }
    }
}


function Render_div_QueryList(dt)
{

     var _blood="" ;
     var NOMSG="";
     
   _blood += '<tbody>';
    try 
    {
        $.each(eval(dt), function(key, item) {
            _blood += '<tr style=\"height:30px\">';
            NOMSG="";
             
            if (item.OUTNO != undefined)
            {
                if (item.OUTNO.fulltrim().length >0) 
                  NOMSG+="\\n出金單號："+item.OUTNO;
            }
            
            if (item.INNO != undefined)
            {
                if (item.INNO.fulltrim().length >0) 
                  NOMSG+="\\n入金單號："+item.INNO;
            }
            
           
         //  
         
            var y="";
            
            if (NOMSG.length>0)
            y= " style=\"color:Blue; cursor:pointer\" onclick=\"alert(\'"+NOMSG+"\');\"";

            if (item.SEQNO == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.SEQNO.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += "<td class=\'contentStyle\' "+y+"   >" + item.SEQNO + "</td>"; }
            
            if (item.TYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.TYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.TYPE_NAME + '</td>'; }
            
         /*   if (item.MTYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.MTYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.MTYPE_NAME + '</td>'; }

            
            if (item.TOMTYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.TOMTYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.TOMTYPE_NAME + '</td>'; }

*/
          if (item.CURRENCY == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.CURRENCY.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.CURRENCY + '</td>'; }
            
            
         /*   if (item.TOCURRENCY == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.TOCURRENCY.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle  align="right\'>' + item.TOCURRENCY + '</td>'; }
         */
                     
            if (item.AMT == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.AMT.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\' align=\'right\' >' + item.AMT + '</td>'; }        
         
                  
            if (item.OPDATE == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.OPDATE.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.OPDATE) + '</td>'; }
            
            
                       if (item.CODE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.CODE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.CODE_NAME + '</td>'; }


            if (item.OPDATE == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.OPDATE.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.OPDATE) + '</td>'; }


            if (item.OPTIME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.OPTIME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateForTimeH(item.OPTIME) + '</td>'; }
            
                          if (item.REMARK == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.REMARK.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.REMARK + '</td>'; }
            
            if (item.REMARK=="尚未處理" )
            {
                _blood += '<td class=\'contentStyle\'><input type=\"button\" value=\"取消\"  onclick=\"btnCancel_Detail_Click(\'' + item.SEQNO + '\',\'' + item.AMT + '\',\'' + item.OPDATE + '\',\'' + item.OPTIME + '\');\" /></td>';
            }
            else
            {
            _blood += '<td class=\'contentStyle\'>&nbsp;</td>';
            }
            
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
 
 
 
 
   $('#tb140').find('tbody').remove();
        $('#tb140').append(_blood);
}


function btnCancel_Detail_Click(o, amt, OPDATE, OPTIME) 
{
    GetServerDataAjax_MOBQ130_140(o, amt, OPDATE, OPTIME);
}


function GetServerDataAjax_MOBQ130_140(seqno, amt, OPDATE, OPTIME) 
{


    var m_WhereParm = { chktime: OPDATE + OPTIME }
    var m_objJSON = fh_CallWebMethod("MOBQ130", "checkSubmitTime?uri=" + tParam, m_WhereParm, false);

    if (m_objJSON == "0") {
        alert("此筆出金單已在處理中無法取消!"); return;

    }
    
 

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
 
    //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(8)
    var COMPANY=$('#company').val();
    COMPANY=padRight(COMPANY," ",7);
    var ACTNO= $('#account').val();
    
    ACTNO=padRight(ACTNO," ",7);
    
    var TYPE="2";//取消
    var AMT=amt;

    AMT=padLeft(AMT.split('.')[0],"0",12)+ padRight(   AMT.split('.')[1],"0",2);
    var CURRENCY="NTT"
    var TOCURRENCY="NTT"
    var Data=COMPANY+ACTNO+TYPE+AMT+CURRENCY+TOCURRENCY+seqno;
    var SignData;
    var signid=$("#ID").val();
    SignData = capiobj.FSCAPISignEx2(Data, "PSCNET", "OU = PSCNET\nCN=" + GetNativeNatureCN(signid), "", "", "", 0x00044012, 0x0080);

	var rtn = capiobj.GetErrorCode();

	if (rtn != 0) 
	{
		alert(fnJSLanguageVer("簽章失敗！錯誤代碼：", "Sign fail![Error No]")+ GetErrorMessage(rtn) );return;
	} 
	else 
	{
		//alert(fnJSLanguageVer("簽章成功！", "sign correct!")); 
	}
   
   
   
    var m_WhereParm = { SignData:SignData , Data: Data, IP:$('#IP').val(),PARAM:tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ130", "QueryMOBQ130?uri="+tParam , m_WhereParm, false);
    if (m_objJSON != null )
    {
        
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
            if(m_objJSON.Withdraw!=null && m_objJSON.Withdraw.length > 0)
            {
            
         
                if (m_objJSON.Withdraw[0].CODE != null && m_objJSON.Withdraw[0].CODE != undefined) 
                {
                    if (m_objJSON.Withdraw[0].CODE == "D000")
                    { alert("此筆出金取消成功");GetServerDataAjax_MOBQ140();}
                    else
                        alert(m_objJSON.Withdraw[0].CODE_NAME);
                   
                }
                else
                    alert ("申請失敗");
               
              }
              else { alert('申請異常'); }
        }
       
    }
   // btnCancel_Click();
    
   
}






$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#txtStartDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#txtEndDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});


$(document).ready(function() {
    $('#txtEndDate').focus(function() {
        $('#txtEndDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#EndDate').keyup(function() {
    //        $('#EndDate').val('');
    //    });
    $('#txtEndDate').change(function() {
        checkDate(this);
    });
    $('#txtStartDate').focus(function() {
        $('#txtStartDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#StartDate').keyup(function() {
    //        $('#StartDate').val('');
    //    });
    $('#txtStartDate').change(function() {
        checkDate(this);
    });
});



function padLeft(str, pad, count) 
{
    if (str==undefined)
    {
        str="";
    }
    while(str.length<count)
        str=pad+str;
    return str;
}

function padRight(str, pad, count) 
{
    if (str==undefined)
    {
        str="";
    }
    while(str.length<count)
        str=str+pad;
    return str;
}

function close_div(divName) {
    $('#' + divName).animate({ opacity: "hide" }, "fase", function() { $('#' + divName).css('display', 'none'); });
}
function show_div(divName) {
    //對話視窗style
    $('#' + divName).css('left', (document.documentElement.clientWidth - $('#' + divName).width()) / 2);
    $('#' + divName).css('top', (document.documentElement.clientHeight - $('#' + divName).height()) / 2);
    $('#' + divName).animate({ opacity: "show" }, "fase", function() { });
}