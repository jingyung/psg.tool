﻿

function GetServerDataAjax_MOBQ100() {

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
    //var m_WhereParm = { Currency: $('#DropDownList2').attr('value'), ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value') }
    //var m_WhereParm = { Currency: $('#DropDownList2').attr('value'), ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM:tParam }
    var m_WhereParm = { Currency: $('#DropDownList2').attr('value'), ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam } 
    var m_objJSON = fh_CallWebMethod("MOBQ100", "QueryMOBQ100?uri="+tParam , m_WhereParm, false);
    if (m_objJSON != null )
    {
        
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
            if(m_objJSON.Margin!=null && m_objJSON.Margin.length > 0)
            {
//                if ($('#FastRadio').attr('checked')) {
                    //alert('簡易');
                    //期貨未平倉浮動損益
                    try {
                        if (m_objJSON.Margin[0].PRTLOS != null && m_objJSON.Margin[0].PRTLOS != undefined) { $('#PRTLOS_fast').text(m_objJSON.Margin[0].PRTLOS); }
                        else { $('#PRTLOS_fast').text(0); }
                    }
                    catch (mExc) { $('#PRTLOS_fast').text(mExc.description); }
                    //所需原始保證金
                    try {
                        if (m_objJSON.Margin[0].IAMT != null && m_objJSON.Margin[0].IAMT != undefined) { $('#IAMT_fast').text(m_objJSON.Margin[0].IAMT); }
                        else { $('#IAMT_fast').text(0); }
                    }
                    catch (mExc) { $('#IAMT_fast').text(mExc.description); }
                    //所需維持保證金
                    try {
                        if (m_objJSON.Margin[0].MAMT != null && m_objJSON.Margin[0].MAMT != undefined) { $('#MAMT_fast').text(m_objJSON.Margin[0].MAMT); }
                        else { $('#MAMT_fast').text(0); }
                    }
                    catch (mExc) { $('#MAMT_fast').text(mExc.description); }
                    //下單可用(提領)保證金
                    try {
                        if (m_objJSON.Margin[0].ORDCEXCESS != null && m_objJSON.Margin[0].ORDCEXCESS != undefined) { $('#ORDCEXCESS_fast').text(m_objJSON.Margin[0].ORDCEXCESS); }
                        else { $('#ORDCEXCESS_fast').text(0); }
                    }
                    catch (mExc) { $('#ORDCEXCESS_fast').text(mExc.description); }
                        //權益數
                    try {
                        if (m_objJSON.Margin[0].CTDAB != null && m_objJSON.Margin[0].CTDAB != undefined) { $('#CTDAB_fast').text(m_objJSON.Margin[0].CTDAB); }
                        else { $('#CTDAB_fast').text(0); }
                    }
                    catch (mExc) { $('#CTDAB_fast').text(mExc.description); }
                    //權益總值
                    try {
                        if (m_objJSON.Margin[0].QPTEQUITY != null && m_objJSON.Margin[0].QPTEQUITY != undefined) { $('#QPTEQUITY_fast').text(m_objJSON.Margin[0].QPTEQUITY); }
                        else { $('#QPTEQUITY_fast').text(0); }
                    }
                    catch (mExc) { $('#QPTEQUITY_fast').text(mExc.description); }
                    //維持比率
                    try {
                        if (m_objJSON.Margin[0].MATRATE != null && m_objJSON.Margin[0].MATRATE != undefined) { $('#MATRATE_fast').text(m_objJSON.Margin[0].MATRATE); }
                        else { $('#MATRATE_fast').text(0); }
                    }
                    catch (mExc) { $('#MATRATE_fast').text(mExc.description); }
                    //清算比率
                    try {
                        if (m_objJSON.Margin[0].TMP2PRICE != null && m_objJSON.Margin[0].TMP2PRICE != undefined) { $('#OPTRATE_fast').text(m_objJSON.Margin[0].TMP2PRICE); }
                        else { $('#OPTRATE_fast').text(0); }
                    }
                    catch (mExc) { $('#OPTRATE_fast').text(mExc.description); }
                    //追繳金額
                    try {
                        if (m_objJSON.Margin[0].AIMT != null && m_objJSON.Margin[0].AIMT != undefined) { $('#AIMT_fast').text(m_objJSON.Margin[0].AIMT); }
                        else { $('#AIMT_fast').text(0); }
                    }
                    catch (mExc) { $('#AIMT_fast').text(mExc.description); }
                    //資料更新日期
                    try {
                        if (m_objJSON.Margin[0].SYSDATE != null && m_objJSON.Margin[0].SYSDATE != undefined) { $('#SYSDATE_fast').text(m_objJSON.Margin[0].SYSDATE); }
                        else { $('#SYSDATE_fast').text(0); }
                    }
                    catch (mExc) { $('#SYSDATE_fast').text(mExc.description); }
                    //資料更新時間
                    try {
                        if (m_objJSON.Margin[0].SYSTIME != null && m_objJSON.Margin[0].SYSTIME != undefined) { $('#SYSTIME_fast').text(m_objJSON.Margin[0].SYSTIME); }
                        else { $('#SYSTIME_fast').text(0); }
                    }
                    catch (mExc) { $('#SYSTIME_fast').text(mExc.description); }
//                }
//                else {
//                    //匯率
//                    try {
//                        if (m_objJSON.Margin[0].EXRATE != null && m_objJSON.Margin[0].EXRATE != undefined) { $('#EXRATE').text(m_objJSON.Margin[0].EXRATE); }
//                        else { $('#EXRATE').text(0); }
//                    }
//                    catch (mExc) { $('#EXRATE').text(mExc.description); }
//                    //昨日帳戶權益數
//                    try {
//                        if (m_objJSON.Margin[0].LCTDAB != null && m_objJSON.Margin[0].LCTDAB != undefined) { $('#LCTDAB').text(m_objJSON.Margin[0].LCTDAB); }
//                        else { $('#LCTDAB').text(0); }
//                    }
//                    catch (mExc) { $('#LCTDAB').text(mExc.description); }
//                    //昨日餘額
//                    try {
//                        if (m_objJSON.Margin[0].LTDAB != null && m_objJSON.Margin[0].LTDAB != undefined) { $('#LTDAB').text(m_objJSON.Margin[0].LTDAB); }
//                        else { $('#LTDAB').text(0); }
//                    }
//                    catch (mExc) { $('#LTDAB').text(mExc.description); }
//                    //本日出入金
//                    try {
//                        if (m_objJSON.Margin[0].DWAMT != null && m_objJSON.Margin[0].DWAMT != undefined) { $('#DWAMT').text(m_objJSON.Margin[0].DWAMT); }
//                        else { $('#DWAMT').text(0); }
//                    }
//                    catch (mExc) { $('#DWAMT').text(mExc.description); }
//                    //期貨平倉損益
//                    try {
//                        if (m_objJSON.Margin[0].OSPRTLOS != null && m_objJSON.Margin[0].OSPRTLOS != undefined) { $('#OSPRTLOS').text(m_objJSON.Margin[0].OSPRTLOS); }
//                        else { $('#OSPRTLOS').text(0); }
//                    }
//                    catch (mExc) { $('#OSPRTLOS').text(mExc.description); }
//                    //期貨未平倉浮動損益
//                    try {
//                        if (m_objJSON.Margin[0].PRTLOS != null && m_objJSON.Margin[0].PRTLOS != undefined) { $('#PRTLOS').text(m_objJSON.Margin[0].PRTLOS); }
//                        else { $('#PRTLOS').text(0); }
//                    }
//                    catch (mExc) { $('#PRTLOS').text(mExc.description); }
//                    //選擇權平倉損益
//                    try {
//                        if (m_objJSON.Margin[0].OPTOSPRTLOS != null && m_objJSON.Margin[0].OPTOSPRTLOS != undefined) { $('#OPTOSPRTLOS').text(m_objJSON.Margin[0].OPTOSPRTLOS); }
//                        else { $('#OPTOSPRTLOS').text(0); }
//                    }
//                    catch (mExc) { $('#OPTOSPRTLOS').text(mExc.description); }
//                    //選擇權未平倉浮動損益
//                    try {
//                        if (m_objJSON.Margin[0].OPTPRTLOS != null && m_objJSON.Margin[0].OPTPRTLOS != undefined) { $('#OPTPRTLOS').text(m_objJSON.Margin[0].OPTPRTLOS); }
//                        else { $('#OPTPRTLOS').text(0); }
//                    }
//                    catch (mExc) { $('#OPTPRTLOS').text(mExc.description); }
//                    //權利金支出/收入
//                    try {
//                        if (m_objJSON.Margin[0].TPREMIUM != null && m_objJSON.Margin[0].TPREMIUM != undefined) { $('#TPREMIUM').text(m_objJSON.Margin[0].TPREMIUM); }
//                        else { $('#TPREMIUM').text(0); }
//                    }
//                    catch (mExc) { $('#TPREMIUM').text(mExc.description); }
//                    //手續費
//                    try {
//                        if (m_objJSON.Margin[0].ORIGNFEE != null && m_objJSON.Margin[0].ORIGNFEE != undefined) { $('#ORIGNFEE').text(m_objJSON.Margin[0].ORIGNFEE); }
//                        else { $('#ORIGNFEE').text(0); }
//                    }
//                    catch (mExc) { $('#ORIGNFEE').text(mExc.description); }
//                    //期交稅
//                    try {
//                        if (m_objJSON.Margin[0].CTAXAMT != null && m_objJSON.Margin[0].CTAXAMT != undefined) { $('#CTAXAMT').text(m_objJSON.Margin[0].CTAXAMT); }
//                        else { $('#CTAXAMT').text(0); }
//                    }
//                    catch (mExc) { $('#CTAXAMT').text(mExc.description); }
//                    //預扣權利金
//                    try {
//                        if (m_objJSON.Margin[0].ORDPREMIUM != null && m_objJSON.Margin[0].ORDPREMIUM != undefined) { $('#ORDPREMIUM').text(m_objJSON.Margin[0].ORDPREMIUM); }
//                        else { $('#ORDPREMIUM').text(0); }
//                    }
//                    catch (mExc) { $('#ORDPREMIUM').text(mExc.description); }
//                    //權益數
//                    try {
//                        if (m_objJSON.Margin[0].CTDAB != null && m_objJSON.Margin[0].CTDAB != undefined) { $('#CTDAB').text(m_objJSON.Margin[0].CTDAB); }
//                        else { $('#CTDAB').text(0); }
//                    }
//                    catch (mExc) { $('#CTDAB').text(mExc.description); }
//                    //下單保證金
//                    try {
//                        if (m_objJSON.Margin[0].ORDIAMT != null && m_objJSON.Margin[0].ORDIAMT != undefined) { $('#ORDIAMT').text(m_objJSON.Margin[0].ORDIAMT); }
//                        else { $('#ORDIAMT').text(0); }
//                    }
//                    catch (mExc) { $('#ORDIAMT').text(mExc.description); }
//                    //所需原始保證金
//                    try {
//                        if (m_objJSON.Margin[0].IAMT != null && m_objJSON.Margin[0].IAMT != undefined) { $('#IAMT').text(m_objJSON.Margin[0].IAMT); }
//                        else { $('#IAMT').text(0); }
//                    }
//                    catch (mExc) { $('#IAMT').text(mExc.description); }
//                    //所需維持保證金
//                    try {
//                        if (m_objJSON.Margin[0].MAMT != null && m_objJSON.Margin[0].MAMT != undefined) { $('#MAMT').text(m_objJSON.Margin[0].MAMT); }
//                        else { $('#MAMT').text(0); }
//                    }
//                    catch (mExc) { $('#MAMT').text(mExc.description); }
//                    //下單可用(提領)保證金
//                    try {
//                        if (m_objJSON.Margin[0].ORDCEXCESS != null && m_objJSON.Margin[0].ORDCEXCESS != undefined) { $('#ORDCEXCESS').text(m_objJSON.Margin[0].ORDCEXCESS); }
//                        else { $('#ORDCEXCESS').text(0); }
//                    }
//                    catch (mExc) { $('#ORDCEXCESS').text(mExc.description); }
//                    //買方權利金市值
//                    try {
//                        if (m_objJSON.Margin[0].BPREMIUM != null && m_objJSON.Margin[0].BPREMIUM != undefined) { $('#BPREMIUM').text(m_objJSON.Margin[0].BPREMIUM); }
//                        else { $('#BPREMIUM').text(0); }
//                    }
//                    catch (mExc) { $('#BPREMIUM').text(mExc.description); }
//                    //賣方權利金市值
//                    try {
//                        if (m_objJSON.Margin[0].SPREMIUM != null && m_objJSON.Margin[0].SPREMIUM != undefined) { $('#SPREMIUM').text(m_objJSON.Margin[0].SPREMIUM); }
//                        else { $('#SPREMIUM').text(0); }
//                    }
//                    catch (mExc) { $('#SPREMIUM').text(mExc.description); }
//                    //權益總值
//                    try {
//                        if (m_objJSON.Margin[0].QPTEQUITY != null && m_objJSON.Margin[0].QPTEQUITY != undefined) { $('#QPTEQUITY').text(m_objJSON.Margin[0].QPTEQUITY); }
//                        else { $('#QPTEQUITY').text(0); }
//                    }
//                    catch (mExc) { $('#QPTEQUITY').text(mExc.description); }
//                    //原始比率
//                    try {
//                        if (m_objJSON.Margin[0].INIRATE != null && m_objJSON.Margin[0].INIRATE != undefined) { $('#INIRATE').text(m_objJSON.Margin[0].INIRATE); }
//                        else { $('#INIRATE').text(0); }
//                    }
//                    catch (mExc) { $('#INIRATE').text(mExc.description); }
//                    //維持比率
//                    try {
//                        if (m_objJSON.Margin[0].MATRATE != null && m_objJSON.Margin[0].MATRATE != undefined) { $('#MATRATE').text(m_objJSON.Margin[0].MATRATE); }
//                        else { $('#MATRATE').text(0); }
//                    }
//                    catch (mExc) { $('#MATRATE').text(mExc.description); }
//                    //清算比率
//                    try {
//                        if (m_objJSON.Margin[0].OPTRATE != null && m_objJSON.Margin[0].OPTRATE != undefined) { $('#OPTRATE').text(m_objJSON.Margin[0].OPTRATE); }
//                        else { $('#OPTRATE').text(0); }
//                    }
//                    catch (mExc) { $('#OPTRATE').text(mExc.description); }
//                    //追繳金額
//                    try {
//                        if (m_objJSON.Margin[0].AIMT != null && m_objJSON.Margin[0].AIMT != undefined) { $('#AIMT').text(m_objJSON.Margin[0].AIMT); }
//                        else { $('#AIMT').text(0); }
//                    }
//                    catch (mExc) { $('#AIMT').text(mExc.description); }
//                    //台幣權益總值
//                    try {
//                        if (m_objJSON.Margin[0].TWDOPTEQUITY != null && m_objJSON.Margin[0].TWDOPTEQUITY != undefined) { $('#TWDOPTEQUITY').text(m_objJSON.Margin[0].TWDOPTEQUITY); }
//                        else { $('#TWDOPTEQUITY').text(0); }
//                    }
//                    catch (mExc) { $('#TWDOPTEQUITY').text(mExc.description); }
//                    //台幣原始比率
//                    try {
//                        if (m_objJSON.Margin[0].TWDINIRATE != null && m_objJSON.Margin[0].TWDINIRATE != undefined) { $('#TWDINIRATE').text(m_objJSON.Margin[0].TWDINIRATE); }
//                        else { $('#TWDINIRATE').text(0); }
//                    }
//                    catch (mExc) { $('#TWDINIRATE').text(mExc.description); }
//                    //台幣可用保證金
//                    try {
//                        if (m_objJSON.Margin[0].TWDORDEXCESS != null && m_objJSON.Margin[0].TWDORDEXCESS != undefined) { $('#TWDORDEXCESS').text(m_objJSON.Margin[0].TWDORDEXCESS); }
//                        else { $('#TWDORDEXCESS').text(0); }
//                    }
//                    catch (mExc) { $('#TWDORDEXCESS').text(mExc.description); }

//                    //有價證券抵繳總額
//                    try {
//                        if (m_objJSON.Margin[0].TOTAL_DAMT != null && m_objJSON.Margin[0].TOTAL_DAMT != undefined) { $('#TOTAL_DAMT').text(m_objJSON.Margin[0].TOTAL_DAMT); }
//                        else { $('#TOTAL_DAMT').text(0); }
//                    }
//                    catch (mExc) { $('#TOTAL_DAMT').text(mExc.description); }

//                    //資料更新日期
//                    try {
//                        if (m_objJSON.Margin[0].SYSDATE != null && m_objJSON.Margin[0].SYSDATE != undefined) { $('#SYSDATE').text(m_objJSON.Margin[0].SYSDATE); }
//                        else { $('#SYSDATE').text(0); }
//                    }
//                    catch (mExc) { $('#SYSDATE').text(mExc.description); }
//                    //資料更新時間
//                    try {
//                        if (m_objJSON.Margin[0].SYSTIME != null && m_objJSON.Margin[0].SYSTIME != undefined) { $('#SYSTIME').text(m_objJSON.Margin[0].SYSTIME); }
//                        else { $('#SYSTIME').text(0); }
//                    }
//                    catch (mExc) { $('#SYSTIME').text(mExc.description); }
//                }
            }
            else
            { alert('查無資料'); }
            
       }
        //$('#DivBlock').unblock();
    }
   

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);
    
    $('#DivBlock').unblock();
    //$.unblockUI();
    
   
}


$(document).ready(function() {
    $('#div_fast').addClass('div_on');
    $('#div_full').addClass('div_off');
});

$(document).ready(function() {
    $('#Button1').click(
            function(event) {
                $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
                //$.blockUI({ message: '<h1><img src="loading2.gif" /></h1>' });
                setTimeout('GetServerDataAjax_MOBQ100()', 999);
                //GetServerDataAjax_MOBQ100();
            }
            )
});


//-----------------------測試的程式------------------
$(document).ready(function() {
    var _HowManyTimes = $('#TestCounter').val();
    if (_HowManyTimes != null && _HowManyTimes > 0) {
        $('#TestTimerButton').click(function(event) {
            //setTimeout('ForTest(' + _HowManyTimes + ');', 500);
            var HowManyTimes = _HowManyTimes;
            //disable normal button
            $('#Button1').hide();
            $('#TestTimerButton').attr('disabled', 'disabled');

            for (HowManyTimes; HowManyTimes > 0; HowManyTimes--) {
                var ReplaceText = '測試' + HowManyTimes.toString() + '次';
                $('#TestTimerButton').attr('value', ReplaceText);

                try {
                    //$('#DivBlock2').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
                    //$('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
                    $('#DivBlock2').hide();

                    var t0b = fh_GetNowTime();
                    var tParam = fh_GenParam();
                    
                    //var m_WhereParm = { Currency: $('#DropDownList2').attr('value'), ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam }
                    var m_WhereParm = { Currency:"TWD", ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam }
                    var m_objJSON = fh_CallWebMethod("MOBQ100", "QueryMOBQ100?uri=" + tParam, m_WhereParm, false);
                    if (m_objJSON != null && m_objJSON.length > 0) {
//                        if ($('#FastRadio').attr('checked')) {
                            //alert('簡易');
                            //期貨未平倉浮動損益
                            try {
                                if (m_objJSON.Margin[0].PRTLOS != null && m_objJSON.Margin[0].PRTLOS != undefined) { $('#PRTLOS_fast').text(m_objJSON.Margin[0].PRTLOS); }
                                else { $('#PRTLOS_fast').text(0); }
                            }
                            catch (mExc) { $('#PRTLOS_fast').text(mExc.description); }
                            //所需原始保證金
                            try {
                                if (m_objJSON.Margin[0].IAMT != null && m_objJSON.Margin[0].IAMT != undefined) { $('#IAMT_fast').text(m_objJSON.Margin[0].IAMT); }
                                else { $('#IAMT_fast').text(0); }
                            }
                            catch (mExc) { $('#IAMT_fast').text(mExc.description); }
                            //所需維持保證金
                            try {
                                if (m_objJSON.Margin[0].MAMT != null && m_objJSON.Margin[0].MAMT != undefined) { $('#MAMT_fast').text(m_objJSON.Margin[0].MAMT); }
                                else { $('#MAMT_fast').text(0); }
                            }
                            catch (mExc) { $('#MAMT_fast').text(mExc.description); }
                            //下單可用(提領)保證金
                            try {
                                if (m_objJSON.Margin[0].ORDCEXCESS != null && m_objJSON.Margin[0].ORDCEXCESS != undefined) { $('#ORDCEXCESS_fast').text(m_objJSON.Margin[0].ORDCEXCESS); }
                                else { $('#ORDCEXCESS_fast').text(0); }
                            }
                            catch (mExc) { $('#ORDCEXCESS_fast').text(mExc.description); }
                            //權益總值
                            try {
                                if (m_objJSON.Margin[0].QPTEQUITY != null && m_objJSON.Margin[0].QPTEQUITY != undefined) { $('#QPTEQUITY_fast').text(m_objJSON.Margin[0].QPTEQUITY); }
                                else { $('#QPTEQUITY_fast').text(0); }
                            }
                            catch (mExc) { $('#QPTEQUITY_fast').text(mExc.description); }
                            //維持比率
                            try {
                                if (m_objJSON.Margin[0].MATRATE != null && m_objJSON.Margin[0].MATRATE != undefined) { $('#MATRATE_fast').text(m_objJSON.Margin[0].MATRATE); }
                                else { $('#MATRATE_fast').text(0); }
                            }
                            catch (mExc) { $('#MATRATE_fast').text(mExc.description); }
                            //清算比率
                            try {
                                if (m_objJSON.Margin[0].TMP2PRICE != null && m_objJSON.Margin[0].TMP2PRICE != undefined) { $('#OPTRATE_fast').text(m_objJSON.Margin[0].TMP2PRICE); }
                                else { $('#OPTRATE_fast').text(0); }
                            }
                            catch (mExc) { $('#OPTRATE_fast').text(mExc.description); }
                            //追繳金額
                            try {
                                if (m_objJSON.Margin[0].AIMT != null && m_objJSON.Margin[0].AIMT != undefined) { $('#AIMT_fast').text(m_objJSON.Margin[0].AIMT); }
                                else { $('#AIMT_fast').text(0); }
                            }
                            catch (mExc) { $('#AIMT_fast').text(mExc.description); }
                            //資料更新日期
                            try {
                                if (m_objJSON.Margin[0].SYSDATE != null && m_objJSON.Margin[0].SYSDATE != undefined) { $('#SYSDATE_fast').text(m_objJSON.Margin[0].SYSDATE); }
                                else { $('#SYSDATE_fast').text(0); }
                            }
                            catch (mExc) { $('#SYSDATE_fast').text(mExc.description); }
                            //資料更新時間
                            try {
                                if (m_objJSON.Margin[0].SYSTIME != null && m_objJSON.Margin[0].SYSTIME != undefined) { $('#SYSTIME_fast').text(m_objJSON.Margin[0].SYSTIME); }
                                else { $('#SYSTIME_fast').text(0); }
                            }
                            catch (mExc) { $('#SYSTIME_fast').text(mExc.description); }
//                        }
//                        else {
//                            //匯率
//                            try {
//                                if (m_objJSON.Margin[0].EXRATE != null && m_objJSON.Margin[0].EXRATE != undefined) { $('#EXRATE').text(m_objJSON.Margin[0].EXRATE); }
//                                else { $('#EXRATE').text(0); }
//                            }
//                            catch (mExc) { $('#EXRATE').text(mExc.description); }
//                            //昨日帳戶權益數
//                            try {
//                                if (m_objJSON.Margin[0].LCTDAB != null && m_objJSON.Margin[0].LCTDAB != undefined) { $('#LCTDAB').text(m_objJSON.Margin[0].LCTDAB); }
//                                else { $('#LCTDAB').text(0); }
//                            }
//                            catch (mExc) { $('#LCTDAB').text(mExc.description); }
//                            //昨日餘額
//                            try {
//                                if (m_objJSON.Margin[0].LTDAB != null && m_objJSON.Margin[0].LTDAB != undefined) { $('#LTDAB').text(m_objJSON.Margin[0].LTDAB); }
//                                else { $('#LTDAB').text(0); }
//                            }
//                            catch (mExc) { $('#LTDAB').text(mExc.description); }
//                            //本日出入金
//                            try {
//                                if (m_objJSON.Margin[0].DWAMT != null && m_objJSON.Margin[0].DWAMT != undefined) { $('#DWAMT').text(m_objJSON.Margin[0].DWAMT); }
//                                else { $('#DWAMT').text(0); }
//                            }
//                            catch (mExc) { $('#DWAMT').text(mExc.description); }
//                            //期貨平倉損益
//                            try {
//                                if (m_objJSON.Margin[0].OSPRTLOS != null && m_objJSON.Margin[0].OSPRTLOS != undefined) { $('#OSPRTLOS').text(m_objJSON.Margin[0].OSPRTLOS); }
//                                else { $('#OSPRTLOS').text(0); }
//                            }
//                            catch (mExc) { $('#OSPRTLOS').text(mExc.description); }
//                            //期貨未平倉浮動損益
//                            try {
//                                if (m_objJSON.Margin[0].PRTLOS != null && m_objJSON.Margin[0].PRTLOS != undefined) { $('#PRTLOS').text(m_objJSON.Margin[0].PRTLOS); }
//                                else { $('#PRTLOS').text(0); }
//                            }
//                            catch (mExc) { $('#PRTLOS').text(mExc.description); }
//                            //選擇權平倉損益
//                            try {
//                                if (m_objJSON.Margin[0].OPTOSPRTLOS != null && m_objJSON.Margin[0].OPTOSPRTLOS != undefined) { $('#OPTOSPRTLOS').text(m_objJSON.Margin[0].OPTOSPRTLOS); }
//                                else { $('#OPTOSPRTLOS').text(0); }
//                            }
//                            catch (mExc) { $('#OPTOSPRTLOS').text(mExc.description); }
//                            //選擇權未平倉浮動損益
//                            try {
//                                if (m_objJSON.Margin[0].OPTPRTLOS != null && m_objJSON.Margin[0].OPTPRTLOS != undefined) { $('#OPTPRTLOS').text(m_objJSON.Margin[0].OPTPRTLOS); }
//                                else { $('#OPTPRTLOS').text(0); }
//                            }
//                            catch (mExc) { $('#OPTPRTLOS').text(mExc.description); }
//                            //權利金支出/收入
//                            try {
//                                if (m_objJSON.Margin[0].TPREMIUM != null && m_objJSON.Margin[0].TPREMIUM != undefined) { $('#TPREMIUM').text(m_objJSON.Margin[0].TPREMIUM); }
//                                else { $('#TPREMIUM').text(0); }
//                            }
//                            catch (mExc) { $('#TPREMIUM').text(mExc.description); }
//                            //手續費
//                            try {
//                                if (m_objJSON.Margin[0].ORIGNFEE != null && m_objJSON.Margin[0].ORIGNFEE != undefined) { $('#ORIGNFEE').text(m_objJSON.Margin[0].ORIGNFEE); }
//                                else { $('#ORIGNFEE').text(0); }
//                            }
//                            catch (mExc) { $('#ORIGNFEE').text(mExc.description); }
//                            //期交稅
//                            try {
//                                if (m_objJSON.Margin[0].CTAXAMT != null && m_objJSON.Margin[0].CTAXAMT != undefined) { $('#CTAXAMT').text(m_objJSON.Margin[0].CTAXAMT); }
//                                else { $('#CTAXAMT').text(0); }
//                            }
//                            catch (mExc) { $('#CTAXAMT').text(mExc.description); }
//                            //預扣權利金
//                            try {
//                                if (m_objJSON.Margin[0].ORDPREMIUM != null && m_objJSON.Margin[0].ORDPREMIUM != undefined) { $('#ORDPREMIUM').text(m_objJSON.Margin[0].ORDPREMIUM); }
//                                else { $('#ORDPREMIUM').text(0); }
//                            }
//                            catch (mExc) { $('#ORDPREMIUM').text(mExc.description); }
//                            //權益數
//                            try {
//                                if (m_objJSON.Margin[0].CTDAB != null && m_objJSON.Margin[0].CTDAB != undefined) { $('#CTDAB').text(m_objJSON.Margin[0].CTDAB); }
//                                else { $('#CTDAB').text(0); }
//                            }
//                            catch (mExc) { $('#CTDAB').text(mExc.description); }
//                            //下單保證金
//                            try {
//                                if (m_objJSON.Margin[0].ORDIAMT != null && m_objJSON.Margin[0].ORDIAMT != undefined) { $('#ORDIAMT').text(m_objJSON.Margin[0].ORDIAMT); }
//                                else { $('#ORDIAMT').text(0); }
//                            }
//                            catch (mExc) { $('#ORDIAMT').text(mExc.description); }
//                            //所需原始保證金
//                            try {
//                                if (m_objJSON.Margin[0].IAMT != null && m_objJSON.Margin[0].IAMT != undefined) { $('#IAMT').text(m_objJSON.Margin[0].IAMT); }
//                                else { $('#IAMT').text(0); }
//                            }
//                            catch (mExc) { $('#IAMT').text(mExc.description); }
//                            //所需維持保證金
//                            try {
//                                if (m_objJSON.Margin[0].MAMT != null && m_objJSON.Margin[0].MAMT != undefined) { $('#MAMT').text(m_objJSON.Margin[0].MAMT); }
//                                else { $('#MAMT').text(0); }
//                            }
//                            catch (mExc) { $('#MAMT').text(mExc.description); }
//                            //下單可用(提領)保證金
//                            try {
//                                if (m_objJSON.Margin[0].ORDCEXCESS != null && m_objJSON.Margin[0].ORDCEXCESS != undefined) { $('#ORDCEXCESS').text(m_objJSON.Margin[0].ORDCEXCESS); }
//                                else { $('#ORDCEXCESS').text(0); }
//                            }
//                            catch (mExc) { $('#ORDCEXCESS').text(mExc.description); }
//                            //買方權利金市值
//                            try {
//                                if (m_objJSON.Margin[0].BPREMIUM != null && m_objJSON.Margin[0].BPREMIUM != undefined) { $('#BPREMIUM').text(m_objJSON.Margin[0].BPREMIUM); }
//                                else { $('#BPREMIUM').text(0); }
//                            }
//                            catch (mExc) { $('#BPREMIUM').text(mExc.description); }
//                            //賣方權利金市值
//                            try {
//                                if (m_objJSON.Margin[0].SPREMIUM != null && m_objJSON.Margin[0].SPREMIUM != undefined) { $('#SPREMIUM').text(m_objJSON.Margin[0].SPREMIUM); }
//                                else { $('#SPREMIUM').text(0); }
//                            }
//                            catch (mExc) { $('#SPREMIUM').text(mExc.description); }
//                            //權益總值
//                            try {
//                                if (m_objJSON.Margin[0].QPTEQUITY != null && m_objJSON.Margin[0].QPTEQUITY != undefined) { $('#QPTEQUITY').text(m_objJSON.Margin[0].QPTEQUITY); }
//                                else { $('#QPTEQUITY').text(0); }
//                            }
//                            catch (mExc) { $('#QPTEQUITY').text(mExc.description); }
//                            //原始比率
//                            try {
//                                if (m_objJSON.Margin[0].INIRATE != null && m_objJSON.Margin[0].INIRATE != undefined) { $('#INIRATE').text(m_objJSON.Margin[0].INIRATE); }
//                                else { $('#INIRATE').text(0); }
//                            }
//                            catch (mExc) { $('#INIRATE').text(mExc.description); }
//                            //維持比率
//                            try {
//                                if (m_objJSON.Margin[0].MATRATE != null && m_objJSON.Margin[0].MATRATE != undefined) { $('#MATRATE').text(m_objJSON.Margin[0].MATRATE); }
//                                else { $('#MATRATE').text(0); }
//                            }
//                            catch (mExc) { $('#MATRATE').text(mExc.description); }
//                            //清算比率
//                            try {
//                                if (m_objJSON.Margin[0].OPTRATE != null && m_objJSON.Margin[0].OPTRATE != undefined) { $('#OPTRATE').text(m_objJSON.Margin[0].OPTRATE); }
//                                else { $('#OPTRATE').text(0); }
//                            }
//                            catch (mExc) { $('#OPTRATE').text(mExc.description); }
//                            //追繳金額
//                            try {
//                                if (m_objJSON.Margin[0].AIMT != null && m_objJSON.Margin[0].AIMT != undefined) { $('#AIMT').text(m_objJSON.Margin[0].AIMT); }
//                                else { $('#AIMT').text(0); }
//                            }
//                            catch (mExc) { $('#AIMT').text(mExc.description); }
//                            //台幣權益總值
//                            try {
//                                if (m_objJSON.Margin[0].TWDOPTEQUITY != null && m_objJSON.Margin[0].TWDOPTEQUITY != undefined) { $('#TWDOPTEQUITY').text(m_objJSON.Margin[0].TWDOPTEQUITY); }
//                                else { $('#TWDOPTEQUITY').text(0); }
//                            }
//                            catch (mExc) { $('#TWDOPTEQUITY').text(mExc.description); }
//                            //台幣原始比率
//                            try {
//                                if (m_objJSON.Margin[0].TWDINIRATE != null && m_objJSON.Margin[0].TWDINIRATE != undefined) { $('#TWDINIRATE').text(m_objJSON.Margin[0].TWDINIRATE); }
//                                else { $('#TWDINIRATE').text(0); }
//                            }
//                            catch (mExc) { $('#TWDINIRATE').text(mExc.description); }
//                            //台幣可用保證金
//                            try {
//                                if (m_objJSON.Margin[0].TWDORDEXCESS != null && m_objJSON.Margin[0].TWDORDEXCESS != undefined) { $('#TWDORDEXCESS').text(m_objJSON.Margin[0].TWDORDEXCESS); }
//                                else { $('#TWDORDEXCESS').text(0); }
//                            }
//                            catch (mExc) { $('#TWDORDEXCESS').text(mExc.description); }

//                            //有價證券抵繳總額
//                            try {
//                                if (m_objJSON.Margin[0].TOTAL_DAMT != null && m_objJSON.Margin[0].TOTAL_DAMT != undefined) { $('#TOTAL_DAMT').text(m_objJSON.Margin[0].TOTAL_DAMT); }
//                                else { $('#TOTAL_DAMT').text(0); }
//                            }
//                            catch (mExc) { $('#TOTAL_DAMT').text(mExc.description); }

//                            //資料更新日期
//                            try {
//                                if (m_objJSON.Margin[0].SYSDATE != null && m_objJSON.Margin[0].SYSDATE != undefined) { $('#SYSDATE').text(m_objJSON.Margin[0].SYSDATE); }
//                                else { $('#SYSDATE').text(0); }
//                            }
//                            catch (mExc) { $('#SYSDATE').text(mExc.description); }
//                            //資料更新時間
//                            try {
//                                if (m_objJSON.Margin[0].SYSTIME != null && m_objJSON.Margin[0].SYSTIME != undefined) { $('#SYSTIME').text(m_objJSON.Margin[0].SYSTIME); }
//                                else { $('#SYSTIME').text(0); }
//                            }
//                            catch (mExc) { $('#SYSTIME').text(mExc.description); }
//                        }
                    }
                    //$('#DivBlock2').unblock();
                    //$('#DivBlock').unblock();
                    
                    var t0e = fh_GetNowTime();
                    fh_LogClientTime(t0b, t0e, tParam);
                    
                    $('#DivBlock2').show();
                }
                catch (mExc) {
                    alert(mExc.description);
                }

            } //end for
            $('#TestTimerButton').attr('value', '測試結束');
            //還原按鈕
            $('#Button1').show();
            $('#TestTimerButton').removeAttr('disabled');
        });
    }
});
//---------------------------------------------------------------------------

$(document).ready(function() {
    if (document.getElementById("TEST_CASE").value == "RUN") {
        window.setTimeout(AutoRun, 1000);
    }
    $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//                //$.blockUI({ message: '<h1><img src="loading2.gif" /></h1>' });
//                setTimeout('GetServerDataAjax_MOBQ100()', 999);
    GetServerDataAjax_MOBQ100();
});

function AutoRun() {
    $("#TestTimerButton").click();
}