﻿function GetServerDataAjax_MOBQ040() {

    var ret = false;
 var sort="";
    if ($('#rdoStirkePrice').attr('checked')) 
    {
        sort="StrikePrice";
    }
    else
    {
        sort="CALLPUT";
    }
    var m_WhereParm = { ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value') };
     var m_objJSON ;
        if(sort=="StrikePrice")
     m_objJSON = fh_CallWebMethod("MOBQ040", "QueryMOBQ040", m_WhereParm, false);
      else   if(sort=="CALLPUT")
        m_objJSON = fh_CallWebMethod("MOBQ040", "QueryMOBQ040SortByCP", m_WhereParm, false);
    if (m_objJSON != null) {
         if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
           ret = false;
       }
       else
       {
        var sumoriginalCost = 0;
         var _blood="" ;
//        var _blood = '<table class=\'style_100\' cellpadding="0" cellspacing="0" border="0"   width="2100">';

//        _blood += '<thead>';
//        _blood += "<tr>";

//        _blood += "<th class='style_ProductId' width='180'>商品</th>";
//        _blood += "<th class='style_ProductId' width='140'>昨日留倉(買)</th>";
//        _blood += "<th class='style_ProductId' width='140'>昨日留倉(賣)</th>";
//        _blood += "<th class='style_ProductId' width='140'>本日委託(買)</th>";
//        _blood += "<th class='style_ProductId' width='140'>本日委託(賣)</th>";
//        _blood += "<th class='style_ProductId' width='140'>目前成交(買)</th>";
//        _blood += "<th class='style_ProductId' width='140'>目前成交(賣)</th>";
//        _blood += "<th class='style_ProductId' width='100'>本日平倉</th>";
//        _blood += "<th class='style_ProductId' width='140'>目前留倉(買)</th>";
//        _blood += "<th class='style_ProductId' width='140'>目前留倉(賣)</th>";
//        _blood += "<th class='style_ProductId' width='90'>即時價位</th>";
//        _blood += "<th class='style_ProductId' width='140'>平均成本(買)</th>";
//        _blood += "<th class='style_ProductId' width='140'>平均成本(賣)</th>";
//        _blood += "<th class='style_ProductId' width='140'>價差點數(買)</th>";
//        _blood += "<th class='style_ProductId' width='140'>價差點數(賣)</th>";
//        _blood += "<th class='style_ProductId' width='120'>浮動損益</th>";
//        
//        
//        
//        
//        _blood += "<th class='style_currency' width='70'>幣別</th>";
//       // _blood += "<th class='style_originalCost' width='100'>原始投入金額</th>";
//       // _blood += "<th class='style_ProductId' width='100'>報酬率</th>";
//        
//        //_blood += "<th class='style_ProductId' width='100'>手續費</th>";
//        //_blood += "<th class='style_ProductId' width='100'>期交稅</th>";

//        _blood += "</tr>";
//        _blood += '</thead>';

        _blood += '<tbody>';
        try {

            if (m_objJSON.RealPart == undefined) return;
            $.each(eval(m_objJSON.RealPart), function(key, item) {
            ret = true;
                _blood += '<tr>';

                if (item.productName == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                else if (item.productName.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_103 contentStyle">' + item.productName + '</td>'; }


                //                try {
                //                    var _OTQtyB = parseFloat(item.OTQtyB);
                //                    var _OTQtyS = parseFloat(item.OTQtyS);
                //                    //分母不能為零
                //                    if (_OTQtyS != 0) {
                //                        _blood += '<td class="style_101 contentStyle">' + (_OTQtyB / _OTQtyS) + '</td>';
                //                    }
                //                    else { _blood += '<td class="style_101 contentStyle">0</td>'; }
                //                }
                //                catch (imExc) { _blood += '<td class="style_101 contentStyle">' + imExc.description + '</td>'; }
                //昨日留倉(買 / 賣)
                if (item.OTQtyB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.OTQtyB.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.OTQtyB + '</td>'; }
                if (item.OTQtyS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.OTQtyS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.OTQtyS + '</td>'; }

                //                try {
                //                    var _NowOrderQtyB = parseFloat(item.NowOrderQtyB);
                //                    var _NowOrderQtyS = parseFloat(item.NowOrderQtyS);
                //                    if (_NowOrderQtyS != 0) {
                //                        _blood += '<td class="style_101 contentStyle">' + (_NowOrderQtyB / _NowOrderQtyS) + '</td>';
                //                    }
                //                    else { _blood += '<td class="style_101 contentStyle">0</td>'; }
                //                }
                //                catch (imExc) { _blood += '<td class="style_101 contentStyle">' + imExc.description + '</td>'; }
                //本日委託買 賣
                if (item.NowOrderQtyB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.NowOrderQtyB.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.NowOrderQtyB + '</td>'; }
                if (item.NowOrderQtyS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.NowOrderQtyS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.NowOrderQtyS + '</td>'; }

                //                try {
                //                    var _NowMatchQtyB = parseFloat(item.NowMatchQtyB);
                //                    var _NowMatchQtyS = parseFloat(item.NowMatchQtyS);
                //                    if (_NowMatchQtyS != 0) {
                //                        _blood += '<td class="style_101 contentStyle">' + (_NowMatchQtyB / _NowMatchQtyS) + '</td>';
                //                    }
                //                    else { _blood += '<td class="style_101 contentStyle">0</td>'; }
                //                }
                //                catch (imExc) { _blood += '<td class="style_101 contentStyle">' + imExc.description + '</td>'; }
                //目前成交
                if (item.NowMatchQtyB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.NowMatchQtyB.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.NowMatchQtyB + '</td>'; }
                if (item.NowMatchQtyS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.NowMatchQtyS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.NowMatchQtyS + '</td>'; }

                if (item.TodayEnd == undefined) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.TodayEnd.length < 1) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td class="style_101 contentStyle">' + item.TodayEnd + '</td>'; }

                //                try {
                //                    var _NowOTQtyB = parseFloat(item.NowOTQtyB);
                //                    var _NowOTQtyS = parseFloat(item.NowOTQtyS);
                //                    if (_NowOTQtyS != 0) {
                //                        _blood += '<td class="style_101 contentStyle">' + (_NowOTQtyB / _NowOTQtyS) + '</td>';
                //                    }
                //                    else { _blood += '<td class="style_101 contentStyle">0</td>'; }
                //                }
                //                catch (imExc) { _blood += '<td class="style_101 contentStyle">' + imExc.description + '</td>'; }
                //目前留倉
                if (item.NowOTQtyB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.NowOTQtyB.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.NowOTQtyB + '</td>'; }
                if (item.NowOTQtyS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.NowOTQtyS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.NowOTQtyS + '</td>'; }

                if (item.RealPrice == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.RealPrice.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td class="style_101 contentStyle">' + item.RealPrice + '</td>'; }

                //                try {
                //                    var _AvgCostB = parseFloat(item.AvgCostB);
                //                    var _AvgCostS = parseFloat(item.AvgCostS);
                //                    if (_AvgCostS != 0) {
                //                        _blood += '<td class="style_101 contentStyle">' + (_AvgCostB / _AvgCostS) + '</td>';
                //                    }
                //                    else { _blood += '<td class="style_101 contentStyle">0</td>'; }
                //                }
                //                catch (imExc) { _blood += '<td class="style_101 contentStyle">' + imExc.description + '</td>'; }
                //平均成本
                if (item.AvgCostB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.AvgCostB.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.AvgCostB + '</td>'; }
                if (item.AvgCostS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.AvgCostS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.AvgCostS + '</td>'; }

                //                try {
                //                    var _PriceDiffB = parseFloat(item.PriceDiffB);
                //                    var _PriceDiffS = parseFloat(item.PriceDiffS);
                //                    if (_PriceDiffS != 0) {
                //                        _blood += '<td class="style_101 contentStyle">' + (_PriceDiffB / _PriceDiffS) + '</td>';
                //                    }
                //                    else { _blood += '<td class="style_101 contentStyle">0</td>'; }
                //                }
                //                catch (imExc) { _blood += '<td class="style_101 contentStyle">' + imExc.description + '</td>'; }
                if (item.PriceDiffB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.PriceDiffB.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.PriceDiffB + '</td>'; }
                if (item.PriceDiffS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.PriceDiffS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.PriceDiffS + '</td>'; }

                if (item.PricePL == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.PricePL.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td class="style_101 contentStyle">' + item.PricePL + '</td>'; }

                //<th class='style_currency' width='100'>幣別</th>";
//                if (item.Currency == undefined) { _blood += '<td class="style_103 contentStyle">&nbsp;</td>'; }
//                else if (item.Currency.length < 1) { _blood += '<td class="style_103 contentStyle">&nbsp;</td>'; }
//                else { _blood += '<td class="style_103 contentStyle">' + item.Currency + '</td>'; }
                
                //<th class='style_ProductId' width='100'>原始投入金額</th>";
               // if (item.originalCost == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
              //  else {
               //     _blood += '<td class="style_101 contentStyle">' + item.originalCost + '</td>';
               //     sumoriginalCost += item.originalCost;
               // }
                //<th class='style_ProductId' width='100'>報酬率</th>";
               // if (item.ROI == undefined) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
                //else if (item.ROI.length < 1) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
               // else { _blood += '<td class="style_101 contentStyle">' + item.ROI + '</td>'; }
                
                







                //<th class='style_ProductId' width='100'>手續費</th>";
                //if (item.fee == undefined) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
                //else if (item.fee.length < 1) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
                //else { _blood += '<td class="style_101 contentStyle">' + item.fee + '</td>'; }
                //<th class='style_ProductId' width='100'>期交稅</th>";
                //if (item.tax == undefined) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
                //else if (item.tax.length < 1) { _blood += '<td class="style_101 contentStyle">&nbsp;</td>'; }
                //else { _blood += '<td class="style_101 contentStyle">' + item.tax + '</td>'; }
                //sumoriginalCost += item.originalCost

                _blood += '</tr>';
            });
        } catch (mExc) { }
        _blood += '</tbody>';

 //       _blood += '</table>';
  $('#tbData').find('tbody').remove();
        $('#tbData').append(_blood);
        //$('#Text1').text(sumoriginalCost);
       // $('#Text1').val(sumoriginalCost);
       
              var systime="";
                    //資料更新日期
                    try {
                        if (m_objJSON.RealPart[0].SYSDATE != null &&m_objJSON.RealPart[0].SYSDATE != undefined)
                         { systime = m_objJSON.RealPart[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (m_objJSON.RealPart[0].SYSTIME != null && m_objJSON.RealPart[0].SYSTIME != undefined) 
                        { systime+=" " +m_objJSON.RealPart[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);

        try { if (m_objJSON.RealPart == null || m_objJSON.RealPart.length < 1) { alert('查無資料'); } }
        catch (mExc) { alert('查無資料'); }
        }
    }
    else { alert('查無資料.'); }
    //  $('#DivBlock').unblock();
    return ret;
}



$(document).ready(function() {
    $('#Button1').click(
            function(event) {
               // $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
                //$('#DivBlock').block({ message: '<span>查詢中</span>' });
                 if ($("#rdoSingle").attr("checked"))
                setTimeout('GetServerDataAjax_MOBQ040()', 999);
                else 
                     setTimeout('GetServerDataAjax_MOBQ041()', 999);
                //
                
        
            }
            )
})

$(document).ready(function() {
      // $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//               
//                setTimeout('GetServerDataAjax_MOBQ040()', 999);
GetServerDataAjax_MOBQ040();
})




function GetServerDataAjax_MOBQ041() {

 var   ret = false;
  var m_objJSON;
   var sort="";
    if ($('#rdoStirkePrice').attr('checked')) 
    {
        sort="StrikePrice";
    }
    else
    {
        sort="CALLPUT";
    }
    var m_WhereParm = { ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value') };
     if(sort=="StrikePrice")
      m_objJSON = fh_CallWebMethod("MOBQ041", "QueryMOBQ041", m_WhereParm, false);
      else   if(sort=="CALLPUT")
       fh_CallWebMethod("MOBQ041", "QueryMOBQ041SortByCP", m_WhereParm, false);
    if (m_objJSON != null) 
    {
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
       var _blood ="";
//            var _blood = '<table class=\'style_100\' cellpadding="0" cellspacing="0" border="0"  id="TQ041">';

//            _blood += '<thead>';
//            _blood += "<tr>";
//            _blood += "<th class='style_multikind'>組合總類</th>";
//            _blood += "<th class='style_product'>商品</th>";
//            _blood += "<th class='style_currency'>買賣</th>";
//            _blood += "<th class='style_realPrice'>留倉總數</th>";
//            _blood += "<th class='style_realPrice'>即時價位</th>";
//            _blood += "<th class='style_AvgMatchPrice'>平均成本</th>";
//            _blood += "<th class='style_realPrice'>價差</th>";
//            _blood += "<th class='style_RefTotalPL'>浮動損益</th>";
//            _blood += "<th class='style_currency'>幣別</th>";
//                 //added by samantha 20101013 增加複式各腳價位欄位
//                _blood += "<th class='style_footMatchPrice'>複式各腳價位</th>";
//    //        _blood += "<th></th>";
//    //        _blood += "<th></th>";
//    //        _blood += "<th></th>";
//    //        _blood += "<th></th>";
//    //        _blood += "<th></th>";
//    //        _blood += "<th></th>";
//            _blood += "</tr>";
//            _blood += '</thead>';

            _blood += '<tbody>';
            try {
                if (m_objJSON.UnLiquidationMain == undefined) return;
                $.each(eval(m_objJSON.UnLiquidationMain), function(key, item) {
                ret = true;
                    _blood += '<tr>';

                    if (item.MultiName == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else if (item.MultiName.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103 contentStyle">' + item.MultiName + '</td>'; }

                    if (item.productName == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else if (item.productName.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103 contentStyle">' + item.productName + '</td>'; }

                    if (item.multipleBS == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else if (item.multipleBS.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103 contentStyle">' + item.multipleBS + '</td>'; }

                    if (item.TotalOTQTY == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else if (item.TotalOTQTY.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103 contentStyle">' + item.TotalOTQTY + '</td>'; }

                    if (item.realPrice == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                    else {
                        _blood += '<td class="style_101 contentStyle">' + item.realPrice + '</td>';
                    }

                    if (item.AvgMatchPrice == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                    else {
                        _blood += '<td class="style_101 contentStyle">' + item.AvgMatchPrice + '</td>';
                    }

                    if (item.PriceDiff == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                    else {
                        _blood += '<td class="style_101 contentStyle">' + item.PriceDiff + '</td>';
                    }

                    if (item.RefTotalPL == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else if (item.RefTotalPL.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103 contentStyle">' + item.RefTotalPL + '</td>'; }

                    if (item.currency == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else if (item.currency.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103 contentStyle">' + item.currency + '</td>'; }
                    
                //added by samantha 20101013 增加複式各腳價位欄位
                if (item.footMatchPrice == undefined) { _blood += '<td class=\'style_103 contentStyle\'>&nbsp;</td>'; }
                else if (item.footMatchPrice.length < 1) { _blood += '<td class=\'style_103 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_103 contentStyle\'>' + item.footMatchPrice.replace("\n","<br/>")  + '</td>'; }


                    _blood += '</tr>';
                });
            } catch (mExc) { }
            _blood += '</tbody>';
            
            //_blood += '</table>';
            
         //   $('#div_Q041').html(_blood);
              $('#tbData2').find('tbody').remove();
        $('#tbData2').append(_blood);
        
        
              var systime="";
                    //資料更新日期
                    try {
                        if (m_objJSON.UnLiquidationMain[0].SYSDATE != null &&m_objJSON.UnLiquidationMain[0].SYSDATE != undefined)
                         { systime = m_objJSON.UnLiquidationMain[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (m_objJSON.UnLiquidationMain[0].SYSTIME != null && m_objJSON.UnLiquidationMain[0].SYSTIME != undefined) 
                        { systime+=" " +m_objJSON.UnLiquidationMain[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);
        }
    }
    // $('#DivBlock').unblock();
    return ret;
}


$(document).ready(function() {
    $('#btnExport').click(function(event) {

        if ($("#rdoSingle").attr("checked")) {
            if (!GetServerDataAjax_MOBQ040()) { alert("查無資料!"); return; }
        }
        else {
            if (!GetServerDataAjax_MOBQ041()) { alert("查無資料!"); return; }
        }


        var Single = "";
        if ($("#rdoSingle").attr("checked"))
            Single = "1";
        else
            Single = "0"

        var ACCT_ID = $('#account').attr('value');
        var COMP_ID = $('#company').attr('value');

        var sort = "";
        if ($('#rdoStirkePrice').attr('checked')) {
            sort = "StrikePrice";
        }
        else {
            sort = "CALLPUT";
        }



        var url = "PARAM=MOBQ040a.aspx&Single=" + Single + "&ACCT_ID=" + ACCT_ID + "&COMP_ID=" + COMP_ID + "&SORT=" + sort;
        url = encodeURI(url); //document.location.protocol+"//"+document.location.host +"/
        //      window.open("MOBQ040a.aspx?" + url,_blank);
        window.location.href = "MOBQ040a.aspx?" + url;
        return false;
    })
});