﻿

$(document).ready(function() {
    $('#Button1').click(
            function(event) {
                //$('#DivBlock').block({ message: '<span>查詢中</span>' });
                $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
                setTimeout('GetServerDataAjax_MOBQ030()', 999);
                //GetServerDataAjax_MOBQ030();
            }
            )
});

$(document).ready(function() {
    $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//                setTimeout('GetServerDataAjax_MOBQ030()', 999);
        GetServerDataAjax_MOBQ030();
});


function GetServerDataAjax_MOBQ030() {
    //show();
    var m_WhereParm = { ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), Currency: $('#DropDownList1').attr('value') };
    var m_objJSON = fh_CallWebMethod("MOBQ030", "QueryMOBQ030", m_WhereParm, false);
   if (m_objJSON != null )
    {
        
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
            if(m_objJSON.Balance!=null && m_objJSON.Balance.length > 0)
            {
                    try {
                        if (m_objJSON.Balance[0].OSPRTLOS != null && m_objJSON.Balance[0].OSPRTLOS != undefined) {
                            //$('#OSPRTLOS').val(m_objJSON.Balance[0].OSPRTLOS); 不可以
                            //$('#OSPRTLOS').html(m_objJSON.Balance[0].OSPRTLOS); 可以
                            $('#OSPRTLOS').text(m_objJSON.Balance[0].OSPRTLOS);
                        }
                        else { $('#OSPRTLOS').val(0); }
                    }
                    catch (mExc) {$('#OSPRTLOS').val(mExc.description); }
                    //買方權利金市值(買權)
                    try {
                        if (m_objJSON.Balance[0].BCPREMIUM != null && m_objJSON.Balance[0].BCPREMIUM != undefined) { $('#BCPREMIUM').text(m_objJSON.Balance[0].BCPREMIUM); }
                        else { $('#BCPREMIUM').text(0); } 
                    }
                    catch (mExc) { $('#BCPREMIUM').val(mExc.description); }
                    //買方權利金市值(賣權)
                    try {
                        if (m_objJSON.Balance[0].BPPREMIUM != null && m_objJSON.Balance[0].BPPREMIUM != undefined) { $('#BPPREMIUM').text(m_objJSON.Balance[0].BPPREMIUM); }
                        else { $('#BPPREMIUM').text(0); } 
                    }
                    catch (mExc) { $('#BPPREMIUM').val(mExc.description); }
                    //賣方權利金市值(買權)
                    try {
                        if (m_objJSON.Balance[0].SCPREMIUM != null && m_objJSON.Balance[0].SCPREMIUM != undefined) { $('#SCPREMIUM').text(m_objJSON.Balance[0].SCPREMIUM); }
                        else { $('#SCPREMIUM').text(0); } 
                    }
                    catch (mExc) { $('#SCPREMIUM').val(mExc.description); }
                    //賣方權利金市值(賣權)
                    try {
                        if (m_objJSON.Balance[0].SPPREMIUM != null && m_objJSON.Balance[0].SPPREMIUM != undefined) { $('#SPPREMIUM').html(m_objJSON.Balance[0].SPPREMIUM); }
                        else { $('#SPPREMIUM').html(0); } 
                    }
                    catch (mExc) { $('#SPPREMIUM').val(mExc.description); }
                    //$('#DivBlock').unblock();
                    
                       var systime="";
                    //資料更新日期
                    try {
                        if (m_objJSON.Balance[0].SYSDATE != null &&m_objJSON.Balance[0].SYSDATE != undefined)
                         { systime = m_objJSON.Balance[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (m_objJSON.Balance[0].SYSTIME != null && m_objJSON.Balance[0].SYSTIME != undefined) 
                        { systime+=" " +m_objJSON.Balance[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                  //  $('#lblSystemTime').text('資料更新時間:'+systime);
            }
             else { alert('查無資料'); }
            
       }
    }
   
    //    hide();
    $('#DivBlock').unblock();
}