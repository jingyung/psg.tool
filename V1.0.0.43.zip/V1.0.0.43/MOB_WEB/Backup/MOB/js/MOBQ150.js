﻿
$(document).ready(init);
function init() {

    $("#selType").bind("change", selTyel_change);

    QueryIB();
    QueryWitrhDrawTime()
 

}
function selTyel_change() {

    QueryWitrhDrawTime();

  

    

}

var _dtHistory;
$(document).ready(function() {
    $('#btnEnter').click(
            function(event) {
            var objStartDate = $('#txtStartDate').datepicker("getDate");
        var objEndDate = $('#txtEndDate').datepicker("getDate");
        if (!$("#rdoToday").attr("checked"))
        {
        
        
            if (objStartDate == null) {
                alert('起始日期需要輸入');
                
                return;
            }
            if (objEndDate == null) {
                alert('結束日期需要輸入');
                
                return;
            }

            if (objStartDate != null & objEndDate != null) {
                if (objStartDate > objEndDate) {
                    alert('起始日期不可大於結束日期');
                  
                    return;
                }
            }
            
            var now = new Date();

     
             var day=(objEndDate-objStartDate )/(1000*60*60*24); 
             if (day>31 ) {
                alert('查詢區間最多1個月!');
               
                $('#txtStartDate').focus();
                return;
            } 
        }
        else
        {
        }

        _startPos = 1;
        _endPos = 20;    
            
            
                
                setTimeout('GetServerDataAjax_MOBQ150()', 999);
               
            }
            )
});


$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#txtStartDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#txtEndDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});


$(document).ready(function() {
    $('#txtEndDate').focus(function() {
        $('#txtEndDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#EndDate').keyup(function() {
    //        $('#EndDate').val('');
    //    });
    $('#txtEndDate').change(function() {
        checkDate(this);
    });
    $('#txtStartDate').focus(function() {
        $('#txtStartDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#StartDate').keyup(function() {
    //        $('#StartDate').val('');
    //    });
    $('#txtStartDate').change(function() {
        checkDate(this);
    });
});
function QueryIB()
{
    var tParam = fh_GenParam();
var dt;
    var m_WhereParm = {  }

    var m_objJSON = fh_CallWebMethod("MOBQ150", "QueryIB?uri=" + tParam, m_WhereParm, false);

        if (m_objJSON != null) {

            if (m_objJSON.IB == undefined) return;
     dt = m_objJSON.IB;

      if(m_objJSON.ErMsg!="")
            {
            fh_AlertMsg(m_objJSON.ErMsg);
            }
            else
            {
                    $.each(eval(dt), function(key, item) 
                    {
                         var opt = document.createElement("OPTION");opt.value = item.COMPANY; opt.text=item.BRKNAME;
                          $("#selCompany")[0].options.add(opt)
                    
                      });
        //產生查詢結果
       
             }
    }
}

function  QueryWitrhDrawTime() {
    var tParam = fh_GenParam();
    var dt;
    var type = $("#selType").val();
    if (type == "33") type = "3";
    var m_WhereParm = { type: type }
    var lenth = $("#selTime")[0].options.length;
    for (var i = 0; i < lenth; i++)
    $("#selTime")[0].options.remove(0);
    var m_objJSON = fh_CallWebMethod("MOBQ150", "QueryWitrhDrawTime?uri=" + tParam, m_WhereParm, false);

    if (m_objJSON != null) {

        if (m_objJSON.WitrhDrawTime == undefined) return;
        dt = m_objJSON.WitrhDrawTime;

        if (m_objJSON.ErMsg != "") {
            fh_AlertMsg(m_objJSON.ErMsg);
        }
        else {
            $.each(eval(dt), function(key, item) {
                var opt = document.createElement("OPTION"); opt.value = item.value; opt.text = item.TimeDesc;
                $("#selTime")[0].options.add(opt)

            });
            //產生查詢結果

        }
    }
}



function GetServerDataAjax_MOBQ150()
{
 
    var tParam = fh_GenParam();
    var dt;
    var time="";
    var date_b = "";
    var date_e = "";
    if ($('#rdoToday').attr("checked")) {
        time= $('#selTime').val();
    }
    else
    {
        date_b= $('#txtStartDate').val();
        date_e= $('#txtEndDate').val();
    }
  
    

    var m_WhereParm = { company: $('#selCompany').val(),  account: $('#txtAct').val(),begin_date:date_b
    , end_date: date_e, type: $('#selType').val(),currency:$('#selCurrency').val() ,time:time,order:$('#selSort').val() +$('#selOrder').val()}

    var m_objJSON = fh_CallWebMethod("MOBQ150", "QueryMOBQ150?uri=" + tParam, m_WhereParm, false);

        if (m_objJSON != null) {
            if (m_objJSON.WITHDRAW == undefined) return;
     dt = m_objJSON.WITHDRAW;

      if(m_objJSON.ErMsg!="")
            {
            fh_AlertMsg(m_objJSON.ErMsg);
            }
            else
            {
                _dtHistory = dt;
                if (_dtHistory.length > 0) {
                    $('#lblTotalCount').html(_dtHistory.length);
                    //顯示總頁數

                    var pageCount = Math.ceil(_dtHistory.length / _pageSize);
                    $('#lblPageCount').html(pageCount.toString());
                    //顯示目前頁數
                    //$('#lblCurrentPage').html("1");
                    //產生下拉的頁數
                    var Lists = new Array();
                    for (row = 0; row <= pageCount - 1; row++) {
                        var itemText = (row + 1).toString();
                        Lists[row] = itemText;
                    }
                    $("#ddlCurrentPage > option").remove();
                    $.each(Lists, function(val, text) {
                        $('#ddlCurrentPage').append(
            $('<option></option>').val(val).html(text)

        );
                    });
                }
                else {
                    $("#ddlCurrentPage > option").remove();
                    $('#lblTotalCount').html(""); $('#lblPageCount').html("");
                }
        //產生查詢結果
        Render_div_QueryList(dt);
        }
    }
}


function Render_div_QueryList(dt)
{

    var dataCount = 0;
     var _blood="" ;
     var NOMSG="";
     var seq = 0;
   _blood += '<tbody>';
    try 
    {
        $.each(eval(_dtHistory), function(key, item) {

            dataCount = dataCount + 1;

            //分頁依起始與結束的索引位置
            if (dataCount >= _startPos && dataCount <= _endPos) {

                _blood += '<tr style=\"height:30px\">';
                NOMSG = "";

                if (item.OUTNO != undefined) {
                    if (item.OUTNO.fulltrim().length > 0)
                        NOMSG += " \n出金單號：" + item.OUTNO;
                }

                if (item.INNO != undefined) {
                    if (item.INNO.fulltrim().length > 0)
                        NOMSG += " \n入金單號：" + item.INNO;
                }


                //
                seq++;
                var y = "";

                _blood += '<td class=\'contentStyle\'>' + seq + '</td>';



                if (item.SEQNO == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.SEQNO.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += "<td class=\'contentStyle\'   >" + item.SEQNO + "</td>"; }

                _blood += '<td class=\'contentStyle\'>' + NOMSG + '</td>';

                if (item.ACTNO == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.ACTNO.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.COMPANY + item.ACTNO + '<br/>' + item.ACTNAME + '</td>'; }




                if (item.TYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.TYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.TYPE_NAME + '</td>'; }



                if (item.MTYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.MTYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.MTYPE_NAME + '</td>'; }


                if (item.TOMTYPE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.TOMTYPE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.TOMTYPE_NAME + '</td>'; }


                if (item.CURRENCY == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.CURRENCY.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.CURRENCY + '</td>'; }


                if (item.TOCURRENCY == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.TOCURRENCY.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle  align="right\'>' + item.TOCURRENCY + '</td>'; }


                if (item.AMT == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.AMT.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\' align=\'right\' >' + item.AMT + '</td>'; }


                if (item.ORDDT == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.ORDDT.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.ORDDT) + " " + fh_TransferDateForTimeH(item.ORDTM) + '</td>'; }



                if (item.CloseDate == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.CloseDate.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.CloseDate) + " " + fh_TransferDateForTimeHM(item.CloseTime) + '</td>'; }




                if (item.CODE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.CODE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.CODE_NAME + '</td>'; }


                if (item.REMARK == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.REMARK.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.REMARK + '</td>'; }


                if (item.ACTNO == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else if (item.ACTNO.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'contentStyle\'>' + item.ACTNO + '</td>'; }


                _blood += '</tr>';
            }
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
 
 
 
 
   $('#tb140').find('tbody').remove();
        $('#tb140').append(_blood);
}
var _pageSize = 20;
var _startPos = 1;
var _endPos = 20;
//下拉頁數改變時
$(document).ready(function() {
    $('#ddlCurrentPage').change(
    function() {
        //   $.blockUI({ message: '<h1><img src="../images/loading2.gif" /></h1>' });

        // $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
    _startPos = (parseInt($('#ddlCurrentPage option:selected').text()) - 1) * _pageSize + 1;
    _endPos = parseInt($('#ddlCurrentPage option:selected').text()) * _pageSize;
        Render_div_QueryList();
        $('#lblCurrentPage').html($('#ddlCurrentPage option:selected').text());
        //     $.unblockUI();
    }
)
});


function pageclick(e) {
    if (_dtHistory == undefined) return;
    if (_dtHistory.length > 0) {
        var page = parseInt($('#ddlCurrentPage option:selected').text());
        if (e == "first") {
            page = 1;
            _startPos = 1;
            _endPos = page * _pageSize;
        }
        else if (e == "pageup") {
        page = page - 1;
        if (page == 0) {
            page = 1;
            _startPos = 1;
            _endPos = page * _pageSize;
        }
        else {
         
            _startPos = (page -1 ) * _pageSize + 1;
            _endPos = page * _pageSize;
        }
        }
        if (e == "pagedown") {
            page = page + 1;
            if (page > $("#ddlCurrentPage > option").length) {
                page = $("#ddlCurrentPage > option").length 
                _startPos = ($("#ddlCurrentPage > option").length - 1) * _pageSize + 1;
                _endPos = page * _pageSize;
            }
            else {
               
                _startPos = (page-1) * _pageSize + 1;
                _endPos = page * _pageSize;
            }
        }
        if (e == "last") {
            page = $("#ddlCurrentPage > option").length ;
            _startPos = ($("#ddlCurrentPage > option").length - 1) * _pageSize + 1;
            _endPos = page * _pageSize;

        }
        $('#ddlCurrentPage').val(page-1);
        Render_div_QueryList();
    }

}

