﻿$(document).ready(init);
function init() {
    $("#btnMonth1").bind("click", btnMonth_Click);
    $("#btnMonth2").bind("click", btnMonth_Click);
    $("#btnMonth3").bind("click", btnMonth_Click);
    $("#btnMonth4").bind("click", btnMonth_Click);
    $("#btnMonth5").bind("click", btnMonth_Click);
    $("#btnMonth6").bind("click", btnMonth_Click);



}
function btnMonth_Click(e) {

 

    $('#txtStartDate').val(e.srcElement.value + '/' + '01')

    var year = e.srcElement.value.split('/')[0];
    var month = e.srcElement.value.split('/')[1];
    var time = new Date(year, month, 0);
    var date = time.getDate();
    $('#txtEndDate').val(e.srcElement.value + '/' + date)

    
    

    GetServerDataAjax_MOBQ120();

}


$(document).ready(function() {
    $('#btnSearch').click(
            function(event) {
                var objStartDate = $('#txtStartDate').datepicker("getDate");
                var objEndDate = $('#txtEndDate').datepicker("getDate");
                if (objStartDate == null) {
                    alert('起始日期需要輸入');

                    return;
                }
                if (objEndDate == null) {
                    alert('結束日期需要輸入');

                    return;
                }
                if (objStartDate != null & objEndDate != null) {
                    if (objStartDate > objEndDate) {
                        alert('起始日期不可大於結束日期');

                        return;
                    }
                }

                var now = new Date();


                var f = $('#chkHistory').attr("checked");
                if (f) {
                    var day = (objEndDate - objStartDate) / (1000 * 60 * 60 * 24);
                    if (day > 180) {
                        alert('查詢區間最多6個月!');

                        $('#txtStartDate').focus();
                        return;
                    }
                }
                else {
                    var day = (objEndDate - objStartDate) / (1000 * 60 * 60 * 24);
                    if (day > 30) {
                        alert('查詢區間最多1個月!');

                        $('#txtStartDate').focus();
                        return;
                    }
                }





                setTimeout('GetServerDataAjax_MOBQ120()', 999);

            }
            )
});


function GetServerDataAjax_MOBQ120()
{
    var tParam = fh_GenParam();
var dt;
    var m_WhereParm = { company: $('#company').attr('value'),  account: $('#account').attr('value'),begin_date: $('#txtStartDate').val(), end_date: $('#txtEndDate').val(),currency:$("#selCurrency").val(),history:  $('#chkHistory').attr("checked")}

    var m_objJSON = fh_CallWebMethod("MOBQ120", "QueryMOBQ120?uri=" + tParam, m_WhereParm, false);

        if (m_objJSON != null) {
         
         
         if (m_objJSON.Withdraw == undefined) return;
     dt = m_objJSON.Withdraw;

      if(m_objJSON.ErMsg!="")
            {
            fh_AlertMsg(m_objJSON.ErMsg);
            }
            else
            {
       
        //產生查詢結果
        Render_div_QueryList(dt);
        }
    }
}


function Render_div_QueryList(dt)
{

    var _blood = "";
    var code_1 = 0;
    var code_2 = 0;
 
   _blood += '<tbody>';
    try 
    {
        $.each(eval(dt), function(key, item) {
            _blood += '<tr>';



            if (item.FIRM == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.FIRM.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.FIRM + '</td>'; }

            if (item.BANKNAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.BANKNAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.BANKNAME + '</td>'; }

            if (item.BANKACTNO == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.BANKACTNO.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + item.BANKACTNO + '</td>'; }


            if (item.TRDDT == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.TRDDT.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.TRDDT) + '</td>'; }

            var code_name_font_color = "";

            if (item.CODE == "1")  //1入金2出金
            {
                code_name_font_color = "#009669";
                code_1 += parseInt(item.AMT);
            }
            else {
                code_name_font_color = "#FF0000";
                code_2 += parseInt(item.AMT);
            }


            if (item.CODE_NAME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.CODE_NAME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'> <font color=\'' + code_name_font_color + '\'>' + item.CODE_NAME + ' </font</td>'; }



            if (item.CURRENCY == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.CURRENCY.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle  align="right\'>' + item.CURRENCY + '</td>'; }


            if (item.AMT == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.AMT.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'  align=\'right\'>' + item.AMT + '</td>'; }


            if (item.MDATE == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.MDATE.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateFor(item.MDATE) + '</td>'; }


            if (item.MTIME == undefined) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else if (item.MTIME.length < 1) { _blood += '<td class=\'contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'contentStyle\'>' + fh_TransferDateForTimeH(item.MTIME) + '</td>'; }

            _blood += '</tr>';
        });
    }
    catch (mExc) { }
    _blood += '<tr>';
    _blood += '<td colspan=6  class=\'contentStyle\'>入金金額總計：';
    _blood += '</td>';
    _blood += '<td class=\'contentStyle\' align=\'right\' >' + code_1;
    _blood += '</td>';
    _blood += '<td colspan=2  class=\'contentStyle\'>';
    _blood += '</td class=\'contentStyle\'>';
    _blood += '</tr>';
    _blood += '<tr>';
    _blood += '<td colspan=6 class=\'contentStyle\' >出金金額總計：';
    _blood += '</td>';
    _blood += '<td class=\'contentStyle\'  align=\'right\'>' + code_2;
    _blood += '</td>';
    _blood += '<td colspan=2 class=\'contentStyle\'>';
    _blood += '</td>';
    _blood += '</tr>';
      _blood += '</tbody>';
 
   $('#tb120').find('tbody').remove();
        $('#tb120').append(_blood);
}


$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#txtStartDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#txtEndDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});


$(document).ready(function() {
    $('#txtEndDate').focus(function() {
        $('#txtEndDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#EndDate').keyup(function() {
    //        $('#EndDate').val('');
    //    });
    $('#txtEndDate').change(function() {
        checkDate(this);
    });
    $('#txtStartDate').focus(function() {
        $('#txtStartDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#StartDate').keyup(function() {
    //        $('#StartDate').val('');
    //    });
    $('#txtStartDate').change(function() {
        checkDate(this);
    });
});


//歷史切換開關日期區間
$(document).ready(function() {
$('#chkHistory').click(function() {
        
        if ($('#chkHistory').attr('checked')) {
            $("#fastdr").show();
         
        }
        else {
            $("#fastdr").hide();


        }
    });

  



});

