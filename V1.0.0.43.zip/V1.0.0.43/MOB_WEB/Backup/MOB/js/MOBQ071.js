﻿var _TIMEOUT=$('#hnAction_Timeout').attr('value');
var _disabledAction=false  ;
//暫存變數
var _UnLiquidationDetail;
var _SelArray = new Array();
function RemoveArray(array, attachId) {
    for (var i = 0, n = 0; i < array.length; i++) {
        if (array[i] != attachId) {
            array[n++] = array[i]
        }
    }
    array.length -= 1;
}

Array.prototype.remove = function(obj) {
    return RemoveArray(this, obj);
};

if (!Array.prototype.filter) {
    Array.prototype.filter = function(fun /*, thisp*/) {
        var len = this.length;
        if (typeof fun != "function")
            throw new TypeError();

        var res = new Array();
        var thisp = arguments[1];
        for (var i = 0; i < len; i++) {
            if (i in this) {
                var val = this[i]; // in case fun mutates this
                if (fun.call(thisp, val, i, this))
                    res.push(val);
            }
        }

        return res;
    };
}

//組合口數限制輸入數字
function KeyNumer() {
    var e_object = window.event;
    var keyascii = e_object.keyCode;
    if (keyascii >= 48 && keyascii <= 57) {
    }
    else {
        e_object.keyCode = 0;
    }
}
//檢查組合口數
function CheckMinPQTY(obj) {
    var curRow = obj.parentElement.parentElement;

    if (jQuery.trim(obj.value) != "") {
        var orgVal = jQuery.trim(curRow.cells[4].innerText);
        if (parseInt(jQuery.trim(obj.value)) > parseInt(orgVal)) {
            alert("口數不可大於點選項的原口數!");
            obj.value = orgVal;
        }
    }
}

//更新 查詢平倉商品資料
$(document).ready(function() {
    $('#btnUpdate').click(function(event) {
        //  window.location.reload(true);
         $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
         GetServerDataAjax_MOBQ071();
 
    })
    $('#btnSure').click(function(event) {
        //window.location.reload(true);
       
             $('#div_message').hide();
            LockBlock(false);
             $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
            GetServerDataAjax_MOBQ071();
         
          
             _disabledAction=true;
          setTimeout("EnableAction()", _TIMEOUT*1000);
    })
});
//第一次載入查詢
$(document).ready(function() {
//    $.blockUI({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//    setTimeout('GetServerDataAjax_MOBQ071()', 999);

 $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
GetServerDataAjax_MOBQ071();
    var divWin = document.getElementById("div_message");
    divWin.style.left = parseInt(window.screen.width / 4);
    
    ;
});
//重選
$(document).ready(function() {
    $('#btnReset').click(function(event) {
        ResetLeftTb();
    })
});
//全選
$(document).ready(function() {
    $('#cbxSelectAll').click(function(event) {
     var tb1 = document.getElementById("T_Q071_1");
         if (tb1 != null)
        SelectAllCheckBox(tb1,$("#cbxSelectAll").attr("checked"));
    })
});

//組合確認
$(document).ready(function() {
    $('#btnOK').click(function(event) {
        if(_disabledAction){
            alert('已送出申請，請勿重複執行 !!');
            return;
        }
       $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        setTimeout('CompleteComposition()', 999);
    })
});
//全組
$(document).ready(function() {
    $('#btnCompleteAll').click(function(event) {
        if(_disabledAction){
            alert('已送出申請，請勿重複執行 !!');
            return;
        }    
    $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        setTimeout('CompleteAll()', 999);
    })
});
//了結
$(document).ready(function() {
    $('#btnNET').click(function(event) {
        if(_disabledAction){
            alert('已送出申請，請勿重複執行 !!');
            return;
        }    
        $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        setTimeout('NetAll()', 999);
    })
});
function NetAll() {
    
    
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var m_WhereParm = {  ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam };
    var m_objJSON = fh_CallWebMethod("MOBQ070", "QueryMOBQ070_b?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
          if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else {

           if (m_objJSON.MOBCombineResult == undefined) return;
        Render_div_single_message(m_objJSON.MOBCombineResult);
        $('#div_message').show();
        LockBlock(true);
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

      $('#DivBlock').unblock();
//    $('#btnNET').attr("disabled", true);
//        setTimeout("EnableAction('btnNET')", _TIMEOUT*1000);
//   _disabledAction=true;
//   setTimeout("EnableAction()", _TIMEOUT*1000);
}

//function EnableAction(o)
//{
//   $("#"+o).attr("disabled", false);
//}
function EnableAction()
{
   _disabledAction=false;
}

function CompleteAll() {

    
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var m_WhereParm = {  ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam };
    var m_objJSON = fh_CallWebMethod("MOBQ071", "QueryMOBQ071_a?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
      if(m_objJSON.ErMsg!="")
       {
           alert(m_objJSON.ErMsg);
       }
       else {
           if (m_objJSON.MOBCombineResult == undefined) return;
        Render_div_single_message(m_objJSON.MOBCombineResult);
        $('#div_message').show();
        LockBlock(true);
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

      $('#DivBlock').unblock();
//         $('#btnCompleteAll').attr("disabled", true);
//       setTimeout("EnableAction('btnCompleteAll')", _TIMEOUT*1000);
//   _disabledAction=true;
//   setTimeout("EnableAction()", _TIMEOUT*1000);
}
//重設
function ResetLeftTb() {
    var tb1 = document.getElementById("T_Q071_1");
    if (tb1 != null)
        SelectAllCheckBox(tb1,false);
    _SelArray = new Array();
}
// clear all checkbox
function SelectAllCheckBox(tbl,isSel) {
    for (i = 0; i < tbl.rows.length; i++) {
        for (j = 0; j < tbl.rows[i].cells.length; j++) {
            var object = tbl.rows[i].cells[j].getElementsByTagName("INPUT");
            if (object != null) {
                for (k = 0; k < object.length; k++) {
                    if (object[k].type == "checkbox") {
                        object[k].checked = isSel;
                        CheckBoxRow(object[k]);
                    }
                }
            }
        }
    }
}



function GetServerDataAjax_MOBQ071() {
    //ResetLeftTb();
      _UnLiquidationDetail=null ;
 _SelArray = new Array(); 
 $('#div_Q0711').html("");
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
    var _currency = "";
    var m_WhereParm = { productKind: "3,4", ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), currency: _currency, PARAM: tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ020", "QueryMOBQ020for71?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
        if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else {

           if (m_objJSON.UnLiquidationDetail == undefined) return;
        _UnLiquidationDetail = m_objJSON.UnLiquidationDetail;
        Render_div_071010(m_objJSON.UnLiquidationMain);
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

     $('#DivBlock').unblock();
      $('#btnOK').attr("disabled", true);
}

//單式部位合計顯示
function Render_div_071010(UnLiquidationMain) {

    var tbIdx = 0;

    var _blood = '<table class=\'style_100\' cellspacing=0  id="T_Q071_1" width="100%" style="border-top-width:0px">';
    try {
        $.each(eval(UnLiquidationMain), function(key, item) {

            tbIdx = tbIdx + 1;
            _blood += '<tr>';
            _blood += '<td class=\'style_102 contentStyle\' style=\'width:5%\'>' + tbIdx + '</td>';

            if (item.productName == undefined) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:45%\'>&nbsp;</td>'; }
            else if (item.productName.length < 1) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:45%\'>&nbsp;</td>'; }
            else {
                _blood += '<td class=\'style_102 contentStyle\' style=\'width:45%\'>' + item.productName.replace("\n","<br/>") +
                     '<span id=\'span_ProductKind\' style=\'display:none\'>' + item.productKind +
                 '</span><span id=\'span_ProductId\' style=\'display:none\'>' + item.ProductId +
                 '</span></td>';
            }

            if (item.callput == undefined) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:6%\'>&nbsp;</td>'; }
            else if (item.callput.length < 1) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:6%\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\' style=\'width:6%\'>' + item.callput.replace("\n", "<br/>") + '</td>'; }

            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:6%\'>&nbsp;</td>'; }
            else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:6%\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\' style=\'width:6%\'>' + item.BS.replace("\n", "<br/>") + '</td>'; }

            if (item.TotalOTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\' style=\'width:13%\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\' style=\'width:13%\'>' + item.TotalOTQTY + '</td>'; }

            _blood += '<td class=\'style_101 contentStyle \' style=\'width:20%\'><input id="txtDismantlingQTY" type="text" disabled="true" style="width:90%;text-align: right" onkeypress="KeyNumer()" maxlength="3" onblur="CheckMinPQTY(this);"/></td>';

            _blood += '<td class=\'style_102 contentStyle\' style=\'width:5%\'><input id="cbo' + item.ProductId + '" type="checkbox" onclick="CheckBoxRow(this);" /></td>';
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
    _blood += '</table>';
    $('#div_Q0711').html(_blood);

}


//選擇權或期貨CheckBox勾選時
function CheckBoxRow(obj) {
    var curRow = obj.parentElement.parentElement;
    var object = curRow.cells[5].getElementsByTagName("INPUT");
    var objText;
    for (k = 0; k < object.length; k++) {
        if (object[k].type == "text") {
            objText = object[k];
        }
    }

    if (obj.checked) {
        _SelArray[_SelArray.length] = curRow;
        objText.disabled = false;
        objText.value = curRow.cells[4].innerText;
        var tb1 = document.getElementById("T_Q071_1");
        if (_SelArray.length == tb1.rows.length)
            $('#cbxSelectAll').attr("checked", true);
        if (_SelArray.length > 0)
            $("#btnOK").attr("disabled", false);
    }
    else {
        _SelArray.remove(curRow);
        objText.disabled = true;
        objText.value = "";
        if (_SelArray.length == 0) {
            $('#cbxSelectAll').attr("checked", false);
            $("#btnOK").attr("disabled", true);
        }    
    }
}


function CompleteComposition() {

    
    var rsDetail = "";

    //明細表
    //先依交易日期由小到大排序，再依委託單號由小到大排序
    var filtered = _UnLiquidationDetail.sort(function(a, b) {
        if (a.tradedate > b.tradedate)
            return 1;
        else
            return -1;
    }).sort(function(a, b) {
        if (a.orderNo > b.orderNo)
            return 1;
        else
            return -1;
    });

    for (rs = 0; rs < _SelArray.length; rs++) {

        //var productName = _SelArray[rs].cells[1].childNodes[0].nodeValue+"<br/>"+_SelArray[rs].cells[1].childNodes[2].nodeValue;
        var productName = _SelArray[rs].cells[1].childNodes[0].nodeValue;
        var CP = _SelArray[rs].cells[2].innerHTML;
        var BS = _SelArray[rs].cells[3].innerHTML;
        var object = _SelArray[rs].cells[5].getElementsByTagName("INPUT");
        var keep_ProductQTY;   
        for (k = 0; k < object.length; k++) {
            if (object[k].type == "text") {
                keep_ProductQTY = object[k].value;
            }
        }
        var productQTY = keep_ProductQTY;
        var keys = _SelArray[rs].cells[1].getElementsByTagName("SPAN");
            if (keys.length ==2) {
                //統計主表
                var productKind = keys.span_ProductKind.innerText;
                var productId = keys.span_ProductId.innerText;       
 
                try {
                    $.each(eval(filtered), function(key, item) {

                    if (item.BS.replace("\n", "") == BS.replace("<BR>", "").replace("<br>", "") && item.productKind == productKind && item.productId == (productId.replace(" ", "\n")) && parseInt(item.OTQTY) > 0) {

                            if (parseInt(productQTY) == 0)
                                return false;

                            var qty = 0;
                            if (parseInt(item.OTQTY) >=parseInt( productQTY)) { //明細口數大於拆解口數
                                qty = productQTY; //以拆解口數為主
                                item.OTQTY = parseInt(item.OTQTY) - parseInt(productQTY); //明細剩餘口數
                                productQTY = 0; //拆解剩餘口數                                           
                            }
                            else if (parseInt(item.OTQTY )< parseInt(productQTY)) {
                                qty = item.OTQTY;
                                productQTY = parseInt(productQTY) - parseInt(item.OTQTY); //拆解剩餘口數
                                item.OTQTY = 0; //明細剩餘口數
                            }
                            rsDetail += "{\"rs\":\"" + rs + "\",\"productKind\":\"" + item.productKind + "\", \"productId\":\"" + item.productId
                                    + "\", \"productQTY\":\"" + keep_ProductQTY + "\", \"productName\":\"" + productName
                                     + "\", \"CP\":\"" + CP + "\", \"COMYM\":\"" + item.COMYM + "\", \"stkprc\":\"" + item.stkprc + "\", \"comno\":\"" + item.COMNO + "\", \"BS\":\"" + BS
                                    + "\",\"tradedate\":\"" + item.tradedate
                                    + "\", \"orderNo1\":\"" + item.orderNo + "1" + item.matchseq 
                                    + "\", \"orderNo2\":\"" + item.orderNo + "2" + item.matchseq
                                            + "\", \"QTY\":\"" + qty + "\"},";                                       
                        }
                    });

                }
                catch (mExc) { }
            }
    }

    rsDetail = "[" + rsDetail.substring(0, rsDetail.length - 1) + "]";

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var m_WhereParm = { rsCount: _SelArray.length, tbDetail: rsDetail, ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam };
    var m_objJSON = fh_CallWebMethod("MOBQ071", "QueryMOBQ071?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
      if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else {
           if (m_objJSON.MOBCombineResult == undefined) return;
        Render_div_message(m_objJSON.MOBCombineResult);
        $('#div_message').show();
        LockBlock(true);
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

   $('#DivBlock').unblock();
//         $('#btnOK').attr("disabled", true);
//      setTimeout("EnableAction('btnOK')", _TIMEOUT*1000);
//   _disabledAction=true;
//   setTimeout("EnableAction()", _TIMEOUT*1000);
}

function Render_div_message(MOBCombineResult) {

    _blood = '<table class=\'style_100\' cellspacing=0>';

    _blood += '<tr>';
    _blood += '<td>序號</td>';
    _blood += '<td>流水號</td>';
    _blood += '<td>商品內容</td>';
    _blood += '<td>C/P</td>';
    _blood += '<td>B/S</td>';
    _blood += '<td>口數</td>';
    _blood += '<td>申請狀態</td>';
    _blood += '</tr>';

    try {
        $.each(eval(MOBCombineResult), function(key, item) {

            _blood += '<tr>';

            if (item.SN == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.SN + '</td>'; }

            if (item.SEQNO == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.SEQNO + '</td>'; }

            if (item.PRODUCT == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.PRODUCT + '</td>'; }


            if (item.CP == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.CP + '</td>'; }

            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS + '</td>'; }

            if (item.QTY == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.QTY + '</td>'; }

            if (item.STATUS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.STATUS + '</td>'; }

            _blood += '</tr>';

        });
    }
    catch (mExc) { }
    _blood += '</table>';
    $('#div_content').html(_blood);

}
function Render_div_single_message(MOBCombineResult) {

    _blood = '<table class=\'style_100\' cellspacing=0>';
 

    try {
        $.each(eval(MOBCombineResult), function(key, item) {

                _blood += '<tr>';

              
                if (item.PRODUCT == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.PRODUCT + '</td>'; }

 
                
                if (item.STATUS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.STATUS + '</td>'; }

                _blood += '</tr>';

        });
    }
    catch (mExc) { }
    _blood += '</table>';
    $('#div_content').html(_blood);

}
function LockBlock(isLock) {
    $('#btnUpdate').attr("disabled", isLock);
    $('#btnReset').attr("disabled", isLock);
    $("#btnOK").attr("disabled", isLock);
    $("#btnCancel").attr("disabled", isLock);
    $("#DivBlock").attr("disabled", isLock);
}
