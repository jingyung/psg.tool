﻿var _TIMEOUT=$('#hnAction_Timeout').attr('value');
var _disabledAction=false ;
//暫存變數
var _UnLiquidationDetail;
var _SelCboCount = 0;
var _SelArray = new Array(2);
var _SelMinVal = 0;
var _idx = -1;
var _Products = new Array();
var _ProductsQTY = new Array();


function RemoveArray(array, attachId) {
    for (var i = 0, n = 0; i < array.length; i++) {
        if (array[i] != attachId) {
            array[n++] = array[i]
        }
    }
    array.length -= 1;
}

Array.prototype.remove = function(obj) {
    return RemoveArray(this, obj);
};

//組合口數限制輸入數字
function KeyNumer() {
    var e_object = window.event;
    var keyascii = e_object.keyCode;
    if (keyascii >= 48 && keyascii <= 57) {
    }
    else {
        e_object.keyCode = 0;
    }
}
//檢查組合口數
function CheckMinPQTY() {
    if (_SelMinVal >0) {
        if (jQuery.trim($('#txtPQTY').val()) != "") {
            for (i = 0; i < _SelArray.length; i++) {
                var row = _SelArray[i];
                if (parseInt(_SelMinVal) > parseInt(row.cells[row.cells.length - 2].innerText))
                    _SelMinVal = row.cells[row.cells.length - 2].innerText;
            }
            if (parseInt($('#txtPQTY').val()) > parseInt(_SelMinVal)) {
                alert("口數不可大於點選二項的最小值!");
                $('#txtPQTY').val(_SelMinVal);
            }
        }
    }
    else
        $('#txtPQTY').val("");
}
//更新 查詢平倉商品資料
$(document).ready(function() {
    $('#btnUpdate').click(function(event) {
//           window.location.reload(true);
 $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
 
             GetServerDataAjax_MOBQ070();

    })
});

$(document).ready(function() {
    $('#btnSure').click(function(event) {
//         window.location.reload(true);
//         $('#hnDisabledAction').attr('value')=true;
    
            $('#div_message').hide();
            LockBlock(false);
             $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
 
            GetServerDataAjax_MOBQ070();
        
    
            _disabledAction=true;
            setTimeout("EnableAction()", _TIMEOUT*1000);
    })    
 });   
//第一次載入查詢
$(document).ready(function() {
//    $.blockUI({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//    setTimeout('GetServerDataAjax_MOBQ070()', 999);

 $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
GetServerDataAjax_MOBQ070();
    var divWin = document.getElementById("div_message");
    divWin.style.left = parseInt(window.screen.width / 4);
 
});
//重選
$(document).ready(function() {
    $('#btnReset').click(function(event) {
        ResetLeftTb();
    })
});

//重設
function ResetLeftTb() {
    var tb1 = document.getElementById("T_Q070_1");
    //    var tb2 = document.getElementById("T_Q070_2");
    if (tb1 != null)
        ClearAllCheckBox(tb1);
    //    ClearAllCheckBox(tb2);
    _SelCboCount = 0;
    _SelArray = new Array(2);
    _SelMinVal = 0;
    $('#txtPQTY').val("");
}
// clear all checkbox
function ClearAllCheckBox(tbl) {
    for (i = 0; i < tbl.rows.length; i++) {
        for (j = 0; j < tbl.rows[i].cells.length; j++) {
            var object = tbl.rows[i].cells[j].getElementsByTagName("INPUT");
            if (object != null) {
                for (k = 0; k < object.length; k++) {
                    if (object[k].type == "checkbox") {
                        object[k].checked = false;
                        //假如選擇權或期貨的口數為0，則disabled勾選
                        if (parseInt(tbl.rows[i].cells[tbl.rows[i].cells.length - 2].innerText) == 0) {                         
                            object[k].disabled = true;
                        }
                        else {                            
                            object[k].disabled = false;
                        }
                    }   
                }
            }
        }
    }
}



function GetServerDataAjax_MOBQ070() {
     _UnLiquidationDetail=null ;
     _SelCboCount = 0;
     _SelArray = new Array(2);
     _SelMinVal = 0;
     _idx = -1;
     _Products = new Array();
     _ProductsQTY = new Array();
    $('#div_Q0703').html("");
    ResetLeftTb();
    
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();
    var _currency = "";
    var m_WhereParm = { productKind: "1,2", ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), currency: _currency, PARAM: tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ020", "QueryMOBQ020for71?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
        if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else {
           if (m_objJSON.UnLiquidationDetail == undefined) return;
        _UnLiquidationDetail = m_objJSON.UnLiquidationDetail;
        Render_div_070010(m_objJSON.UnLiquidationMain);
       }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

   $('#DivBlock').unblock();
    $('#btnOK').attr("disabled", true);
}


//選擇權或期貨CheckBox勾選時
function CheckBoxRow(obj) {
    var curRow = obj.parentElement.parentElement;

    if (obj.checked) {
        for (i = 0; i < _SelArray.length; i++) {
            var row = _SelArray[i];
            if (_SelArray[i] == null) {
                _SelArray[i] = curRow;
                break;
            }
        }
        _SelCboCount = _SelCboCount + 1;
        _SelMinVal = curRow.cells[curRow.cells.length - 2].innerText;
    }
    else {
        _SelCboCount = _SelCboCount - 1;
        for (i = 0; i < _SelArray.length; i++) {
            var row = _SelArray[i];
            if (curRow == row) {
                _SelArray[i] = null;
                break;
            }   
        }
    }

    var tb1 = document.getElementById("T_Q070_1");
//    var tb2 = document.getElementById("T_Q070_2");
    if (_SelCboCount == 2) {
        LockedAllCheckBox(tb1, true);
//        LockedAllCheckBox(tb2, true);
        for (i = 0; i < _SelArray.length; i++) {
            var row = _SelArray[i];
            if (parseInt(_SelMinVal) > parseInt(row.cells[row.cells.length - 2].innerText))
                _SelMinVal = row.cells[row.cells.length - 2].innerText;
        }
        $('#txtPQTY').val(_SelMinVal);
    }
    else {
        LockedAllCheckBox(tb1, false);
//        LockedAllCheckBox(tb2, false);
    }
}
//lock checkbox
function LockedAllCheckBox(tbl,isLock) {
    for (i = 0; i < tbl.rows.length; i++) {
        for (j = 0; j < tbl.rows[i].cells.length; j++) {
            var object = tbl.rows[i].cells[j].getElementsByTagName("INPUT");
            if (object != null) {
                for (k = 0; k < object.length; k++) {
                    if (object[k].type == "checkbox" && object[k].checked == false) {
                        //假如選擇權或期貨口數為0時,disabled勾選
                        if (parseInt(tbl.rows[i].cells[tbl.rows[i].cells.length - 2].innerText) == 0) {
                            object[k].disabled = true;
                        }
                        else {
                            object[k].disabled = isLock;
                        }
                    }
                }
            }
        }
    }   
}

//單式部位合計顯示
function Render_div_070010(UnLiquidationMain) {
    //(選擇權)
    var _blood = '<table class="style_100" cellspacing=\'0\'  id="T_Q070_1" width="100%" style="border-top-width:0px">';

    try {
        $.each(eval(UnLiquidationMain), function(key, item) {
            if (item.productKind == "2") {
                _blood += '<tr>';

                if (item.ProductId == undefined) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:50%\'>&nbsp;</td>'; }
                else if (item.ProductId.length < 1) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:50%\'>&nbsp;</td>'; }
                else {
                    _blood += '<td class=\'style_102 contentStyle\' style=\'width:50%\'>' + item.productName +
                     '<span id=\'span_ProductKind\' style=\'display:none\'>' + item.productKind +
                 '</span><span id=\'span_ProductId\' style=\'display:none\'>' + item.ProductId +
                 '</span></td>';
                }

                if (item.callput == undefined) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:15%\'>&nbsp;</td>'; }
                else if (item.callput.length < 1) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:15%\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\' style=\'width:15%\'>' + item.callput + '</td>'; }

                if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:15%\'>&nbsp;</td>'; }
                else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\' style=\'width:15%\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\' style=\'width:15%\'>' + item.BS + '</td>'; }

                if (item.TotalOTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\' style=\'width:10%\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_101 contentStyle\' style=\'width:10%\'>' + item.TotalOTQTY + '</td>'; }
                _blood += '<td class=\'style_101 contentStyle\' style=\'width:10%\'><input id="cbo' + item.ProductId + '" type="checkbox" onclick="CheckBoxRow(this);" /></td>';
                _blood += '</tr>';
            }
        });
    }
    catch (mExc) { }
    _blood += '</table>';
    $('#div_Q0701').html(_blood);


//    //期貨
//    _blood = '';
//    _blood = '<table class=\'style_100\' cellspacing=0 id="T_Q070_2">';
//    _blood += "<tr>";
//    _blood += "<th class='style_ProductId'>商品內容</th>";
//    _blood += "<th class='style_BS'>買賣別</th>";
//    _blood += "<th class='style_OTQTY'>口數</th>";
//    _blood += "<th class=''>選取</th>";    
//    _blood += "</tr>";
//    try {
//        $.each(eval(UnLiquidationMain), function(key, item) {
//            if (item.productKind == "1") {
//                _blood += '<tr>';
//                if (item.ProductId == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//                else if (item.ProductId.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//                else {
//                    _blood += '<td class=\'style_102 contentStyle\'>' + item.ProductId +
//                 '<span id=\'span_ProductKind\' style=\'display:none\'>' + item.productKind +
//                 '</span><span id=\'span_ProductId\' style=\'display:none\'>' + item.ProductId +
//                 '</span></td>';
//                }

//                if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//                else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS + '</td>'; }

//                //_blood += '<td class=\'style_101\'>' + item.OTQTY + '</td>';
//                if (item.TotalOTQTY == undefined) { _blood += '<td class=\'style_101\'>&nbsp;</td>'; }
//                else { _blood += '<td class=\'style_101\'>' + item.TotalOTQTY + '</td>'; }
//                _blood += '<td class=\'style_101\'><input id="cbo' + item.ProductId + '" type="checkbox" onclick="CheckBoxRow(this);" /></td>';
//                _blood += '</tr>';
//            }
//        });
//    } catch (mExc) { }
//    _blood += '</table>';
//    $('#div_Q0702').html(_blood);


}


//選擇組合
function SelectProduct() {
    if (jQuery.trim($('#txtPQTY').val()) == "" || jQuery.trim($('#txtPQTY').val()) == "0")
        return;
    _idx = _idx + 1;
    _Products[_idx] = _SelArray;
    _ProductsQTY[_idx] = $('#txtPQTY').val();

    $("#btnOK").attr("disabled", false);

    //組合
    _blood = '';
    _blood = '<table class=\'style_100\' cellspacing=0 id="T_Q070_3" width="100%" style="border-top-width:0px">';

    for (rsIdx = 0; rsIdx < _Products.length; rsIdx++) {

        _blood += '<tr>';
        _blood += '<td class=\'style_102 contentStyle\' style=\'width:10%\'>' + (rsIdx + 1).toString() + '</td>';

        var curRS = _Products[rsIdx];
        var tmp1 = "";
        var tmp2 = "";
        var tmp3 = "";
        for (i = 0; i < curRS.length; i++) {
            var row = curRS[i];

            tmp1 += row.cells[0].innerHTML + '<br/>';
            if (row.cells.length == 5) {
                tmp2 += row.cells[1].innerHTML + '<br/>';
            }
            else {
                tmp2 += '<br/>';
            }
            if (row.cells.length == 5) {
                tmp3 += row.cells[2].innerHTML + '<br/>';
            }
            else {
                tmp3 += '<br/>';
            }
        }
        _blood += '<td class=\'style_102 contentStyle\' style=\width:48%\'>' + tmp1.substring(0, tmp1.length - 5) + '</td>';
        _blood += '<td class=\'style_102 contentStyle\' style=\'width:10%\'>' + tmp2.substring(0, tmp2.length - 5) + '</td>';
         _blood += '<td class=\'style_102 contentStyle\' style=\'width:12%\'>' + tmp3.substring(0, tmp3.length - 5) + '</td>';
        _blood += '<td class=\'style_102 contentStyle\' style=\'width:10%\'>' + _ProductsQTY[rsIdx] + '</td>';
        _blood += '<td class=\'style_102 contentStyle\' style=\'width:10%\'><input id="cbo' + _idx.toString() + '" type="checkbox" /></td>';
        _blood += '</tr>';
    }
    _blood += '</table>';
    $('#div_Q0703').html(_blood);

    for (i = 0; i < _SelArray.length; i++) {
        var row = _SelArray[i];
        var object = row.cells[row.cells.length - 2];
        if (object != null) {
            var pQty = $('#txtPQTY').val();
            object.innerText = parseInt(object.innerText) - parseInt(pQty);
        }

    }

    ResetLeftTb();
}
//取消組合
function CancelProduct() {

    var tb1 = document.getElementById("T_Q070_1");
//    var tb2 = document.getElementById("T_Q070_2");
    var tb3 = document.getElementById("T_Q070_3");

    if (tb3 == null)
        return;
    
    var SelIdx = 0;
    var SelChecked = new Array();
    
    for (i = 0; i < tb3.rows.length; i++) {
        var row = tb3.rows[i];
        var tb3_cell_2 = row.cells[1].innerText.split('\n');
        var tb3_cell_n = row.cells[row.cells.length-2].innerText;
        var tb3_cell_4 = row.cells[3].innerText.split('\n');
    
        var object = row.cells[row.cells.length - 1].getElementsByTagName("INPUT");
        if (object != null) {
            for (j = 0; j < object.length; j++) {
                if (object[j].type == "checkbox") {
                    if (object[j].checked) {
                        //tb1
                        for (k = 0; k < tb1.rows.length; k++) {
                            var row2 = tb1.rows[k];
                            var cell_1 = row2.cells[0].innerText;
                            var cell_n = row2.cells[row2.cells.length - 2].innerText;
                             var cell_3 = row2.cells[2].innerText;
                            for (idx = 0; idx < tb3_cell_2.length; idx++) {
                                if (jQuery.trim(tb3_cell_2[idx]) == jQuery.trim(cell_1) && jQuery.trim(tb3_cell_4[idx])== jQuery.trim(cell_3)) {
                                    row2.cells[row2.cells.length - 2].innerText = parseInt(cell_n) + parseInt(tb3_cell_n);
                                }
                            }
                        }
                        //tb2
//                        for (m = 1; m < tb2.rows.length; m++) {
//                            var row3 = tb2.rows[m];
//                            var cell_1 = row3.cells[0].innerText;
//                            var cell_n = row3.cells[row3.cells.length - 2].innerText;
//                            for (idx = 0; idx < tb3_cell_2.length; idx++) {
//                                if (jQuery.trim(tb3_cell_2[idx]) == jQuery.trim(cell_1)) {
//                                    row3.cells[row3.cells.length - 2].innerText = parseInt(cell_n) + parseInt(tb3_cell_n);
//                                }
//                            }
//                        }                        
               
                        if ((i + 1) < tb3.rows.length) {
                            tb3.rows[i + 1].cells[0].innerText = parseInt(tb3.rows[i + 1].cells[0].innerText) - 1;
                        }
                      
                        SelChecked[SelIdx]=i;
                        SelIdx=SelIdx+1;
                        _Products.remove(row);
                        _ProductsQTY.remove(tb3_cell_n);
                        _idx = _idx - 1;
                    }
                }
            }
        }
    }
    for (z = SelChecked.length-1; z >=0; z--) {
        tb3.deleteRow(SelChecked[z]);
    }
    if (tb3.rows.length == 0)
        $("#btnOK").attr("disabled", true);
    ResetLeftTb();
}

//組合確認
$(document).ready(function() {
    $('#btnOK').click(function(event) {
        if(_disabledAction){
            alert('已送出申請，請勿重複執行 !!');
            return;
        }
     $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        setTimeout('CompleteComposition()', 999);
    })
});
//了結
$(document).ready(function() {
    $('#btnNET').click(function(event) {
        if(_disabledAction){
            alert('已送出申請，請勿重複執行 !!');
            return;
        }
       $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        setTimeout('NetAll()', 999);
    })
});
//全組
$(document).ready(function() {
    $('#btnCompleteAll').click(function(event) {
        if(_disabledAction){
            alert('已送出申請，請勿重複執行 !!');
            return;
        }
       $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        setTimeout('CompleteAll()', 999);
    })
});
function CompleteAll() {

     
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var m_WhereParm = {  ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam };
    var m_objJSON = fh_CallWebMethod("MOBQ070", "QueryMOBQ070_a?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
      if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else {
           if (m_objJSON.MOBCombineResult == undefined) return;
        Render_div_single_message(m_objJSON.MOBCombineResult);
        $('#div_message').show();
        LockBlock(true);
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

      $('#DivBlock').unblock();
//       $('#btnCompleteAll').attr("disabled", true);
//       setTimeout("EnableAction('btnCompleteAll')", _TIMEOUT*1000);
//         _disabledAction=true;
//        setTimeout("EnableAction()", _TIMEOUT*1000);
}
function CompleteComposition() {

    var rsStr = "";
    var rsDetail = "";

    //明細表
    //先依交易日期由小到大排序，再依委託單號由小到大排序
    var filtered = _UnLiquidationDetail.sort(function(a, b) {
        if (a.tradedate > b.tradedate)
            return 1;
        else
            return -1;
    }).sort(function(a, b) {
        if (a.orderNo > b.orderNo)
            return 1;
        else
            return -1;
    });
    
    for (rs = 0; rs < _Products.length; rs++) {
        for (rsc = 0; rsc < _Products[rs].length; rsc++) {

            var productName = _Products[rs][rsc].cells[0].firstChild.nodeValue;
            var CP = _Products[rs][rsc].cells[1].innerText;
            var BS = _Products[rs][rsc].cells[2].innerText;
            var keys = _Products[rs][rsc].cells[0].getElementsByTagName("SPAN");
            if (keys.length == 2) {
                //統計主表
                var productKind = keys.span_ProductKind.innerText;
                var productId = keys.span_ProductId.innerText;
                var productQTY = _ProductsQTY[rs];

                try {
                    $.each(eval(filtered), function(key, item) {

                        if (item.productKind == productKind && item.productId == productId && parseInt(item.OTQTY) > 0&& item.BS==BS ) {


                            if (parseInt(productQTY) == 0)
                                return false;

                            var qty = 0;
                            if (parseInt(item.OTQTY )>= parseInt(productQTY)) {
                                qty = productQTY;
                                item.OTQTY = parseInt(item.OTQTY) -parseInt( productQTY); //明細剩餘口數
                                productQTY = 0; //組合剩餘口數                                           
                            }
                            else if (parseInt(item.OTQTY) < parseInt(productQTY)) {
                                qty = item.OTQTY;
                                productQTY = parseInt(productQTY) - parseInt(item.OTQTY); //組合剩餘口數
                                item.OTQTY = 0; //明細剩餘口數
                            }
                          
                            if(item.matchseq.length==2)
                            {
                                   rsDetail += "{\"rs\":\"" + rs + "\",\"rsc\":\"" + rsc + "\",\"productKind\":\"" + item.productKind + "\", \"productId\":\"" + item.productId
                                    + "\", \"productQTY\":\"" +_ProductsQTY[rs]+ "\", \"productName\":\"" + productName
                                     + "\", \"CP\":\"" + CP + "\", \"COMYM\":\"" + item.COMYM + "\", \"stkprc\":\"" + item.stkprc + "\", \"comno\":\"" + item.COMNO + "\", \"BS\":\"" + BS 
                                    + "\",\"tradedate\":\"" + item.tradedate
                                    + "\", \"orderNo\":\"" + item.orderNo   + item.matchseq
                                            + "\", \"QTY\":\"" + qty + "\"},";
                            }
                            else
                            {
                                   rsDetail += "{\"rs\":\"" + rs + "\",\"rsc\":\"" + rsc + "\",\"productKind\":\"" + item.productKind + "\", \"productId\":\"" + item.productId
                                    + "\", \"productQTY\":\"" +_ProductsQTY[rs]+ "\", \"productName\":\"" + productName
                                     + "\", \"CP\":\"" + CP + "\", \"COMYM\":\"" + item.COMYM + "\", \"stkprc\":\"" + item.stkprc + "\", \"comno\":\"" + item.COMNO + "\", \"BS\":\"" + BS 
                                    + "\",\"tradedate\":\"" + item.tradedate
                                    + "\", \"orderNo\":\"" + item.orderNo + "1" + item.matchseq
                                            + "\", \"QTY\":\"" + qty + "\"},";
                            }
                            
                     
                        }
                    });

                }
                catch (mExc) { }                
            }
        }
    }

    rsDetail = "[" + rsDetail.substring(0, rsDetail.length - 1) + "]";

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var m_WhereParm = { rsCount: _Products.length, tbDetail: rsDetail, ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam };
    var m_objJSON = fh_CallWebMethod("MOBQ070", "QueryMOBQ070?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
    if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else {

           if (m_objJSON.MOBCombineResult == undefined) return;
        Render_div_message(m_objJSON.MOBCombineResult);
        $('#div_message').show();
        LockBlock(true);
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

      $('#DivBlock').unblock();
        //$('#btnOK').attr("disabled", true);
      //setTimeout("EnableAction('btnOK')", _TIMEOUT*1000);
//        _disabledAction=true;
//        setTimeout("EnableAction()", _TIMEOUT*1000);
}
function NetAll() {
    
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var m_WhereParm = {  ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), PARAM: tParam };
    var m_objJSON = fh_CallWebMethod("MOBQ070", "QueryMOBQ070_b?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {
      if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
        Render_div_single_message(m_objJSON.MOBCombineResult);
        $('#div_message').show();
        LockBlock(true);
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

    $('#DivBlock').unblock();
//        $('#btnNET').attr("disabled", true);
//        setTimeout("EnableAction('btnNET')", _TIMEOUT*1000);
//         _disabledAction=true;
//        setTimeout("EnableAction()", _TIMEOUT*1000);
}

//function EnableAction(o)
//{
//   $("#"+o).attr("disabled", false);
//}

function EnableAction()
{
   _disabledAction=false;
}

function Render_div_message(MOBCombineResult) {

    _blood = '<table class=\'style_100 tableStyle\' cellspacing=0>';

    _blood += '<tr>';
    _blood += '<td>序號</td>';
    _blood += '<td>流水號</td>';
    _blood += '<td>商品內容</td>';
    _blood += '<td>C/P</td>';
    _blood += '<td>B/S</td>';
    _blood += '<td>口數</td>';
    _blood += '<td>申請狀態</td>';
    _blood += '</tr>';

    try {
        $.each(eval(MOBCombineResult), function(key, item) {

                _blood += '<tr>';

                if (item.SN == undefined) { _blood += '<td class=\'style_101\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_101 contentStyle\'>' + item.SN + '</td>'; }

                if (item.SEQNO == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.SEQNO + '</td>'; }

                if (item.PRODUCT == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.PRODUCT + '</td>'; }


                if (item.CP == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.CP + '</td>'; }

                if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS + '</td>'; }

                if (item.QTY == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.QTY + '</td>'; }
                
                if (item.STATUS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.STATUS + '</td>'; }

                _blood += '</tr>';

        });
    }
    catch (mExc) { }
    _blood += '</table>';
    $('#div_content').html(_blood);

}
function Render_div_single_message(MOBCombineResult) {

    _blood = '<table class=\'style_100\' cellspacing=0>';
 

    try {
        $.each(eval(MOBCombineResult), function(key, item) {

                _blood += '<tr>';

              
                if (item.PRODUCT == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.PRODUCT + '</td>'; }

 
                
                if (item.STATUS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_102 contentStyle\'>' + item.STATUS + '</td>'; }

                _blood += '</tr>';

        });
    }
    catch (mExc) { }
    _blood += '</table>';
    $('#div_content').html(_blood);

}
function LockBlock(isLock) {
    $('#txtPQTY').attr("disabled", isLock);
    $('#btnUpdate').attr("disabled", isLock);
    $('#btnReset').attr("disabled", isLock);
    $("#btnOK").attr("disabled", isLock);
    $("#btnCancel").attr("disabled", isLock);
    $("#btnRight").attr("disabled", isLock);
    $("#btnLeft").attr("disabled", isLock);
    $("#DivBlock").attr("disabled", isLock);
}

if (!Array.prototype.filter) {
    Array.prototype.filter = function(fun /*, thisp*/) {
        var len = this.length;
        if (typeof fun != "function")
            throw new TypeError();

        var res = new Array();
        var thisp = arguments[1];
        for (var i = 0; i < len; i++) {
            if (i in this) {
                var val = this[i]; // in case fun mutates this
                if (fun.call(thisp, val, i, this))
                    res.push(val);
            }
        }

        return res;
    };
}


