﻿$(document).ready(init);
function init() {
   
    $("#btnChangePassword").bind("click", btnChangePassword_Click);
 
}



function btnChangePassword_Click() {

    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(8)
    var COMPANY = $('#company').val();
    COMPANY = padRight(COMPANY, " ", 7);
    var ACTNO = $('#account').val();

    ACTNO = padRight(ACTNO, " ", 7);

    var OriPassoword = $('#txtOriPassoword').val();
    var NewPassoword = $('#txtNewPassoword').val();
    var ConfirmPassoword = $('#txtConfirmPassoword').val();
    if (OriPassoword.length == 0) {
        alert("請輸入密碼!"); return;
    }
    if (NewPassoword.length == 0) {
        alert("請輸入密碼!"); return;
    }
    if (ConfirmPassoword.length == 0) {
        alert("請輸入密碼!"); return;
    }

    if (NewPassoword.length <6 ) {
        alert("新密碼不可少於六個字元!"); return;
    }
    if (NewPassoword == OriPassoword) {
        alert("新設密碼不可與原密碼相同!"); return;
    }
    if (NewPassoword != ConfirmPassoword) {
        alert("新密碼與確認密碼不符!"); return;
    }
    var m_WhereParm = { company: COMPANY, actno: ACTNO, password: OriPassoword, changepassword: ConfirmPassoword, PARAM: tParam }
    var m_objJSON = fh_CallWebMethod("MOBQ130", "WS_ChangePassword?uri=" + tParam, m_WhereParm, false);
    if (m_objJSON != null) {

        if (m_objJSON.ErMsg != "") {
            fh_AlertMsg(m_objJSON.ErMsg);
        }
        else {
            if (m_objJSON.MSG != null && m_objJSON.MSG.length > 0) {


                if (m_objJSON.MSG[0].msg != null && m_objJSON.MSG[0].msg != undefined) {
                    if (m_objJSON.MSG[0].msg == "00000") {
                        $('#txtOriPassoword').val("");
                        $('#txtNewPassoword').val("");
                        $('#txtConfirmPassoword').val("");
                        alert("更改密碼成功");
                      
                        return true;
                    }
                    else if (m_objJSON.MSG[0].msg == "-1218")
                        alert("-1218 出金密碼錯誤");
                    else if (m_objJSON.MSG[0].msg == "-1221")
                        alert("-1221 出金密碼已被鎖定");
                    else if (m_objJSON.MSG[0].msg == "-1226")
                        alert("-1226 網路出金功能已暫停");
                    else if (m_objJSON.MSG[0].msg == "-1219") {


                    }
                    else
                        alert("更改密碼失敗");

                }
                else
                    alert("更改密碼失敗");

            }
            else { alert('更改密碼失敗'); }
        }

    }

}