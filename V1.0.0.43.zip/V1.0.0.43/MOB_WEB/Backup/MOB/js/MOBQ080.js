﻿function RemoveArray(array, attachId) {
    for (var i = 0, n = 0; i < array.length; i++) {
        if (array[i] != attachId) {
            array[n++] = array[i]
        }
    }
    array.length -= 1;
}

Array.prototype.remove = function(obj) {
    return RemoveArray(this, obj);
};

var _dtHistory;

function GetServerDataAjax_MOBQ080() {


    var ret = false;
    var now = new Date();
 
    $('#lblQueryTime').html(showLocale(now));
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var strProductKind;
    if ($('#FullRadio').attr('checked')) { strProductKind = $('#FullRadio').val(); }
    if ($('#FuturesRadio').attr('checked')) { strProductKind = $('#FuturesRadio').val(); }
    if ($('#OptionsRadio').attr('checked')) { strProductKind = $('#OptionsRadio').val(); }

    var acctId = $('#account').attr('value');
    
    var SortExpress = $('#ddlSortExpression').val() + "," + $('#ddlSortDirection').val();
    var m_WhereParm = { productKind: strProductKind, startDate: $('#StartDate').val(), strSort: SortExpress, endDate: $('#EndDate').val(), ACCT_ID: acctId, COMP_ID: $('#company').attr('value'), PARAM: tParam }

    var m_objJSON = fh_CallWebMethod("MOBQ080", "QueryMOBQ080?uri=" + tParam, m_WhereParm, false);

    if (m_objJSON != null) {
        if (m_objJSON.dtHistory == undefined) return;
          _dtHistory = m_objJSON.dtHistory;

         if(m_objJSON.ErMsg!="")
            {
            fh_AlertMsg(m_objJSON.ErMsg);
            }
            else
            {
              
                 
      
            //產生查詢結果
         ret=   Render_div_QueryList(); 
            }
    }
    //顯示查無資料
    if (_dtHistory.length == 0) {
        $('#div_QueryList').html("");
        $('#div_result').show();
    }
    else
    { $('#div_result').hide(); }
    //顯示總筆數
    $('#lblTotalCount').html(_dtHistory.length);
    //顯示總頁數
    var pageCount = Math.ceil(_dtHistory.length / 10);
    $('#lblPageCount').html(pageCount.toString());
    //顯示目前頁數
    $('#lblCurrentPage').html("1");

    //產生下拉的頁數
    var Lists = new Array();
    for (row = 0; row <= pageCount - 1; row++) {
        var itemText = (row + 1).toString();
        Lists[row] = itemText;
    }
    $("#ddlCurrentPage > option").remove();
    $.each(Lists, function(val, text) {
        $('#ddlCurrentPage').append(
            $('<option></option>').val(val).html(text)
        );
    });

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);
    return ret;
  //  $.unblockUI();
  //   $('#DivBlock').unblock();
}

function Render_div_QueryList() {
    var ret = false;
    var _blood = '<table class=\'titleStyle tableStyle\'   id="table_QueryList">';
    _blood += "<tr>";
    _blood += "<th class=''>委託時間</th>";
    _blood += "<th class=''>委託單號<br/>原始單號</th>";
    _blood += "<th class=''>買賣</th>";
    _blood += "<th class=''>商品內容</th>";
    _blood += "<th class=''>委託條件</th>";
    _blood += "<th class=''>委託價</th>";
    _blood += "<th class=''>原委託</th>";
    _blood += "<th class=''>已成交</th>";
    _blood += "<th class=''>總取消</th>";
    _blood += "<th class=''>委託來源</th>";
    _blood += "<th class=''>交易日期</th>";
    _blood += "<th class=''>狀態</th>";
    _blood += "<th class=''>當沖</th>";
    _blood += "</tr>";

    var dataCount = 0;

    try {

        $.each(eval(_dtHistory), function(key, item) {
            ret = true;
            dataCount = dataCount + 1;

            //分頁依起始與結束的索引位置
            if (dataCount >= _startPos && dataCount <= _endPos) {
                _blood += "<tr>";
                _blood += "<td class='style_102 contentStyle'>" + item.ORDTIME + "</td>";
                _blood += "<td class='style_102 contentStyle'>" + item.ORDNO + "</td>";
                _blood += "<td class='style_102 contentStyle'>" + item.PS + "</td>";

                var productName = "";
                if (item.ProductName != undefined) { productName = item.ProductName; }
                _blood += "<td class='style_102 contentStyle'>" + productName + "</td>";
                _blood += "<td class='style_102 contentStyle'>" + item.OPENS + "</td>";
                _blood += "<td class='style_101 contentStyle'>" + item.UTPRICE1 + "</td>";
                _blood += "<td class='style_101 contentStyle'>" + item.ORDQTY + "</td>";
                _blood += "<td class='style_101 contentStyle'>" + item.TRDQTY + "</td>";
                _blood += "<td class='style_101 contentStyle'>" + item.TotalCancled + "</td>";
                _blood += "<td class='style_102 contentStyle'>" + item.ENTTYPE + "</td>";
                _blood += "<td class='style_102 contentStyle'>" + item.ORDDT + "</td>";
                _blood += "<td class='style_102 contentStyle'>" + item.msgdata + "</td>";
                _blood += "<td class='style_102 contentStyle'>" + item.DTOVER + "</td>";
                _blood += "</tr>";
            }

        });
    }
    catch (mExc) { }
    _blood += '</table>';
    $('#div_QueryList').html(_blood);
    return ret;
}
//重新整理
$(document).ready(function() {
    $('#btnReflash').click(function(event) {
        window.location.reload(true);
    })
});

$(document).ready(function() {
    $('#div_result').hide();
});

var _pageSize = 10;
var _startPos = 1;
var _endPos = 10;
//下拉頁數改變時
$(document).ready(function() {
    $('#ddlCurrentPage').change(
    function() {
       // $.blockUI({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
       
       // $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        _startPos = (parseInt($('#ddlCurrentPage option:selected').text()) - 1) * 10 + 1;
        _endPos = parseInt($('#ddlCurrentPage option:selected').text()) * 10;
        Render_div_QueryList();
      $('#lblCurrentPage').html($('#ddlCurrentPage option:selected').text());
     //   $.unblockUI();
    }
)
});

$(document).ready(function() {
  $('#div_result').hide();
});

$(document).ready(function() {
    $('#btnExport').click(function(event) {

        if (!GetServerDataAjax_MOBQ080()) {
            alert("查無資料!"); return;
        }

        var SortExpress = $('#ddlSortExpression').val() + "," + $('#ddlSortDirection').val();
        var acctId = $('#account').attr('value');
        var date1 = $('#StartDate').val();
        var date2 = $('#EndDate').val();
        var comid = $('#company').attr('value');

        var strProductKind;
        if ($('#FullRadio').attr('checked')) { strProductKind = $('#FullRadio').val(); }
        if ($('#FuturesRadio').attr('checked')) { strProductKind = $('#FuturesRadio').val(); }
        if ($('#OptionsRadio').attr('checked')) { strProductKind = $('#OptionsRadio').val(); }

        var url = "PARAM=MOBQ080a.aspx&pk=" + strProductKind + "&date1=" + date1 + "&date2=" + date2 + "&sort=" + SortExpress + "&accid=" + acctId + "&comid=" + comid;
        url = encodeURI(url); //document.location.protocol+"//"+document.location.host +"/
        //    window.open("MOBQ080a.aspx?" + url,'_blank');
        window.location.href = "MOBQ080a.aspx?" + url;
        return false;
    })
});


$(document).ready(function() {
$('#btnSearch').click(function(event) {
     //檢查日期起訖
        var objStartDate = $('#StartDate').datepicker("getDate");
        var objEndDate = $('#EndDate').datepicker("getDate");
        if (objStartDate == null) {
            alert('起始日期需要輸入');
            
            return;
        }
        if (objEndDate == null) {
            alert('結束日期需要輸入');
            
            return;
        }
        if (objStartDate != null & objEndDate != null) {
            if (objStartDate > objEndDate) {
                alert('起始日期不可大於結束日期');
              
                return;
            }
        }

        var now = new Date();

        var month=Math.abs( now-objStartDate )/(1000*60*60*24*30); 
        if (month>6) {
            alert('最多往前查6個月!');
      
            $('#StartDate').focus();
            return;
        } 
         var day=(objEndDate-objStartDate )/(1000*60*60*24); 
         if (day>31 ) {
            alert('查詢區間最多1個月!');
           
            $('#StartDate').focus();
            return;
        } 
              
     //   $.blockUI({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
     // $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        setTimeout('GetServerDataAjax_MOBQ080()', 999);
        _startPos = 1;
        _endPos = 10;
    })
});

$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#StartDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#EndDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});


$(document).ready(function() {
    $('#EndDate').focus(function() {
        $('#EndDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#EndDate').keyup(function() {
    //        $('#EndDate').val('');
    //    });
    $('#EndDate').change(function() {
        checkDate(this);
    });
    $('#StartDate').focus(function() {
        $('#StartDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#StartDate').keyup(function() {
    //        $('#StartDate').val('');
    //    });
    $('#StartDate').change(function() {
        checkDate(this);
    });
});


function showLocale(objD) {
    var str, colorhead, colorfoot;
    var yy = objD.getYear();
    if (yy < 1900) yy = yy + 1900;
    var MM = objD.getMonth() + 1;
    if (MM < 10) MM = '0' + MM;
    var dd = objD.getDate();
    if (dd < 10) dd = '0' + dd;
    var hh = objD.getHours();
    if (hh < 10) hh = '0' + hh;
    var mm = objD.getMinutes();
    if (mm < 10) mm = '0' + mm;
    var ss = objD.getSeconds();
    if (ss < 10) ss = '0' + ss;
    var ww = objD.getDay();
    if (ww == 0) colorhead = "<font color=\"#FF0000\">";
    if (ww > 0 && ww < 6) colorhead = "<font color=\"#373737\">";
    if (ww == 6) colorhead = "<font color=\"#008000\">";
    if (ww == 0) ww = "星期日";
    if (ww == 1) ww = "星期一";
    if (ww == 2) ww = "星期二";
    if (ww == 3) ww = "星期三";
    if (ww == 4) ww = "星期四";
    if (ww == 5) ww = "星期五";
    if (ww == 6) ww = "星期六";
    colorfoot = "</font>"
    str = colorhead + yy + "-" + MM + "-" + dd + " " + hh + ":" + mm + ":" + ss + "  " + ww + colorfoot;
    return (str);
} 