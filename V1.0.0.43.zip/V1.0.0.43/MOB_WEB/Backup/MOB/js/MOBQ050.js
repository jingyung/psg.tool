﻿$(document).ready(init);
function init() {
    $("#btnMonth1").bind("click", btnMonth_Click);
    $("#btnMonth2").bind("click", btnMonth_Click);
    $("#btnMonth3").bind("click", btnMonth_Click);
    $("#btnMonth4").bind("click", btnMonth_Click);
    $("#btnMonth5").bind("click", btnMonth_Click);
    $("#btnMonth6").bind("click", btnMonth_Click);
 


}
function btnMonth_Click(e) {

    $('#StartDate').val(e.srcElement.value + '/' + '01')
  
    var year = e.srcElement.value.split('/')[0];
    var month = e.srcElement.value.split('/')[1];
    var time = new Date(year, month, 0);
    var date = time.getDate();
    $('#EndDate').val(e.srcElement.value + '/' + date)
    GetServerDataAjax_MOBQ050();

}




function GetServerDataAjax_MOBQ050() {
    //檢查日期起訖
    var ret = false;
    var m_Param;
    m_Param = { SourceType: 'DDSC', company: $('#company').val(), account: $('#account').val(), begin_date: $('#StartDate').val(), end_date: $('#EndDate').val(), currency: $('#Select1').attr('value'), customerID: $('#account').val() };
    var m_objJSON = fh_CallWebMethod("MOBQ050", "QueryMOBQ050", m_Param, false);
    
    if (m_objJSON != null) {
      if(m_objJSON.ErMsg!="")
            {
                fh_AlertMsg(m_objJSON.ErMsg);
            }
            else{
               var _blood ='';
//                    var _blood = '<table class=\'style_100\' cellpadding="0" cellspacing="0" border="0" id="TQ050">';
//                    
//                    _blood += '<thead>';
//                    _blood += "<tr>";
//                    _blood += "<th class='style_TDDT'>日期</th>";
//                    _blood += "<th class='style_TDDT'>帳戶權益數</th>";
//                    _blood += "<th class='style_TDDT'>清算權益數</th>";
//               
//                
//                    _blood += "<th class='style_TDDT'>期貨平倉損益</th>";
//                    _blood += "<th class='style_TDDT'>期貨未平倉損益</th>";
//                    _blood += "<th class='style_TDDT'>出入金</th>"
//                    _blood += "<th class='style_OP_TMPAB'>選擇權平倉損益</th>";
//                    _blood += "<th class='style_OP_PROLOS'>選擇權未平倉損益</th>";
//                    _blood += "<th class='style_OP_TMPAB'>買方權利金市值</th>";
//                    _blood += "<th class='style_OP_PROLOS'>賣方權利金市值</th>";
//                    _blood += "<th class='style_TDDT'>交易稅</th>";
//                    _blood += "<th class='style_TDDT'>手續費</th>";
//                    _blood += "</tr>";
//                    _blood += '</thead>';

                    _blood += '<tbody>';
                    try {
                        if (m_objJSON.HM == undefined) return;
                        $.each(eval(m_objJSON.HM), function(key, item) {
                        ret = true;
                            _blood += '<tr>';
                            //日期
                            if (item.TDDT == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                            else if (item.TDDT.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_103 contentStyle">' + item.TDDT + '</td>'; }
//帳戶權益數
                            if (item.Margin == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else {
                                _blood += '<td class="style_101 contentStyle">' + item.Margin + '</td>';
                            }
        //清算權益數            
                            if (item.ClearMargin == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else {
                                _blood += '<td class="style_101 contentStyle">' + item.ClearMargin + '</td>';
                            }
                            
                                                        //出入金
                            if (item.DWAMT == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else {
                                _blood += '<td class="style_101 contentStyle">' + item.DWAMT + '</td>';
                            }

//期貨平倉損益
                            if (item.TMPAB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else {
                                _blood += '<td class="style_101 contentStyle">' + item.TMPAB + '</td>';
                            }
                            //期貨未平倉損益
                            if (item.PROLOS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else {
                                _blood += '<td class="style_101 contentStyle">' + item.PROLOS + '</td>';
                            }

//選擇權平倉損益
                            if (item.OP_TMPAB == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else if (item.OP_TMPAB.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_101 contentStyle">' + item.OP_TMPAB + '</td>'; }
//選擇權未平倉損益
                            if (item.OP_PROLOS == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                            else if (item.OP_PROLOS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_101 contentStyle">' + item.OP_PROLOS + '</td>'; }
                            
                        if (item.FU1921 == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else if (item.FU1921.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_101 contentStyle">' + item.FU1921 + '</td>'; }
                            
                            
                            
//買方權利金市值
                            if (item.BPREMIUM == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else if (item.BPREMIUM.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_101 contentStyle">' + item.BPREMIUM + '</td>'; }
                            //賣方權利金市值
                            if (item.SPREMIUM == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else if (item.SPREMIUM.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_101 contentStyle">' + item.SPREMIUM + '</td>'; }
                            
//交易稅
   if (item.tax == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else if (item.tax.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_101 contentStyle">' + item.tax + '</td>'; }


//手續費
                         
                            if (item.charge == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else if (item.charge.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                            else { _blood += '<td  class="style_101 contentStyle">' + item.charge + '</td>'; }

                            _blood += '</tr>';
                            
                        });
                    } catch (mExc) { }
                    _blood += '</tbody>';

                    //_blood += '</table>';
                    
                    var systime="";
                    //資料更新日期
                    try {
                        if (m_objJSON.HM[0].SYSDATE != null &&m_objJSON.HM[0].SYSDATE != undefined)
                         { systime = m_objJSON.HM[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (m_objJSON.HM[0].SYSTIME != null && m_objJSON.HM[0].SYSTIME != undefined) 
                        { systime+=" " +m_objJSON.HM[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);
                    
                    //寫入DOM
                   // $('#div_Q050').html(_blood);
                    $('#TQ050').find('tbody').remove();
    $('#TQ050').append(_blood);
        }
    }
    //  $('#DivBlock').unblock();
    return ret;
}


$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#StartDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#EndDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
});

$(document).ready(function() {
    $('#EndDate').focus(function() {
        $('#EndDate').datepicker("show");
        $(this).blur(function() { });
    });
    //    $('#EndDate').keyup(function() {
    //        $('#EndDate').val('');
    //    });
    $('#EndDate').change(function() {
        checkDate(this);
    });
    $('#StartDate').focus(function() {
        $('#StartDate').datepicker("show");
        $(this).blur(function() { });
    });
//    $('#StartDate').keyup(function() {
//        $('#StartDate').val('');
    //    });
    $('#StartDate').change(function() {
        checkDate(this);
    });
});
$(document).ready(function() {
    $('#btnExport').click(function(event) {

        if (!checkdate()) {
            return;
        }
        if (!GetServerDataAjax_MOBQ050()) {
            alert("查無資料!"); return;
        }

        var acctId = $('#account').val();
        var date1 = $('#StartDate').val();
        var date2 = $('#EndDate').val();
        var comid = $('#company').val();
        var currency = $('#Select1').attr('value');


        var url = "PARAM=MOBQ050a.aspx&currency=" + currency + "&date1=" + date1 + "&date2=" + date2 + "&accid=" + acctId + "&comid=" + comid;
        url = encodeURI(url); //document.location.protocol+"//"+document.location.host +"/
        //     var win =window.open("MOBQ050a.aspx?" + url,'_blank' );

        window.location.href = "MOBQ050a.aspx?" + url;
        return false;
    })
});
function  checkdate()
{
    var objStartDate = $('#StartDate').datepicker("getDate");
    var objEndDate = $('#EndDate').datepicker("getDate");
    if (objStartDate == null) {
        alert('起始日期需要輸入');
        $('#DivBlock').unblock(); 
        return false ;
    }
    if (objEndDate == null) {
        alert('結束日期需要輸入');
        $('#DivBlock').unblock(); 
        return false;
    }
    if (objStartDate != null & objEndDate != null) {
        if (objStartDate > objEndDate) {
            alert('起始日期不可大於結束日期');
            $('#DivBlock').unblock(); 
            return false;
        }
    }
    var now = new Date();
    var month=Math.abs( now-objStartDate )/(1000*60*60*24*30); 
    if (month>6) {
        alert('最多往前查6個月!');
        $('#DivBlock').unblock();
        $('#StartDate').focus();
        return false;
    } 
    var day=(objEndDate-objStartDate )/(1000*60*60*24); 
    if (day>31 ) {
        alert('查詢區間最多1個月!');
        $('#DivBlock').unblock();
        $('#StartDate').focus();
        return false;
    }
    return true;
}
$(document).ready(function() {
    $('#Button1').click(
            function(event) {
                if(!checkdate())
                {
                    return;
                }
            //   $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
                //$('#DivBlock').block({ message: '<span>查詢中</span>' });
                setTimeout('GetServerDataAjax_MOBQ050()', 999);
                //
            }
            )
});

 