﻿function GetServerDataAjax_MOBQ041() {
    var m_WhereParm = { ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value') };
    var m_objJSON = fh_CallWebMethod("MOBQ041", "QueryMOBQ041", m_WhereParm, false);
    if (m_objJSON != null) 
    {
       if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
       }
       else
       {
            var _blood = '<table class=\'style_100\' cellpadding="0" cellspacing="0" border="0"  id="TQ041">';

            _blood += '<thead>';
            _blood += "<tr>";
            _blood += "<th class='style_multikind'>組合總類</th>";
            _blood += "<th class='style_product'>商品</th>";
            _blood += "<th class='style_currency'>買賣</th>";
            _blood += "<th class='style_realPrice'>留倉總數</th>";
            _blood += "<th class='style_realPrice'>即時價位</th>";
            _blood += "<th class='style_AvgMatchPrice'>平均成本</th>";
            _blood += "<th class='style_realPrice'>價差</th>";
            _blood += "<th class='style_RefTotalPL'>浮動損益</th>";
            _blood += "<th class='style_currency'>幣別</th>";
                 //added by samantha 20101013 增加複式各腳價位欄位
                _blood += "<th class='style_footMatchPrice'>複式各腳價位</th>";
    //        _blood += "<th></th>";
    //        _blood += "<th></th>";
    //        _blood += "<th></th>";
    //        _blood += "<th></th>";
    //        _blood += "<th></th>";
    //        _blood += "<th></th>";
            _blood += "</tr>";
            _blood += '</thead>';

            _blood += '<tbody>';
            try {
                if (m_objJSON.UnLiquidationMain == undefined) return;
                $.each(eval(m_objJSON.UnLiquidationMain), function(key, item) {
                    _blood += '<tr>';

                    if (item.MultiName == undefined) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else if (item.MultiName.length < 1) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103">' + item.MultiName + '</td>'; }

                    if (item.productName == undefined) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else if (item.productName.length < 1) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103">' + item.productName + '</td>'; }

                    if (item.multipleBS == undefined) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else if (item.multipleBS.length < 1) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103">' + item.multipleBS + '</td>'; }

                    if (item.TotalOTQTY == undefined) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else if (item.TotalOTQTY.length < 1) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103">' + item.TotalOTQTY + '</td>'; }

                    if (item.realPrice == undefined) { _blood += '<td  class="style_101">&nbsp;</td>'; }
                    else {
                        _blood += '<td class="style_101">' + item.realPrice + '</td>';
                    }

                    if (item.AvgMatchPrice == undefined) { _blood += '<td  class="style_101">&nbsp;</td>'; }
                    else {
                        _blood += '<td class="style_101">' + item.AvgMatchPrice + '</td>';
                    }

                    if (item.PriceDiff == undefined) { _blood += '<td  class="style_101">&nbsp;</td>'; }
                    else {
                        _blood += '<td class="style_101">' + item.PriceDiff + '</td>';
                    }

                    if (item.RefTotalPL == undefined) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else if (item.RefTotalPL.length < 1) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103">' + item.RefTotalPL + '</td>'; }

                    if (item.currency == undefined) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else if (item.currency.length < 1) { _blood += '<td  class="style_103">&nbsp;</td>'; }
                    else { _blood += '<td  class="style_103">' + item.currency + '</td>'; }
                    
                //added by samantha 20101013 增加複式各腳價位欄位
                if (item.footMatchPrice == undefined) { _blood += '<td class=\'style_103\'>&nbsp;</td>'; }
                else if (item.footMatchPrice.length < 1) { _blood += '<td class=\'style_103\'>&nbsp;</td>'; }
                else { _blood += '<td class=\'style_103\'>' + item.footMatchPrice.replace("\n","<br/>")  + '</td>'; }


                    _blood += '</tr>';
                });
            } catch (mExc) { }
            _blood += '</tbody>';
            
            _blood += '</table>';
            $('#div_Q041').html(_blood);
        }
    }
    $('#DivBlock').unblock(); 
}


$(document).ready(function() {
    $('#Button1').click(
            function(event) {
                $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
                //$('#DivBlock').block({ message: '<span>查詢中</span>' });
                setTimeout('GetServerDataAjax_MOBQ041()', 999);
                //
            }
            )
})


$(document).ready(function() {
// $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//                //$('#DivBlock').block({ message: '<span>查詢中</span>' });
//                setTimeout('GetServerDataAjax_MOBQ041()', 999);
GetServerDataAjax_MOBQ041();
})