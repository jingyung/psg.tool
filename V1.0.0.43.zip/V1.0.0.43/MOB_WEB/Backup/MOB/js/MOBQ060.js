﻿$(document).ready(init);
function init() {
    $("#btnMonth1").bind("click", btnMonth_Click);
    $("#btnMonth2").bind("click", btnMonth_Click);
    $("#btnMonth3").bind("click", btnMonth_Click);
    $("#btnMonth4").bind("click", btnMonth_Click);
    $("#btnMonth5").bind("click", btnMonth_Click);
    $("#btnMonth6").bind("click", btnMonth_Click);



}
function btnMonth_Click(e) {

    $('#StartDate').val(e.srcElement.value + '/' + '01')

    var year = e.srcElement.value.split('/')[0];
    var month = e.srcElement.value.split('/')[1];
    var time = new Date(year, month, 0);
    var date = time.getDate();
    $('#EndDate').val(e.srcElement.value + '/' + date)

    GetServerDataAjax_MOBQ060();

}


//可以輸入小數（純 javascript); 大於0的浮點數; e=觸發的DOM參考; pnumber=value
function ValidateNumber_2(e, pnumber) {
    if (!/^\d+[.]?\d*$/.test(pnumber)) {
        //e.value = /^\d+[.]?\d*/.exec(e.value);
        e.value = '';
        return false;
    }
    return true;
}



//判斷是否為數字
function IsNumber(value) {
    if (isNaN(value))
    { return false; }

    return true;
}


function GetServerDataAjax_MOBQ060() {
var ret=false;
    var m_WhereParm;
    var m_objJSON;
    //分支設定參數
    //分支呼叫web method
    if ($('#SummaryRadio').attr('checked')) {
        var _type;
        if ($('#HistoryChk').attr('checked')) { _type = 0; }
        else { _type = 1; }

        var _SourceType = 'DDSC';

        var _company = $('#company').attr('value');
        var _account = $('#account').attr('value');

        var _begin_date = $('#StartDate').val();
        var _end_date = $('#EndDate').val();

        var _currency = $('#SelectCurrency').attr('value');

        var _comtype = $('#SelectProduct').attr('value');

        var _comym = $('#SelectMonth').attr('value');

        var _min_price = $('#StrikePriceText1').attr('value');
        var _max_price = $('#StrikePriceText2').attr('value');
        
        var _CP = $('#SelectCP').attr('value');
       // if(_comtype!='1' ){  _CP='';      }
        m_WhereParm = { type: _type, SourceType: _SourceType,
            company: _company, account: _account,
            begin_date: _begin_date, end_date: _end_date,
            currency: _currency,
            comtype: _comtype,
            comym: _comym,
            min_price: _min_price, max_price: _max_price,
            CP: _CP
        }

        var m_objJSON = fh_CallWebMethod("MOBQ060", "QueryMOBQ060_getEquityCollect", m_WhereParm, false);

        if (m_objJSON != null) 
        { 
            if(m_objJSON.ErMsg!="") {

                if (m_objJSON.ErMsg != "無平倉資料") {
                    $('#T_Q060').find('tbody').remove();
                    fh_AlertMsg(m_objJSON.ErMsg);
                }
            }
            else {
                if (m_objJSON.Collect == undefined) return;
              ret  = Render_Collect(m_objJSON.Collect); }
        }
    }
    else if ($('#DetailsRadio').attr('checked')) {
        var _type;
        if ($('#HistoryChk').attr('checked')) { _type = 0; }
        else { _type = 1; }
        var _SourceType = 'DDSC';

        var _company = $('#company').attr('value');
        var _account = $('#account').attr('value');
        var _currency = $('#SelectCurrency').attr('value');
        var _begin_date = $('#StartDate').val();
        var _end_date = $('#EndDate').val();

        m_WhereParm = { type: _type, SourceType: _SourceType, company: _company, account: _account, begin_date: _begin_date, end_date: _end_date,currency:_currency }

        var m_objJSON = fh_CallWebMethod("MOBQ060", "QueryMOBQ060_getEquityDetail", m_WhereParm, false);

        if (m_objJSON != null)
        { 
            if(m_objJSON.ErMsg!="") {
                if (m_objJSON.ErMsg != "無平倉資料") {
                    $('#T_Q061').find('tbody').remove();
                    fh_AlertMsg(m_objJSON.ErMsg);
                }
            }
            else {
                if (m_objJSON.Details == undefined) return;
               ret=  Render_Details(m_objJSON.Details); }
        }
    }



   // $.unblockUI();
   return ret;
}

function Render_Collect(Collect) {

   var ret =false;
    
        var _blood ="";
//    var _blood = '<table class=\'style_100\' cellpadding="0" cellspacing="0" border="0" id="T_Q060">';

//    _blood += '<thead>';
//    _blood += "<tr>";
//    _blood += "<th class='OFFSETDATE'>平倉日期</th>";
//    _blood += "<th class='PRODUCTNAME' >商品代號</th>";
//    if (  $('#HistoryChk').attr('checked')) 
//    {
//        _blood += "<th class='ordtype' >類型</th>";
//    }
//    _blood += "<th class='OFFSETDATE' >平倉口數</th>";
//    if ( !$('#HistoryChk').attr('checked')) 
//    {
//        _blood += "<th class='OFFSETDATE' >放棄口數</th>";
//    }
//    _blood += "<th class='PL' >交易損益</th>";
//    _blood += "<th class='CURRENCY' >幣別</th>";
//    if ( $('#HistoryChk').attr('checked')) 
//    {
//        _blood += "<th class='OFFSETDATE' >手續費</th>";
//        _blood += "<th class='OFFSETDATE' >期交稅</th>";
//        _blood += "<th class='PL' >淨損益</th>";
//    }
//    //_blood += "<th ></th>";
//    _blood += "</tr>";
    //_blood += '</thead>';

    _blood += '<tbody>';
    try {
        $.each(eval(Collect), function(key, item) {
            ret = true;
            _blood += '<tr>';

            if (item.OFFSETDATE == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else if (item.OFFSETDATE.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_103 contentStyle">' + item.OFFSETDATE + '</td>'; }

            if (item.ProductName == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else if (item.ProductName.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_103 contentStyle">' + item.ProductName + '</td>'; }
            //            if (  $('#HistoryChk').attr('checked')) 
            //            {
            //                if (item.ordtype == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            //                else if (item.ordtype.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            //                else { _blood += '<td  class="style_103 contentStyle">' + item.ordtype + '</td>'; }

            //            }
            if (item.OFFSETQTY == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else if (item.OFFSETQTY.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_101 contentStyle">' + item.OFFSETQTY + '</td>'; }
            if (!$('#HistoryChk').attr('checked')) {
                if (item.GiveUp == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else if (item.GiveUp.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
                else { _blood += '<td  class="style_101 contentStyle">' + item.GiveUp + '</td>'; }
            }

            if (item.OSPRTLOS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else if (item.OSPRTLOS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_101 contentStyle">' + item.OSPRTLOS + '</td>'; }

            //            if (item.CURRENCY == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            //            else if (item.CURRENCY.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            //            else { _blood += '<td  class="style_103 contentStyle">' + item.CURRENCY + '</td>'; }

            //            if ($('#HistoryChk').attr('checked')) 
            //            {
            if (item.tax == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else {
                _blood += '<td class="style_101 contentStyle">' + item.tax + '</td>';
            }
            if (item.charge == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else {
                _blood += '<td class="style_101 contentStyle">' + item.charge + '</td>';
            }



            if (item.equity == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else {
                _blood += '<td class="style_101 contentStyle">' + item.equity + '</td>';
            }

            if ($('#HistoryChk').attr('checked')) {
                if (item.ordtype == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                else {
                    _blood += '<td class="style_103 contentStyle">' + item.ordtype + '</td>';
                }
            }
            //         }


            _blood += '</tr>';
        });
    } catch (mExc) { }
    _blood += '</tbody>';

   // _blood += '</table>';

    //寫入DOM
    //$('#div_Q060').html(_blood);
    $('#T_Q060').find('tbody').remove();
    $('#T_Q060').append(_blood);
    
        
                       var systime="";
                    //資料更新日期
                    try {
                        if (Collect[0].SYSDATE != null && Collect[0].SYSDATE != undefined)
                         { systime =  Collect[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (Collect[0].SYSTIME != null && Collect[0].SYSTIME != undefined) 
                        { systime+=" " +Collect[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);
                    return ret;   
}


function Render_Details(Details) {
    var ret = false;
    
 var _blood ="";
//    var _blood = '<table class=\'style_100\' cellpadding="0" cellspacing="0" border="0" id="T_Q060">';

//    _blood += '<thead>';
//    _blood += "<tr>";
//    _blood += "<th class='CURRENCY'>序號</th>";
//    _blood += "<th class='OFFSETDATE' >成交日期</th>";
//    _blood += "<th class='OFFSETDATE' >委託單號</th>";
//    _blood += "<th class='PRODUCTNAME' >商品代碼</th>";
//    _blood += "<th class='CURRENCY' >買賣</th>";
//    _blood += "<th class='OFFSETDATE' >成交價</th>";
//    _blood += "<th class='OFFSETDATE' >平倉量</th>";
//    _blood += "<th class='CURRENCY' >幣別</th>";
//    _blood += "<th class='OFFSETDATE' >平倉日期</th>";
//    _blood += "<th class='PL' >平倉損益</th>";
//    if ( $('#HistoryChk').attr('checked')) 
//     {
//    _blood += "<th class='OFFSETDATE' >手續費</th>";
//    _blood += "<th class='OFFSETDATE' >期交稅</th>";
//    _blood += "<th class='PL' >淨損益</th>";
//    _blood += "<th class='PL' >類型</th>";
//    }
//    _blood += "</tr>";
//    _blood += '</thead>';

    _blood += '<tbody>';
    try {
        $.each(eval(Details), function(key, item) {
            ret = true;
            _blood += '<tr>';

            if (item.SeqNo == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else if (item.SeqNo.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_103 contentStyle">' + item.SeqNo + '</td>'; }

            if (item.OPTTRDDT == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else if (item.OPTTRDDT.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_103 contentStyle">' + item.OPTTRDDT + '</td>'; }

            if (item.ORDNO == undefined) { _blood += '<td  class="style_102 contentStyle">&nbsp;</td>'; }
            else if (item.ORDNO.length < 1) { _blood += '<td  class="style_102 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_102 contentStyle">' + item.ORDNO + '</td>'; }

            if (item.ProductName == undefined) { _blood += '<td  class="style_102 contentStyle">&nbsp;</td>'; }
            else if (item.ProductName.length < 1) { _blood += '<td  class="style_102 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_102 contentStyle">' + item.ProductName + '</td>'; }

            if (item.PS == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else if (item.PS.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_103 contentStyle">' + item.PS + '</td>'; }

            if (item.PRICE == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else {
                _blood += '<td class="style_101 contentStyle">' + item.PRICE + '</td>';
            }

            if (item.OFFSETQTY == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else if (item.OFFSETQTY.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_101 contentStyle">' + item.OFFSETQTY + '</td>'; }



            if (item.OFFSETDATE == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else if (item.OFFSETDATE.length < 1) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_103 contentStyle">' + item.OFFSETDATE + '</td>'; }

            if (item.OSPRTLOS == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else if (item.OSPRTLOS.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_101 contentStyle">' + item.OSPRTLOS + '</td>'; }
            //            if ( $('#HistoryChk').attr('checked')) 
            //            {

            if (item.tax == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else {
                _blood += '<td class="style_101 contentStyle">' + item.tax + '</td>';
            }
            if (item.charge == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else {
                _blood += '<td class="style_101 contentStyle">' + item.charge + '</td>';
            }


            if (item.equity == undefined) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else if (item.equity.length < 1) { _blood += '<td  class="style_101 contentStyle">&nbsp;</td>'; }
            else { _blood += '<td  class="style_101 contentStyle">' + item.equity + '</td>'; }
            if ($('#HistoryChk').attr('checked')) {
                if (item.ordtype == undefined) { _blood += '<td  class="style_103 contentStyle">&nbsp;</td>'; }
                else {
                    _blood += '<td class="style_103 contentStyle">' + item.ordtype + '</td>';
                }
            }

            //            }
            _blood += '</tr>';
        });
    } catch (mExc) { }
    _blood += '</tbody>';

    //_blood += '</table>';
    //寫入DOM
   // $('#div_Q060').html(_blood);
     $('#T_Q061').find('tbody').remove();
    $('#T_Q061').append(_blood);
    
    
       
                       var systime="";
                    //資料更新日期
                    try {
                        if (Details[0].SYSDATE != null && Details[0].SYSDATE != undefined)
                         { systime =   Details[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if ( Details[0].SYSTIME != null &&  Details[0].SYSTIME != undefined) 
                        { systime+=" " + Details[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }

                    $('#lblSystemTime').text('資料更新時間:' + systime);

                    return ret;
        
}


$(document).ready(function() {
    $.datepicker.setDefaults($.datepicker.regional['zh-TW']);
    $('#StartDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#StartDate').focus(function() {
        $('#StartDate').datepicker("show");
        $(this).blur(function() { });
    });
    $('#StartDate').change(function() {
        checkDate(this);
    });
    $('#EndDate').datepicker({
        showButtonPanel: true
        //changeMonth: true,
        //changeYear: true
    });
    $('#EndDate').focus(function() {
        $('#EndDate').datepicker("show");
        $(this).blur(function() { });
    });
    $('#EndDate').change(function() {
        checkDate(this);
    });
});

//歷史切換開關日期區間
$(document).ready(function() {
    $('#HistoryChk').click(function() {
         $('#lblSystemTime').text('');
        if ($('#HistoryChk').attr('checked')) 
        {
            $('#StartDate').removeAttr("disabled");
            $('#EndDate').removeAttr("disabled");
            
               $("#fastdr").show();

        }
        else
        {
            $('#StartDate').attr("disabled", "disabled");
            $('#StartDate').val('');
            $('#EndDate').attr("disabled", "disabled");
            $('#EndDate').val('');
            
        }
    });

    $('#Today').click(function() {
        $('#lblSystemTime').text('');
        if ($('#HistoryChk').attr('checked')) {
            $('#StartDate').removeAttr("disabled");
            $('#EndDate').removeAttr("disabled");

            $("#fastdr").show();

        }
        else {
            $('#StartDate').attr("disabled", "disabled");
            $('#StartDate').val('');
            $('#EndDate').attr("disabled", "disabled");
            $('#EndDate').val('');
            $("#fastdr").hide();

        }
    });
    
    
    
});
//明細和彙總切換
$(document).ready(function() {
    $('#SummaryRadio').click(function() {
        $('#lblSystemTime').text('');
        if ($('#SummaryRadio').attr('checked')) {
            $('#SelectCurrency').removeAttr("disabled");
            $('#SelectProduct').removeAttr("disabled");
             $('#SelectMonth').removeAttr("disabled");
            $('#StrikePriceText1').removeAttr("disabled");
            $('#StrikePriceText2').removeAttr("disabled");
            $('#SelectCP').removeAttr("disabled");
        }
        else {
         //   $('#SelectCurrency').attr("disabled", "disabled");
           
            $('#SelectProduct').attr("disabled", "disabled");
            $('#SelectProduct').val('');
             $('#SelectMonth').attr("disabled", "disabled");
            $('#SelectMonth').val('');
            
            $('#StrikePriceText1').attr("disabled", "disabled");
            $('#StrikePriceText1').val('');
            $('#StrikePriceText2').attr("disabled", "disabled");
            $('#StrikePriceText2').val('');
            $('#SelectCP').attr("disabled", "disabled");
            $('#SelectCP').val('');
        }
    });
});
$(document).ready(function() {
    $('#DetailsRadio').click(function() {
        if ($('#SummaryRadio').attr('checked')) {
            $('#SelectCurrency').removeAttr("disabled");
            $('#SelectProduct').removeAttr("disabled");
             $('#SelectMonth').removeAttr("disabled");
            $('#StrikePriceText1').removeAttr("disabled");
            $('#StrikePriceText2').removeAttr("disabled");
            $('#SelectCP').removeAttr("disabled");
        }
        else {
         //   $('#SelectCurrency').attr("disabled", "disabled");
           
            $('#SelectProduct').attr("disabled", "disabled");
            $('#SelectProduct').val('');
             $('#SelectMonth').attr("disabled", "disabled");
            $('#SelectMonth').val('');
            
            $('#StrikePriceText1').attr("disabled", "disabled");
            $('#StrikePriceText1').val('');
            $('#StrikePriceText2').attr("disabled", "disabled");
            $('#StrikePriceText2').val('');
            $('#SelectCP').attr("disabled", "disabled");
            $('#SelectCP').val('');
        }
    });
});

//商品切換 CP 履約價
$(document).ready(function() {
    $('#SelectProduct').change(function() {
        if ($('#SelectProduct').val() == '1') {
            $('#StrikePriceText1').removeAttr("disabled");
            $('#StrikePriceText2').removeAttr("disabled");
            $('#SelectCP').removeAttr("disabled");
        }
        else {
            $('#StrikePriceText1').attr("disabled", "disabled");
            $('#StrikePriceText1').val('');
            $('#StrikePriceText2').attr("disabled", "disabled");
            $('#StrikePriceText2').val('');
            $('#SelectCP').attr("disabled", "disabled");
            $('#SelectCP').val('');
        }
    });
});


//履約價
$(document).ready(function() {
    $('#StrikePriceText1').change(function() {
        //if (IsNumber($('#StrikePriceText1').val())) { }
        //else {
        //alert('履約價(前)數字有誤');
        //$('#StrikePriceText1').val('');
        //$('#StrikePriceText1').focus();
        //}
        if (ValidateNumber_2(document.getElementById('StrikePriceText1'), $('#StrikePriceText1').val())) { }
        else { $('#StrikePriceText1').val(''); }
    });
    $('#StrikePriceText2').change(function() {
        //if (IsNumber($('#StrikePriceText2').val())) { }
        //else {
        //alert('履約價(前)數字有誤');
        //$('#StrikePriceText2').val('');
        //$('#StrikePriceText2').focus();
        //}
        if (ValidateNumber_2(document.getElementById('StrikePriceText2'), $('#StrikePriceText2').val())) { }
        else { $('#StrikePriceText2').val(''); }
    });
});

//月份的產生
//$(document).ready(function() {
//    for (var i = -3; i < 16; i++) {
//        var d = new Date();
//        //
//        d.setMonth(d.getMonth() + i);
//        var TargetYear = d.getFullYear();
//        var TargetMonth = d.getMonth() + 1;
//    }
//});
$(document).ready(function() {
    $('#btnExport').click(function(event) {
    
         if(!check())
                    {
                        return;
                    }


                    if (!GetServerDataAjax_MOBQ060()) {
                          return;
                    }
      
       var kind;
       var _type;
   if ($('#SummaryRadio').attr('checked')) 
   {
   kind=0; 
   }
   else
   {
   kind=1;
   }
     
        
        if ($('#HistoryChk').attr('checked')) { _type = 0; }
        else { _type =1; }
     
 
     
       
       
       

        var comtype = $('#SelectProduct').attr('value');

        var comym = $('#SelectMonth').attr('value');

        var min_price = $('#StrikePriceText1').attr('value');
        var max_price = $('#StrikePriceText2').attr('value');
        
        var cp = $('#SelectCP').attr('value');
        
        
        var acctId = $('#account').val();
        var date1 = $('#StartDate').val();
        var date2 = $('#EndDate').val();
        var comid = $('#company').val();
        var currency = $('#SelectCurrency').attr('value');
    
        var url = "PARAM=MOBQ060a.aspx&kind="+kind+"&type="+_type+"&currency=" + currency + "&date1=" + date1 + "&date2=" + date2 + "&accid=" + acctId + "&comid=" + comid+ "&comtype=" + comtype+ "&comym=" + comym+ "&min_price=" + min_price+ "&max_price=" + max_price + "&cp=" + cp    ;
        url = encodeURI(url);//document.location.protocol+"//"+document.location.host +"/
             //       window.open("MOBQ060a.aspx?" + url,'_blank');
window.location.href="MOBQ060a.aspx?" + url;
        return false;
    })
});

function check(){
        //檢查日期起訖
        if ($('#HistoryChk').attr('checked')) {
        
     
        
        
            var objStartDate = $('#StartDate').datepicker("getDate");
            var objEndDate = $('#EndDate').datepicker("getDate");
            if (objStartDate == null) {
                alert('起始日期需要輸入');
                $('#DivBlock').unblock();
                $('#StartDate').focus();
                return false ;
            }
          
            if (objEndDate == null) {
                alert('結束日期需要輸入');
                $('#DivBlock').unblock();
                $('#EndDate').focus();
                return false;
            }
            if (objStartDate != null & objEndDate != null) {
                if (objStartDate > objEndDate) {
                    alert('起始日期不可大於結束日期');
                    $('#DivBlock').unblock();
                    $('#StartDate').focus();
                    return false;
                }
                var now = new Date();
                var month=Math.abs( now-objStartDate )/(1000*60*60*24*30); 
                if (month>6) {
                    alert('最多往前查6個月!');
                    $('#DivBlock').unblock();
                    $('#StartDate').focus();
                    return false;
                } 
                var day=(objEndDate-objStartDate )/(1000*60*60*24); 
                if (day>31 ) {
                    alert('查詢區間最多1個月!');
                    $('#DivBlock').unblock();
                    $('#StartDate').focus();
                    return false;
                }
            }
        }
        //履約價大小起訖
        var _MIN = 0;
        var _MAX = 0;
        if ($('#StrikePriceText1').val() != '') { _MIN = parseFloat($('#StrikePriceText1').val()); }
        if ($('#StrikePriceText2').val() != '') { _MAX = parseFloat($('#StrikePriceText2').val()); }
        if (_MIN > _MAX) {
            alert('履約價後面不可大於前面');
            return false;
        }
        return true;
}
//更新 click
$(document).ready(function() {
    $('#ButtonQuery').click(function() {
          
         if(!check())
                    {
                        return;
                    }
                  //   $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
        //$.blockUI({ message: '<span>查詢中</span>' });
      //  $.blockUI({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
       // setTimeout('', 999);
        GetServerDataAjax_MOBQ060();
    });
});




//更新 click
$(document).ready(function() {
// $.blockUI({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//    setTimeout('GetServerDataAjax_MOBQ060()', 999);
  //   $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
GetServerDataAjax_MOBQ060();
});