﻿function GetServerDataAjax_MOBQ020_Total() {

    var ret = false;
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

    var productKind = "";
    if ($('#rdoSingle').attr('checked')) {
        productKind = "1,2";
    }
    else if ($('#rdoMutiple').attr('checked')) {
        productKind = "3,4";
    }
    else if ($('#rdoCombine').attr('checked')) {
        productKind = "";
    }
    var sort = "";
    var _sort = "";
    if ($('#rdoStirkePrice').attr('checked')) {
        sort = "StrikePrice";
    }
    else {
        sort = "CALLPUT";
        _sort = "CP";
    }
    var _currency = $('#selSource').attr('value');

    //var m_WhereParm = $('#Select1').attr('value');
    var m_WhereParm = { productKind: productKind, ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'), currency: _currency, sort: _sort, PARAM: tParam }
    //m_WhereParm.productKind = $('#Select1').attr('value');
    //var m_WhereParm = new function() { productKind: $('#Select1').attr('value') };

    var m_objJSON;
    
        m_objJSON = fh_CallWebMethod("MOBQ020", "QueryMOBQ020TOTAL?uri=" + tParam, m_WhereParm, false);
   
    if (m_objJSON != null) {
        if (m_objJSON.ErMsg != "") {
            fh_AlertMsg(m_objJSON.ErMsg);
            ret = false;
        }
        else {
            if (m_objJSON.UnLiquidationMain == undefined) return;
            $.each(eval(m_objJSON.UnLiquidationMain), function(key, item) {
                ret = true;
            });

            if ($('#FullRadio').attr('checked')) {
                if ($('#rdoSingle').attr('checked') || $('#rdoCombine').attr('checked')) {
                    //$('#div_02010').show();
                    Render_div_020010(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);
                }
                else {
                    //$('#div_02020').show();
                    Render_div_020020(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);

                }
            }
            else if ($('#FastRadio').attr('checked')) {
                if ($('#rdoSingle').attr('checked') || $('#rdoCombine').attr('checked')) {
                    //$('#div_02030').show();
                    Render_div_020030(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);
                }
                else {
                    //$('#div_02040').show();
                    Render_div_020040(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);

                }
            }

        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

    return ret
}




function GetServerDataAjax_MOBQ020() {

    var ret = false;
    var t0b = fh_GetNowTime();
    var tParam = fh_GenParam();

var productKind="";
    if ($('#rdoSingle').attr('checked')) 
   {
        productKind="1,2";
   }
   else  if ($('#rdoMutiple').attr('checked')) 
   {
        productKind="3,4";
   }
    else  if ($('#rdoCombine').attr('checked')) 
   {
        productKind="";
   }
   var sort="";
    if ($('#rdoStirkePrice').attr('checked')) 
    {
        sort="StrikePrice";
    }
    else
    {
        sort="CALLPUT";
    }
    var _currency = $('#selSource').attr('value');

    //var m_WhereParm = $('#Select1').attr('value');
    var m_WhereParm = { productKind: productKind, ACCT_ID: $('#account').attr('value'), COMP_ID: $('#company').attr('value'),currency:_currency, PARAM: tParam }
    //m_WhereParm.productKind = $('#Select1').attr('value');
    //var m_WhereParm = new function() { productKind: $('#Select1').attr('value') };
    
    var m_objJSON ;
    if(sort=="StrikePrice")
        m_objJSON= fh_CallWebMethod("MOBQ020", "QueryMOBQ020?uri="+tParam, m_WhereParm, false);
    else   if(sort=="CALLPUT")
        m_objJSON= fh_CallWebMethod("MOBQ020", "QueryMOBQ020SortByCP?uri="+tParam, m_WhereParm, false);
    if (m_objJSON != null) 
    {
        if(m_objJSON.ErMsg!="")
       {
           fh_AlertMsg(m_objJSON.ErMsg);
           ret = false;
       }
       else {
           if (m_objJSON.UnLiquidationMain==undefined)return;
           $.each(eval(m_objJSON.UnLiquidationMain), function(key, item) {
           ret = true;
           });
       
            if ($('#FullRadio').attr('checked')) {
               if ($('#rdoSingle').attr('checked')||$('#rdoCombine').attr('checked')) 
                {
                        //$('#div_02010').show();
                        Render_div_020010(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);
                  }
                  else
                  {
                        //$('#div_02020').show();
                        Render_div_020020(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);
                         
                }
            }
            else if ($('#FastRadio').attr('checked')) {
              if ($('#rdoSingle').attr('checked')||$('#rdoCombine').attr('checked')) 
                {
                        //$('#div_02030').show();
                        Render_div_020030(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);
                     }
                  else
                  {
                        //$('#div_02040').show();
                        Render_div_020040(m_objJSON.UnLiquidationMain, m_objJSON.UnLiquidationDetail, m_objJSON.UnLiquidationGroup);
                         
                }
            }
           
        }
    }

    var t0e = fh_GetNowTime();
    fh_LogClientTime(t0b, t0e, tParam);

    return ret
}

//完整單式未平倉查詢
function Render_div_020010(UnLiquidationMain, UnLiquidationDetail,UnLiquidationGroup) {

    var _blood = "";
    var ret = false;
//    var _blood = '<table class=\'style_100\' cellspacing=0  id="T_02011">';
//    _blood += "<tr>";
//    _blood += "<th class='style_BS'>買賣別</th>";
//    _blood += "<th class='style_ProductId'>商品內容</th>";
//    _blood += "<th class='style_TotalOTQTY'>總留倉口數</th>";


//    _blood += "<th class='style_RefTotalPL'>參考浮動損益</th>";
//    _blood += "<th class='style_AvgMatchPrice'>平均成交價</th>";
//    
// 
////    _blood += "<th>複式商品代碼</th>";
////    _blood += "<th>複式商品買賣別</th>";
//    _blood += "<th class='style_realPrice'>參考即時價</th>";
//    _blood += "</tr>";
   _blood += '<tbody>';
    try {
        $.each(eval(UnLiquidationMain), function(key, item) {
            _blood += '<tr>';
            
             _blood += '<td class=\'style_102 contentStyle\'><input type=checkbox /></td>';  
            

            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS + '</td>'; }


            if (item.productName == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.productName.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.productName + '</td>'; }

            if (item.TotalOTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TotalOTQTY + '</td>'; }


            


            

        
            if (item.AvgMatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.AvgMatchPrice + '</td>'; }

 

            //if (item.realPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            if (item.realPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.realPrice + '</td>'; }
            
                
            if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }

            if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
            if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
            if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
    //_blood += '</table>';
    //$('#div_02011').html(_blood);
   $('#T_02011').find('tbody').remove();
        $('#T_02011').append(_blood);

//群組統計
  _blood = '';
   _blood += '<tbody>';
    try {
        $.each(eval(UnLiquidationGroup), function(key, item) {
            _blood += '<tr>';
           

            if (item.comtype == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.comtype + '</td>'; }
            
            if (item.B == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.B + '</td>'; }
            
            
            if (item.S == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.S + '</td>'; }
            
 
            if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }

            if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
            if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
            if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
    //_blood += '</table>';
    //$('#div_02011').html(_blood);
   $('#T_02013').find('tbody').remove();
        $('#T_02013').append(_blood);
        
    //明細
    _blood = '';
//    _blood = '<table class=\'style_100\' cellspacing=0 id="T_02012">';
//    _blood += "<tr>";
//  
//    _blood += "<th class='style_tradedate'>成交日期</th>";
//    _blood += "<th class='style_orderNo'>成交單號</th>";
//    _blood += "<th class='style_BS'>買賣別</th>";
//    _blood += "<th class='style_ProductId'>商品內容</th>";
//    _blood += "<th class='style_MatchPrice'>成交價</th>";
//    _blood += "<th class='style_realPrice'>參考即時價</th>";
//    _blood += "<th class='style_OTQTY'>留倉口數</th>";
//    _blood += "<th class='style_RefTotalPL'>參考浮動損益</th>";
//    _blood += "<th class='style_DTOVER'>當沖</th>";
//    
//    
////    _blood += "<th>複式商品代碼</th>";
////    _blood += "<th>複式商品買賣別</th>";
//    _blood += "</tr>";

   _blood += '<tbody>';
    try {
        $.each(eval(UnLiquidationDetail), function(key, item) {
            _blood += '<tr>';

 
     _blood += '<td class=\'style_102 contentStyle\'><input type=checkbox /></td>';  

            if (item.tradedate == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.tradedate.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.tradedate + '</td>'; }


            if (item.orderNo == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.orderNo.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.orderNo + '</td>'; }


            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS + '</td>'; }
            

            if (item.productName == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.productName.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.productName + '</td>'; }

            //_blood += '<td class=\'style_101 contentStyle\'>' + item.OTQTY + '</td>';
            if (item.OTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.OTQTY + '</td>'; }


            //_blood += '<td class=\'style_101 contentStyle\'>' + item.MatchPrice + '</td>';
            if (item.MatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.MatchPrice + '</td>'; }

            //_blood += '<td class=\'style_101 contentStyle\'>' + item.RefRealPrice + '</td>';
            if (item.RefRealPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefRealPrice + '</td>'; }

            //_blood += '<td class=\'style_101 contentStyle\'>' + item.RefPL + '</td>';
            if (item.RefPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefPL + '</td>'; }
            
            //_blood += '<td class=\'style_102 contentStyle\'>' + item.DTOVER + '</td>';
            if (item.DTOVER == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.DTOVER.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.DTOVER + '</td>'; }

            
                if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
                if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
                if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }

            //        _blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>';
            //        _blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>';
            _blood += '</tr>';
        });
    } catch (mExc) { }
//    _blood += '</table>';
//    $('#div_02012').html(_blood);

 _blood += '</tbody>';
   
  $('#T_02012').find('tbody').remove();
        $('#T_02012').append(_blood);
                               var systime="";
                              
                    //資料更新日期
                    try {
                        if (UnLiquidationMain[0].SYSDATE != null && UnLiquidationMain[0].SYSDATE != undefined)
                         { systime = UnLiquidationMain[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (UnLiquidationMain[0].SYSTIME != null && UnLiquidationMain[0].SYSTIME != undefined) 
                        { systime+=" " +UnLiquidationMain[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);
    
}

//完整複式未平倉查詢
function Render_div_020020(UnLiquidationMain, UnLiquidationDetail,UnLiquidationGroup) {



    var _blood="" ;
       _blood += '<tbody>';
//    var _blood = '<table class=\'style_100\' cellspacing=0 id="T_02021">';
//    //合計
//    _blood += "<tr>";
//    _blood += "<th class='style_BS'>買賣別</th>";
//    _blood += "<th class='style_ProductId'>商品內容</th>";
//    _blood += "<th class='style_TotalOTQTY'>總留倉口數</th>";
//    _blood += "<th class='style_RefTotalPL'>參考浮動損益</th>";
//    _blood += "<th class='style_AvgMatchPrice'>平均成交價</th>";
//    _blood += "<th class='style_currency'>幣別</th>";
//    _blood += "<th class='style_realPrice'>參考即時價</th>";
//    _blood += "<th class='style_multiplecomno'>複式商品代碼</th>";
//    _blood += "<th class='style_multipleBS'>複式商品買賣別</th>";
//    //added by samantha 20101013 增加複式各腳價位欄位
//    _blood += "<th class='style_footMatchPrice'>複式各腳價位</th>";
//    _blood += "</tr>";

    try {
        $.each(eval(UnLiquidationMain), function(key, item) {
            _blood += '<tr>';
     _blood += '<td class=\'style_102 contentStyle\'><input type=checkbox /></td>';  
            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS.replace("\n","<br/>")  + '</td>'; }
            
            if (item.productName == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.productName.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.productName.replace("\n","<br/>")  + '</td>'; }
            
            if (item.TotalOTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TotalOTQTY + '</td>'; }
            
        
            
            if (item.AvgMatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.AvgMatchPrice + '</td>'; }
            
 
            
            if (item.realPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.realPrice + '</td>'; }
            
                if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }
            
            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>';
            if (item.multiplecomno == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.multiplecomno.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>';
            if (item.multipleBS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.multipleBS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>'; }
            
            //added by samantha 20101013 增加複式各腳價位欄位
            if (item.footMatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else if (item.footMatchPrice.length < 1) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.footMatchPrice.replace("\n","<br/>") + '</td>'; }
                  
                if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
                if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
                if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
     _blood += '</tbody>';
   // _blood += '</table>';
    //$('#div_02021').html(_blood);
      $('#T_02021').find('tbody').remove();
        $('#T_02021').append(_blood);
        
//群組統計
  _blood = '';
   _blood += '<tbody>';
    try {
        $.each(eval(UnLiquidationGroup), function(key, item) {
            _blood += '<tr>';
            
             
          if (item.comtype == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.comtype + '</td>'; }
            
              if (item.B == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.B + '</td>'; }
            
            
            if (item.S == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.S + '</td>'; }
            
 
            if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }

            if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
            if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
            if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
    //_blood += '</table>';
    //$('#div_02011').html(_blood);
   $('#T_02023').find('tbody').remove();
        $('#T_02023').append(_blood);
    //明細
    _blood = '';
//    _blood = '<table class=\'style_100\' cellspacing=0 id="T_02022">';
//    _blood += "<tr>";

//    _blood += "<th class='style_tradedate'>成交日期</th>";
//    _blood += "<th class='style_orderNo'>成交單號</th>";
//    _blood += "<th class='style_BS'>買賣別</th>";
//    _blood += "<th class='style_ProductId'>商品內容</th>";
//    _blood += "<th class='style_MatchPrice'>成交價</th>";
//    _blood += "<th class='style_realPrice'>參考即時價</th>";
//    _blood += "<th class='style_OTQTY'>留倉口數</th>";
//    _blood += "<th class='style_RefTotalPL'>參考浮動損益</th>";
//    _blood += "<th class='style_DTOVER'>當沖</th>";
//    _blood += "<th class='style_multiplecomno'>複式商品代碼</th>";
//    _blood += "<th class='style_multipleBS'>複式商品買賣別</th>";
//     //added by samantha 20101013 增加複式各腳價位欄位
//    _blood += "<th class='style_footMatchPrice'>複式各腳價位</th>";
//    _blood += "</tr>";

    try {
        $.each(eval(UnLiquidationDetail), function(key, item) {
            _blood += '<tr>';

              _blood += '<td class=\'style_102 contentStyle\'><input type=checkbox /></td>';  

            if (item.tradedate == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.tradedate.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.tradedate + '</td>'; }

            if (item.orderNo == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.orderNo.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.orderNo + '</td>'; }

            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS.replace("\n","<br/>")  + '</td>'; }

            if (item.productName == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.productName.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.productName.replace("\n","<br/>")  + '</td>'; }

      //_blood += '<td class=\'style_101 contentStyle\'>' + item.OTQTY + '</td>';
            if (item.OTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.OTQTY + '</td>'; }

            //_blood += '<td class=\'style_101 contentStyle\'>' + item.MatchPrice + '</td>';
            if (item.MatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.MatchPrice + '</td>'; }

            //_blood += '<td class=\'style_101 contentStyle\'>' + item.RefRealPrice + '</td>';
            if (item.RefRealPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefRealPrice + '</td>'; }

      
            //_blood += '<td class=\'style_101 contentStyle\'>' + item.RefPL + '</td>';
            if (item.RefPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefPL + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.DTOVER + '</td>';
            if (item.DTOVER == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.DTOVER.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.DTOVER + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>';
            if (item.multiplecomno == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.multiplecomno.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>';
            if (item.multipleBS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.multipleBS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>'; }
            
             //added by samantha 20101013 增加複式各腳價位欄位
            if (item.footMatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else if (item.footMatchPrice.length < 1) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.footMatchPrice.replace("\n","<br/>")  + '</td>'; }
                  
                if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
                if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
                if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            _blood += '</tr>';
        });
    } catch (mExc) { }
    
//    _blood += '</table>';
//    $('#div_02022').html(_blood);
  $('#T_02022').find('tbody').remove();
        $('#T_02022').append(_blood);
                               var systime="";
                    //資料更新日期
                    try {
                        if (UnLiquidationMain[0].SYSDATE != null &&UnLiquidationMain[0].SYSDATE != undefined)
                         { systime =  UnLiquidationMain[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (UnLiquidationMain[0].SYSTIME != null && UnLiquidationMain[0].SYSTIME != undefined) 
                        { systime+=" " +UnLiquidationMain[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);
}

//簡易單式未平倉查詢
function Render_div_020030(UnLiquidationMain, UnLiquidationDetail,UnLiquidationGroup) {

    var _blood="" ;
       _blood += '<tbody>';
    //合計
//    var _blood = '<table class=\'style_100\' cellspacing=0 id="T_02031">';
//    _blood += "<tr>";
//    _blood += "<th class='style_BS'>買賣別</th>";
//    _blood += "<th class='style_ProductId'>商品內容</th>";
//    _blood += "<th class='style_OTQTY'>留倉口數</th>";
//    _blood += "<th class='style_RefTotalPL'>未平倉損益</th>";
//    
////    _blood += "<th>平均成交價</th>";
////    _blood += "<th>幣別</th>";
////    _blood += "<th>參考即時價</th>";
////    _blood += "<th>複式商品代碼</th>";
////    _blood += "<th>複式商品買賣別</th>";
//    _blood += "</tr>";

    try {
        $.each(eval(UnLiquidationMain), function(key, item) {
            _blood += '<tr>';
     _blood += '<td class=\'style_102 contentStyle\'><input type=checkbox /></td>';  
            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS + '</td>'; }

            if (item.productName == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.productName.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.productName + '</td>'; }

            if (item.TotalOTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TotalOTQTY + '</td>'; }
            
            if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }
                if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
                if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
                if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }

//            if (item.AvgMatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
//            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.AvgMatchPrice + '</td>'; }

//            if (item.currency == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//            else if (item.currency.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.currency + '</td>'; }

//            if (item.realPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
//            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.realPrice + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>';
//            if (item.multiplecomno == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//            else if (item.multiplecomno.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>';
//            if (item.multipleBS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//            else if (item.multipleBS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
//            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>'; }

            _blood += '</tr>';
        });
    }
    catch (mExc) { }
    
//    _blood += '</table>';
//    $('#div_02031').html(_blood);
    _blood += '</tbody>';
      $('#T_02031').find('tbody').remove();
        $('#T_02031').append(_blood);
        
//群組統計
  _blood = '';
   _blood += '<tbody>';
    try {
        $.each(eval(UnLiquidationGroup), function(key, item) {
            _blood += '<tr>';
            
             
            if (item.comtype == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.comtype + '</td>'; }
            
              if (item.B == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.B + '</td>'; }
            
            
            if (item.S == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.S + '</td>'; }
            
            
            if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }

            if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
            if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
            if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
    //_blood += '</table>';
    //$('#div_02011').html(_blood);
   $('#T_02032').find('tbody').remove();
        $('#T_02032').append(_blood);
                               var systime="";
                    //資料更新日期
                    try {
                        if (UnLiquidationMain[0].SYSDATE != null &&UnLiquidationMain[0].SYSDATE != undefined)
                         { systime =  UnLiquidationMain[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (UnLiquidationMain[0].SYSTIME != null && UnLiquidationMain[0].SYSTIME != undefined) 
                        { systime+=" " +UnLiquidationMain[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);
}

//簡易.複式未平倉
function Render_div_020040(UnLiquidationMain, UnLiquidationDetail,UnLiquidationGroup) {
    //合計
     var _blood="" ;
       _blood += '<tbody>';
//    var _blood = '<table class=\'style_100\' cellspacing=0 id="T_02041">';
//    _blood += "<tr>";
//    _blood += "<th class='style_BS'>買賣別</th>";
//    _blood += "<th class='style_ProductId'>商品內容</th>";
//    _blood += "<th class='style_OTQTY'>留倉口數</th>";
//    _blood += "<th class='style_RefTotalPL'>未平倉損益</th>";

//    //    _blood += "<th>平均成交價</th>";
//    //    _blood += "<th>幣別</th>";
//    //    _blood += "<th>參考即時價</th>";
//    _blood += "<th class='style_multiplecomno'>複式商品代碼</th>";
//    _blood += "<th class='style_multipleBS'>複式商品買賣別</th>";
//     //added by samantha 20101013 增加複式各腳價位欄位
//      _blood += "<th class='style_footMatchPrice'>複式各腳價位</th>";
//    _blood += "</tr>";

    try {
        $.each(eval(UnLiquidationMain), function(key, item) {
            _blood += '<tr>';
     _blood += '<td class=\'style_102 contentStyle\'><input type=checkbox /></td>';  
            if (item.BS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.BS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.BS.replace("\n","<br/>")  + '</td>'; }

            if (item.productName == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.productName.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.productName.replace("\n","<br/>")  + '</td>'; }

            if (item.TotalOTQTY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TotalOTQTY + '</td>'; }

            if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }

            //            if (item.AvgMatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            //            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.AvgMatchPrice + '</td>'; }

            //            if (item.currency == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            //            else if (item.currency.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            //            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.currency + '</td>'; }

            //            if (item.realPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            //            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.realPrice + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>';
            if (item.multiplecomno == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.multiplecomno.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multiplecomno + '</td>'; }

            //_blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>';
            if (item.multipleBS == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else if (item.multipleBS.length < 1) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.multipleBS + '</td>'; }
            //added by samantha 20101013 增加複式各腳價位欄位
            if (item.footMatchPrice == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else if (item.footMatchPrice.length < 1) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.footMatchPrice.replace("\n","<br/>")  + '</td>'; }
    if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
                if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
                if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>0</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
    
//    _blood += '</table>';
//    $('#div_02041').html(_blood);
  _blood += '</tbody>';
 $('#T_02041').find('tbody').remove();
        $('#T_02041').append(_blood);
        
       
//群組統計
  _blood = '';
   _blood += '<tbody>';
    try {
        $.each(eval(UnLiquidationGroup), function(key, item) {
            _blood += '<tr>';
            
             
         if (item.comtype == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_102 contentStyle\'>' + item.comtype + '</td>'; }
  if (item.B == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.B + '</td>'; }
            
            
            if (item.S == undefined) { _blood += '<td class=\'style_102 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.S + '</td>'; }
            
 
            if (item.RefTotalPL == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.RefTotalPL + '</td>'; }

            if (item.TAX == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.TAX + '</td>'; }
            if (item.FEE == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.FEE + '</td>'; }
            if (item.EQUITY == undefined) { _blood += '<td class=\'style_101 contentStyle\'>&nbsp;</td>'; }
            else { _blood += '<td class=\'style_101 contentStyle\'>' + item.EQUITY + '</td>'; }
            
            _blood += '</tr>';
        });
    }
    catch (mExc) { }
      _blood += '</tbody>';
    //_blood += '</table>';
    //$('#div_02011').html(_blood);
   $('#T_02042').find('tbody').remove();
        $('#T_02042').append(_blood);        
        
                       var systime="";
                    //資料更新日期
                    try {
                        if (UnLiquidationMain[0].SYSDATE != null &&UnLiquidationMain[0].SYSDATE != undefined)
                         { systime = UnLiquidationMain[0].SYSDATE ; }
                       
                    }
                    catch (mExc) {  }
                    //資料更新時間
                    try {
                        if (UnLiquidationMain[0].SYSTIME != null && UnLiquidationMain[0].SYSTIME != undefined) 
                        { systime+=" " +UnLiquidationMain[0].SYSTIME ; }
                    
                    }
                    catch (mExc) {  }
                    
                    $('#lblSystemTime').text('資料更新時間:'+systime);
}

$(document).ready(function() {
    $('#FullRadio').click(function() {
              $('#lblSystemTime').text('');
        $('#div_02010').hide();
        $('#div_02020').hide();
        $('#div_02030').hide();
        $('#div_02040').hide();
             if ($('#rdoSingle').attr('checked')||$('#rdoCombine').attr('checked')) 
          {
                $('#div_02010').show();
                }
            else{
                $('#div_02020').show();
                }
       
    });
});

$(document).ready(function() {
    $('#FastRadio').click(function() {
        $('#lblSystemTime').text('');
        $('#div_02010').hide();
        $('#div_02020').hide();
        $('#div_02030').hide();
        $('#div_02040').hide();
          if ($('#rdoSingle').attr('checked')||$('#rdoCombine').attr('checked')) 
          {
                $('#div_02030').show();
        }
        else{
                $('#div_02040').show();
               
        }
    });
});

 

 
$(document).ready(function() {
    $('#rdoSingle').click( rdoClick);
      $('#rdoMutiple').click( rdoClick);
       $('#rdoCombine').click( rdoClick);
}); 
 
 function rdoClick()
 {
     $('#lblSystemTime').text('');
    $('#div_02010').hide();
        $('#div_02020').hide();
        $('#div_02030').hide();
        $('#div_02040').hide();
        if ($('#FullRadio').attr('checked')) 
        {
          if ($('#rdoSingle').attr('checked')||$('#rdoCombine').attr('checked')) 
          {
            $('#div_02010').show();
          }
          else
          {
            $('#div_02020').show();
          }
 
        }
        else if ($('#FastRadio').attr('checked')) 
        {
             if ($('#rdoSingle').attr('checked')||$('#rdoCombine').attr('checked')) 
          {
            $('#div_02030').show();
          }
          else
          {
            $('#div_02040').show();
          }
        }
 }

$(document).ready(function() {
    $('#Button1').click(function(event) {
        //$.blockUI({ message: '<span>查詢中</span>' });
        //$('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
    setTimeout('GetServerDataAjax_MOBQ020_Total()', 999);
})



});

 

//-----------------------測試的程式------------------
$(document).ready(function() {
    var _HowManyTimes = $('#TestCounter').val();
    if (_HowManyTimes != null && _HowManyTimes > 0) {
        $('#TestTimerButton').click(function(event) {
            var HowManyTimes = _HowManyTimes;
            //disable normal button
            $('#Button1').hide();
            $('#TestTimerButton').attr('disabled', 'disabled');

            for (HowManyTimes; HowManyTimes > 0; HowManyTimes--) {
                var ReplaceText = '測試' + HowManyTimes.toString() + '次';
                $('#TestTimerButton').attr('value', ReplaceText);

                GetServerDataAjax_MOBQ020();

            } //end for
            $('#TestTimerButton').attr('value', '測試結束');
            //還原按鈕
            $('#Button1').show();
            $('#TestTimerButton').removeAttr('disabled');
        });
    }
});

//---------------------------------------------------------------------------

$(document).ready(function() {
    if (document.getElementById("TEST_CASE").value == "RUN") {
        window.setTimeout(AutoRun, 1000);
    }
//     $('#DivBlock').block({ message: '<h1><img src="../images/loading2.gif" /></h1>' });
//    setTimeout('GetServerDataAjax_MOBQ020()', 999);
    GetServerDataAjax_MOBQ020_Total()

});

function AutoRun() {
    $("#TestTimerButton").click();
}
$(document).ready(function() {
    $('#btnDetail').click(function(event) {
 
        GetServerDataAjax_MOBQ020();
    })



});
$(document).ready(function() {
    $('#btnExport').click(function(event) {



        if (!GetServerDataAjax_MOBQ020()) {
            alert("查無資料!");
            return;
        }



        var productKind = "";
        var Full = "";
        if ($('#rdoSingle').attr('checked')) {
            productKind = "1,2";
        }
        else if ($('#rdoMutiple').attr('checked')) {
            productKind = "3,4";
        }
        else if ($('#rdoCombine').attr('checked')) {
            productKind = "";
        }

        if ($('#FullRadio').attr('checked')) {
            Full = "1";
        }
        else {
            Full = "0";
        }
        var sort = "";
        if ($('#rdoStirkePrice').attr('checked')) {
            sort = "StrikePrice";
        }
        else {
            sort = "CALLPUT";
        }



        var ACCT_ID = $('#account').attr('value');
        var COMP_ID = $('#company').attr('value');

        var _currency = $('#selSource').attr('value');
        var url = "PARAM=MOBQ020a.aspx&Full=" + Full + "&productKind=" + productKind + "&ACCT_ID=" + ACCT_ID + "&COMP_ID=" + COMP_ID + "&currency=" + _currency + "&SORT=" + sort;
        url = encodeURI(url); //document.location.protocol+"//"+document.location.host +"/
        //  window.open("MOBQ020a.aspx?" + url,_blank);
        window.location.href = "MOBQ020a.aspx?" + url;
        return false;
    })
});