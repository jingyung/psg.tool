﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;

public partial class MOB_MOBQ030 : BasePage
{
    //

    protected void Page_Load(object sender, EventArgs e)
    {
        //
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------
            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}
            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
            }
        }
    }
    [WebMethod()]
    public static string QueryMOBQ030(string ACCT_ID, string COMP_ID, string Currency)
    {
        //System.Threading.Thread.Sleep(2000);
        string ErMsg = string.Empty;
        string JSON_Balance = string.Empty;
        FunctionHandler fh = new FunctionHandler();
        //當日損益
        //string OriginalstrData = "S  10.72.205.198:3143      500000019IF0080009811139TWD-000000139650.00+000000003650.00-000000000000.00-000000000000.00-000000000000.001\n";
        string[] OriginalstrData;
        MobDataParse mobData = new MobDataParse();
        ////-----加入log記錄元件----
        //WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff"));
        //WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff"));
        ////------------------------
        //try
        //{
        //    OriginalstrData = fh.getMOB_CurrentBalance(ACCT_ID, Currency, COMP_ID, mobj_T1Log, mobj_T4Log);
        //    mobData.parseMobInfoData(OriginalstrData);
        //    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
        //    Int32 idx = 0;
        //    for (idx = 0; idx < OriginalstrData.Length; idx++)
        //    {
        //        mobj_T4Log.WriteEntryData(OriginalstrData[idx].Substring(1, 27) + mobj_T4Log.T4b + T4e + OriginalstrData[idx]);
        //    }
        //}
        //catch (Exception ex)
        //{

        //}
        //finally
        //{
        //    mobj_T1Log.Close();
        //    mobj_T4Log.Close();
        //}

        //string msg = "";


        try
        { 

            ////DataTable dt = mobData.GetMOBCurrentMarginDT();
            //DataTable dt = mobData.GetMOBCurrentBalanceDT();

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = ws.WS_getReal_CurrentBalance(COMP_ID, ACCT_ID,Currency ).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                if (dt.Columns.Contains("error"))
                {
                    JSON_Balance = "{}";
                    ErMsg = dt.Rows[0]["error"].ToString();
                }
                else
                {

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        //加大; 測試;
                        //foreach (DataRow itemR in dt.Rows)
                        //{
                        //    foreach (DataColumn itemC in dt.Columns)
                        //    {
                        //        try
                        //        {
                        //            if (double.Parse(itemR[itemC].ToString()) < 1)
                        //            {
                        //                double _s = double.Parse(itemR[itemC].ToString());
                        //                Random generator = new Random();
                        //                int randomValue;

                        //                randomValue = generator.Next(10, 100);
                        //                _s += randomValue;
                        //                itemR[itemC] = _s;
                        //            }
                        //        }
                        //        catch (Exception Er)
                        //        {
                        //            ErMsg=Er.Message;
                        //            //throw;
                        //        }
                        //    }
                        //}
                        JSON_Balance = fh.DT_To_JSON(dt);
                    }
                    else
                    {
                        JSON_Balance = "{}";
                    }
                }
            }
            else
            {
                JSON_Balance = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON_Balance = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        return " {\"Balance\":" + JSON_Balance + ",\"ErMsg\":\"" + ErMsg + "\" } ";

    }
}
