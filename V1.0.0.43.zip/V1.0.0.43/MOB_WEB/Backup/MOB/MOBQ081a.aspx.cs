﻿using System;
using System.Data;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class MOB_MOBQ081a : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        var strFilter = Request["sort"].Split(',');

        DataTable dtHistory;

        try
        {
            var ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            var startDate = Request["date1"].Replace("/", "");
            var endDate = Request["date2"].Replace("/", "");

            dtHistory = ws.WS_getHistoryFBTDTR_List(Request["comid"], Request["accid"], "", startDate, endDate);
        }
        catch (Exception ex)
        {
            throw;
        }
        var vdtHistory = dtHistory.DefaultView;

        if (strFilter.Length > 1)
            switch (strFilter[0])
            {
                case "1":
                    vdtHistory.Sort = "TRDDT " + strFilter[1];
                    break;

                case "2":
                    vdtHistory.Sort = "ProductInfo " + strFilter[1];
                    break;
            }

        dtHistory = vdtHistory.ToTable();
        dtHistory.Columns["TRDTM"].ColumnName = "成交時間";
        dtHistory.Columns["EXH"].ColumnName = "期交所";
        dtHistory.Columns["ORDNO"].ColumnName = "委託單號";
        dtHistory.Columns["ps"].ColumnName = "買/賣";
        dtHistory.Columns["ProductInfo"].ColumnName = "商品內容";
        dtHistory.Columns["totalQTY"].ColumnName = "成交量";
        dtHistory.Columns["average"].ColumnName = "平均價格";
        dtHistory.Columns["ENTCD"].ColumnName = "委託來源";
        dtHistory.Columns["TRDDT"].ColumnName = "交易日期";
        GridView1.DataSource = dtHistory;
        GridView1.DataBind();

        if (dtHistory.Rows.Count == 0)
        {
            string strJs = "<script>alert('查無資料');window.close();</script>";
            Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
        }
        else
        {
            GridView1.DataSource = dtHistory;
            GridView1.DataBind();
            ExportExcel("MOBQ081", GridView1);
        }

    }

    //匯出EXCEL
    public void ExportExcel(string strExportFileName, Control webControl)
    {
        try
        {
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "";
            //Response.Cache.SetCacheability(HttpCacheability.NoCache)

            Response.Cache.SetCacheability(HttpCacheability.Public);

            Response.ContentType = "application/vnd.ms-excel";
            var stringWrite = new StringWriter();
            var htmlWrite = new HtmlTextWriter(stringWrite);
            var hf = new HtmlForm();
            Controls.Add(hf);
            hf.Controls.Add(webControl);
            hf.RenderControl(htmlWrite);
            Response.Write(stringWrite.ToString());
            Response.End();

        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }
}
