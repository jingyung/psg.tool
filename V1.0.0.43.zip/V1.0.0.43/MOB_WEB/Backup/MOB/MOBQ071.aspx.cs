﻿using System;
using System.Collections;
using System.Web.Services;
using Newtonsoft.Json;
using System.Data;
using System.Configuration;
public partial class MOB_MOBQ071 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.hnAction_Timeout.Value = ConfigurationManager.AppSettings["Action_Timeout"].ToString();
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------


            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}
            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
            }
        }
    }

    [WebMethod()]
    public static string QueryMOBQ071(string rsCount, string tbDetail, string ACCT_ID, string COMP_ID, string PARAM)
    {
        string ErMsg = string.Empty;
        string JSON_MOBCombineResut = "";
        try
        {

            DataTable dtDetail = JsonConvert.DeserializeObject<DataTable>(tbDetail);

            ArrayList aryCombineData = new ArrayList();
            FunctionHandler fh = new FunctionHandler();

            DataTable dtResult = new DataTable();

            dtResult.Columns.Add("SN");
            dtResult.Columns.Add("SEQNO");
            dtResult.Columns.Add("PRODUCT");
            dtResult.Columns.Add("CP");
            dtResult.Columns.Add("BS");
            dtResult.Columns.Add("QTY");
            dtResult.Columns.Add("STATUS");

            int rowCount = int.Parse(rsCount);
            int rowSeqNo = 0;
            for (int rs = 0; rs < rowCount; rs++)
            {
                DataRow[] drData = dtDetail.Select("rs='" + rs.ToString() + "' ");



                if (drData.Length > 0)
                {
                    rowSeqNo += 1;
                    string SEQNO = rowSeqNo.ToString().PadLeft(4, '0');
                    string COMPANY = COMP_ID.PadLeft(7, '0');
                    string ACTNO = ACCT_ID.PadLeft(7, '0');
                    drData[0]["cp"] = drData[0]["cp"].ToString().Replace("<BR>", "<br>");
                    drData[0]["bs"] = drData[0]["bs"].ToString().Replace("<BR>", "<br>");
              



                    //商品代號1	Comno1	X(7)    
                    string Comno1 = drData[0]["comno"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None)[0].Trim().PadRight(7, ' ');
                    //商品年月1	Comym1	X(6)   
                    string Comym1 = drData[0]["comym"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None)[0].Trim().PadRight(6, ' ');
                    //履約價1	Stkprc1	9(5)V9(4)
                    decimal ds1 = 0;
                    decimal.TryParse(drData[0]["Stkprc"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None)[0].Trim(), out ds1);
                    string Stkprc1 = ds1.ToString("00000.0000").Replace(".", "").PadLeft(9, '0');
                    //CALL/PUT1	Callput1	X(1) 
                    string cp1 = drData[0]["cp"].ToString().Split(new string[] { "<br>" }, StringSplitOptions.None)[0].Trim().PadRight(1, ' ');
                    //買賣別1	BS1	X(1)         
                    string BS1 = drData[0]["bs"].ToString().Split(new string[] { "<br>" }, StringSplitOptions.None)[0].Trim().PadRight(1, ' ');
                    //數量1	Qty1	9(5)     
                    string Qty1 = drData[0]["productQTY"].ToString().Trim().PadLeft(5, '0');
                    //商品代號2	Comno2	X(7)    
                    string Comno2 = drData[0]["comno"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None)[1].Trim().PadRight(7, ' ');
                    //商品年月2	Comym2	X(6)   
                    string Comym2 = drData[0]["comym"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None)[1].Trim().PadRight(6, ' ');
                    //履約價2	Stkprc2	9(5)V9(4)
                    decimal ds2 = 0;
                    decimal.TryParse(drData[0]["Stkprc"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None)[1].Trim(), out ds2);
                    string Stkprc2 = ds2.ToString("00000.0000").Replace(".", "").PadLeft(9, '0');
                    //CALL/PUT2	Callput2	X(1) 
                    string cp2 = drData[0]["cp"].ToString().Split(new string[] { "<br>" }, StringSplitOptions.None)[1].Trim().PadRight(1, ' ');
                    //買賣別2	BS2	X(1)         
                    string BS2 = drData[0]["bs"].ToString().Split(new string[] { "<br>" }, StringSplitOptions.None)[1].Trim().PadRight(1, ' ');
                    //數量1	Qty2	9(5)     
                    string Qty2 = drData[0]["productQTY"].ToString().Trim().PadLeft(5, '0');

                    string text = SEQNO + COMPANY + ACTNO + Comno1 + Comym1 + Stkprc1 + cp1 + BS1 + Qty2 + Comno2 + Comym2 + Stkprc2 + cp2 + BS2 + Qty2;
                    aryCombineData.Add(text);

                    DataRow rw = dtResult.NewRow();
                    rw["SN"] = (rs + 1).ToString();

                    rw["SEQNO"] = SEQNO + "<br/>";
                    rw["PRODUCT"] = drData[0]["productName"].ToString() + "<br/>";
                    rw["CP"] = drData[0]["CP"].ToString() + "<br/>";
                    rw["BS"] = drData[0]["BS"].ToString() + "<br/>";
                    rw["QTY"] = drData[0]["productQTY"].ToString() + "<br/>";

                    dtResult.Rows.Add(rw);
                }
            }

            string TYPE = "1"; //異動別：拆解
            string COUNT = aryCombineData.Count.ToString().PadLeft(4, '0');

            for (int c_idx = 0; c_idx < aryCombineData.Count; c_idx++)
            {
                aryCombineData[c_idx] = TYPE + COUNT + aryCombineData[c_idx];
            }


            //-----加入log記錄元件----
            //WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
            //WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());

            string[] combineData = aryCombineData.ToArray(typeof(string)) as string[];

            //     string[] ResultData  ;

            //     //ResultData[0] = " 123456780003000100         123456780003000100 ";
            //     //ResultData[1] = " 123456780003000200         123456780003000200 ";
            //     //ResultData[2] = " 123456780003000300         123456780003000300 ";

            //     MobDataParse mobData = new MobDataParse();

            //     try
            //     {
            //ResultData = fh.getMOB_Combine(ACCT_ID, COMP_ID, combineData, mobj_T1Log, mobj_T4Log);

            //       mobData.parseMobInfoData(ResultData);

            //         string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
            //         Int32 idx = 0;
            //         for (idx = 0; idx < ResultData.Length; idx++)
            //         {
            //             mobj_T4Log.WriteEntryData(ResultData[idx].Substring(1, 27) + mobj_T4Log.T4b + T4e + ResultData[idx]);
            //         }

            //         mobj_T1Log.WriteEntryData("=======" + PARAM);
            //     }
            //     catch (Exception ex)
            //     {

            //     }
            //     finally
            //     {
            //         mobj_T1Log.Close();
            //         mobj_T4Log.Close();
            //     }

            //     DataTable MOBCombineData = mobData.GetMOBCombineDT();

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = ws.WS_getMOB_Combine(COMP_ID, ACCT_ID, combineData).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                DataTable MOBCombineData = ds.Tables[0];
                if (MOBCombineData.Columns.Contains("error"))
                {
                    JSON_MOBCombineResut = "{}";
                    ErMsg = MOBCombineData.Rows[0]["error"].ToString();
                }
                else
                {

                    foreach (DataRow drCombine in dtResult.Rows)
                    {
                        string[] seqs = drCombine["SEQNO"].ToString().Split(new string[] { "<br/>" }, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string strSeq in seqs)
                        {
                            DataRow[] drsCombine = MOBCombineData.Select("SEQNO='" + strSeq + "'");
                            if (drsCombine.Length > 0)
                            {
                                drCombine["STATUS"] += drsCombine[0]["STATUS"].ToString() + "<br/>";
                            }

                        }
                    }

                    JSON_MOBCombineResut = fh.DT_To_JSON(dtResult);
                }
            }
            else
            {
                JSON_MOBCombineResut = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON_MOBCombineResut = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        return "{\"MOBCombineResult\":" + JSON_MOBCombineResut + ",\"ErMsg\":\"" + ErMsg + "\"}";

    }

    [WebMethod()]
    public static string QueryMOBQ071_a(string ACCT_ID, string COMP_ID, string PARAM)
    {
        string ErMsg = string.Empty;
        string JSON_MOBCombineResut;
        try
        {

            ArrayList aryCombineData = new ArrayList();
            FunctionHandler fh = new FunctionHandler();
            DataTable dtResult = new DataTable();

            dtResult.Columns.Add("SN");
            dtResult.Columns.Add("SEQNO");
            dtResult.Columns.Add("PRODUCT");
            dtResult.Columns.Add("CP");
            dtResult.Columns.Add("BS");
            dtResult.Columns.Add("QTY");
            dtResult.Columns.Add("STATUS");
            string COMPANY = COMP_ID.PadLeft(7, '0');
            string ACTNO = ACCT_ID.PadLeft(7, '0');
            string ORDDT = DateTime.Now.ToString("yyyy/MM/dd");
            string ORDTM = DateTime.Now.ToString("HHmmss");
            string text = "0001" + COMPANY + ACTNO + "             000000000  00000             000000000  00000";

            aryCombineData.Add("20001" + text);

            DataRow rw = dtResult.NewRow();
            rw["SN"] = "1";
            rw["SEQNO"] += "0001<br/>";
            rw["PRODUCT"] += "<br/>";
            rw["CP"] += "<br/>";
            rw["BS"] += "<br/>";
            rw["QTY"] += "<br/>";
            dtResult.Rows.Add(rw);
            ////-----加入log記錄元件----
            //WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
            //WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());

            string[] combineData = aryCombineData.ToArray(typeof(string)) as string[];

            //MobDataParse mobData = new MobDataParse();

            //string[] ResultData;


            ////ResultData[0] = " 123456780003000100         123456780003000100 ";
            ////ResultData[1] = " 123456780003000200         123456780003000200 ";
            ////ResultData[2] = " 123456780003000300         123456780003000300 ";

            //try
            //{
            //    ResultData = fh.getMOB_Combine(ACCT_ID, COMP_ID, combineData, mobj_T1Log, mobj_T4Log);

            //    mobData.parseMobInfoData(ResultData);


            //    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
            //    Int32 idx = 0;
            //    for (idx = 0; idx < ResultData.Length; idx++)
            //    {
            //        mobj_T4Log.WriteEntryData(ResultData[idx].Substring(1, 27) + mobj_T4Log.T4b + T4e + ResultData[idx]);
            //    }

            //    mobj_T1Log.WriteEntryData("=======" + PARAM);
            //}
            //catch (Exception ex)
            //{

            //}
            //finally
            //{
            //    mobj_T1Log.Close();
            //    mobj_T4Log.Close();
            //}

            //DataTable MOBCombineData = mobData.GetMOBCombineDT();
            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = ws.WS_getMOB_Combine(COMP_ID, ACCT_ID, combineData).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                DataTable MOBCombineData = ds.Tables[0];
                if (MOBCombineData.Columns.Contains("error"))
                {
                    JSON_MOBCombineResut = "{}";
                    ErMsg = MOBCombineData.Rows[0]["error"].ToString();
                }
                else
                {
                    foreach (DataRow drCombine in dtResult.Rows)
                    {
                        string[] seqs = drCombine["SEQNO"].ToString().Split(new string[] { "<br/>" }, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string strSeq in seqs)
                        {
                            DataRow[] drsCombine = MOBCombineData.Select("SEQNO='" + strSeq + "'");
                            if (drsCombine.Length > 0)
                            {
                                drCombine["STATUS"] += drsCombine[0]["STATUS"].ToString() + "<br/>";
                            }

                        }
                        drCombine["PRODUCT"] = "全拆";
                    }

                    JSON_MOBCombineResut = fh.DT_To_JSON(dtResult);
                }
            }
            else
            {
                JSON_MOBCombineResut = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON_MOBCombineResut = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        return "{\"MOBCombineResult\":" + JSON_MOBCombineResut + ",\"ErMsg\":\"" + ErMsg + "\"}";

    }

}
