﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class MOB_MOBQ080a : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {



        DataTable dtHistory = null;
        try
        {
            BOSDataParse objBOS = new BOSDataParse();



            DataSet dsReturn = new DataSet();

            var kind = Request["kind"];  // kind=0; 彙總  kind=1 明細

            var type = Request["type"];// type=0; 當日  type=1 歷史

            var currency = Request["currency"];
            var date1 = Request["date1"].Replace("/", "");
            var date2 = Request["date2"].Replace("/", "");

            var accid = Request["accid"];
            var comid = Request["comid"];
            var comtype = Request["comtype"];
            var comym = Request["comym"];

            var min_price = Request["min_price"];
            var max_price = Request["max_price"];

            var cp = Request["cp"];


            if (kind == "0")
            {
                dsReturn = objBOS.getEquityCollect(type, "DDSC", comid, accid, date1, date2, currency, comtype, comym, min_price, max_price, cp);

            }
            else
            {
                dsReturn = objBOS.getEquityDetail(type, "DDSC", comid, accid, date1, date2, currency);

            }


            if (dsReturn.Tables[0].Rows.Count > 0)
            {
                string strJs = "<script>alert('查無資料');window.close();</script>";
                Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);

                return;
            }
            else
            {
                dtHistory = dsReturn.Tables[1];

                if (kind == "0")//彙總  
                {


                    dtHistory.Columns["OFFSETDATE"].ColumnName = "平倉日期  ";

                    dtHistory.Columns["ProductName"].ColumnName = "商品代碼";
                    if (type == "0")//歷史
                        dtHistory.Columns["GiveUp"].ColumnName = "放棄口數";
                    dtHistory.Columns["OFFSETQTY"].ColumnName = "平倉口數";
                    dtHistory.Columns["CURRENCY"].ColumnName = "幣別";
                    dtHistory.Columns["charge"].ColumnName = "手續費";
                    dtHistory.Columns["tax"].ColumnName = "期交稅";
                    dtHistory.Columns["OSPRTLOS"].ColumnName = "交易損益";
                    dtHistory.Columns["equity"].ColumnName = "淨損益";

                    dtHistory.Columns["ordtype"].ColumnName = "類型";
                }
                else
                {
                    dtHistory.Columns["SeqNo"].ColumnName = "序號";
                    dtHistory.Columns["OFFSETDATE"].ColumnName = "平倉日期  ";
                    dtHistory.Columns["OPTTRDDT"].ColumnName = "成交日期";
                    dtHistory.Columns["ORDNO"].ColumnName = "委託單號";
                    dtHistory.Columns["ProductName"].ColumnName = "商品代碼";
                    dtHistory.Columns["PS"].ColumnName = "買賣別";
                    dtHistory.Columns["PRICE"].ColumnName = "成交價";
                    dtHistory.Columns["OFFSETQTY"].ColumnName = "平倉口數";
                    dtHistory.Columns["CURRENCY"].ColumnName = "幣別";
                    dtHistory.Columns["charge"].ColumnName = "手續費";
                    dtHistory.Columns["tax"].ColumnName = "期交稅";
                    dtHistory.Columns["OSPRTLOS"].ColumnName = "交易損益";
                    dtHistory.Columns["equity"].ColumnName = "淨損益";

                    dtHistory.Columns["ordtype"].ColumnName = "類型";
                }


            }



        }
        catch (Exception ex)
        {
            throw;
        }



        GridView1.DataSource = dtHistory;
        GridView1.DataBind();


        if (dtHistory.Rows.Count == 0)
        {
            string strJs = "<script>alert('查無資料');window.close();</script>";
            Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
        }
        else
        {
            GridView1.DataSource = dtHistory;
            GridView1.DataBind();
            ExportExcel("MOBQ060", GridView1);
        }

        // ExportExcel("MOBQ080", GridView1);
    }

    //匯出EXCEL
    public void ExportExcel(string strExportFileName, Control webControl)
    {
        try
        {
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "";
            //Response.Cache.SetCacheability(HttpCacheability.NoCache)

            Response.Cache.SetCacheability(HttpCacheability.Public);

            Response.ContentType = "application/vnd.ms-excel";
            var stringWrite = new StringWriter();
            var htmlWrite = new HtmlTextWriter(stringWrite);

            var hf = new HtmlForm();
            Controls.Add(hf);
            hf.Controls.Add(webControl);
            hf.RenderControl(htmlWrite);
            Response.Write(stringWrite.ToString());
            Response.End();

        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }
}
