﻿using System;
using System.Web.Services;
using System.Data;
using Newtonsoft.Json;

public partial class MOB_MOBQ080 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {

        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------

            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}
            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
                lblBranch.Text = comp_id;
                lblAccount.Text = acct_id;
            }
        }
    }
    [WebMethod()]
    public static string QueryMOBQ080(string productKind, string startDate, string endDate, string strSort, string ACCT_ID, string COMP_ID, string PARAM) 
    {
        string jsonDtHistory;
        string ErMsg = "";
        string[] strFilter = strSort.Split(',');

        try
        {
            DataTable dtHistory = null;

            var ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            startDate = startDate.Replace("/", "");
            endDate = endDate.Replace("/", "");



            DataTable dtReturn = new DataTable();
            dtReturn = ws.WS_getHistoryFOTORD_List(COMP_ID, ACCT_ID, productKind, startDate, endDate);
            if (dtReturn.Columns.Contains("error") )
            {
                jsonDtHistory = "{}";
                ErMsg = dtReturn.Rows[0]["Error"].ToString();
            }
            else
            {
                dtHistory = dtReturn;
                var vdtHistory = dtHistory.DefaultView;

                if (strFilter.Length > 1)
                    switch (strFilter[0])
                    {
                        case "1":
                            vdtHistory.Sort = "ORDDT " + strFilter[1];
                            break;

                        case "2":
                            vdtHistory.Sort = "ProductName " + strFilter[1];
                            break;
                    }

                dtHistory = vdtHistory.ToTable();

                jsonDtHistory = JsonConvert.SerializeObject(dtHistory);// fh.DT_To_JSON(dtHistory);
            }






        }
        catch (Exception ex)
        {
            jsonDtHistory = "{}";
            ErMsg = "WSError:" + ex.Message.ToString();
        }

        return "{\"dtHistory\":" + jsonDtHistory + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }
}
