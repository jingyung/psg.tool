﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class MOB_MOBQ040a : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DataTable dtHistory = null;
        try
        {
            BOSDataParse objBOS = new BOSDataParse();


            DataSet dsReturn = new DataSet();

            var ACCT_ID = Request["ACCT_ID"];
            var COMP_ID = Request["COMP_ID"];
            var sSingle = Request["Single"];
            var sort = Request["SORT"];



            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = "";

            if (sSingle == "1")
            {
                if (sort == "StrikePrice")
                    ss = ws.WS_getReal_Position("1", COMP_ID, ACCT_ID).OuterXml;
                else
                    ss = ws.WS_getReal_PositionSortByCP("1", COMP_ID, ACCT_ID).OuterXml;
            }
            else
            {
                if (sort == "StrikePrice")
                    ss = ws.WS_getReal_UnLiquidation(COMP_ID, ACCT_ID, "NTT").OuterXml;
                else
                    ss = ws.WS_getReal_UnLiquidationSortByCP(COMP_ID, ACCT_ID, "NTT").OuterXml;
            }

            System.IO.StringReader xml = new System.IO.StringReader(ss);
            dsReturn.ReadXml(xml);

            DataTable _UnLiquidationMain = null;
            if (dsReturn.Tables.Count > 0)
            {

                if (sSingle == "1")
                {

                    dtHistory = dsReturn.Tables[0];
                }
                else
                {
                    dtHistory = dsReturn.Tables[0];
                    DataRow[] foundRows = dtHistory.Select("productKind IN ('3','4') ");
                    _UnLiquidationMain = dtHistory.Clone();
                    if (foundRows != null && foundRows.Length > 0)
                    {
                        foreach (DataRow itemR in foundRows)
                        {
                            _UnLiquidationMain.ImportRow(itemR);
                        }
                    }
                    else
                    {

                    }
                    dtHistory = _UnLiquidationMain;
                }
            }

            if (dtHistory == null)
            {
                string strJs = "<script>alert('查無資料');window.close();</script>";
                Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
                return;
            }
            //dtHistory = dsReturn.Tables[0]








            if (dtHistory.Rows.Count == 0)
            {
                string strJs = "<script>alert('查無資料');window.close();</script>";
                Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
            }
            else
            {
                if (sSingle == "1")//單式
                {
                    ExportExcelSingle("MOBQ040", dtHistory);
                }
                else
                {
                    ExportExcel("MOBQ040", dtHistory);
                }
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    public void ExportExcelSingle(string strExportFileName, DataTable dt)
    {

        try
        {
            this.Response.Clear();

            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode("strExportFileName", Encoding.UTF8) + ".xls");
            Response.Charset = "big5";
            Response.Cache.SetCacheability(HttpCacheability.Public);
            Response.ContentType = "application/vnd.xls";
            Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
            //  StringBuilder szHtml = new StringBuilder();
            string szHtml = "";
            szHtml = @"  <table    border=1  width='1150' id='tbData'>
                <thead>
                 <tr>
                 
                 <th class='style_ProductId' width='250' rowspan=2  >
                            商品
                        </th>
                         <th class='style_ProductId'  colspan=2>
                            昨日留倉
                        </th>
                        <th class='style_ProductId'   colspan=2>
                            本日委託
                        </th>
                          <th class='style_ProductId'  colspan=2>
                            目前成交
                        </th>
                          <th class='style_ProductId' width='150' rowspan=2>
                            本日了結
                        </th>
                           <th class='style_ProductId'  colspan=2>
                            目前留倉
                        </th>
                          <th class='style_ProductId' width='150' rowspan=2>
                            即時價位
                        </th>
                            <th class='style_ProductId'   colspan=2>
                            平均成本
                        </th>
                          <th class='style_ProductId'   colspan=2>
                            價差點數
                        </th>
                           <th class='style_ProductId' width='150' rowspan=2>
                            浮動損益
                        </th>
                    </tr>
                    <tr>
         
                        <th class='style_ProductId' width='110'>
                             買 
                        </th>
                        <th class='style_ProductId' width='110'>
                             賣 
                        </th>
                        <th class='style_ProductId' width='110'>
                            買 
                        </th>
                        <th class='style_ProductId' width='110'>
                            賣 
                        </th>
                        <th class='style_ProductId' width='110'>
                             買 
                        </th>
                        <th class='style_ProductId' width='110'>
                             賣 
                        </th>
                      
                        <th class='style_ProductId' width='110'>
                             買 
                        </th>
                        <th class='style_ProductId' width='110'>
                            賣 
                        </th>
                      
                        <th class='style_ProductId' width='110'>
                             買 
                        </th>
                        <th class='style_ProductId' width='110'>
                             賣 
                        </th>
                        <th class='style_ProductId' width='110'>
                             買
                        </th>
                        <th class='style_ProductId' width='110'>
                             賣
                        </th>
                        
                        
                        <!-- <th class='style_ProductId' width='100'>
                            手續費
                        </th>
                        <th class='style_ProductId' width='100'>
                            期交稅
                        </th> -->
              
                        <!--<th class='style_originalCost' width='100'>
                            原始投入金額
                        </th>
                        <th class='style_ProductId' width='100'>
                            報酬率
                        </th>-->
                    </tr>
                   
                </thead>
            <tbody>";

            foreach (DataRow dr in dt.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["OTQtyB"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["OTQtyS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["NowOrderQtyB"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["NowOrderQtyS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["NowMatchQtyB"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["NowMatchQtyS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TodayEnd"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["NowOTQtyB"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["NowOTQtyS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RealPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["AvgCostB"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["AvgCostS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["PriceDiffB"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["PriceDiffS"].ToString();
                szHtml += "</td>";

                szHtml += "<td>" + dr["PricePL"].ToString();
                szHtml += "</td>";

                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";
            Response.Write(szHtml.ToString());

            Response.End();
        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }



    public void ExportExcel(string strExportFileName, DataTable dt)
    {
        try
        {

            this.Response.Clear();

            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "big5";
            Response.Cache.SetCacheability(HttpCacheability.Public);
            Response.ContentType = "application/vnd.xls";
            Response.Write("<meta http-equiv=Content-Type content=text/html;charset=utf-8>");
            //  StringBuilder szHtml = new StringBuilder();
            string szHtml = "";
            szHtml = @"  <table    width='800' id='tbData2' border=1>
        <thead>
        <tr><th class='style_ProductId' width='100'>組合總類</th>
        <th class='style_ProductId' width='250'>商品</th>
        <th class='style_ProductId'  width='100'>買賣</th>
        <th class='style_ProductId' width='100'>留倉總數</th>
        <th class='style_ProductId' width='100'>即時價位</th>
        <th class='style_ProductId' width='100'>平均成本</th>
        <th class='style_ProductId' width='100'>價差</th>
        <th class='style_ProductId' width='100'>浮動損益</th>
        <th class='style_ProductId' width='100'>幣別</th>
        <th class='style_ProductId' width='100'>複式各腳價位</th></tr>
        </thead><tbody>";

            foreach (DataRow dr in dt.Rows)
            {
                szHtml += "<tr>";
                szHtml += "<td>" + dr["MultiName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["productName"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["multipleBS"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["TotalOTQTY"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["realPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["AvgMatchPrice"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["PriceDiff"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["RefTotalPL"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["currency"].ToString();
                szHtml += "</td>";
                szHtml += "<td>" + dr["footMatchPrice"].ToString();
                szHtml += "</td>";


                szHtml += "</tr>";
            }

            szHtml += "</tbody></table>";
            Response.Write(szHtml.ToString());

            Response.End();

        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }

}
