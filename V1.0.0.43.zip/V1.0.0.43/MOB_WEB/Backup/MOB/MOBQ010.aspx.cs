﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;

using System.Configuration;
public partial class MOB_MOBQ010 : BasePage  
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=
            
            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";
            
            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------



            TestCounter.Visible = false;
            TestTimerButton.Visible = false;
            

            if (Request["TEST_CASE"] == "RUN")
            {
                this.TEST_CASE.Value = "RUN";
            }
            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}

            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            { 
                this.company.Value = comp_id;
                this.account.Value = acct_id;
            }
            
            

            
           

        }
    }

    
    //string OriginalstrData = "Q  10.72.205.198:3143      400000018IF00800098111392010/06/10TWD+00001.0000+000000000000.00+000000000000.00+000010000000.00-000000043800.00-000000130800.00-000000009000.00-000000008850.00-000000021500.00+000000011396.00+000000000737.00+000000000000.00+000009791767.00+000000085250.00+000000624250.00+000000490250.00+000009159717.00+000000003650.00+000000000000.00+000009795417.00+0000018.1665+0000023.7088+0000018.1733+000009795417.00+000000000018.16+000009159717.00201006101452241\n";

    ////當日損益
    //string OriginalstrData = "S  10.72.205.198:3143      500000019IF0080009811139TWD-000000139650.00+000000003650.00-000000000000.00-000000000000.00-000000000000.001\n";

    ////未平倉  此次查詢為回兩筆
    //"  10.72.205.198:3143      600000020F008000981113905ITIMz2002 112010/06/10B1TXO    201006007200CN0001000380000000000-00000008850000000000000000000F04690TWD002500000000000000000000050000000000000000ITIMz5001 112010/06/10B0FITX   201006000000NN0001070370000000000-00000061400000007700000059000F04697TWD074680000000000000000000200000000000000000ITIMz7002 112010/06/10B0FITX   201006000000NN0001070370000000000-00000061400000007700000059000F04697TWD074680000000000000000000200000000000000000ITIMz4001 112010/06/10B0FITX   201006000000NN0001070370000000000-00000015800000007700000059000F04697TWD072400000000000000000000200000000000000000ITIMz2001 112010/06/10B0FITX   201006000000NN0001070370000000000+00000001600000007700000059000F04697TWD071530000000000000000000200000000000000000\v"
    //"  10.72.205.198:3143      600000020F008000981113903ITIMz3001 112010/06/10B0FITX   201006000000NN0001070370000000000+00000001600000007700000059000F04697TWD071530000000000000000000200000000000000000ITIMz0001 112010/06/10B0FITX   201006000000NN0001070370000000000+00000001800000007700000059000F04697TWD071520000000000000000000200000000000000000ITIMz1001 112010/06/10B0FITX   201006000000NN0001070370000000000+00000002800000007700000059000F04697TWD071470000000000000000000200000000000000000\n"

    ////即時部位   此次查詢為回兩筆
    //"W  10.72.205.198:3143      300000017IF00800098111391TWDFITX   201006N000000000000000009000200090000000100070000+7254.428+     nan+000000539000.00+000000000000.00+000000413000.00+000000000000.000000000002000000000000000000\n"
    //"W  10.72.205.198:3143      300000017IF00800098111391TWDTXO    201006C007200000000000002000400020000000100010000+51031.00+     nan+000000000000.00+000000000000.00+000000000000.00+000000000000.000000000000500000000000000009\n"
        
    
        
    [WebMethod()]
    public static string QueryMOBQ010(string Currency, string ACCT_ID, string COMP_ID, string PARAM) 
    {
        //System.Threading.Thread.Sleep(3000);
        string ErMsg = string.Empty;
        string JSON_Margin = string.Empty;
        FunctionHandler fh = new FunctionHandler();
        MobDataParse mobData = new MobDataParse();
        ////string OriginalstrData = "Q  10.72.205.198:3143      400000018IF00800098111392010/06/10TWD+00001.0000+000000000000.00+000000000000.00+000010000000.00-000000043800.00-000000130800.00-000000009000.00-000000008850.00-000000021500.00+000000011396.00+000000000737.00+000000000000.00+000009791767.00+000000085250.00+000000624250.00+000000490250.00+000009159717.00+000000003650.00+000000000000.00+000009795417.00+0000018.1665+0000023.7088+0000018.1733+000009795417.00+000000000018.16+000009159717.00201006101452241\n";

        ////-----加入log記錄元件----
        //WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
        //WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
        ////------------------------

        ////判斷當天MOBGW是否關閉
        //bool closeday = false;
        //if (DateTime.Now.DayOfWeek.GetHashCode() == 0)
        //{
        //    closeday = ConfigurationSettings.AppSettings["MOBGW_CloseDay"].ToString().Contains("7");
        //}
        //else
        //{
        //    closeday = ConfigurationSettings.AppSettings["MOBGW_CloseDay"].ToString().Contains(DateTime.Now.DayOfWeek.GetHashCode().ToString());
        //}
        //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOB_ENDTIME"].ToString()))
        //{
        //    try
        //    {
        //        string[] OriginalstrData = fh.getMOB_CurrentMargin(ACCT_ID, Currency, COMP_ID, mobj_T1Log, mobj_T4Log);
        //        mobData.parseMobInfoData(OriginalstrData);


        //        string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
        //        Int32 idx = 0;
        //        for (idx = 0; idx < OriginalstrData.Length; idx++)
        //        {
        //            mobj_T4Log.WriteEntryData(OriginalstrData[idx].Substring(1, 27) + mobj_T4Log.T4b + T4e + OriginalstrData[idx]);
        //        }

        //        mobj_T1Log.WriteEntryData("=======" + PARAM);
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    finally
        //    {
        //        mobj_T1Log.Close();
        //        mobj_T4Log.Close();
        //    }
        //}
        //else
        //{
        //    mobj_T1Log.WriteEntryData("bos currency="+Currency+" Actno="+ACCT_ID +" company="+COMP_ID +" param="+PARAM );
        //    if (Currency == "TWD")
        //    {
        //        Currency = "NTT";
        //    }
        //    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);
        //      try
        //{
        //    WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
        //    DataTable dt = ws.WS_getMargin(COMP_ID, ACCT_ID, Currency);
        //    mobData.mdt_MOBCurrentMargin = dt;
        //    mobj_T4Log.WriteEntryData("count" + dt.Rows.Count.ToString());
        //}
        //catch (Exception ex1)
        //{
        //    return "{}";
        //}
         
        //}
        try
        { 

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();
            string ss = ws.WS_getReal_Margin(COMP_ID, ACCT_ID, Currency).OuterXml;

            System.IO.StringReader xml = new System.IO.StringReader(ss);
            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON_Margin = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {
                    mobData.mdt_MOBCurrentMargin = ds.Tables[0];
                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (mobData.mdt_MOBCurrentMargin != null && mobData.mdt_MOBCurrentMargin.Rows.Count > 0)
                    {
                        JSON_Margin = fh.DT_To_JSON(mobData.mdt_MOBCurrentMargin);
                    }
                    else
                    {
                        JSON_Margin = "{}";
                    }
                }
            }
            else
            {
                JSON_Margin = "{}";
            }
           
        }
        catch (Exception ex )
        {
            JSON_Margin = "{}";
            ErMsg = "WSError:"+ex.Message;
        }
        return " {\"Margin\":" + JSON_Margin + ",\"ErMsg\":\"" + ErMsg + "\" } ";
  
    }
}
