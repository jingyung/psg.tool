﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class MOB_MOBQ080a : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {


        DataTable dtHistory = null;
        try
        {
            BOSDataParse objBOS = new BOSDataParse();


            DataSet dsReturn = new DataSet();

            var currency = Request["currency"];
            var startDate = Request["date1"].Replace("/", "");
            var endDate = Request["date2"].Replace("/", "");

            dsReturn = objBOS.getHistoryMargin("DDSC", Request["comid"], Request["accid"], startDate, endDate, currency, Request["accid"]);

            if (dsReturn.Tables[0].Rows.Count > 0)
            {
                string strJs = "<script>alert('查無資料');window.close();</script>";
                Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
                return;
            }
            else
            {
                dtHistory = dsReturn.Tables[1];
            }
            //dtHistory = dsReturn.Tables[0]


        }
        catch (Exception ex)
        {
            throw;
        }

        dtHistory.Columns["TDDT"].ColumnName = "日期";
        dtHistory.Columns["Margin"].ColumnName = "帳戶權益數";
        dtHistory.Columns["ClearMargin"].ColumnName = "權益總值";
        dtHistory.Columns["TMPAB"].ColumnName = "期貨平倉損益淨額";
        dtHistory.Columns["PROLOS"].ColumnName = "未沖銷期貨浮動損益";
        dtHistory.Columns["DWAMT"].ColumnName = "存提";
        dtHistory.Columns["OP_TMPAB"].ColumnName = "選擇權平倉損益";
        dtHistory.Columns["OP_PROLOS"].ColumnName = "選擇權未平倉損益";
        dtHistory.Columns["FU1921"].ColumnName = "到期履約損益";
        dtHistory.Columns["BPREMIUM"].ColumnName = "買方權利金市值";
        dtHistory.Columns["SPREMIUM"].ColumnName = "賣方權利金市值";
        dtHistory.Columns["charge"].ColumnName = "期交稅";
        dtHistory.Columns["tax"].ColumnName = "手續費";
        dtHistory.Columns["SYSDATE"].ColumnMapping = MappingType.Hidden;
        GridView1.DataSource = dtHistory;
        GridView1.DataBind();


        if (dtHistory.Rows.Count == 0)
        {
            string strJs = "<script>alert('查無資料');window.close();</script>";
            Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
        }
        else
        {
            dtHistory.Columns.Remove("SYSDATE");
            dtHistory.Columns.Remove("SYSTIME");
            GridView1.DataSource = dtHistory;
            GridView1.DataBind();
            ExportExcel("MOBQ050", GridView1);
        }

        // ExportExcel("MOBQ080", GridView1);
    }

    //匯出EXCEL
    public void ExportExcel(string strExportFileName, Control webControl)
    {
        try
        {
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "";
            //Response.Cache.SetCacheability(HttpCacheability.NoCache)

            Response.Cache.SetCacheability(HttpCacheability.Public);

            Response.ContentType = "application/vnd.ms-excel";
            var stringWrite = new StringWriter();
            var htmlWrite = new HtmlTextWriter(stringWrite);

            var hf = new HtmlForm();
            Controls.Add(hf);
            hf.Controls.Add(webControl);
            hf.RenderControl(htmlWrite);
            Response.Write(stringWrite.ToString());
            Response.End();

        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw;
        }
    }
}
