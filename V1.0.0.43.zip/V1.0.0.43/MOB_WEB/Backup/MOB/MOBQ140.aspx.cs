﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Services;
public partial class MOB_MOBQ140 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";
            string id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
                //if (param[idx].ToUpper().IndexOf("IDNO") > -1)
                //{
                //    id = (param[idx].Split('='))[1];
                //}
               
            }





            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
                this.ID.Value = GetID(comp_id, acct_id);
               
            }
            this.IP.Value = this.Page.Request.UserHostAddress;


        }
    }
    public string GetID(string company, string actno)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {
            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            DataSet ds = new DataSet();

            string ss = ws.WS_getKEY(company, actno).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                return fh.fh_EncString(ds.Tables[0].Rows[0]["IDNO"].ToString());
            }
            else
            {
                return "";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return ErMsg;
    }


    [WebMethod()]
    public static string QueryMOBQ140(string company, string account, string begin_date, string end_date, string type)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            string ss = ws.WS_getOrderWithdrawFind( company, account, begin_date.Replace("/", ""), end_date.Replace("/", ""), type, "" ).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" +  ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"WITHDRAW\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }



}
