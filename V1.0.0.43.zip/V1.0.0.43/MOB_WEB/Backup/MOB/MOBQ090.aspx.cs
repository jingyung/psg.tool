﻿using System;
using System.Web.Services;
using System.Data;
using Newtonsoft.Json;

public partial class MOB_MOBQ090 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
         Response.HeaderEncoding = System.Text.Encoding.GetEncoding("big5");
         Response.ContentEncoding = System.Text.Encoding.GetEncoding("big5");
                                     
        if (this.IsPostBack)
        {

        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------

            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}
            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
            }
        }
    }
}
