﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Services;

using System.Collections.Generic;
public partial class MOB_MOBQ160 : BasePage
{

    public class clsTWHOLIDAY_SET
    {
        public string HOLIDAY_DATE { get; set; }
        public string NOTE { get; set; }
        public string TWDAY { get; set; }
        public string ACTION_TYPE { get; set; }

    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    [WebMethod()]
    public static string Get_Years()
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            string ss = ws.WS_Holiday_Year().OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"HOLIDAY\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }



    [WebMethod()]
    public static string Query(string year)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            string ss = ws.WS_Holiday_Year_Query(year).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"HOLIDAY\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }


    [WebMethod()]
    public static string Maintain_Save(WSBOSHistoryQuery.clsTWHOLIDAY_SET[] holiday)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            bool ret = ws.WS_HolidayMaintain(holiday);

            if (ret)
            {
                return " {\"HOLIDAY\":" + "{success}" + ",\"ErMsg\":\"" + "" + "\" } ";

            }
            else
            {
                return " {\"HOLIDAY\":" + "{}" + ",\"ErMsg\":\""  +"年度休假日建立失敗" + "\" } ";
            }

        }
        catch (Exception ex)
        {
            return " {\"HOLIDAY\":" + "{}" + ",\"ErMsg\":\"" + "WSError:" + ex.Message + "年度休假日建立失敗" + "\" } ";
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";

    }




    //產生年度假日
    [System.Web.Services.WebMethod()]
    public static string Generate_Holiday(string year)
    {
        try
        {
            FunctionHandler g_fh = new FunctionHandler();

            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            bool ret = ws.WS_ChkHoliday_Year(year);


            if (ret)
            {
                return " {\"HOLIDAY\":" + "{}" + ",\"ErMsg\":\"" + year + "年度休假日已存在" + "\" } ";

            }

            ret = ws.WS_AddHoliday_Year(year);
            if (ret)
            {
                return " {\"HOLIDAY\":" + "{success}" + ",\"ErMsg\":\"" + "" + "\" } ";

            }
            else
                return " {\"HOLIDAY\":" + "{}" + ",\"ErMsg\":\"" + year + "年度休假日建立失敗" + "\" } ";
        }
        catch (Exception ex)
        {
            return " {\"HOLIDAY\":" + "{}" + ",\"ErMsg\":\"" + "WSError:" + ex.Message + "年度休假日建立失敗" + "\" } ";
        }

    }
}