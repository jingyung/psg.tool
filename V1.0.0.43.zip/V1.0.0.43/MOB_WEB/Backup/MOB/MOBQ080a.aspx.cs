﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class MOB_MOBQ080a : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string[] strFilter = Request["sort"].Split(',');

        DataTable dtHistory = null;
        try
        {
            var ws = new WSBOSHistoryQuery.BOSHistoryQuery();

            var productKind = Request["pk"];
            var startDate = Request["date1"].Replace("/", "");
            var endDate = Request["date2"].Replace("/", "");

            dtHistory = ws.WS_getHistoryFOTORD_List(Request["comid"], Request["accid"], productKind, startDate, endDate);
        }
        catch (Exception ex)
        {
            throw;
        }
        var vdtHistory = dtHistory.DefaultView;

        if (strFilter.Length > 1)
            switch (strFilter[0])
            {
                case "1":
                    vdtHistory.Sort = "ORDDT " + strFilter[1];
                    break;

                case "2":
                    vdtHistory.Sort = "ProductName " + strFilter[1];
                    break;
            }

        dtHistory = vdtHistory.ToTable();

        dtHistory.Columns["ORDTIME"].ColumnName = "委託時間";
        dtHistory.Columns["ORDNO"].ColumnName = "委託單號";
        dtHistory.Columns["PS"].ColumnName = "買賣";
        dtHistory.Columns["productName"].ColumnName = "商品內容";
        dtHistory.Columns["OPENS"].ColumnName = "委託條件";
        dtHistory.Columns["UTPRICE1"].ColumnName = "委託價";
        dtHistory.Columns["ORDQTY"].ColumnName = "原委託";
        dtHistory.Columns["TRDQTY"].ColumnName = "已成交";
        dtHistory.Columns["TotalCancled"].ColumnName = "總取消";
        dtHistory.Columns["ENTTYPE"].ColumnName = "委託來源";
        dtHistory.Columns["ORDDT"].ColumnName = "交易日期";
        dtHistory.Columns["msgdata"].ColumnName = "狀態";
        dtHistory.Columns["DTOVER"].ColumnName = "當沖";

        GridView1.DataSource = dtHistory;
        GridView1.DataBind();


        if (dtHistory.Rows.Count == 0)
        {
            string strJs = "<script>alert('查無資料');window.close();</script>";
            Page.ClientScript.RegisterStartupScript(GetType(), "winclose", strJs);
        }
        else
        {
            GridView1.DataSource = dtHistory;
            GridView1.DataBind();
            ExportExcel("MOBQ080", GridView1);
        }

       // ExportExcel("MOBQ080", GridView1);
    }

    //匯出EXCEL
    public void ExportExcel(string strExportFileName, Control webControl)
    {
        try
        {
            Response.Clear();
            Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlEncode(strExportFileName, Encoding.UTF8) + ".xls");
            Response.Charset = "";
            //Response.Cache.SetCacheability(HttpCacheability.NoCache)

            Response.Cache.SetCacheability(HttpCacheability.Public);

            Response.ContentType = "application/vnd.ms-excel";
            var stringWrite = new StringWriter();
            var htmlWrite = new HtmlTextWriter(stringWrite);

            var hf = new HtmlForm();
            Controls.Add(hf);
            hf.Controls.Add(webControl);
            hf.RenderControl(htmlWrite);
            Response.Write(stringWrite.ToString());
            Response.End();

        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            throw ;
        }
    }
}
