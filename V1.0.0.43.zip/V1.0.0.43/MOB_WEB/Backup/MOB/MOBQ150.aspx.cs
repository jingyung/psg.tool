﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Services;
public partial class MOB_MOBQ150 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";
            string id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("IDNO") > -1)
                {
                    id = (param[idx].Split('='))[1];
                }

            }





            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.txtCompany.Value = comp_id;
                this.txtACC_ID.Value = acct_id;
              

            }
          


        }
    }


    [WebMethod()]
    public static string QueryIB()
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            string ss = ws.WS_getIB().OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"IB\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }


    [WebMethod()]
    public static string QueryWitrhDrawTime(string type)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            string ss = ws.WS_getWITHDRAWTIME(type).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"WitrhDrawTime\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }



    [WebMethod()]
    public static string QueryMOBQ150(string company, string account, string begin_date, string end_date, string type,string currency,string time,string order)
    {
        string ErMsg = string.Empty;
        string JSON = string.Empty;
        try
        {

            FunctionHandler fh = new FunctionHandler();


            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            DataSet ds = new DataSet();

            string ss = ws.WS_getOrderWithdrawFindForMGM(company, account, begin_date.Replace("/", ""), end_date.Replace("/", ""), type, currency, time, order).OuterXml;


            System.IO.StringReader xml = new System.IO.StringReader(ss);

            ds.ReadXml(xml);
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Columns.Contains("error"))
                {

                    JSON = "{}";

                    ErMsg = ds.Tables[0].Rows[0]["error"].ToString();
                }
                else
                {

                    //DataTable dt = mobData.GetMOBCurrentMarginDT(COMP_ID, ACCT_ID, Currency);

                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        JSON = fh.DT_To_JSON(ds.Tables[0]);
                    }
                    else
                    {
                        JSON = "{}";
                    }
                }
            }
            else
            {
                JSON = "{}";
            }
        }
        catch (Exception ex)
        {
            JSON = "{}";
            ErMsg = "WSError:" + ex.Message;
        }
        //return JSON_HistoryMargin;
        //return "{\"HM\":" + JSON_HistoryMargin + "}";
        return " {\"WITHDRAW\":" + JSON + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }



}
