﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;

using System.Configuration;
public partial class MOB_MOBQ060 : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //
        }
        else
        {
            //----取得參數--------------
            string rawURL = Request.RawUrl;
            string param_str = rawURL.Substring(rawURL.IndexOf("?") + 7); //--?param=

            FunctionHandler fh = new FunctionHandler();
            string decodeParam = fh.fh_EncString(param_str);
            string[] param = decodeParam.Split('&');

            string comp_id = "";
            string acct_id = "";

            for (Int32 idx = 0; idx < param.Length; idx++)
            {
                if (param[idx].ToUpper().IndexOf("COMP_ID") > -1)
                {
                    comp_id = (param[idx].Split('='))[1];
                }
                if (param[idx].ToUpper().IndexOf("ACCT_ID") > -1)
                {
                    acct_id = (param[idx].Split('='))[1];
                }
            }
            //------------------------

            //-----log---
            //BasePage.Employee _Emp = Session["OnUser"] as BasePage.Employee;
            //if (_Emp != null)
            //{
            //    this.company.Value = _Emp.COMP_ID;
            //    this.account.Value = _Emp.ACCT_ID;
            //}
            //----------
            //if ((Request.QueryString["COMP_ID"] != null) && (Request.QueryString["COMP_ID"].Length > 0) && (Request.QueryString["ACCT_ID"] != null) && (Request.QueryString["ACCT_ID"].Length > 0))
            //{
            //    this.company.Value = Request.QueryString["COMP_ID"];
            //    this.account.Value = Request.QueryString["ACCT_ID"];
            //}
            if (User.Identity.Name.Trim() != acct_id)
            {
                System.Web.Security.FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                this.company.Value = comp_id;
                this.account.Value = acct_id;
            }

            for (int i = -3; i < 16; i++)
            {
                SelectMonth.Items.Add(new ListItem(DateTime.Now.AddMonths(i).ToString("yyyyMM"), DateTime.Now.AddMonths(i).ToString("yyyyMM")));
            }
        }


        this.btnMonth1.Value = DateTime.Now.ToString("yyyy/MM");
        this.btnMonth2.Value = DateTime.Now.AddMonths(-1).ToString("yyyy/MM");
        this.btnMonth3.Value = DateTime.Now.AddMonths(-2).ToString("yyyy/MM");
        this.btnMonth4.Value = DateTime.Now.AddMonths(-3).ToString("yyyy/MM");
        this.btnMonth5.Value = DateTime.Now.AddMonths(-4).ToString("yyyy/MM");
        this.btnMonth6.Value = DateTime.Now.AddMonths(-5).ToString("yyyy/MM");
    }
    [WebMethod()]
    public static string QueryMOBQ060_getEquityCollect(string type, string SourceType, string company, string account, string begin_date, string end_date, string currency, string comtype, string comym, string min_price, string max_price, string CP)
    {
        string ErMsg = "";
        string JSON_Collect = string.Empty;
        FunctionHandler fh = new FunctionHandler();
        BOSDataParse objBOS = new BOSDataParse();
        DataTable Collect = null;
        try
        {
         
            //if (type == "1" && (DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["BOS_CloseTime"].ToString())))
            //{
            //    JSON_Collect = "{}";
            //    //throw; 
            //    ErMsg = "14:30～16:30進行轉檔作業，16:30後請從歷史資料查詢 !!";

            //}
            //else
            //{
                DataSet dsReturn = new DataSet();
                dsReturn = objBOS.getEquityCollect(type, SourceType, company, account, begin_date.Replace("/", string.Empty), end_date.Replace("/", string.Empty), currency, comtype, comym, min_price, max_price, CP);
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    JSON_Collect = "{}";
                    ErMsg = dsReturn.Tables[0].Rows[0]["Error"].ToString();
                }
                else
                {
                    Collect = dsReturn.Tables[1];
                    JSON_Collect = fh.DT_To_JSON(Collect);
                }

            //}
        }
        catch(Exception ex)
        {
              JSON_Collect = "{}";
              ErMsg = ex.Message;
        }
        return " {\"Collect\":" + JSON_Collect + " ,\"ErMsg\":\"" + ErMsg + "\" } ";
    }
    [WebMethod()]
    public static string QueryMOBQ060_getEquityDetail(string type, string SourceType, string company, string account, string begin_date, string end_date, string currency)
    {
        string ErMsg = "";
        string JSON_Details = string.Empty;
        FunctionHandler fh = new FunctionHandler();
        BOSDataParse objBOS = new BOSDataParse();
        DataTable Details = null;
        try
        {
            
            //if (type == "1" && (DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["BOS_CloseTime"].ToString())))
            //{
            //    JSON_Details = "{}";
            //    //throw; 
            //    ErMsg = "14:30～16:30進行轉檔作業，16:30後請從歷史資料查詢 !!";

            //}
            //else
            //{
                DataSet dsReturn = new DataSet();
                dsReturn = objBOS.getEquityDetail(type, SourceType, company, account, begin_date.Replace("/", string.Empty), end_date.Replace("/", string.Empty), currency);
                if (dsReturn.Tables[0].Rows.Count > 0)
                {
                    JSON_Details = "{}";
                    ErMsg = dsReturn.Tables[0].Rows[0]["Error"].ToString();
                }
                else
                {
                    Details = dsReturn.Tables[1];
                    JSON_Details = fh.DT_To_JSON(Details);
                }


            //}
        }
        catch (Exception ex)
        {
            JSON_Details = "{}";
            //throw;
            ErMsg = ex.Message ;
        }
        return " {\"Details\":" + JSON_Details + ",\"ErMsg\":\"" + ErMsg + "\" } ";
    }
}
