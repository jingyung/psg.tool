﻿var _sysname = "MOB_WEB";
var g_hostAddress = document.location.protocol + "//" + document.location.host + "/" + _sysname;

$().ready(function()
{

    $("input.NumCtrl_L").keypress(function(event)
    {
        return CheckCharCode(event);

    });
    $("input.NumCtrl_L").focus(function(event)
    {
        e = fh_GetEvent(event);
        e.value = e.value.replace(/,/g, "");
        e.select();
    });
    $("input.NumCtrl_L").keyup(function(event)
    {
        e = fh_GetEvent(event);
        if (e.value != "")
        {
            if (CheckCharCode(event))// Numbers
            { }
            else
            {
                GetValue(e.value, e.id, event)
            }
        }
    });
    $("input.NumCtrl_L").blur(function(event)
    {
        e = fh_GetEvent(event);
        if (e.value != "")
        {
            var keyVal = (event.charCode ? event.charCode : ((event.vlaue) ? event.keyCode : event.which));
            if (CheckCharCode(event))// Numbers
            { }
            else
            {
                if (isNaN(e.value.replace(/,/g, "")))
                {
                    e.value = "";
                }
            }
        }
    });


    $("input.NumCtrl").keypress(function(event)
    {
        return CheckCharCode(event);

    });
    $("input.NumCtrl").focus(function(event)
    {

        e = fh_GetEvent(event);
        e.value = e.value.replace(/,/g, "");
        e.select();
    });
    $("input.NumCtrl").keyup(function(event)
    {
        e = fh_GetEvent(event);
        if (e.value != "")
        {
            if (CheckCharCode(event))// Numbers
            { }
            else
            {
                GetValue(e.value, e.id, event)
            }
        }
    });
    $("input.NumCtrl").blur(function(event)
    {
        e = fh_GetEvent(event);
        if (e.value != "")
        {
            var keyVal = (event.charCode ? event.charCode : ((event.vlaue) ? event.keyCode : event.which));
            if (CheckCharCode(event))// Numbers
            { }
            else
            {
                e.value = fh_ConvertToAccountFormate(GetValue(e.value, undefined, event));
                if (isNaN(e.value.replace(/,/g, "")))
                {
                    e.value = "";
                }
            }
        }
    });

    $("input.DateCtrl").keypress(function(event)
    {
        return CheckCharCode(event, "Date");

    });
    $("input.DateCtrl").focus(function(event)
    {
        e = fh_GetEvent(event);
        var deleteChar = "/";
        e.value = e.value.replace(new RegExp(deleteChar, "g"), "");
        e.select();
    });
    $("input.DateCtrl").keyup(function(event)
    {
        e = fh_GetEvent(event);
        if (e.value != "")
        {
            if (CheckCharCode(event, "Date"))// Numbers
            { }
            else
            {
                GetValue(e.value, e.id, event, "Date")
            }
        }
    });
    $("input.DateCtrl").blur(function(event)
    {
        e = fh_GetEvent(event);
        if (e.value != "")
        {
            var keyVal = (event.charCode ? event.charCode : ((event.vlaue) ? event.keyCode : event.which));
            if (CheckCharCode(event, "Date"))// Numbers
            { }
            else
            {
                var m_value = GetValue(e.value, undefined, event, "Date");
                if (m_value.toString().length == 8)
                {
                    e.value = m_value.substr(0, 4) + "/" + m_value.substr(4, 2) + "/" + m_value.substr(6, 2);
                }
                else
                {
                    e.value = m_value;
                }
                // e.value = m_value;

            }
        }
    });
    if ($("input.DateCtrl").datepicker != undefined)
    {

        if (document.location.host.indexOf("localhost") != -1)
        {
            g_hostAddress = "";
        }
        if (this.location.pathname == "/Default.aspx")
        {
            $("input.DateCtrl").datepicker({ dateFormat: 'yy/mm/dd', showOn: 'both',
                buttonImageOnly: true, buttonImage: g_hostAddress + '/images/btn_cal.jpg'
            });
        } else
        {
            $("input.DateCtrl").datepicker({ dateFormat: 'yy/mm/dd', showOn: 'both',
                buttonImageOnly: true, buttonImage: g_hostAddress + '/images/btn_cal.jpg'
            });
        }

    }


});

function chineseCount(word)
{
    if (word != " ")
    {
        var ReturnNum = 0
        for (cc = 0; cc < word.length; cc++)
        {
            c = word.charCodeAt(cc);
            if (!(c >= 32 && c <= 126)) ReturnNum++;
        }
        return ReturnNum;
    }
    else
    {
        return 1;
    }
}
function SetValue(m_ElementId, m_value, m_flag)
{
    document.getElementById(m_ElementId).value = m_value;
    if (m_flag == "C")
    {
        alert(LanguageManagerBySingle("MSG033"));
    }

    document.getElementById(m_ElementId).value = m_value;
    clearTimeout(setTimeout1);
}

function CheckCharCode(event,Type)
{
    try
    {
        var m_MaxLength = 0;
        var m_NumberLength = 0;
        var m_FloatLength = 0;
        
        e = fh_GetEvent(event);
        if (Type == "Date")
        {
            m_MaxLength = 8;
            m_FloatLength = 0;
        }
        else
        {
            if (e.maxLength != "")
            {
                m_MaxLength = parseInt(e.lang.split(",")[0]) + parseInt(e.lang.split(",")[1]) + 1;
                m_NumberLength = parseInt(e.lang.split(",")[0]);
                m_FloatLength = parseInt(e.lang.split(",")[1]);
                m_MaxLength = m_NumberLength + m_FloatLength + (m_FloatLength == 0 ? 0 : 1);
                
            }
        }
        e.maxLength = m_MaxLength;
        var keyVal = (event.charCode ? event.charCode : ((event.keyCode) ? event.keyCode : event.which));
        var ChkSub;
        if (Type == undefined)
        {
            ChkSub = keyVal == 45;
        }
        else
        {
            ChkSub = false;
        }

        if (e.value == "" && ChkSub)
        {
            return true;
        } else
        {
            if (m_FloatLength == 0)
            {
                if (keyVal == 46)
                {
                    return false;
                }
                else if (keyVal == 37)
                {
                    return true;
                }
                else if (keyVal == 39)
                {
                    return true;
                }
                else
                {
                    return CheckFormat(keyVal);
                }
            }
            else
            {
                if (e.value.indexOf(".") == -1)
                {
                    return CheckFormat(keyVal);
                }
                else
                {
                    if (keyVal == 46)
                    {
                        return false;
                    }
                    else if (keyVal == 37)
                    {
                        return true;
                    }
                    else if (keyVal == 39)
                    {
                        return true;
                    }
                    else if (keyVal == 8)
                    {
                        return true;
                    }
                    else
                    {
                        return CheckFormat(keyVal);
                    }
                }
            }
        }
    }
    catch (e)
    {
        alert(e.toString())
    }

}
function CheckFormat(keyVal)
{
    try
    {
        if (keyVal != undefined)
        {
            if ((keyVal >= 48 && keyVal <= 57))// Numbers
            {
                return true;
            }
            else
            {
                if (keyVal == 46)
                {
                    return true;
                }
                else if (keyVal == 37)
                {
                    return true;
                }
                else if (keyVal == 39)
                {
                    return true;
                }
                else if (keyVal == 8)
                {
                    return true;
                }
                else if (keyVal == 45)
                {
                    return true;
                }
                else if (keyVal == 190)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
    catch (e)
    {
        alert(e.toString())
    }

}

function GetValue(m_srcElement, srcElement_id, e,Type)
{
    try
    {
        e = fh_GetEvent(e);
        var m_ReplaceStr = "";
        var is_Don = false;
        var is_Sub = false;
        var is_Replace = false;
        var i_Median = 0;
        var i_Number = 0;
        var m_flag = "N";
        var m_MaxLength = 0;
        var m_FloatLength = 0;
        var m_NumberLength = 0;
        if (Type == "Date")
        {
            m_MaxLength = 10;
            m_FloatLength = 0;
        }
        else
        {
            if (e.value.indexOf("-") == -1)
            {
                //m_MaxLength = e.lang.split(",")[0];

                m_MaxLength = parseInt(e.lang.split(",")[0]) + parseInt(e.lang.split(",")[1]) + 1;
                m_NumberLength = parseInt(e.lang.split(",")[0]);
                m_FloatLength = parseInt(e.lang.split(",")[1]);
                m_MaxLength = m_NumberLength + m_FloatLength + (m_FloatLength == 0 ? 0 : 1);
                
            }
            else
            {
                //m_MaxLength = (parseInt(e.lang.split(",")[0]) + 1);

                m_MaxLength = parseInt(e.lang.split(",")[0]) + parseInt(e.lang.split(",")[1]) + 2;
                m_NumberLength = parseInt(e.lang.split(",")[0]);
                m_FloatLength = parseInt(e.lang.split(",")[1]);
                m_MaxLength = m_NumberLength + m_FloatLength + (m_FloatLength == 0 ? 0 : 1);
            }
        }
        for (var i = 0; i < e.value.length; i++)
        {
            if (chineseCount(m_srcElement.substr(i, 1)) == 0)
            {
                if ((!isNaN(m_srcElement.substr(i, 1))) || (m_srcElement.substr(i, 1) == ".") || (m_srcElement.substr(i, 1) == "-"))
                {
                    if (m_srcElement.substr(i, 1) == ".")
                    {
                        if (is_Don) { }
                        else
                        {
                            if (m_FloatLength == 0)
                            {

                            }
                            else
                            {
                                m_ReplaceStr += m_srcElement.substr(i, 1);
                            }
                            is_Don = true;
                        }
                    }
                    else if (m_srcElement.substr(i, 1) == "-")
                    {
                        if (Type == undefined)
                        {
                            if (is_Sub) { }
                            else
                            {
                                m_ReplaceStr += m_srcElement.substr(i, 1);
                                is_Sub = true;
                            } 
                        }
                    }
                    else
                    {
                        if (i_Median - 1 < m_FloatLength)
                        {
                            m_ReplaceStr += m_srcElement.substr(i, 1);
                        }
                    }
                    if (is_Don)
                    {
                        i_Median++;
                    }
                    else
                    {
                        i_Number++;
                    }
                }
            }
            else
            {
                m_flag = "C";
            }
        }
        if (parseInt(m_MaxLength) < i_Number)
        {
            m_ReplaceStr = m_ReplaceStr.substr(0, parseInt(m_MaxLength)) + (m_ReplaceStr.indexOf(".") != -1 ? m_ReplaceStr.substr(m_ReplaceStr.indexOf(".")) : "");
        }
        if (srcElement_id == undefined)
        {
            return m_ReplaceStr;
        }
        else
        {
            setTimeout1 = setTimeout("SetValue(\"" + srcElement_id + "\",\"" + m_ReplaceStr + "\",\"" + m_flag + "\")", 50);
        }
    }
    catch (e)
    {
        alert(e.toString())
    }
}
