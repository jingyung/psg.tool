﻿try
{
    loadJs('../ComJs/FunctionHandler.js');
    var p_Page = document.location.pathname;
    var  m_JsPage = p_Page.replace('aspx', 'js');
    m_JsPage = m_JsPage.substr(0, m_JsPage.lastIndexOf("/")) + "/js" + ((p_Page == "Home.aspx") ? "/" : "") + m_JsPage.substr(((m_JsPage.lastIndexOf("/")) == -1 ? 0 : m_JsPage.lastIndexOf("/")));
    loadJs('..' + m_JsPage);   
    
}
catch (e)
{
}
function loadJs(src)
{
    try
    {
        var s = document.createElement('script');
        s.setAttribute('type', 'text/javascript');
        s.setAttribute('src', src);
        var head = document.getElementsByTagName('head')[0];
        if (head) head.appendChild(s);
        else document.body.appendChild(s);
    }
    catch (e)
    {
    }


}


function loadCSS(src)
{
    var diFile = document.createElement("link");
    diFile.setAttribute("rel", "stylesheet");
    diFile.setAttribute("type", "text/css");
    diFile.setAttribute("href", src);

    if (typeof diFile != "undefined")
    {
        document.getElementsByTagName("head")[0].appendChild(diFile);
    }
}

   