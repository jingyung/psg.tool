var cabfileCAPI="../FSCAPIATL2.cab#Version=2,1,9,120";
var classidCAPI="CLSID:4B6C50D7-0E3F-4DB3-8998-F7AC9684C105";

var gDebug = 0;

/*
 *  FSCAIPATL ��������ѼƩw�q
 */
 	var FSCAPI_FLAG_READFILE_DELETE				=	0x00100000;

	var FSCAPI_FLAG_SELCERT_MANUAL				=	0x00000001;
	var FSCAPI_FLAG_SELCERT_AUTO 				= 	0x00000002 ;
	var FSCAPI_FLAG_SELCERT_MEMORY				=	0x00400000;

	var FSCAPI_FLAG_EXPORTABLE					=	0x00000001;
	var FSCAPI_FLAG_MEMORY						=	0x00400000;

	var FSCAPI_STORE_CU_FILE				=	0x00400000;

	var FS_KU_NON_REPUDIATION				= 	0x0040;
	var FS_KU_DIGITAL_SIGNATURE					=	0x0080;
	var FS_KU_KEY_ENCIPHERMENT					=	0x0020;
	var FS_KU_DATA_ENCIPHERMENT					=	0x0010;

	var FS_FLAG_SUBJECT_PARTIALMATCH			=	0x00080000;
	var FSCAPI_FLAG_SELCERT_MANUAL				=	0x00000001;
	var FSCAPI_FLAG_SELCERT_AUTO				=	0x00000002;
	var FSCAPI_FLAG_SELCERT_SELFAUTO			=	0x00000003;
	var FSCAPI_FLAG_SELCERT_AFTER 				=	0x00000004;
	var FSCAPI_FLAG_SELCERT_OLDEST				= 	0x00000008;
	var FSCAPI_FLAG_SELCERT_CHECKVALID 			=	0x00000010;	
	
	var FSCAPI_FLAG_ENABLE_EMPTY_PASSWORD		=	0x00001000;
	var FSCAPI_FLAG_SELCERT_USEIE				=	0x00002000;
	
	var FS_FLAG_CERT_ATTACHALL					= 	0x00000200;	

	var FS_FLAG_VERIFY_CONTENT_ONLY				=	0x00000000;
	var FS_FLAG_VERIFY_CERTCHAIN				=	0x00000001;
	var FS_FLAG_VERIFY_CRL						=	0x00000002;
	var FS_FLAG_VERIFY_FULL						=	0x00000003;


	var FS_FLAG_DETACHMSG						=	0x00004000;

	var FS_FLAG_SUBJECT_COMMON_NAME				=	0x00010000;
	var FS_FLAG_SUBJECT_RSA_EMAILADDR			=	0x00020000;
	var FS_FLAG_SUBJECT_ORGANIZATION_NAME 		= 0x00040000;
	var FS_FLAG_SUBJECT_ORGANIZATIONAL_UNIT_NAME = 0x00080000;
	var FS_FLAG_SUBJECT_COUNTRY_NAME			= 0x00100000;
	var FS_FLAG_SUBJECT_DEVICE_SERIAL_NUMBER	= 0x00200000;
	
	var FS_FLAG_DOHASH							= 0x00010000;
	var FS_FLAG_NOHASHOID						= 0x00020000;
	var FS_ALGOR_MD5							= 0x01;
	var FS_ALGOR_SHA1							= 0x02;
		
	var FS_FLAG_BASE64_ENCODE = 0x00001000;
	


function fnJSLanguageVer(sWordC, sWordE){
	return sWordC;
}



/*
 *  FSCAIPATL ����������~�N�X
 */
function GetErrorMessage(ErrCode, Debug, SN){
	var msg = "";

	switch(ErrCode){

		case 0:
		     msg += fnJSLanguageVer('����', 'Success ');
		     break;

		case 5001:
			msg += fnJSLanguageVer("[" + ErrCode + '] �@��ʿ��~', "[" + ErrCode + '] general error ');
			break;
		case 5002:
			msg += fnJSLanguageVer("[" + ErrCode + '] �O����t�m���~',"[" + ErrCode + '] Memory Allocation Error');
			break;
		case 5003:
			msg += fnJSLanguageVer("[" + ErrCode + '] Buffer too small',"[" + ErrCode + '] Buffer too small');
			break;
		case 5005:
			msg += fnJSLanguageVer("[" + ErrCode + '] �Ѽƿ��~',"[" + ErrCode + '] Invalid parameter');
			break;
		case 5006:
			msg += fnJSLanguageVer("[" + ErrCode + '] Invalid handle',"[" + ErrCode + '] Invalid handle');
			break;
		case 5007:
			msg += fnJSLanguageVer("[" + ErrCode + '] ����w�L��',"[" + ErrCode + '] TrialVersion Library is expired');
			break;
		case 5008:
			msg += fnJSLanguageVer("[" + ErrCode + '] Base64 Encoding/Decoding Error',"[" + ErrCode + '] Base64 Encoding/Decoding Error');
			break;

		case 5010:
			msg += fnJSLanguageVer("[" + ErrCode + '] �䤣��ŦX����',"[" + ErrCode + '] certificate not found');
			break;
		case 5011:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���Ҥw�L��',"[" + ErrCode + '] Certicate Expired');
			break;
		case 5012:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���ҩ|������',"[" + ErrCode + '] Certificate can not be used now');
			break;

		case 5014:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���ҥD�������~',"[" + ErrCode + '] Certificate subject not match');
			break;

		case 5015:
			msg += fnJSLanguageVer("[" + ErrCode + '] �䤣����ҵo���',"[" + ErrCode + '] Unable to find certificate issuer');
			break;

		case 5016:
			msg += fnJSLanguageVer("[" + ErrCode + '] ����ñ���ȵL��',"[" + ErrCode + '] Certificate signature is invalid');
			break;

		case 5017:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���~�����_�ϥΤ覡',"[" + ErrCode + '] Invalid ertificate keyusage');
			break;

		case 5020:
		case 5021:
		case 5022:
		case 5023:
		case 5024:
		case 5025:
		case 5026:
		case 5028:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���Ҥw�M�P',"[" + ErrCode + '] Certificate is revoked');
			break;

		case 5030:
			msg += fnJSLanguageVer("[" + ErrCode + '] CRL �w�L��',"[" + ErrCode + '] CRL expired.');
			break;
		case 5031:
			msg += fnJSLanguageVer("[" + ErrCode + '] CRL �|������',"[" + ErrCode + '] CRL not yet valid.');
			break;
		case 5032:
			msg += fnJSLanguageVer("[" + ErrCode + '] �䤣�� CRL ',"[" + ErrCode + '] CRL not found.');
			break;
		case 5034:
			msg += fnJSLanguageVer("[" + ErrCode + '] CRL ��ñ���ȿ��~ ',"[" + ErrCode + '] CRL signature invalid.');
			break;
		case 5036:
			msg += fnJSLanguageVer("[" + ErrCode + '] ��ƪ�ñ���ȿ��~ ',"[" + ErrCode + '] Invalid data signature.');
			break;
		case 5037:
			msg += fnJSLanguageVer("[" + ErrCode + '] ñ���������~ ',"[" + ErrCode + '] Content not match.');
			break;

		case 5040:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���~�����Ү榡 ',"[" + ErrCode + '] Incorrect Certificate format.');
			break;

		case 5041:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���~�� CRL �榡 ',"[" + ErrCode + '] Incorrect CRL format.');
			break;

		case 5042:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���~�� PKCS#7 �榡 ',"[" + ErrCode + '] Incorrect PKCS7 format.');
			break;

		case 5050:
			msg += fnJSLanguageVer("[" + ErrCode + '] �䤣����w���� ',"[" + ErrCode + '] FS_RTN_OBJ_NOT_FOUND.');
			break;
		case 5071:
			msg += fnJSLanguageVer("[" + ErrCode + '] �K�X�����T ',"[" + ErrCode + '] FS_RTN_PASSWD_INVALID.');
			break;

		case 5204:
			msg += fnJSLanguageVer("[" + ErrCode + '] �䤣��p�K���_ ',"[" + ErrCode + '] FS_RTN_OBJ_NOT_FOUND.');
			break;
		case 5205:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���ҵL�k�ץX ',"[" + ErrCode + '] FSCAPI_RTN_UNEXPORTABLE.');
			break;
		case 5206:
			msg += fnJSLanguageVer("[" + ErrCode + '] �v������ ',"[" + ErrCode + '] FSCAPI_RTN_STORE_ACCESSDENY.');
			break;
		case 5902:
			msg += fnJSLanguageVer("[" + ErrCode + '] �䤣���ɮ� ',"[" + ErrCode + '] FS_RTN_FILE_NOT_FOUND.');
			break;
		case 5906:
			msg += fnJSLanguageVer("[" + ErrCode + '] �S���v���s�� ',"[" + ErrCode + '] FS_RTN_ACCESS_DENIED.');
			break;

		// PKCS#11 return code
		case 9005:
			msg += fnJSLanguageVer("[" + ErrCode + '] �� PKCS#11 ���䴩�� Function ',"[" + ErrCode + '] FSP11_RTN_OBJECT_NOT_EXIST.');
			break;
		case 9006:
			msg += fnJSLanguageVer("[" + ErrCode + '] PKCS#11 �Ѽƿ��~ ',"[" + ErrCode + '] FSP11_RTN_ARGUMENTS_BAD.');
			break;
		case 9039:
		case 9040:
			msg += fnJSLanguageVer("[" + ErrCode + '] PKCS#11 Pin �X���~ ',"[" + ErrCode + '] FSP11_RTN_PIN_INCORRECT.');
			break;
		case 9043:
			msg += fnJSLanguageVer("[" + ErrCode + '] PKCS#11 Pin Lock ',"[" + ErrCode + '] FSP11_RTN_PIN_INCORRECT.');
			break;


		case 9100:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���󤣦s�b ',"[" + ErrCode + '] FSP11_RTN_OBJECT_NOT_EXIST.');
			break;

		case 9100:
			msg += fnJSLanguageVer("[" + ErrCode + '] ���󤣦s�b ',"[" + ErrCode + '] FSP11_RTN_OBJECT_NOT_EXIST.');
			break;
		case 9101:
			msg += fnJSLanguageVer("[" + ErrCode + '] ����w�s�b ',"[" + ErrCode + '] FSP11_RTN_OBJECT_EXIST.');
			break;
		case 9102:
			msg += fnJSLanguageVer("[" + ErrCode + '] ����o�Ͱ��D(�i��O�]���@�ӥH�W) ',"[" + ErrCode + '] FSP11_RTN_OBJECT_HAS_PROBLEM.');
			break;

		case 9110:
		case 9111:
			msg += fnJSLanguageVer("[" + ErrCode + '] Load Library ���� ',"[" + ErrCode + '] FSP11_RTN_LIBRARY_NOT_LOAD.');
			break;

		case 9112:
			msg += fnJSLanguageVer("[" + ErrCode + '] �䤣�� slot ',"[" + ErrCode + '] FSP11_RTN_SLOT_NOT_FOUND.');
			break;



		default:
			msg += fnJSLanguageVer('��L���~,�аѦҤ����U: (',  'Unknown Error, please reference document: (') + ErrCode + ") " ;
		  	return msg;

	}

	return msg;
}

if (navigator.platform != "Win32") {
	alert("Only Windows System is supported");
}

if (navigator.appName == "Netscape") {
	alert("Netscape is not supported now");
}


var isInstalled = true;
function installActiveXError(){
	isInstalled = false;
<!--
//    document.faqax.submit();
//-->
 
	
}

	var Obj =

	"<object classid='" + classidCAPI + "' " +
    "codebase='" + cabfileCAPI + "' " +
    "id='capiobj' onerror='installActiveXError()'" +
    "width='0' " +
    "height='0' "+
  
	" ></object>" ;

	 document.write(Obj);

if (!isInstalled) { 
	alert("ActiceX����|���w�˦��\��IE�w���ʳ]�w�����\����ActiceX����I");
}

function TestMyobjShowDebugMessage() {
	alert("FSCAPIShowDebugMessage True!");
	capiobj.FSCAPIShowDebugMessage(1);
}
