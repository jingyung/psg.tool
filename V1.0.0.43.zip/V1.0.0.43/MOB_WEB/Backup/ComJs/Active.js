﻿  var szloading="<div > <object id=\"DDSCMessageCom\" name=\"DDSCMessageCom\"  classid=\"clsid:6E6DEBE0-C051-4ef3-8E29-60818CD07B51\"  codebase=\"../DDSCMessageCom.cab#version=1,0,0,0\"   style=\"display:none\" ></object></div>";


 //document.write(szloading);