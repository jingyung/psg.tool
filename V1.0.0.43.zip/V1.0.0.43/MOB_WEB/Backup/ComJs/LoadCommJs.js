﻿try
{
    //loadJs('ComJs/jquery.js');
    //loadJs('ComJs/FunctionHandler.js');
    setFunction = setTimeout("loadComJs()", 500);
}
catch (e)
{
}
function loadJs(src)
{
    try
    {
        var s = document.createElement('script');
        s.setAttribute('type', 'text/javascript');
        s.setAttribute('src', src);
        var head = document.getElementsByTagName('head')[0];
        if (head) head.appendChild(s);
        else document.body.appendChild(s);
    }
    catch (e)
    {
    }


}


    function loadCSS(src)
    {
        var diFile = document.createElement("link");
        diFile.setAttribute("rel", "stylesheet");
        diFile.setAttribute("type", "text/css");
        diFile.setAttribute("href", src);

        if (typeof diFile != "undefined")
        {
            document.getElementsByTagName("head")[0].appendChild(diFile);
        }
    }

    function loadComJs(src)
    {

        loadJs('ComJs/ui.datepicker.js');
        loadJs('ComJs/GridDataBind.js');
    }
   