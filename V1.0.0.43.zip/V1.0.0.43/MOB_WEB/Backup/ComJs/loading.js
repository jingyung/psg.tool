﻿
var szloading = "<div id=\"DivBack\"  style=\"z-index: 99; left: 0px; position: absolute; top: 0px; background-color: #FFFFFF ;\
      filter: alpha(opacity=500); opacity: 0.7; display: none; text-align: center;\"><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />\
     <table align =center style=\"vertical-align: middle; text-align: center; border-top-style: none; border-right-style: none; border-left-style: none; border-bottom-style: none;\"><tr><td style=\" background-color: #FFFFFF \"><img STYLE=\"filter:progid:DXImageTransform.Microsoft.Alpha( Opacity=150, FinishOpacity=0, Style=0, StartX=0,  FinishX=100, StartY=0, FinishY=100)\"  src =\"../images/loading2.gif\"/> </td>\
       </tr></table> </div>";
//document.write(szloading);

//show();
//jQuery(document).ready(function()
//{
//    setTimeout("hide()", 700);
//});

function show()
{
    var back = document.getElementById("DivBack");
    var clientWidth, clientHeight;
    
    if(navigator.userAgent.indexOf(' MSIE ') > -1)
    {
        clientWidth = document.documentElement.clientWidth;
        clientHeight = document.documentElement.clientHeight;
    }
    else if (navigator.userAgent.indexOf(' Safari/') > -1)
    {
        clientWidth = window.innerWidth;
        clientHeight = window.innerHeight;
    }
    else if (navigator.userAgent.indexOf('Opera/') > -1)
    {
        clientWidth = Math.min(window.innerWidth, document.body.clientWidth);
        clientHeight = Math.min(window.innerHeight, document.body.clientHeight);
    }
    else
    {
        clientWidth = Math.min(window.innerWidth, document.documentElement.clientWidth);
        clientHeight = Math.min(window.innerHeight, document.documentElement.clientHeight);
    }

    back.style.width = Math.max(Math.max(document.documentElement.scrollWidth, document.body.scrollWidth), clientWidth)+'px';
    back.style.height = Math.max(Math.max(document.documentElement.scrollHeight, document.body.scrollHeight), clientHeight)+'px';
    back.style.display = '';
    
    toggleSelect('hidden');
}

function hide()
{
    document.getElementById("DivBack").style.visibility='hidden' 
    toggleSelect('visible');
}
function toggleSelect(visibility)
{
    var ss = document.getElementsByTagName('select');

    for(var i = 0; i < ss.length; i++)
    {
        ss[i].style.readOnly = true;
    }
}