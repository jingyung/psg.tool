﻿var year_base = 1911
var reDate = /(\d{2})\W(\d{2})\W(\d{4})/

function checkDate(obj) {
    var dateformat = "yyyy/mm/dd";
    var year = "";
    var month = "";
    var day = "";
    var str = obj.value.split("/");
    var dateFormatStr = dateformat.split("/");
    var src_event = "";
    for (var i = 0; i < dateFormatStr.length; i++) {
        if (dateFormatStr[i].indexOf('y') != -1) {

            year = parseInt(str[i])  ;
        }
        else if (dateFormatStr[i].indexOf('m') != -1) {
            month = str[i];
        }
        else {
            day = str[i];
        }
    }


    if (obj.value != '') {
        if (!isDate(month + '/' + day + '/' + year)) {
            if (obj.ErrMsg != null) {
                alert(obj.ErrMsg);
            }
            else {
                alert('請輸入正確日期格式!(yyyy/mm/dd) ')
            }
            obj.value = "";
            obj.focus();
            return false;
        }
        else {
            return true;
        }
    }
    else {
        return false;
    }
}

//isDate('mm/dd/yyyy')
function isDate(strDate) {

    var bTest = false;
    bTest = reDate.test(strDate);
    if (!reDate.test(strDate)) {
        return false;
    }
    var nMonth = Number(strDate.replace(reDate, "$1"));
    var nDate = Number(strDate.replace(reDate, "$2"));
    var nYear = Number(strDate.replace(reDate, "$3"));
    var testDT = new Date(parseInt(nYear), parseInt(nMonth) - 1, parseInt(nDate));

    if (testDT.getDate() != parseInt(nDate) || testDT.getMonth() != (parseInt(nMonth) - 1) || testDT.getFullYear() != parseInt(nYear)) {
        return false;
    }
    return true;
}