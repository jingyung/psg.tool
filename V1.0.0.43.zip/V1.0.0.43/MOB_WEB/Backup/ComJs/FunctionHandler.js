﻿var g_Width = "845px";
var g_Height = "680px";
var g_dialogStr = "width=" + g_Width + ",height=" + g_Height + ",scrollbars= yes,center=yes,status=no,resizable=yes";
var g_hostAddress = document.location.protocol + "//" + document.location.host + "/EC_WEB";
var g_OnUser = new Object;

var ERRORMESSAGE = "查詢連線異常，請洽所屬營業員查詢帳務！\n";

var ERRORMESSAGE1 = "目前帳務查詢異常，請洽所屬營業員查詢！\n";

var ERRORMESSAGE2 = "目前帳務查詢異常或屆服務停止區間，請洽所屬營業員查詢！\n";
function fh_AlertMsg(msg)
{
    alert(ERRORMESSAGE2 + msg);
}
function fh_AlertMsg2(msg) {
    alert(ERRORMESSAGE2 + msg);
}

 	
String.prototype.fulltrim=function(){return this.replace(/(?:(?:^|\n)\s+|\s+(?:$|\n))/g,'').replace(/\s+/g,' ');};

function NumRound(origin_num, round_num)
{

    // 四捨五入至小數點第round_num位 
    origin = Math.round(origin_num * Math.pow(10, round_num)) / Math.pow(10, round_num);

    return origin;

}

//從新載入ControlHandler
function fh_LoadPageControlHandler()
{
    try
    {
        fh_ReleaseJs("/ComJs/ControlHandler.js", "js");
        var ControlHandler = setTimeout("fh_LoadControlHandler('/ComJs/ControlHandler.js')", 500);
    }
    catch (e)
    {
        throw e;
    }
}


//------------增加判斷若重覆載入functionHandler.js若沒有載入，才new Object------
//var g_CheckPage = new Object;
var g_CheckPage;
if (g_CheckPage != 'undefined')
{
    //do nothing
}
else
{
    g_CheckPage = new Object;
}
//--------------------------end -----------------------------------


//關閉遮罩DIV
function fh_UnblockLoadingPage()
{
    $.unblockUI();
    $("#menu2").fadeTo("fast", 1, function() { });
    $("#menu3").fadeTo("fast", 1, function() { });
}

//載入控制項js
function fh_LoadControlHandler(p_src)
{
    try
    {
        if (document.location.host.indexOf("localhost") != -1)
        {
            g_hostAddress = "";
        }
        //        p_src = g_hostAddress + p_src;
        
        if (p_src.indexOf("/") != 0) //要串連location時若第一個字元不是"/"
        {
            p_src = g_hostAddress + "/" + p_src;
        }
        else
        {
            p_src = g_hostAddress + p_src;
        }

        
        var s = document.createElement('script');
        s.setAttribute('type', 'text/javascript');
        s.setAttribute('src', p_src);
        var head = document.getElementsByTagName('head')[0];
        if (head) head.appendChild(s);
        else document.body.appendChild(s);
    }
    catch (e)
    {
        throw e;
    }
}

//釋放控制項js
function fh_ReleaseJs(p_removeName, p_thType)
{
    try
    {
        if (document.location.host.indexOf("localhost") != -1)
        {
            g_hostAddress = "";
        }
        p_removeName = g_hostAddress + p_removeName;

        var targetElement = (p_thType == "js") ? "script" : (p_thType == "css") ? "link" : "none";
        var targetAttr = (p_thType == "js") ? "src" : (p_thType == "css") ? "href" : "none";
        var allsuspects = document.getElementsByTagName(targetElement);
        var i = allsuspects.length;
        for (i; i >= 0; i--)
        {
            if (allsuspects[i] != undefined)
            {
                if (allsuspects[i] && allsuspects[i].getAttribute(targetAttr) != null
				&& p_removeName.indexOf(allsuspects[i].getAttribute(targetAttr)) != -1)
                {
                    allsuspects[i].parentNode.removeChild(allsuspects[i]);
                }
            }
            
        }
    }
    catch (e)
    {
        throw e;
    }
}

//依時分秒日期組出參數，供url接收
function fh_getURLParam()
{
    try
    {
        var d = new Date();
        var s = "" + d.getHours() + d.getMinutes() + d.getSeconds() + d.getMilliseconds();
        var urlStr = "";
        if (document.getElementById("hidLogined") != null)
        {
            urlStr = "urlParam=" + s + "&LanguageFlag=" + $("#LanguageFlag")[0].lang + "&Logined=" + document.getElementById("hidLogined").value;
        }
        else
        {
            if ($("#LanguageFlag").length == 0)
            {
                urlStr = "urlParam=" + s + "&LanguageFlag=" + fh_getSearchKey("LanguageFlag") + "&Logined=" + fh_getSearchKey("Logined");
            }
            else
            {
                urlStr = "urlParam=" + s + "&LanguageFlag=" + $("#LanguageFlag")[0].lang + "&Logined=" + fh_getSearchKey("Logined");
            }
        }
        
        return urlStr;
    }
    catch (e)
    {
        throw e;
    }
}
/*creator : Ben 函式說明: 將數字轉成會計格式*/
function fh_ConvertToAccountFormate(p_sInnerText)
{
    try
    {
        if (p_sInnerText != "")
        {
            p_sInnerText = p_sInnerText.toString().replace(/,/g, "");
            var isSub = false
            if (p_sInnerText.indexOf('-') != -1)
            {
                p_sInnerText = p_sInnerText.toString().replace('-', '');
                isSub = true
            }
            var FormatText = "";
            var Str = "";
            if (p_sInnerText.indexOf('.') != -1)
            {
                Str = p_sInnerText.replace(p_sInnerText.substr(p_sInnerText.indexOf('.')), '');
            }
            else
            {
                Str = p_sInnerText;
            }
            Str = parseFloat(Str).toString();
            for (var StrCount = 1; StrCount < Math.ceil(Str.length / 3, 0) + 1; StrCount++)
            {
                if (StrCount == Math.ceil(Str.length / 3, 0))
                {
                    FormatText = Str.substr(0, Str.length - (parseInt(StrCount) - 1) * 3) + FormatText;
                }
                else
                {
                    FormatText = ',' + Str.substr(Str.length - (parseInt(StrCount) * 3), 3) + FormatText;
                }
            }
            if (p_sInnerText.indexOf('.') != -1)
            {
                FormatText += p_sInnerText.substr(p_sInnerText.indexOf('.'));
            }
            if (isSub)
            {
                FormatText = "-" + FormatText
            }
        } else
        {
            FormatText = "";
        }
        return FormatText;
    }
    catch (e)
    {
        throw e;
    }
}

/*creator : Ben 函式說明: 將下拉選項清空*/
function fh_ClearCob(p_Obj)
{
    try
    {
        $("#" + p_Obj.id).empty();
    }
    catch (e)
    {
        
    }
}
/*creator : Ben 函式說明: 組下拉選項*/
function fh_AddCboItem(p_Obj, p_Text, p_Value)
{
    try
        {
            if (p_Obj != null)
            {
                var opt = document.createElement("OPTION");
                opt.value = p_Text;
                opt.text = p_Value;
                p_Obj.options.add(opt);
            }
    }
    catch (e)
    {
        throw e;
    }
}

/*creator : Cedric 函式說明: 新增item至下拉選單，並可指定要insert的位置*/
function fh_AddCboItem(p_Obj, p_Text, p_Value, p_AddIndex)
{
    try
    {
        if (p_Obj != null)
        {
            var opt = document.createElement("OPTION");

            opt.value = p_Text;
            opt.text = p_Value;
            if (p_AddIndex == "" || p_AddIndex == undefined)
            {
                p_Obj.options.add(opt);
            }
            else
            {
                p_Obj.options.add(opt, p_AddIndex);
            }
        }
    }
    catch (e)
    {
        throw e;
    }
}



//取得EVENT
function fh_GetEvent(e)
{
    try
    {
        if (e.target == undefined)
        {
            e = window.event.srcElement; //IE
        }
        else
        {
            e = e.target; //ELSE
        }
        return e;
    }
    catch (e)
    {
        throw e;
    }
}


//呼叫VB Function(網頁名稱ClassName,Function Name,Where條件,是否同步作業)
function fh_CallWebMethod(m_Source, m_Method, m_WhereParm, m_async)
{
    try
    {
        var WhereParam = "";
        if (m_WhereParm != "")
        {
            for (var Param in m_WhereParm)
            {
                if (typeof(m_WhereParm[Param])=="object")
                {
                var pWhereParam  = Param + ": [  ";
                 for (var P in m_WhereParm[Param])
                 {
              
    
                           pWhereParam +=  " '" + m_WhereParm[Param][P]  + "' , ";
                    
                    
                  
                 }
                   pWhereParam = pWhereParam.substr(0, pWhereParam.lastIndexOf(","));
                   pWhereParam += "], ";
                   WhereParam +=pWhereParam;
                }
                else
                    WhereParam += Param + ": '" + m_WhereParm[Param] + "' , ";
            }
            WhereParam = WhereParam.substr(0, WhereParam.lastIndexOf(","));
        }

        var ReturnObj = { ErMsg: "" };
        $.ajax({
            type: "POST",
            async: m_async,
            url: m_Source + ".aspx/" + m_Method,
            data: "{" + WhereParam + "}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            error: function(xmlHttpRequest, error)
            {
                var m_ErrMessage = jsonParse(xmlHttpRequest.responseText).Message;




                alert(ERRORMESSAGE+m_ErrMessage );
 
            },
            success: function(data)
            {
                if (data.d != null)
                {
                    ReturnObj = jsonParse(data.d.toString());
                }
            }
        });
        return ReturnObj;
    }
    catch (e)
    {
        alert(ERRORMESSAGE );
    }
}

function JSON_Trim(p_str_JSONString)
{
    return p_str_JSONString.replace(/\\/g, "\\\\").replace(/\r\n/g, "\\n").replace(/\r/g, "").replace(/'/g, "\\\'").replace(/"/g, "\\\"").replace(/</g, "").replace(/>/g, "");
}


//------記錄log-------
function fh_LogClientTime(p_T0B,p_TOE,p_PARAM) {
    try {

//        var m_WhereParm = { TOB: p_T0B, TOE: p_TOE, T_PARAM: p_PARAM }
//        var m_objJSON = fh_CallWebMethod("MOBQ010", "LOG_CLIENT_TMIE", m_WhereParm, true);
    }
    catch (e) {
        throw e;
    }
}

function fh_GetNowDate() {
    var sdate = new Date();
     var MM = sdate.getMonth() + 1;
    if (MM < 10) MM = '0' + MM;
    var dd = sdate.getDate();
    if (dd < 10) dd = '0' + dd;
  var t = sdate.getFullYear() + "/" +MM + "/" +dd ;
     return t;

}

function fh_GetNowTime() {
    var sdate = new Date();
    //var t = sdate.getFullYear() + "/" + (sdate.getMonth()+1) + "/" + sdate.getDate() + " " + sdate.getHours() + ":" + sdate.getMinutes() + ":" + sdate.getSeconds() + "";
    var t = sdate.getHours() + ":" + sdate.getMinutes() + ":" + sdate.getSeconds() + "."+sdate.getMilliseconds();
    return t;

}

function fh_GenParam() {
    var t = "";
    try {
        var sdate = new Date();
        t = sdate.getFullYear() + "" + (sdate.getMonth() + 1) + "" + sdate.getDate() + "" + sdate.getHours() + "" + sdate.getMinutes() + "" + sdate.getSeconds() + "" + sdate.getMilliseconds();  
        
    }
    catch (e) {

    }
    return t;
}


function fh_TransferDateFor(YYYYMMDD)
{
   return   YYYYMMDD.substr(0,4)+"/"+  YYYYMMDD.substr(4,2)+"/"+  YYYYMMDD.substr(6,2);

}
function fh_TransferDateForTime(mmss)
{
   return   mmss.substr(0,2)+":"+  mmss.substr(2,2) ;

}
function fh_TransferDateForTimeH(HHmmss)
{
    return HHmmss.substr(0, 2) + ':' + HHmmss.substr(2, 2) +':'+HHmmss.substr(4,2);//+'.'+ HHmmss.substr(6,2) ;

}
function fh_TransferDateForTimeHM(HHmmss) {
    return HHmmss.substr(0, 2) + ':' + HHmmss.substr(2, 2); //+':'+HHmmss.substr(4,2);//+'.'+ HHmmss.substr(6,2) ;

}
function  GetNativeNatureCN( pid)
{
    return "TW" + pid + "1";
   
}

function padLeft(str, pad, count) 
{
    if (str==undefined)
    {
        str="";
    }
    while(str.length<count)
        str=pad+str;
    return str;
}

function padRight(str, pad, count) 
{
    if (str==undefined)
    {
        str="";
    }
    while(str.length<count)
        str=str+pad;
    return str;
}



 //動態安裝
 
// 
//  var szloading="<div > <object id=\"DDSCMessageCom\" name=\"DDSCMessageCom\"  classid=\"clsid:58575229-FC75-4c15-887B-41AFD269965F\"  codebase=\"../DDSCMessageCom.cab#version=1,0,0,0\"   style=\"display:none\" ></object></div>";



//   
 
//var o=document.createElement("object");
//o.id="DDSCMessageCom";
//o.name="DDSCMessageCom";
//o.classid="clsid:58575229-FC75-4c15-887B-41AFD269965F";
//o.codebase="../DDSCMessageCom.cab#version=1,0,0,0";
 
 function checkURL(value) {
    var urlregex = new RegExp("^(http:\/\/www.|https:\/\/www.|ftp:\/\/www.|www.){1}([0-9A-Za-z]+\.)");
    if (urlregex.test(value)) {
        return (true);
    }
    return (false);
}



//呼叫VB Function(網頁名稱ClassName,Function Name,Where條件,是否同步作業)
function fh_CallWebMethodEX(m_Source, m_Method, m_WhereParm, m_async) {
    try {
        var WhereParam = "";
        if (m_WhereParm != "") {
            for (var Param in m_WhereParm) {
                if (typeof (m_WhereParm[Param]) == "object") {
                    var pWhereParam = Param + ": [  ";
                    for (var P in m_WhereParm[Param]) {
                        pWhereParam += "{";
                        for (var wp in m_WhereParm[Param][P]) {
                            pWhereParam += wp + ": '" + m_WhereParm[Param][P][wp] + "' , ";
                        }
                        pWhereParam = pWhereParam.substr(0, pWhereParam.lastIndexOf(","));
                        pWhereParam += "},";
                    }
                    pWhereParam = pWhereParam.substr(0, pWhereParam.lastIndexOf(","));
                    pWhereParam += "], ";
                    WhereParam += pWhereParam;
                }
                else
                    WhereParam += Param + ": '" + m_WhereParm[Param] + "' , ";
            }
            WhereParam = WhereParam.substr(0, WhereParam.lastIndexOf(","));
        }

        var ReturnObj = {ErMsg:""};
        $.ajax({
            type: "POST",
            async: m_async,
            url: m_Source + ".aspx/" + m_Method,
            data: "{" + WhereParam + "}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            error: function(xmlHttpRequest, error) {
                var m_ErrMessage = jsonParse(xmlHttpRequest.responseText).Message;
                alert(ERRORMESSAGE + m_ErrMessage);
            },
            success: function(data) {
                if (data.d != null) {
                    ReturnObj = jsonParse(data.d.toString());
                }
            }
        });
        return ReturnObj;
    }
    catch (e) {
        alert(ERRORMESSAGE);
    }
}




//呼叫VB Function(網頁名稱ClassName,Function Name,Where條件,是否同步作業)
function fh_CallWebMethodToString(m_Source, m_Method, m_WhereParm, m_async) {
    try {
        var WhereParam = "";
        if (m_WhereParm != "") {
            for (var Param in m_WhereParm) {
                if (typeof (m_WhereParm[Param]) == "object") {
                    var pWhereParam = Param + ": [  ";
                    for (var P in m_WhereParm[Param]) {
                        pWhereParam += "{";
                        for (var wp in m_WhereParm[Param][P]) {
                            pWhereParam += wp + ": '" + m_WhereParm[Param][P][wp] + "' , ";
                        }
                        pWhereParam = pWhereParam.substr(0, pWhereParam.lastIndexOf(","));
                        pWhereParam += "},";
                    }
                    pWhereParam = pWhereParam.substr(0, pWhereParam.lastIndexOf(","));
                    pWhereParam += "], ";
                    WhereParam += pWhereParam;
                }
                else
                    WhereParam += Param + ": '" + m_WhereParm[Param] + "' , ";
            }
            WhereParam = WhereParam.substr(0, WhereParam.lastIndexOf(","));
        }

        var ReturnObj = { ErMsg: "" };
        $.ajax({
            type: "POST",
            async: m_async,
            url: m_Source + ".aspx/" + m_Method,
            data: "{" + WhereParam + "}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            error: function(xmlHttpRequest, error) {
                var m_ErrMessage = jsonParse(xmlHttpRequest.responseText).Message;

                alert(ERRORMESSAGE + m_ErrMessage);
            },
            success: function(data) {
                if (data.d != null) {
                    ReturnObj =  data.d.toString() ;
                }
            }
        });
        return ReturnObj;
    }
    catch (e) {
        alert(ERRORMESSAGE);
    }
}