﻿
var _sysname = "EC_WEB";
var g_hostAddress = document.location.protocol + "//" + document.location.host + "/" + _sysname;
//var g_hostAddress = "";

$(document).ready(function()
{
   
    var m_RepuestStr = new Array;

    var ObjCtrl = $("label[id^='lbl']");
    for (var CtrlCount = 0; CtrlCount < ObjCtrl.length; CtrlCount++)
    {
        m_RepuestStr.push(ObjCtrl[CtrlCount]);
    }

    var m_UseLanguage = "";
    if ($("#LanguageFlag")[0] == undefined)
    {
        m_UseLanguage = fh_getSearchKey("LanguageFlag");
    }
    else
    {
        m_UseLanguage = $("#LanguageFlag")[0].lang;
    }
    fh_ReleaseJs("/styles/en/Mains.css", "css");
    fh_ReleaseJs("/styles/cn/Mains.css", "css");
    fh_ReleaseJs("/styles/tw/Mains.css", "css");
    switch (m_UseLanguage.toUpperCase())
    {
        case "ZH-TW":
            fh_LoadCSS("/styles/tw/Mains.css");
            break;
        case "ZH-CN":
            fh_LoadCSS("/styles/cn/Mains.css");
            break;
        case "ZH-EN":
            fh_LoadCSS("/styles/en/Mains.css");
            break;
    }

    LanguageManagerByPage(m_RepuestStr, m_UseLanguage);
    if ($("#Home_News_Link").length != 0)
    {
        if (g_OnUser.IsAutouth)
        {
            fh_GetMemberMenu($("#LanguageFlag")[0].lang, "MEMBER_LINK");
            $("#MEMBER_LINK").show("slow");
        }
    }
    //畫面控制項處裡結束UnblockLoadingPage
    if (document.getElementById("CheckPage") != undefined)
    {
        setTimeout("fh_UnblockLoadingPage()", 1000);
        
        if (document.getElementById("Current_MenuId") != undefined)
        {
            setTimeout("Set_isReadOnly('" + document.getElementById("Current_MenuId").lang + "','" + m_UseLanguage.toUpperCase() + "')", 500);
            //Set_isReadOnly(document.getElementById("Current_MenuId").lang, m_UseLanguage.toUpperCase());
        }
    }
    

});

function getOuterHTML(object)
{
    var element;
    if (!object) return null;
    element = document.createElement("div");
    element.appendChild(object.cloneNode(true));
    return element.innerHTML;
}
function Set_isReadOnly(p_Current_MenuId, p_UseLanguage)
{
    if (p_Current_MenuId != "")
    {
        var m_DESC = "";
        var m_StrWhere = { FK_ECMD_ID: p_Current_MenuId.replace("MenuID_", "") };
        var myJsonObj = fh_CallWebMethod("Default", "Get_isReadOnly", m_StrWhere, false);
        if (myJsonObj.PageInfo != undefined)
        {
            if (myJsonObj.PageInfo[0].Result == "000")
            {
                g_OnUser.Page_isReadOnly = false;
                if (myJsonObj.PageInfo[0].isReadOnly == "Y")
                {
                    g_OnUser.Page_isReadOnly = true;
                    $("input[id^='btn_add']").hide();
                    $("input[id^='btn_approve']").hide();
                }

                if ($("#present").length != 0)
                {
                    $("#present").empty();
                    var m_Html = "<label onclick=\"Home()\" >" + LanguageManagerBySingle("lblHOME") + "</label> &gt;";
                    var m_Count = myJsonObj.PageInfo[0].Item.length-1;
                    for (m_Count; m_Count >= 0; m_Count--)
                    {
                        if (m_Count == 0)
                        {
                            m_DESC = myJsonObj.PageInfo[0].Item[m_Count].DESC;
                            m_Html += "<label style=\"cursor: default\" class=\"sel\">" + m_DESC + " </label>";
                        }
                        else
                        {
                            m_Html += "<label style=\"cursor: default\">" + myJsonObj.PageInfo[0].Item[m_Count].DESC + " </label> &gt;";
                        }
                    }
                    $("#present").html(m_Html);


                    if ($("#banner")[0].innerHTML != undefined)
                    {
                        $("#banner")[0].innerHTML = m_DESC;
                    }
                }
            }
        }
    }
}
function LanguageManagerByPage(m_RepuestStr, m_UseLanguage)
{
    if (m_RepuestStr.length != 0)
    {

        if (document.location.host.indexOf("localhost") != -1)
        {
            g_hostAddress = "";
        }
         var m_Ctrls = "";
        for (var m_CtrlCountid in m_RepuestStr)
        {
            m_Ctrls += "'" + m_RepuestStr[m_CtrlCountid].id.replace("lbl", "") + "',";
        }
        m_Ctrls = m_Ctrls.substr(0, m_Ctrls.lastIndexOf(","));
        var m_ReturnStr = "";
        $.ajax({
            type: "POST",
            async: false,
            url: g_hostAddress + "/Default.aspx/GetMultiResources",
            data: "{ ControlName :[" + m_Ctrls + "],UseLanguage :'" + m_UseLanguage + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            error: function(xmlHttpRequest, error)
            {
                var m_ErrMessage = jsonParse(xmlHttpRequest.responseText).Message;
                alert(m_ErrMessage);
            },
            success: function(data)
            {
                if (data.d.indexOf("999,") == -1)
                {
                    m_ReturnStr = data.d;
                }
            }
        });
        var myJsonObj = jsonParse(m_ReturnStr.replace("\r\n", "\\n").replace("\r", "").replace("\n", "\\n").replace("'", "\\'").replace("\"", "\\\""));
        for (var m_lblObj in m_RepuestStr)
        { 
        
        }
        for (var ColumnsName in myJsonObj.Resources[0])
        {
            if ($("#lbl" + ColumnsName)[0] != undefined)
            {
                for (var CtrlCount = 0; CtrlCount < $("label[id='lbl" + ColumnsName + "']").length; CtrlCount++)
                {
                    $("label[id='lbl" + ColumnsName + "']")[CtrlCount].innerHTML = myJsonObj.Resources[0][ColumnsName];
                }
            }
        }
        
    }
}


