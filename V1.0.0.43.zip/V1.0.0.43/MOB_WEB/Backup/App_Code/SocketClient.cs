﻿using System;
using System.Collections.Generic;
using System.Text;
using Dart.PowerTCP.SslSockets;
//using com.ddsc.tool;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace com.ddsc.net
{
    public class SocketClient
    {

        ///// <summary>
        ///// 使用Socket物件
        ///// </summary>
        //public Socket m_ObjTcpSocket;

        public Tcp tcp;



        /// <summary>
        /// 網路流        /// </summary>
        //private System.Net.Sockets.NetworkStream mobj_NetworkStream = null;
        /// <summary>
        /// remoteIP
        /// </summary>
        private string m_strIP;
        /// <summary>
        /// remote Port
        /// </summary>
        private int m_intPort;
        /// <summary>
        /// 使用者ID
        /// </summary>
        private string m_strUserId;

        private string m_strCompany;
       
        /// <summary>
        /// 初始化物件
        /// </suD:\統一\SocketTest\20100331\20100331\20100331\TCPClientClass\TCPClientSocket.csmmary>
        public SocketClient(string name, string ip, string port, string company, string userId,int connectionTimeOut, int receiveTimeOut, int sendTimeOut)
        {
            try
            {
                m_strIP = ip;
                m_intPort = System.Convert.ToInt32(port);
                m_strUserId = userId;
                m_strCompany = company;
                tcp = new Tcp();

                tcp.ConnectTimeout = connectionTimeOut;
                tcp.ReceiveTimeout = receiveTimeOut;
                tcp.SendTimeout = sendTimeOut;
            
            }
            catch (Exception ex)
            {
                // mobj_ErrorLog.WriteError(ex.Source, "初始化失敗:" + ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);
                throw ex;
            }

        }
        
        /// <summary>
        /// Socket連結
        /// </summary>
        /// <param name="remoteEP"></param>
        /// <param name="client"></param>
        public Boolean Connect()
        {
            Boolean status = false;
            try
            {
                //IPEndPoint ep = new IPEndPoint(IPAddress.Parse(m_strIP), m_intPort);     // ip , port  
                //m_ObjTcpSocket.Connect(ep);
                tcp.Connect(m_strIP, m_intPort);
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
                //SocketClientDispose();
                tcp.Dispose();
                throw ex;
            }
            finally
            {
                
                
            }
            return status;
       }

       
        /// <summary>
        /// 接收資料處理
        /// </summary>
        public string[] Receive(WriterLOG mobj_T4Log)
        {
            string[] receiveData;
            
            System.Collections.ArrayList receiveArray = new System.Collections.ArrayList();

            Boolean hasReceived = false;

            DateTime startReceiveTime = DateTime.Now;
            string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
            if (timeOut == "")
            {
                timeOut = "0";
            }
            try
            {
                while (tcp.Connected)
                {
                    byte[] lbyt_Head = new byte[1];
                    byte[] lbyt_Len = new byte[4];
                    byte[] lbyt_Data;
                    int lint_Len = 0;
                    string STR_ReceivedData;
                    string STR_ReceivedData1;


                    //迴圈中不斷讀取資訊
                    //讀頭碼
                    TCP_ByteRead(tcp, lbyt_Head, 0, 1);

                    //讀長度
                    TCP_ByteRead(tcp, lbyt_Len, 0, 4);

                    lint_Len = int.Parse(new string(Encoding.Default.GetChars(lbyt_Len)));
                    //讀內文

                    if (lint_Len > 1)
                    {
                        lbyt_Data = new byte[lint_Len];
                        TCP_ByteRead(tcp, lbyt_Data, 0, lint_Len);

                        STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Head))
                            + new string(Encoding.Default.GetChars(lbyt_Len))
                            + new string(Encoding.Default.GetChars(lbyt_Data));
                        //receiveArray.Add(STR_ReceivedData);
                        STR_ReceivedData1 = STR_ReceivedData.Substring(7, STR_ReceivedData.Length - 7).Replace("\0","0");
                        receiveArray.Add(STR_ReceivedData1);
                        if (lbyt_Head[0] == 0x0e)
                        {
                            //----記錄第一次收到訊息的時間----------
                            if (!hasReceived)
                            {
                                hasReceived = true;
                                mobj_T4Log.T4b  = DateTime.Now.ToString("HH:mm:ss.fff");
                            }
                            //---------------------------------------
                            //---------取得回覆資料後，再依傳送的型態判斷是否是完整的筆數--------------
                            string strData = STR_ReceivedData1.Substring(0, 1) + STR_ReceivedData1.Substring(28);
                            
                            
                            //依 strData頭碼分派資料給個 unMOB                
                            byte[] header = Encoding.Default.GetBytes(strData.Substring(0, 1));
                            Boolean conFlag = true;
                            switch (header[0].ToString().Trim())
                            {
                                case "81":   // 0x51保證金查詢 回覆
                                    conFlag = false;
                                    break;
                                case "19":       //0x13 未平倉查詢回覆
                                    if (strData.Substring(strData.Length - 2, 1) == "\n" || strData.Substring(strData.Length - 2, 1) == "\r")
                                    {
                                        conFlag = false;
                                    }
                                    break;

                                case "83":       // 0x53當日損益查詢回覆
                                    conFlag = false;
                                    break;

                                case "87":   //0x57 即時部位查詢回覆  單式查詢  混合查詢 分別填入兩個不同的table
                                    if (strData.Substring(strData.Length - 3, 1) == "1" | strData.Substring(strData.Length - 3, 1) == "9")
                                    {
                                        conFlag = false;
                                    }
                                    break;
                                case "89":   //0x59 即時組合查詢回覆
                                    break;
                                case "98":   //0x62 拆組
                                    //判斷是否為最後一筆
                                        //if (strData.Substring(9, 4) == strData.Substring(13, 4))
                                    //{
                                        conFlag = false;
                                    //}
 
                                    break;
                                default :
                                    conFlag = false;
                                    break;
                            }
                            //---------------------------------------------------------------
                            if (!conFlag)
                            {
                                tcp.Close();
                                tcp.Dispose();
                                break;
                            }
                        }


                    }

                    if (DateTime.Now > startReceiveTime.AddMilliseconds(Convert.ToDouble(timeOut)))
                    {
                        break;
                        throw new Exception("Receive Time Out");
                    }
                }

                

            }
            catch (System.Net.Sockets.SocketException ex)
            {
                string errMsg = ex.ToString();
                throw ex;
            }
            receiveData = new string[receiveArray.Count];
            Int32 idx = 0;
            for (idx = 0; idx < receiveArray.Count; idx++)
            {
                receiveData[idx] = receiveArray[idx].ToString();
            }
            
            return receiveData;
        }


        /// <summary>
        /// 讀取網路流資料
        /// </summary>
        private int TCP_ByteRead(Tcp tcp, byte[] buffer, int start, int length)
        {
            int lint_total = 0;
            int lint_read = 0;
            int lint_count = 0;

            do
            {
                Segment s = tcp.Receive(buffer, start + lint_total, length - lint_total, System.Net.Sockets.SocketFlags.None);
                lint_read = s.Count;
                lint_total += lint_read;
                lint_count++;
            } while ((lint_total < length) && (lint_count < 100));
            return lint_total;
        }


        /// <summary>
        /// 傳送資料
        /// </summary>
        public void m_ObjTcpSocketSendData(Tcp m_ObjTcpSocket, string str_Data)
        {
            try
            {
                if (m_ObjTcpSocket != null && m_ObjTcpSocket.Connected)
                {

                    //取得頭碼
                    byte byte_TradeFlag = byte.Parse(str_Data.Substring(0, 2));

                    byte byte_EndFlag = byte.Parse("10");


                    if (str_Data.Length > 3)
                    {
                        str_Data = str_Data.Substring(2, str_Data.Length - 2);
                    }
                    else
                    {
                        str_Data = "";
                    }

                    byte[] SendDataBuffer = new byte[4906];
                    int lint_Len = 0;
                    Encoding EncodType;
                    EncodType = Encoding.Default;

                    lint_Len = getStringLen(str_Data) + 1;
                    //將字串轉成buffer
                    SendDataBuffer = EncodType.GetBytes(" " + lint_Len.ToString().PadLeft(4, '0') + str_Data + " ");
                    //加尾碼
                    SendDataBuffer.SetValue(byte_EndFlag, SendDataBuffer.Length - 1);
                    //將頭碼加在buffer最前面
                    SendDataBuffer.SetValue(byte_TradeFlag, 0);
                    m_ObjTcpSocket.Send(SendDataBuffer);
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //mobj_ErrorLog.WriteError(ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

            }

        }

        /// <summary>
        /// 取字串轉byte後長度        /// </summary>
        private static int getStringLen(string STR_Data)
        {
            byte[] bString = System.Text.Encoding.Default.GetBytes(STR_Data);
            return bString.Length;
        }

        //範例方法 Send 會以 ASCII 格式將指定字串資料編碼，
        //並以非同步方式將資料傳送到由指定通訊端表示的網路裝置。下列範例實作了 Send 方法
        public void Send(String data)
        {
            if (tcp.Connected)
            {
                try
                {
                    m_ObjTcpSocketSendData(tcp, data);
                }
                catch (Exception e)
                {
                    throw e;
                    Console.WriteLine(e.ToString());
                }
            }
            else
            { 
                //連結未建立
            }
   
        }

        public void ConnectionDispose()
        {
            tcp.Dispose();
        }
        
       

    }
}
