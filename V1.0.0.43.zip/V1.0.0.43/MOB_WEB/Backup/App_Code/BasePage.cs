﻿using System.Text;
using System.Resources;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Data;
using System.Web;
//using com.ddsc.database;
using System.Reflection;
using System.Web.Services;
using System.Web.UI;
using System;


/// <summary>
/// BasePage 的摘要描述

/// </summary>
/// <remarks>
/// CallBack 機制
/// inherits 的aspx, 在 head tag 前要加上一段 Js Script
/// </remarks>
public class BasePage : System.Web.UI.Page
{
    #region "Gobal variable"
    private const string _sys_name = "MOB_WEB";
    private static bool Session_OnUser = false;
    private static string g_LanguageFlag = "zh-tw";

    private ResourceManager rm;
    private ResourceManager rmhk;
    #endregion

    public class ClsPageCtrl
    {

        private string _Value;

        private string _Text;

        public string Value
        {
            get
            {
                return _Value;
            }
            set
            {
                _Value = value;
            }
        }

        public string Text
        {
            get
            {
                return _Text;
            }
            set
            {
                _Text = value;
            }
        }
    }



    public void InnertScript(string InnerKey, string InnertText)
    {
        ClientScriptManager cs = this.Page.ClientScript;
        if (!cs.IsClientScriptBlockRegistered(InnerKey))
        {
            cs.RegisterClientScriptBlock(this.GetType(), InnerKey, InnertText);
        }
    }


    [Serializable()]
    public class Employee
    {

        /// <summary>
        /// company id
        /// </summary>
        public string COMP_ID { get; set; }
        /// <summary>
        /// account id
        /// </summary>
        public string ACCT_ID { get; set; }

        public Employee()
        {
            try
            {
                CreateEmployee();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //
        private void CreateEmployee()
        {
            // To do
        }
    }


    [Serializable()]
    public class DataItem
    {

        public bool Enable;

        public string ID;

        public DataItem(bool Value, string ID)
        {
            this.ID = ID;
            this.Enable = Value;
        }
    }


    public static Employee LoginUser()
    {
        if ((HttpContext.Current.Session["OnUser"] == null))
        {
            HttpContext.Current.Session["OnUser"] = new Employee();
        }
        else if ((HttpContext.Current.Session["OnUser"] == null))
        {
            HttpContext.Current.Session["OnUser"] = new Employee();
        }
        return ((Employee)(HttpContext.Current.Session["OnUser"]));
    }



    protected override void OnLoad(System.EventArgs e)
    {
        try
              
        {
        
            //if ((Session["OnUser"] == null))
            //{
            //    Employee OnUser = LoginUser();
            //}
            string m_Page_Path = ((System.Web.UI.Page)Page).AppRelativeVirtualPath.ToString();

            System.Web.UI.HtmlControls.HtmlLink cssLink = new System.Web.UI.HtmlControls.HtmlLink();

            //----載入jquery的js-----
            //InnertScript("{F3AE6520-1ED9-4422-B1FD-22B75BF7DDBA}", "<script src=\'../ComJs/jquery.js\'></script>");
            //InnertScript("{F3AE6520-1ED9-4422-B1FD-22B75BF7DDBB}", "<script src=\'../ComJs/loading.js\'></script>");
            //------------------    


            Page.Header.Controls.Add(cssLink);
            // 

            Response.ExpiresAbsolute = DateTime.Now;

            Response.Expires = -1441;

            Response.CacheControl = "no-cache";

            Response.AddHeader("Pragma", "no-cache");

            Response.AddHeader("Pragma", "no-store");

            Response.AddHeader("cache-control", "no-cache");

            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            Response.Cache.SetNoServerCaching();

            base.OnLoad(e);

             string ComputerID = System.Configuration.ConfigurationSettings.AppSettings["ComputerID"];
             //Response.Write("<SPAN   style=\"color: #6BAEDE\">" + ComputerID + "</SPAN>");


             ClientScriptManager cs = this.Page.ClientScript;
             if (!cs.IsStartupScriptRegistered("l"))
             {

                 cs.RegisterStartupScript(this.GetType(), "l", "<div   style=\"color: #6BAEDE\">" + ComputerID + "</div>");
             }
   
        }
        catch (System.Threading.ThreadAbortException tex)
        {
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
  
   
    protected override void OnUnload(EventArgs e)
    {
        rm = null;
        base.Dispose();
        Page.Dispose();
        base.OnUnload(e);
    }

    [WebMethod()]
    public static void ExceptionLog(string ExceptionMsg, string Function_Name, string Form_Id)
    {
        System.Diagnostics.EventLog.WriteEntry("MOB_WEB", ("Form_Id:"
                        + (Form_Id
                        + (Environment.NewLine + ("Function_Name:"
                        + (Function_Name
                        + (Environment.NewLine + ("ExceptionMsg:" + ExceptionMsg))))))));
        //return ExceptionMsg;
    }

    [WebMethod()]
    public static string LOG_CLIENT_TMIE(string TOB, string TOE, string T_PARAM)
    {
        //-----加入log記錄元件----
        WriterLOG mobj_T0Log = null;
        try
        {
            mobj_T0Log = new WriterLOG("webinfoT0" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
            mobj_T0Log.WriteEntryData(TOB.PadLeft(20, ' ') + TOE.PadLeft(20, ' ') + T_PARAM.PadLeft(50, ' '));

        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (mobj_T0Log != null)
            {
                mobj_T0Log.Close();
            }

        }

        return "{}";

    }
}
