﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Data;
using System.IO;

/// <summary>
/// BOSDataParse 的摘要描述
/// </summary>
public class BOSDataParse
{
	public BOSDataParse()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
	}

    /// <summary>
    /// 取得歷史保證金資料
    /// </summary>
    /// <param name="SourceType"></param>
    /// <param name="company"></param>
    /// <param name="account"></param>
    /// <param name="begin_date"></param>
    /// <param name="end_date"></param>
    /// <param name="currency"></param>
    /// <param name="customerID"></param>
    /// <returns></returns>
    public DataSet getHistoryMargin(string SourceType, string company, string account, string begin_date, string end_date, string currency,string customerID)
    {
        DataTable dtHistoryMarginSource = null;
        DataTable dtErrorSource = null;
     
        //try
        //{
        //    System.IO.StreamWriter sw = new StreamWriter("D:\\MOB\\TT.txt", true);
        //    sw.WriteLine("123");
        //    sw.Close();
        //    sw.Dispose();
        //}
        //catch (Exception e1)
        //{

        //}
        //--------------------------------------
        dtHistoryMarginSource = new DataTable();
        dtHistoryMarginSource.Columns.Add("TDDT");             // TDDT : 日期
        dtHistoryMarginSource.Columns.Add("Margin" );             // Equity = TMIAMT+TMEXCESS      : 試算可用保證金額
        dtHistoryMarginSource.Columns.Add("ClearMargin" );        // ClearEquity =TMIAMT+TMEXCESS+BMKTVAL+SMKTVAL     :試算原始保證總額
 
        dtHistoryMarginSource.Columns.Add("DWAMT" );                             //出入金
        dtHistoryMarginSource.Columns.Add("TMPAB" );              //平倉損益(成交價)
        dtHistoryMarginSource.Columns.Add("PROLOS");            //未平倉損益(成交價)
        dtHistoryMarginSource.Columns.Add("OP_TMPAB");
        dtHistoryMarginSource.Columns.Add("OP_PROLOS");
        dtHistoryMarginSource.Columns.Add("FU1921");
        dtHistoryMarginSource.Columns.Add("BPREMIUM");
        dtHistoryMarginSource.Columns.Add("SPREMIUM");
        dtHistoryMarginSource.Columns.Add("charge");            // 手續費
        dtHistoryMarginSource.Columns.Add("tax");                // 交易稅
        dtHistoryMarginSource.Columns.Add("SYSDATE");
        dtHistoryMarginSource.Columns.Add("SYSTIME");
        dtErrorSource = new DataTable();
        dtErrorSource.Columns.Add("Error");
        //--------------------------------------



        DataTable dt = new DataTable();
        DataTable dtt = new DataTable();
        DataSet ds = new DataSet("HistoryMargin");
        try
        {
            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            string[] strData = ws.WS_getHistoryMargin("DDSC", company, customerID, begin_date, end_date, currency);
            System.IO.StringReader xmlSR = new System.IO.StringReader(strData[0]);
            ds.ReadXml(xmlSR);

           
       
            dtHistoryMarginSource.Rows.Clear();

            if (ds.Tables.Count != 0)
            {
                if (ds.Tables["Result"].Columns.Contains("error"))
                {
                    dtErrorSource.Rows.Clear();

                    DataRow drrr = dtErrorSource.NewRow();
                    drrr["Error"] = ds.Tables["Result"].Rows[0]["Error"].ToString();
                    dtErrorSource.Rows.Add(drrr);
                    
                }
                else
                {
                    for (int i = 0; i < ds.Tables["Result"].Rows.Count; i++)
                    {
                        DataRow drr = dtHistoryMarginSource.NewRow();
                        drr["TDDT"] = setDateFormat(ds.Tables["Result"].Rows[i]["TDDT"].ToString());
                        drr["Margin"] = ds.Tables["Result"].Rows[i]["Margin"].ToString();
                        drr["ClearMargin"] = ds.Tables["Result"].Rows[i]["ClearMargin"].ToString();

                        if (ds.Tables["Result"].Rows[i]["charge"].ToString() != "N/A")
                        {
                            decimal charge_temp = decimal.Parse(ds.Tables["Result"].Rows[i]["charge"].ToString());
                            drr["charge"] = charge_temp.ToString("#,##0.##");

                        }
                        else
                        {
                            drr["charge"] = ds.Tables["Result"].Rows[i]["charge"].ToString();
                        }



                        if (ds.Tables["Result"].Rows[i]["tax"].ToString() != "N/A")
                        {
                            decimal tax_temp = decimal.Parse(ds.Tables["Result"].Rows[i]["tax"].ToString());
                            drr["tax"] = tax_temp.ToString("#,##0.##");

                        }
                        else
                        {
                            drr["tax"] = ds.Tables["Result"].Rows[i]["charge"].ToString();
                        }



                        drr["TMPAB"] = ds.Tables["Result"].Rows[i]["TMPAB"].ToString();
                        drr["PROLOS"] = ds.Tables["Result"].Rows[i]["PROLOS"].ToString();
                        drr["DWAMT"] = ds.Tables["Result"].Rows[i]["DWAMT"].ToString();

                        //20100204  OP 平倉損益   OP未平倉損益


                        if (ds.Tables["Result"].Rows[i]["OP_TMPAB"].ToString() != "N/A")
                        {
                            decimal OP_TMPAB_temp = decimal.Parse(ds.Tables["Result"].Rows[i]["OP_TMPAB"].ToString());
                            drr["OP_TMPAB"] = OP_TMPAB_temp.ToString("#,##0.##");

                        }
                        else
                        {
                            drr["OP_TMPAB"] = ds.Tables["Result"].Rows[i]["OP_TMPAB"].ToString();
                        }

                        if (ds.Tables["Result"].Rows[i]["OP_PROLOS"].ToString() != "N/A")
                        {
                            decimal OP_PROLOS_temp = decimal.Parse(ds.Tables["Result"].Rows[i]["OP_PROLOS"].ToString());
                            drr["OP_PROLOS"] = OP_PROLOS_temp.ToString("#,##0.##");

                        }
                        else
                        {
                            drr["OP_PROLOS"] = ds.Tables["Result"].Rows[i]["OP_PROLOS"].ToString();
                        }



                        //drr["OP_TMPAB"] = ds.Tables["Result"].Rows[i]["OP_TMPAB"].ToString();
                        //drr["OP_PROLOS"] = ds.Tables["Result"].Rows[i]["OP_PROLOS"].ToString();

                        drr["FU1921"] = ds.Tables["Result"].Rows[i]["FU1921"].ToString();

                        drr["BPREMIUM"] = ds.Tables["Result"].Rows[i]["BPREMIUM"].ToString();
                        drr["SPREMIUM"] = ds.Tables["Result"].Rows[i]["SPREMIUM"].ToString();
                        drr["SYSDATE"] = ds.Tables["Result"].Rows[i]["SYSDATE"].ToString();
                        drr["SYSTIME"] = ds.Tables["Result"].Rows[i]["SYSTIME"].ToString();

                        //待補完......
                        dtHistoryMarginSource.Rows.Add(drr);

                    }


                    //計算 charge , tax的小計
                    //dtHistoryMarginCountSource.Rows.Clear();
                    //DataRow drrr = dtHistoryMarginCountSource.NewRow();
                    decimal charge = 0;
                    decimal tax = 0;
                    decimal TMPAB = 0;
                    decimal PROLOS = 0;
                    decimal DWAMT = 0;
                    decimal OP_TMPAB = 0;
                    //decimal BPREMIUM = 0;
                    //decimal SPREMIUM = 0;
                    decimal OP_PROLOS = 0;
                    decimal FU1921 = 0;
                    for (int j = 0; j < dtHistoryMarginSource.Rows.Count; j++)
                    {
                        if (dtHistoryMarginSource.Rows[j]["charge"].ToString().Trim() != "N/A")
                            charge += decimal.Parse(dtHistoryMarginSource.Rows[j]["charge"].ToString());
                        if (dtHistoryMarginSource.Rows[j]["tax"].ToString().Trim() != "N/A")
                            tax += decimal.Parse(dtHistoryMarginSource.Rows[j]["tax"].ToString());

                        TMPAB += decimal.Parse(dtHistoryMarginSource.Rows[j]["TMPAB"].ToString());
                      //  PROLOS += decimal.Parse(dtHistoryMarginSource.Rows[j]["PROLOS"].ToString());
                        //added philip 20100202 出入金
                        DWAMT += decimal.Parse(dtHistoryMarginSource.Rows[j]["DWAMT"].ToString());
                    //    OP_PROLOS += decimal.Parse(dtHistoryMarginSource.Rows[j]["OP_PROLOS"].ToString());
                        //20100204  OP 平倉損益加總  
                      //  if (dtHistoryMarginSource.Rows[j]["OP_TMPAB"].ToString().Trim() != "N/A")
                            OP_TMPAB += decimal.Parse(dtHistoryMarginSource.Rows[j]["OP_TMPAB"].ToString());
                        //BPREMIUM += decimal.Parse(dtHistoryMarginSource.Rows[j]["BPREMIUM"].ToString());
                        //SPREMIUM += decimal.Parse(dtHistoryMarginSource.Rows[j]["SPREMIUM"].ToString());
                        //OP_TMPAB += decimal.Parse(dtHistoryMarginSource.Rows[j]["OP_TMPAB"].ToString());

                            FU1921 += decimal.Parse(dtHistoryMarginSource.Rows[j]["FU1921"].ToString());
                    }


                    DataRow drCount = dtHistoryMarginSource.NewRow();

                    drCount["TDDT"] = "加總";
                    drCount["charge"] = charge.ToString("#,##0.##");
                    drCount["tax"] = tax.ToString("#,##0.##");

                    drCount["TMPAB"] = TMPAB.ToString("#,##0.##");
                   // drCount["PROLOS"] = PROLOS.ToString("#,##0.##");
                    //added philip 20100202 出入金
                    drCount["DWAMT"] = DWAMT.ToString("#,##0.##");

                    //20100204  OP 平倉損益加總   
                    drCount["OP_TMPAB"] = OP_TMPAB.ToString("#,##0.##");

                   // drCount["OP_PROLOS"] = OP_PROLOS.ToString("#,##0.##");
                    //drCount["BPREMIUM"] = BPREMIUM.ToString("#,##0.##");
                    //drCount["SPREMIUM"] = SPREMIUM.ToString("#,##0.##");

                    drCount["FU1921"] = FU1921.ToString("#,##0.##");

                    dtHistoryMarginSource.Rows.Add(drCount);

                   
                } 
            }
            //else
            //{
            //    dtErrorSource.Rows.Clear();

            //    DataRow drrr = dtErrorSource.NewRow();
            //    drrr["Error"] = "查無資料";
            //    dtErrorSource.Rows.Add(drrr);
               
            //}

            ds.Dispose();
        }
        catch (Exception ex)
        {
            dtErrorSource.Rows.Clear();

            DataRow drrr = dtErrorSource.NewRow();
            drrr["Error"] = "WSError:" + "資料處理失敗:" + ex.Message.ToString();
            dtErrorSource.Rows.Add(drrr);
        
        }
        DataSet dsReturn = new DataSet();
        dsReturn.Tables.Add(dtErrorSource);
        dsReturn.Tables.Add(dtHistoryMarginSource);
        return dsReturn;
    }

    /// <summary>
    /// 平倉損益查詢--彙總歷史查詢或彙總即時查詢
    /// </summary>
    /// <param name="type">只能傳0或1,0表示歷史查詢，1表示即時查詢</param>
    /// <param name="SourceType"></param>
    /// <param name="company"></param>
    /// <param name="account"></param>
    /// <param name="begin_date"></param>
    /// <param name="end_date"></param>
    /// <param name="currency"></param>
    /// <param name="comtype"></param>
    /// <param name="comym"></param>
    /// <param name="min_price"></param>
    /// <param name="max_price"></param>
    /// <param name="CP"></param>
    /// <returns></returns>
    public DataSet getEquityCollect(string type, string SourceType, string company, string account, string begin_date, string end_date, string currency, string comtype, string comym, string min_price, string max_price, string CP)
    {
        DataTable dtHistoryEquityCollectSource = null;               //彙總
        DataTable dtErrorSource = null;

        //錯誤訊息的table
        dtErrorSource = new DataTable();
        dtErrorSource.Columns.Add("Error");

        

        //彙總
        dtHistoryEquityCollectSource = new DataTable();
        dtHistoryEquityCollectSource.Columns.Add("OFFSETDATE"); //平倉日期
        dtHistoryEquityCollectSource.Columns.Add("ProductName");  //商品代號
        dtHistoryEquityCollectSource.Columns.Add("OFFSETQTY");  //平倉口數

        dtHistoryEquityCollectSource.Columns.Add("GiveUp");     //放棄口數
        dtHistoryEquityCollectSource.Columns.Add("OSPRTLOS"); //交易損益       
        dtHistoryEquityCollectSource.Columns.Add("CURRENCY");  //幣別 
        dtHistoryEquityCollectSource.Columns.Add("charge" );    //手續費  
        dtHistoryEquityCollectSource.Columns.Add("tax" );       //期交稅   
        dtHistoryEquityCollectSource.Columns.Add("equity" );    //淨損益  = 交易損益+手續費+期交稅
        dtHistoryEquityCollectSource.Columns.Add("ordtype");     //類型

        dtHistoryEquityCollectSource.Columns.Add("SYSDATE");
        dtHistoryEquityCollectSource.Columns.Add("SYSTIME");
        try
        {
        
            DataSet ds = new DataSet("HistoryEquity");
            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            string[] strData;
            if (type == "0")    //歷史
            {
                strData = ws.WS_getHistoryEquityCollect("DDSC", company, account, begin_date, end_date, currency.Trim(), comtype, comym, min_price.Trim(), max_price.Trim(), CP);
            }
            else//即時
            {
                strData = ws.WS_getCurrentEquityCollect("DDSC", company, account, currency.Trim(), comtype, comym, min_price.Trim(), max_price.Trim(), CP);
            
            }
            
            System.IO.StringReader xmlSR = new System.IO.StringReader(strData[0]);
            ds.ReadXml(xmlSR);


      
            dtHistoryEquityCollectSource.Rows.Clear();

            if (ds.Tables.Count != 0)
            {
                 if (ds.Tables["Result"].Columns.Contains("error"))
                {
                    dtErrorSource.Rows.Clear();

                    DataRow drrr = dtErrorSource.NewRow();
                    drrr["Error"] = ds.Tables["Result"].Rows[0]["Error"].ToString();
                    dtErrorSource.Rows.Add(drrr);
                    
                }
                else
                { 
                    int j = 0;
                    decimal OSPRTLOSCount = 0;
                    decimal chargeCount = 0;
                    decimal taxCount = 0;
                    decimal EquityCount = 0;
                    int OFFSETQTYCount = 0;
                    int GiveUpCount = 0;

                    for (int i = 0; i < ds.Tables["Result"].Rows.Count; i++)
                    {
                        DataRow drr = dtHistoryEquityCollectSource.NewRow();
                        drr["OFFSETDATE"] = setDateFormat(ds.Tables["Result"].Rows[i]["OFFSETDATE"].ToString());
                        drr["SYSDATE"] = ds.Tables["Result"].Rows[i]["SYSDATE"].ToString();
                        drr["SYSTIME"] = ds.Tables["Result"].Rows[i]["SYSTIME"].ToString();
                        if (type != "0")
                        {
                            drr["ProductName"] = ds.Tables["Result"].Rows[i]["ProductName"].ToString().Trim();

                            drr["GiveUp"] = ds.Tables["Result"].Rows[i]["GiveUp"].ToString();

                            if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "3")
                            {
                                drr["ordtype"] = "結算";
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "4")
                            {
                                drr["ordtype"] = "履約";
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "5")
                            {
                                drr["ordtype"] = "指派";
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "6")
                            {
                                drr["ordtype"] = "放棄";
                            }
                            else
                            {
                                drr["ordtype"] = "平倉";
                            }

                        }
                        else
                        {
                            if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "3")
                            {
                                drr["ordtype"] = "結算";
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "4")
                            {
                                drr["ordtype"] = "履約";
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "5")
                            {
                                drr["ordtype"] = "指派";
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "6")
                            {
                                drr["ordtype"] = "放棄";
                            }
                            else
                            {
                                drr["ordtype"] = "平倉";
                            }
                          
                            if (ds.Tables["Result"].Rows[i]["callput"].ToString() == "N")
                            {
                                drr["ProductName"] = ds.Tables["Result"].Rows[i]["abbr"].ToString().Trim() + ds.Tables["Result"].Rows[i]["comym"].ToString().Trim().Substring(4, 2);
                            }
                            else
                            {
                                drr["ProductName"] = ds.Tables["Result"].Rows[i]["abbr"].ToString().Trim() + decimal.Parse(ds.Tables["Result"].Rows[i]["stkprc"].ToString().Trim()).ToString("#0.#") + ds.Tables["Result"].Rows[i]["callput"].ToString().Trim() + ds.Tables["Result"].Rows[i]["comym"].ToString().Trim().Substring(4, 2);
                            }
                        }
                        //drr["ProductName"] = ds.Tables["Result"].Rows[i]["ProductName"].ToString();
                        drr["OFFSETQTY"] = ds.Tables["Result"].Rows[i]["OFFSETQTY"].ToString();
                       
                           
                       
                        //  drr["OSPRTLOS"] =  ds.Tables["Result"].Rows[i]["OSPRTLOS"].ToString();

                        drr["OSPRTLOS"] =   ds.Tables["Result"].Rows[i]["OSPRTLOS"].ToString() ;

                        drr["CURRENCY"] = ds.Tables["Result"].Rows[i]["CURRENCY"].ToString();
                        drr["charge"] =  ds.Tables["Result"].Rows[i]["charge"].ToString() ;
                        drr["tax"] =  ds.Tables["Result"].Rows[i]["tax"].ToString() ;
                        drr["equity"] =  ds.Tables["Result"].Rows[i]["Equity"].ToString();



                        //計算加總
                        OSPRTLOSCount += decimal.Parse(ds.Tables["Result"].Rows[i]["OSPRTLOS"].ToString());
                        //if (type == "0")    //歷史
                        //{
                            EquityCount += decimal.Parse(ds.Tables["Result"].Rows[i]["Equity"].ToString());

                            taxCount += decimal.Parse(ds.Tables["Result"].Rows[i]["tax"].ToString());
                            chargeCount += decimal.Parse(ds.Tables["Result"].Rows[i]["charge"].ToString());
                        //}
                        //else
                        //{
                        //    GiveUpCount += int.Parse(ds.Tables["Result"].Rows[i]["GiveUp"].ToString());
                        //}
                       
                        OFFSETQTYCount += int.Parse(ds.Tables["Result"].Rows[i]["OFFSETQTY"].ToString());

                        

                        dtHistoryEquityCollectSource.Rows.Add(drr);

                    }

                    

                    //modified 20100208  將加總至於同個datagridview的最後一列

                    DataRow drCount = dtHistoryEquityCollectSource.NewRow();

                    drCount["OFFSETDATE"] = "加總";
                    drCount["equity"] = EquityCount.ToString("#,0.##");
                    drCount["charge"] = chargeCount.ToString("#,0.##");
                    drCount["tax"] = taxCount.ToString("#,0.##");
                    drCount["OSPRTLOS"] = OSPRTLOSCount.ToString("#,0.##");
                    drCount["OFFSETQTY"] = OFFSETQTYCount.ToString();
                  
                    drCount["GiveUp"] = GiveUpCount.ToString();
                    
                    dtHistoryEquityCollectSource.Rows.Add(drCount);

                    
                    //displayHistoryEquityCollect();

                    

                }
                //else
                //{

                //    dtErrorSource.Rows.Clear();

                //    DataRow drrr = dtErrorSource.NewRow();
                //    drrr["Error"] = ds.Tables["Result"].Rows[0]["Error"].ToString();
                //    dtErrorSource.Rows.Add(drrr);
                    

                //}
            }
            //else
            //{
            //    dtErrorSource.Rows.Clear();

            //    DataRow drrr = dtErrorSource.NewRow();
            //    drrr["Error"] = "無此帳號平倉資料";
            //    dtErrorSource.Rows.Add(drrr);
                
            //}

            

           
        }
        catch (Exception ex)
        {
            //AEFutureMaster.frmMain.AOBJ_ErrLog.WriteError(ex.Source, ex.StackTrace.ToString(), ex.Message, System.Diagnostics.EventLogEntryType.Error);
            dtErrorSource.Rows.Clear();

            DataRow drrr = dtErrorSource.NewRow();
            drrr["Error"] = "WSError:" + "資料處理失敗:" + ex.Message.ToString();
            dtErrorSource.Rows.Add(drrr);
        }
        DataSet dsReturn = new DataSet();
        dsReturn.Tables.Add(dtErrorSource);
        dsReturn.Tables.Add(dtHistoryEquityCollectSource);
        return dsReturn;

    }

    /// <summary>
    /// 平倉損益查詢--明細歷史查詢或明細即時查詢
    /// </summary>
    /// <param name="type">只能傳0或1,0表示歷史查詢，1表示即時查詢</param>
    /// <param name="SourceType"></param>
    /// <param name="company"></param>
    /// <param name="account"></param>
    /// <param name="begin_date"></param>
    /// <param name="end_date"></param>
    /// <returns></returns>
    public DataSet getEquityDetail(string type, string SourceType, string company, string account, string begin_date, string end_date,string currency)
    {
        DataTable dtHistoryEquityClearListSource = null;              //明細
        DataTable dtErrorSource = null;

        //錯誤訊息的table
        dtErrorSource = new DataTable();
        dtErrorSource.Columns.Add("Error");

        //明細
        dtHistoryEquityClearListSource = new DataTable();
        dtHistoryEquityClearListSource.Columns.Add("SeqNo");     //序號
        dtHistoryEquityClearListSource.Columns.Add("OFFSETDATE"); //平倉日期
        dtHistoryEquityClearListSource.Columns.Add("OPTTRDDT");  //成交日期
        dtHistoryEquityClearListSource.Columns.Add("ORDNO");     //委託單號  TRDORDNO  & OPTORDNO
        dtHistoryEquityClearListSource.Columns.Add("ProductName");  //商品代碼
        dtHistoryEquityClearListSource.Columns.Add("PS");        //買賣別
        dtHistoryEquityClearListSource.Columns.Add("PRICE" );     //成交價   TRDPRC1 & OPTPRIC1
        dtHistoryEquityClearListSource.Columns.Add("OFFSETQTY"); //平倉量       
        dtHistoryEquityClearListSource.Columns.Add("CURRENCY");  //幣別 
        dtHistoryEquityClearListSource.Columns.Add("charge" );    //手續費   依 委託單號 去FBTDTR.ORIGNFEE  FOTORD.UTPRICE8  加/減  FBTDTR的ORDNO -> 'W2503 11'  'W2503 21'
        dtHistoryEquityClearListSource.Columns.Add("tax" );       //期交稅   依 委託單號 去FBTDTR.CTAXAMT   FOTORD.UTPRICE9  加/減
        dtHistoryEquityClearListSource.Columns.Add("OSPRTLOS");  //交易損益=  平倉損益
        dtHistoryEquityClearListSource.Columns.Add("equity");    //淨損益  = 交易損益+手續費+期交稅

        dtHistoryEquityClearListSource.Columns.Add("ordtype");    //類型

        dtHistoryEquityClearListSource.Columns.Add("SYSDATE");
        dtHistoryEquityClearListSource.Columns.Add("SYSTIME");
     
        try
        {
          
            DataSet ds = new DataSet("HistoryEquity");
            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
            string[] strData;
            if (type == "0")    //歷史
            {
                strData = ws.WS_getHistoryEquity("DDSC", company, account, begin_date, end_date, currency);
            }
            else//即時
            {
                strData = ws.WS_getCurrentEquity("DDSC", company, account, currency);
            }

            System.IO.StringReader xmlSR = new System.IO.StringReader(strData[0]);
            ds.ReadXml(xmlSR);


   
            dtHistoryEquityClearListSource.Rows.Clear();
            if (ds.Tables.Count != 0)
            {
                if (ds.Tables["Result"].Columns.Contains("error"))
                {
                    dtErrorSource.Rows.Clear();

                    DataRow drrr = dtErrorSource.NewRow();
                    drrr["Error"] = ds.Tables["Result"].Rows[0]["Error"].ToString();
                    dtErrorSource.Rows.Add(drrr);
                    
                }
                else
                { 
                
                    int j = 0;
                    decimal OSPRTLOSCount = 0;
                    decimal chargeCount = 0;
                    decimal taxCount = 0;
                    decimal EquityCount = 0;

                    for (int i = 0; i < ds.Tables["Result"].Rows.Count; i++)
                    {
                        DataRow drr = dtHistoryEquityClearListSource.NewRow();//原單
                        DataRow drr2 = dtHistoryEquityClearListSource.NewRow();//平倉單

                        j++;

                        drr["SeqNo"] = j.ToString();
                        drr["OFFSETDATE"] = ds.Tables["Result"].Rows[i]["OFFSETDATE"].ToString();
                        drr["SYSDATE"] = ds.Tables["Result"].Rows[i]["SYSDATE"].ToString();

                        drr["SYSTIME"] =  ds.Tables["Result"].Rows[i]["SYSTIME"].ToString() ;
                      
                        drr["ORDNO"] = ds.Tables["Result"].Rows[i]["TRD_ORDNO"].ToString();
                        if (type != "0")
                        {
                            drr["OPTTRDDT"] = " --- ";
                            drr["ProductName"] = ds.Tables["Result"].Rows[i]["ProductName"].ToString().Trim();
                            drr["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            if (ds.Tables["Result"].Rows[i]["PS"].ToString() == "B")
                            {
                                drr2["PS"] = "S";
                            }
                            else
                            {
                                drr2["PS"] = "B";
                            }



                            if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "3")
                            {
                                drr["ordtype"] = "結算";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "4")
                            {
                                drr["ordtype"] = "履約";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "5")
                            {
                                drr["ordtype"] = "指派";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "6")
                            {
                                drr["ordtype"] = "放棄";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else
                            {
                                drr["ordtype"] = "平倉";
                                drr["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                                if (ds.Tables["Result"].Rows[i]["PS"].ToString() == "B")
                                {
                                    drr2["PS"] = "S";
                                }
                                else
                                {
                                    drr2["PS"] = "B";
                                }
                            }


                        }
                        else
                        {
                            drr["OPTTRDDT"] =setDateFormat( ds.Tables["Result"].Rows[i]["trdtrddt"].ToString().Trim());
                            if (ds.Tables["Result"].Rows[i]["callput"].ToString() == "N")
                            {
                                drr["ProductName"] = ds.Tables["Result"].Rows[i]["abbr"].ToString().Trim() + ds.Tables["Result"].Rows[i]["comym"].ToString().Trim().Substring(4, 2);
                            }
                            else
                            {
                                drr["ProductName"] = ds.Tables["Result"].Rows[i]["abbr"].ToString().Trim() + decimal.Parse(ds.Tables["Result"].Rows[i]["stkprc"].ToString().Trim()).ToString("#0.#") + ds.Tables["Result"].Rows[i]["callput"].ToString().Trim() + ds.Tables["Result"].Rows[i]["comym"].ToString().Trim().Substring(4, 2);
                            }
                            if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "3")
                            {
                                drr["ordtype"] = "結算";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "4")
                            {
                                drr["ordtype"] = "履約";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "5")
                            {
                                drr["ordtype"] = "指派";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else if (ds.Tables["Result"].Rows[i]["ordtype"].ToString() == "6")
                            {
                                drr["ordtype"] = "放棄";
                                drr["PS"] = "--";
                                drr2["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                            }
                            else
                            {
                                drr["ordtype"] = "平倉";
                                drr["PS"] = ds.Tables["Result"].Rows[i]["PS"].ToString();
                                if (ds.Tables["Result"].Rows[i]["PS"].ToString() == "B")
                                {
                                    drr2["PS"] = "S";
                                }
                                else
                                {
                                    drr2["PS"] = "B";
                                }
                            }
                        }
                        
                     
                        drr["PRICE"] = ds.Tables["Result"].Rows[i]["TRDPRC1"].ToString();
                        drr["OFFSETQTY"] = ds.Tables["Result"].Rows[i]["OFFSETQTY"].ToString();
                        drr["CURRENCY"] = ds.Tables["Result"].Rows[i]["CURRENCY"].ToString();
                        drr["charge"] =  ds.Tables["Result"].Rows[i]["TRD_charge"].ToString()  ;
                        drr["tax"] = ds.Tables["Result"].Rows[i]["TRD_tax"].ToString() ;
                        drr["OSPRTLOS"] = " --- ";
                        drr["equity"] = " --- ";





                        j++;
                        drr2["SeqNo"] = j.ToString();
                        //20110503 samantha 因為日期位置顛倒修正
                        //  drr2["OFFSETDATE"] = setDateFormat(ds.Tables["Result"].Rows[i]["OFFSETDATE"].ToString());
                        drr2["OFFSETDATE"] = " --- ";

                        drr2["ordtype"] = " --- ";
                        drr2["OPTTRDDT"] = setDateFormat(ds.Tables["Result"].Rows[i]["OPTTRDDT"].ToString()); 
                        drr2["ORDNO"] = ds.Tables["Result"].Rows[i]["OPT_ORDNO"].ToString();
                        if (type != "0")
                        {
                            drr2["ProductName"] = ds.Tables["Result"].Rows[i]["ProductName"].ToString().Trim();
                        }
                        else
                        {
                            if (ds.Tables["Result"].Rows[i]["callput"].ToString() == "N")
                            {
                                drr2["ProductName"] = ds.Tables["Result"].Rows[i]["abbr"].ToString().Trim() + ds.Tables["Result"].Rows[i]["comym"].ToString().Trim().Substring(4, 2);
                            }
                            else
                            {
                                drr2["ProductName"] = ds.Tables["Result"].Rows[i]["abbr"].ToString().Trim() + decimal.Parse(ds.Tables["Result"].Rows[i]["stkprc"].ToString().Trim()).ToString("#0.#") + ds.Tables["Result"].Rows[i]["callput"].ToString().Trim() + ds.Tables["Result"].Rows[i]["comym"].ToString().Trim().Substring(4, 2);
                            }
                           
                        }
                       
                        drr2["PRICE"] = ds.Tables["Result"].Rows[i]["OPTPRIC1"].ToString();
                        drr2["OFFSETQTY"] = ds.Tables["Result"].Rows[i]["OFFSETQTY"].ToString();
                        drr2["CURRENCY"] = ds.Tables["Result"].Rows[i]["CURRENCY"].ToString();
                        if (ds.Tables["Result"].Rows[i]["OPT_charge"].ToString() != "")
                        {
                            drr2["charge"] =  ds.Tables["Result"].Rows[i]["OPT_charge"].ToString() ;
                            chargeCount += decimal.Parse(ds.Tables["Result"].Rows[i]["OPT_charge"].ToString());
                        }
                        if (ds.Tables["Result"].Rows[i]["OPT_tax"].ToString() != "")
                        {
                            drr2["tax"] =  ds.Tables["Result"].Rows[i]["OPT_tax"].ToString();
                            taxCount += decimal.Parse(ds.Tables["Result"].Rows[i]["OPT_tax"].ToString());
                        }

                        drr2["OSPRTLOS"] =  ds.Tables["Result"].Rows[i]["OSPRTLOS"].ToString() ;
                        drr2["equity"] = ds.Tables["Result"].Rows[i]["Equity"].ToString() ;

                        //計算加總
                        OSPRTLOSCount += decimal.Parse(ds.Tables["Result"].Rows[i]["OSPRTLOS"].ToString());
                        //if (type == "0")    //歷史
                        //{
                            EquityCount += decimal.Parse(ds.Tables["Result"].Rows[i]["Equity"].ToString());

                            taxCount += decimal.Parse(ds.Tables["Result"].Rows[i]["TRD_tax"].ToString());


                            chargeCount += decimal.Parse(ds.Tables["Result"].Rows[i]["TRD_charge"].ToString());
                        //}

                        //待補完......
                        dtHistoryEquityClearListSource.Rows.Add(drr);
                        dtHistoryEquityClearListSource.Rows.Add(drr2);

                    }




                    DataRow drCount = dtHistoryEquityClearListSource.NewRow();

                    drCount["SeqNo"] = "加總";
                    drCount["equity"] = EquityCount.ToString("#,0.##");
                    drCount["charge"] = chargeCount.ToString("#,0.##");
                    drCount["tax"] = taxCount.ToString("#,0.##");
                    drCount["OSPRTLOS"] = OSPRTLOSCount.ToString("#,0.##");

                    dtHistoryEquityClearListSource.Rows.Add(drCount);

                    
                }
                //else
                //{

                //    dtErrorSource.Rows.Clear();

                //    DataRow drrr = dtErrorSource.NewRow();
                //    drrr["Error"] = ds.Tables["Result"].Rows[0]["Error"].ToString();
                //    dtErrorSource.Rows.Add(drrr);
                    


                //}
            }
            //else
            //{
            //    dtErrorSource.Rows.Clear();

            //    DataRow drrr = dtErrorSource.NewRow();
            //    drrr["Error"] = "無此帳號平倉資料";
            //    dtErrorSource.Rows.Add(drrr);
                

            //}

            
        }
        catch (Exception ex)
        {
            //AEFutureMaster.frmMain.AOBJ_ErrLog.WriteError(ex.Source, ex.StackTrace.ToString(), ex.Message, System.Diagnostics.EventLogEntryType.Error);
            dtErrorSource.Rows.Clear();

            DataRow drrr = dtErrorSource.NewRow();
            drrr["Error"] = "WSError:" + "資料處理失敗:" + ex.Message.ToString();
            dtErrorSource.Rows.Add(drrr);
        }
        DataSet dsReturn = new DataSet();
        dsReturn.Tables.Add(dtErrorSource);
        dsReturn.Tables.Add(dtHistoryEquityClearListSource);
        return dsReturn;
    }

    // added by philip 20100127 將日期插入 "/"
    private string setDateFormat(string date)
    {
        string DateResult = date.Substring(0, 4) + "/" + date.Substring(4, 2) + "/" + date.Substring(6, 2);

        return DateResult;
    }

}
