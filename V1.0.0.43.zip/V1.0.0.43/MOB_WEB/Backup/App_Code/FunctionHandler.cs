﻿using System.Text;
using System.Data;
using System.Resources;
using System.Reflection;
using System.IO;
using System.Security.Cryptography;
using System.Xml;
using System;
using System.Collections.Generic;


public class FunctionHandler
{
    /// <summary>
    /// 資料表轉JSON字串
    /// </summary>
    /// <param name="T">資料表</param>
    /// <returns></returns>
    public string DT_To_JSON(System.Data.DataTable T)
    {
        if (T == null)
        {
            throw new Exception("資料表參數為null");
        }
        try
        {
            System.Web.Script.Serialization.JavaScriptSerializer _JSS = new System.Web.Script.Serialization.JavaScriptSerializer();
            List<Dictionary<string, object>> _Rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> _row;
            foreach (System.Data.DataRow itemRow in T.Rows)
            {
                _row = new Dictionary<string, object>();
                foreach (System.Data.DataColumn itemCol in T.Columns)
                {
                    _row.Add(itemCol.ColumnName, itemRow[itemCol]);
                }
                _Rows.Add(_row);
            }
            return _JSS.Serialize(_Rows);
        }
        catch (Exception Exc)
        {
            // Create the source, if it does not already exist.
            if (!System.Diagnostics.EventLog.SourceExists("統一_MOB_WEB查詢"))
            {
                System.Diagnostics.EventLog.CreateEventSource("統一_MOB_WEB查詢", "MOB_WEB");
            }

            // Create an EventLog instance and assign its source.
            System.Diagnostics.EventLog myLog = new System.Diagnostics.EventLog();
            myLog.Source = "統一_MOB_WEB查詢";

            // Write an informational entry to the event log.    
            //myLog.WriteEntry("Action complete.");
            myLog.WriteEntry(Exc.Message);
            throw;
        }
    }

    /// <summary>
    /// added by peter  dataset transfer to jsonstring
    /// </summary>
    /// <param name="ds"></param>
    /// <returns></returns>
    public string DataSetToJSON(DataSet ds)
    {
        System.Web.Script.Serialization.JavaScriptSerializer _JSS = new System.Web.Script.Serialization.JavaScriptSerializer();
        Dictionary<string, object> resultInfo = new Dictionary<string, object>();
        Dictionary<string, object> resultMain = new Dictionary<string, object>();
        string RetuenJsonString = "";
        if (ds.Tables.Count > 1 && ds.Tables["info"].Rows[0]["ReturnCode"].ToString() != "100" && ds.Tables["info"].Rows[0]["ReturnCode"].ToString() != "999")
        {
            int m_index = 0;
            foreach (DataRow dr in ds.Tables[1].Rows)
            {
                Dictionary<string, object> result = new Dictionary<string, object>();
                foreach (DataColumn dc in ds.Tables[1].Columns)
                {
                    result.Add(dc.ColumnName, dr[dc].ToString());
                }
                resultMain.Add(m_index.ToString(), result);
                m_index++;
            }

            Dictionary<string, object> result_info = new Dictionary<string, object>();
            result_info.Add("ReturnCode", ds.Tables["info"].Rows[0]["ReturnCode"].ToString());
            result_info.Add("ReturnMessage", ds.Tables["info"].Rows[0]["ReturnMessage"].ToString());
            resultInfo.Add("0", result_info);

            RetuenJsonString = @"{""TableRows"":" + _JSS.Serialize(resultMain) + ",";
            RetuenJsonString += (@"""PageInfo"":" + _JSS.Serialize(resultInfo) + "}");
        }
        else
        {
            Dictionary<string, object> result_info = new Dictionary<string, object>();
            if (ds.Tables["info"].Rows[0]["ReturnCode"].ToString() == "100")
            {
                result_info.Add("ReturnCode", ds.Tables["info"].Rows[0]["ReturnCode"].ToString());
                result_info.Add("ReturnMessage", ds.Tables["info"].Rows[0]["ReturnMessage"].ToString());
            }
            else
            {
                result_info.Add("ReturnCode", ds.Tables["info"].Rows[0]["ReturnCode"].ToString()  );
                result_info.Add("ReturnMessage", ds.Tables["info"].Rows[0]["ReturnMessage"].ToString());
            }
            resultInfo.Add("0", result_info);
            RetuenJsonString = @"{""PageInfo"":" + _JSS.Serialize(resultInfo) + "}";
        }
        return RetuenJsonString;
    }

    public string GetRndString(int max)
    {
        try
        {
            return Guid.NewGuid().ToString().Replace("-", "").Substring(0, max);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    //public ResourceManager LanguageManager(string LangType)
    //{
    //    try
    //    {
    //        return Resources.zh_tw.ResourceManager;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}


    //編碼
    public string fh_EncString(string pwd)
    {
        Int32 i = 0;
        string encPwd = "";
        try
        {
            if (pwd != "")
            {
                for (i = 0; i < pwd.Length; i++)
                {
                    encPwd = encPwd + Convert.ToChar(159 - ((int)Convert.ToChar(pwd.Substring(i, 1)))).ToString();
                }
            }
        }
        catch (Exception ex)
        {

        }
        return encPwd;
    }

    //取得檢查碼
    public string fh_GetCheckNo(string acct)
    {
        string s = acct;
        int len = s.Length;
        int idx = 1;
        Int32 total = 0;
        string checkNo = "";

        for (idx = 1; idx <= len; idx++)
        {
            total += idx * Convert.ToInt32(s.Substring(idx - 1, 1));

        }

        for (idx = total.ToString().Length; idx > 0; idx--)
        {
            checkNo += total.ToString().Substring(idx - 1, 1);
        }
        return checkNo;
    }

    ////public bool BindDrpDown(DataTable p_dt, System.Web.UI.HtmlControls.HtmlSelect p_DrpDown, string p_value, string p_text, bool p_IsAll)
    ////{
    ////    try
    ////    {
    ////        System.Web.UI.WebControls.ListItem m_lc = new System.Web.UI.WebControls.ListItem();
    ////        m_lc.Text = "ALL";
    ////        m_lc.Value = "";
    ////        p_DrpDown.DataSource = p_dt;
    ////        p_DrpDown.DataTextField = p_text;
    ////        p_DrpDown.DataValueField = p_value;
    ////        p_DrpDown.DataBind();
    ////        if (p_IsAll)
    ////        {
    ////            p_DrpDown.Items.Insert(0, m_lc);
    ////        }
    ////        else
    ////        {
    ////            p_DrpDown.Items.Insert(0, "");
    ////        }
    ////        return true;
    ////    }
    ////    catch (Exception ex)
    ////    {
    ////        return false;
    ////    }
    ////}

    ///// <summary>
    ///// 透過Socket取得訊息
    ///// </summary>
    ///// <param name="SendMsg">查詢條件的字串</param>
    ///// <returns></returns>
    //public string[] GetMessage(string SendMsg)
    //{
    //    string remoteIP = System.Configuration.ConfigurationManager.AppSettings["REMOTE_IP"];
    //    string remotePORT = System.Configuration.ConfigurationManager.AppSettings["REMOTE_PORT"];
    //    string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
    //    com.ddsc.net.SocketClient client = new com.ddsc.net.SocketClient("", remoteIP, remotePORT,"", "",Convert.ToInt32(timeOut),Convert.ToInt32(timeOut),Convert.ToInt32(timeOut));
    //    string msg = SendMsg;
    //    string addr = "";

    //    WriterLOG mobj_T1Log = new WriterLOG("webinfoT1" + DateTime.Now.ToString("HHmmssfff"));
    //    WriterLOG mobj_T4Log = new WriterLOG("webinfoT4" + DateTime.Now.ToString("HHmmssfff"));

    //    try
    //    {
    //        //System.Web.HttpContext.Current.Session["objSOCKET"] = client;
    //        client.Connect();

    //        addr = client.tcp.LocalEndPoint.Address.ToString() + ":" + client.tcp.LocalEndPoint.Port.ToString();
    //        addr = addr.PadLeft(21, ' ');
    //        msg = "15" + addr + SendMsg.Substring(21);

    //        string T1b = DateTime.Now.ToString("HH:mm:ss.fff");

    //        client.Send(msg);

    //        string T1e = DateTime.Now.ToString("HH:mm:ss.fff");
    //        mobj_T1Log.WriteEntryData(msg.Substring(2, 27) + T1b + T1e + msg);
    //        //client.Send(SendMsg);

    //        string T4b = "";

    //        string[] s = client.Receive(mobj_T4Log);

    //        string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
    //        Int32 idx = 0;
    //        for (idx = 0; idx < s.Length; idx++)
    //        {
    //            mobj_T4Log.WriteEntryData(s[idx].Substring(1, 27) + T4b + T4e + s[idx]);
    //        }


    //        client.ConnectionDispose();
    //        return s;
    //    }
    //    catch (Exception ex)
    //    {
    //        if (client.tcp != null)
    //        {
    //            client.ConnectionDispose();
    //        }
    //        //port = 0;
    //        //addr = "";
    //        WriterLOG errLog = new WriterLOG("ErrorLog" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
    //        errLog.WriteEntryData("GetMessage Error : " + ex.Message + "\n" + ex.StackTrace + "\n <傳送訊息：>" + msg);
    //        errLog.Close();
    //        return null;
    //    }
    //    finally
    //    {
    //        mobj_T1Log.Close();
    //        mobj_T4Log.Close();
    //    }

    //}

    //public string[] GetMessage(string SendMsg,WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)
    //{
    //    string remoteIP = System.Configuration.ConfigurationManager.AppSettings["REMOTE_IP"];
    //    string remotePORT = System.Configuration.ConfigurationManager.AppSettings["REMOTE_PORT"];
    //    string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
    //    com.ddsc.net.SocketClient client = new com.ddsc.net.SocketClient("", remoteIP, remotePORT, "", "", Convert.ToInt32(timeOut), Convert.ToInt32(timeOut), Convert.ToInt32(timeOut));
    //    string msg = SendMsg;
    //    string addr = "";

    //    try
    //    {
    //        //System.Web.HttpContext.Current.Session["objSOCKET"] = client;
    //        client.Connect();

    //        addr = client.tcp.LocalEndPoint.Address.ToString() + ":" + client.tcp.LocalEndPoint.Port.ToString();
    //        addr = addr.PadLeft(21, ' ');
    //        msg = "15" + addr + SendMsg.Substring(21);

    //        string T1b = DateTime.Now.ToString("HH:mm:ss.fff");

    //        client.Send(msg);

    //        string T1e = DateTime.Now.ToString("HH:mm:ss.fff");
    //        mobj_T1Log.WriteEntryData(msg.Substring(2, 27) + T1b + T1e + msg);

    //        //string T4b = DateTime.Now.ToString("HH:mm:ss.fff");

    //        string[] s = client.Receive(mobj_T4Log);

    //        //string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
    //        //Int32 idx = 0;
    //        //for (idx = 0; idx < s.Length; idx++)
    //        //{
    //        //    mobj_T4Log.WriteEntryData(s[idx].Substring(1, 27) + T4b + T4e + s[idx]);
    //        //}


    //        client.ConnectionDispose();
    //        return s;
    //    }
    //    catch (Exception ex)
    //    {
    //        if (client.tcp != null)
    //        {
    //            client.ConnectionDispose();
    //        }
    //        //port = 0;
    //        //addr = "";
    //        WriterLOG errLog = new WriterLOG("ErrorLog" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
    //        errLog.WriteEntryData("GetMessage Error : " + ex.Message + "\n" + ex.StackTrace+"\n <傳送訊息：>"+msg);
    //        errLog.Close();
    //        return null;
    //    }
    //    finally
    //    {

    //    }

    //}
    //public string[] GetMessage(string[] SendMsg, WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)
    //{
    //    string remoteIP = System.Configuration.ConfigurationManager.AppSettings["REMOTE_IP"];
    //    string remotePORT = System.Configuration.ConfigurationManager.AppSettings["REMOTE_PORT"];
    //    string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
    //    com.ddsc.net.SocketClient client = new com.ddsc.net.SocketClient("", remoteIP, remotePORT, "", "", Convert.ToInt32(timeOut), Convert.ToInt32(timeOut), Convert.ToInt32(timeOut));

    //    string addr = "";

    //    try
    //    {
    //        //System.Web.HttpContext.Current.Session["objSOCKET"] = client;
    //        client.Connect();

    //        addr = client.tcp.LocalEndPoint.Address.ToString() + ":" + client.tcp.LocalEndPoint.Port.ToString();
    //        addr = addr.PadLeft(21, ' ');
    //        foreach (string str in SendMsg)
    //        {
    //            string msg = str;
    //            msg = "15" + addr + str.Substring(21);

    //            string T1b = DateTime.Now.ToString("HH:mm:ss.fff");

    //            client.Send(msg);

    //            string T1e = DateTime.Now.ToString("HH:mm:ss.fff");
    //            mobj_T1Log.WriteEntryData(msg.Substring(2, 27) + T1b + T1e + msg);

    //            //string T4b = DateTime.Now.ToString("HH:mm:ss.fff");
    //        }
    //        string[] s = client.Receive(mobj_T4Log);

    //        //string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
    //        //Int32 idx = 0;
    //        //for (idx = 0; idx < s.Length; idx++)
    //        //{
    //        //    mobj_T4Log.WriteEntryData(s[idx].Substring(1, 27) + T4b + T4e + s[idx]);
    //        //}


    //        client.ConnectionDispose();
    //        return s;
    //    }
    //    catch (Exception ex)
    //    {
    //        if (client.tcp != null)
    //        {
    //            client.ConnectionDispose();
    //        }
    //        //port = 0;
    //        //addr = "";
    //        WriterLOG errLog = new WriterLOG("ErrorLog" + DateTime.Now.ToString("HHmmssfff") + System.Guid.NewGuid().ToString());
    //        errLog.WriteEntryData("GetMessage Error : " + ex.Message + "\n" + ex.StackTrace + "\n <傳送訊息：>" + String.Concat(SendMsg));
    //        errLog.Close();
    //        return null;
    //    }
    //    finally
    //    {

    //    }

    //}

    ///// <summary>
    ///// MOB保証金查詢
    ///// </summary>
    ///// <param name="CustomerId"></param>
    ///// <param name="currency"></param>
    ///// <param name="CompanyID"></param>
    ///// <returns></returns>
    //public string[] getMOB_CurrentMargin(string CustomerId, string currency,string CompanyID,WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)
    //{
    //    string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
    //    futureID = "";
    //    string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x50 }) + futureID + CompanyID.Trim() + CustomerId + currency);
    //    string[] returnStr = GetMessage(sendStr,mobj_T1Log,mobj_T4Log );
    //    return returnStr;
    //}

    ///// <summary>
    ///// MOB當日損益查詢
    ///// </summary>
    ///// <param name="CustomerId"></param>
    ///// <param name="currency"></param>
    ///// <param name="CompanyID"></param>
    ///// <returns></returns>
    //public string[] getMOB_CurrentBalance(string CustomerId, string currency, string CompanyID,WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)
    //{
    //    string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
    //    futureID = "";
    //    string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x52 }) + futureID + CompanyID.Trim() + CustomerId + currency);
    //    string[] returnStr = GetMessage(sendStr, mobj_T1Log, mobj_T4Log);
    //    return returnStr;

    //}


    ///// <summary>
    ///// 即時部位查詢
    ///// </summary>
    ///// <param name="CustomerId"></param>
    ///// <param name="type">1:單式部位  2:全部</param>
    ///// <param name="CompanyID"></param>
    ///// <returns></returns>
    //public string[] getMOB_CurrentPosition(string CustomerId, string type, string CompanyID,WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)  //傳入customer id 與  type(看單式部位或是全部)
    //{
    //   //即時部位查詢 0x56   1:單式部位  2:全部
    //    string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
    //    futureID = "";
    //    string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x56 }) + futureID + CompanyID.Trim() + CustomerId+"2" + type + "".PadLeft(20, ' '));
    //    string[] returnStr = GetMessage(sendStr, mobj_T1Log, mobj_T4Log);
    //    return returnStr;
    //}

    ///// <summary>
    ///// 取得MOB未平倉資料
    ///// </summary>
    ///// <param name="CustomerId"></param>
    ///// <param name="CompanyID"></param>
    ///// <returns></returns>
    //public string[] getMOB_UnLiquidation(string CustomerId,string CompanyID,WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)
    //{
    //    string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
    //    futureID = "";
    //    string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x05 }) + futureID + CompanyID.Trim() + CustomerId);
    //    string[] returnStr = GetMessage(sendStr, mobj_T1Log, mobj_T4Log);
    //    return returnStr;
    //}


    ///// <summary>
    ///// 拆組申請
    ///// </summary>
    ///// <param name="CustomerId"></param>
    ///// <param name="CompanyID"></param>
    ///// <returns></returns>
    //public string[] getMOB_Combine(string CustomerId, string CompanyID,string[] combineData, WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)
    //{
    //    string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
    //    futureID = "";
    //    string[] sendStr = new string[combineData.Length];
    //    for (int i = 0; i < combineData.Length; i++)
    //    {
    //        sendStr[i] = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x61 }) + combineData[i]);
    //    }
    //    string[] returnStr = GetMessage(sendStr, mobj_T1Log, mobj_T4Log);
    //    return returnStr;
    //}
    ///// <summary>
    ///// 了結申請
    ///// </summary>
    ///// <param name="CustomerId"></param>
    ///// <param name="CompanyID"></param>
    ///// <returns></returns>
    //public string[] getMOB_Net(string CustomerId, string CompanyID, string[] combineData, WriterLOG mobj_T1Log, WriterLOG mobj_T4Log)
    //{
    //    string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
    //    futureID = "";
    //    string[] sendStr = new string[combineData.Length];
    //    for (int i = 0; i < combineData.Length; i++)
    //    {
    //        sendStr[i] = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x64 }) + combineData[i]);
    //    }
    //    string[] returnStr = GetMessage(sendStr, mobj_T1Log, mobj_T4Log);
    //    return returnStr;
    //}

    ////20100226 added by philip  供 MOB查詢時抓 socket的strlocalip & strlocalport
    //public string MOB_RequestSeqID(string subject)
    //{
    //    string sendData = "";
    //    try
    //    {
    //        string remoteIP = System.Configuration.ConfigurationManager.AppSettings["REMOTE_IP"];
    //        string remotePORT = System.Configuration.ConfigurationManager.AppSettings["REMOTE_PORT"];

    //        //string addressID = mobj_AccountRequestSocketClient.strlocalip + ":" + mobj_AccountRequestSocketClient.strlocalport.PadRight(5, ' ');
    //        string addressID = remoteIP + ":" + remotePORT.PadRight(5, ' ');

    //        //string seq = (addressID.PadLeft(21, ' ') + "1".ToString().PadLeft(6, ' ')).PadLeft(27, ' ');
    //        string seq = (addressID.PadLeft(21, ' ') + "1".ToString().PadLeft(6, ' ')).PadLeft(27, ' ');

    //        //sendData = "15" + seq + subject;
    //        sendData = seq + subject;
    //    }
    //    catch (Exception ex)
    //    {
    //        //AEFutureMaster.frmMain.AOBJ_ErrLog.WriteError(ex.Source, ex.StackTrace.ToString(), ex.Message, System.Diagnostics.EventLogEntryType.Error);

    //    }
    //    return sendData;
    //}
}
