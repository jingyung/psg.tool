﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Data;


/// <summary>
/// MobDataParse 的摘要描述
/// </summary>
public class MobDataParse
{

    private  DataTable mdt_RealPart;
    private  DataTable mdt_RealPartMix;
    private  DataTable mdt_UnLiquidationDetail;
    private  DataTable mdt_PositionData;
    private  DataTable mdt_UnLiquidationMain;

    private  DataTable mdt_FutureData;
    private  DataTable mdt_OptionData;
    private  DataTable mdt_translate_values;

    public DataTable mdt_MOBCurrentMargin;
    public DataTable mdt_MOBCurrentBalance;
    public DataTable mdt_MOBCombineData;

    //private DataTable mdt_MOBCurrenetMarginRapid;
    WriterLOG mobj_ErroLog = new WriterLOG("MOBError" + DateTime.Now.ToString("HHmmssfff"));
	public MobDataParse()
	{
		//
		// TODO: 在此加入建構函式的程式碼
		//
        //-----取得初始資料------
        //this.getINIData();

        //初始化Table
        initializedRealPart();
        initializedRealPartMix();
        initializedUnLiquidationDetail();
        initializedPositionData();
        initializedUnLiquidationMain();
        initializedMOBCombineData();


	}

    public void parseMobInfoData(string OriginalstrData)
    {
        string[] str = new string[1];
        str[0] = OriginalstrData;
        parseMobInfoData(str);
    }

    /// <summary>
    /// 拆解行情資訊
    /// </summary>
    /// <param name="strData">The STR data.</param>
    // public void parseMobInfoData(string strData)
    public void  parseMobInfoData(string[] OriginalstrDataArry)
    {
        
        Int32 idx = 0;
        
        for (idx = 0; idx < OriginalstrDataArry.Length; idx++)
        {
            string OriginalstrData = OriginalstrDataArry[idx];
            try
            {
               
                //mobj_InfoLog.WriteEntryData(OriginalstrData);

                string strData = OriginalstrData.Substring(0, 1) + OriginalstrData.Substring(28);
                
                //依 strData頭碼分派資料給個 unMOB                
                byte[] header = Encoding.Default.GetBytes(strData.Substring(0, 1));
               
                switch (header[0].ToString().Trim())
                {
                    case "81":   // 0x51保證金查詢 回覆
                        
                        bool bolHaveData_cm = unCurrentMargin_MobInfo(strData);
                        
                        break;
                    case "19":       //0x13 未平倉查詢回覆


                        Boolean bolHaveData = false;
                        int BodyCount = Convert.ToInt16(strData.Substring(23, 2));

                        Byte[] byteLiquidation = new byte[Encoding.Default.GetBytes(strData).Length];
                        Array.Copy(Encoding.Default.GetBytes(strData), 0, byteLiquidation, 0, byteLiquidation.Length);
                        string[] strProducts = new string[BodyCount];
                        for (int i = 0; i < BodyCount; i++)
                        {

                            strProducts[i]= SubStr(strData, i * 145 + 59, 10).Trim();

                            Array.Copy(Encoding.Default.GetBytes("".PadRight(10, ' ')), 0, byteLiquidation, i * 145 + 25 + 34, 10);
                           
                        }
                        bolHaveData = unLiquidation_MobInfo(Encoding.Default.GetString(byteLiquidation), strProducts);
                        break;
                        
                    case "83":       // 0x53當日損益查詢回覆
                        
                        bool bolHaveData_cb = CurrentBalance_MobInfo(strData);
                        break;

                    case "87":   //0x57 即時部位查詢回覆  單式查詢  混合查詢 分別填入兩個不同的table
                        Boolean bolhaveData_real = false;
                        Boolean bolhaveData_realMix = false;


                        Byte[] byteCurrentPosition = new byte[Encoding.Default.GetBytes(strData).Length];
                        Array.Copy(Encoding.Default.GetBytes(strData), 0, byteCurrentPosition, 0, byteCurrentPosition.Length);
                        string strProduct ="";


                        strProduct = SubStr(strData,38, 10).Trim();

                        Array.Copy(Encoding.Default.GetBytes("".PadRight(10, ' ')), 0, byteCurrentPosition, 38, 10);
 

                        if (strData.Substring(24, 1) == "1")
                        {
                            bolhaveData_real = ucCurrentPosition_MobInfo(Encoding.Default.GetString(byteCurrentPosition), strProduct);
                            
                        }
                        if (strData.Substring(24, 1) == "2")
                        {
                            bolhaveData_realMix = ucCurrentPositionMix_MobInfo(Encoding.Default.GetString(byteCurrentPosition));
                            
                        }
                        
                        break;
                    case "89":   //0x59 即時組合查詢回覆
                        //Boolean bolHaveData_comb = false;
                        //bolHaveData_comb = unLiquidation_MobInfo(strData);
                        break;
                    //case "98":   //0x62 拆組                     
                    //    if (strData.Substring(17, 2) == "00")
                    //    {
                    //        //批號_流水號
                    //        //strData.Substring(1, 8) + "_" + strData.Substring(13, 4) + "申請成功!!"
                    //    }
                    //    else if (strData.Substring(17, 2) == "99")
                    //    {
                    //        //批號_流水號
                    //        //strData.Substring(1, 8) + "_" + strData.Substring(13, 4) + "申請失敗!!"
                    //    }
                    //    break;


                    case "98":  //0x62 拆組     98
                    case "101":  //0x65 拆組     101

                        for (int i = 1; i <= int.Parse(strData.Substring(13, 4)); i++)
                        {

                            DataRow dr = mdt_MOBCombineData.NewRow();



                            dr["ADJNO"] = strData.Substring(1, 8);

                            dr["COUNT"] = strData.Substring(9, 4);

                            dr["SEQNO"] = i.ToString().PadLeft(4,'0');



                            if (strData.Substring(17, 2) == "00")
                            {

                                dr["STATUS"] = "申請成功!!";

                            }

                            else if (strData.Substring(17, 2) == "99")
                            {

                                dr["STATUS"] = "申請失敗!!";

                            }



                            mdt_MOBCombineData.Rows.Add(dr);
                        }
                        break;


                }
            }
            catch (Exception ex)
            {
                mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            }
            
        }
    }
    public string SubStr(string a_SrcStr, int a_StartIndex, int a_Cnt)
    {
        Encoding l_Encoding = Encoding.GetEncoding("big5", new EncoderExceptionFallback(), new DecoderReplacementFallback(""));
        byte[] l_byte = l_Encoding.GetBytes(a_SrcStr);
        if (a_Cnt <= 0)
            return "";
        //例若長度10 
        //若a_StartIndex傳入9 -> ok, 10 ->不行 
        if (a_StartIndex + 1 > l_byte.Length)
            return "";
        else
        {
            //若a_StartIndex傳入9 , a_Cnt 傳入2 -> 不行 -> 改成 9,1 
            if (a_StartIndex + a_Cnt > l_byte.Length)
                a_Cnt = l_byte.Length - a_StartIndex;
        }
        return l_Encoding.GetString(l_byte, a_StartIndex, a_Cnt);
    }


    /// <summary>
    /// MOB CurrentBalance MOB當日損益查詢
    /// </summary>
    private  Boolean  CurrentBalance_MobInfo(string info)
    {
        DataTable infoDT1 = new DataTable();
        Boolean status = false;

        try
        {   
            if (info.Substring(107, 1) == "1")
            {


                infoDT1.Columns.Add(new DataColumn("OSPRTLOS"));//當日損益
                infoDT1.Columns.Add(new DataColumn("BCPREMIUM"));//買方權利金市值(買權)
                infoDT1.Columns.Add(new DataColumn("BPPREMIUM"));//買方權利金市值(賣權)
                infoDT1.Columns.Add(new DataColumn("SCPREMIUM"));//賣方權利金市值(買權)
                infoDT1.Columns.Add(new DataColumn("SPPREMIUM"));//賣方權利金市值(賣權)

                DataRow dr = infoDT1.NewRow();
                dr["OSPRTLOS"] = NumberTrim(info.Substring(27, 16));
                dr["BCPREMIUM"] = NumberTrim(info.Substring(43, 16));
                dr["BPPREMIUM"] = NumberTrim(info.Substring(59, 16));
                dr["SCPREMIUM"] = NumberTrim(info.Substring(75, 16));
                dr["SPPREMIUM"] = NumberTrim(info.Substring(91, 16));

                infoDT1.Rows.Add(dr);
                infoDT1.AcceptChanges();

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[0]["value"] = NumberTrim(info.Substring(27, 16));        //當日損益
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[1]["value"] = NumberTrim(info.Substring(43, 16));         //買方權利金市值(買權)
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[2]["value"] = NumberTrim(info.Substring(59, 16));       //買方權利金市值(賣權)
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[3]["value"] = NumberTrim(info.Substring(75, 16));   //賣方權利金市值(買權)
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[4]["value"] = NumberTrim(info.Substring(91, 16)); //賣方權利金市值(賣權)
                
                status = true;
            }
            else
            {
                //do nothing 
                status = false;
            }
        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData("初始化失敗" + ex.Message + ex.StackTrace.ToString() + ex.Source.Trim());
            status = false;
        }
        mdt_MOBCurrentBalance = infoDT1;
        return status;

    }


    //added 20100421 MOB unliquidation 明細
    private DataRow unLiquidation_list(string info, DataRow ddr, int i,string productdesc)
    {
        try
        {
            //added by philip 20100319
            double CurrentBalance = 0;
            double CurrentValue = 0;

            ddr["currency"] = info.Substring(i * 145 + 125, 3);           //幣別
            ddr["investorAcno"] = info.Substring(16, 7);                  //下單帳號
            ddr["tradedate"] = info.Substring(i * 145 + 37, 10);          //成交日期
            ddr["matchTime"] = "";                                        //成交時間  先帶空白
            ddr["orderNo"] = info.Substring(i * 145 + 29, 6);             //委託單號
            ddr["BS"] = info.Substring(i * 145 + 47, 1);                  //買賣別
            
            //商品代碼
            ddr["productId"] = info.Substring(i * 145 + 49, 10).Trim();
            //ddr["productId"] = getProductId(comtypeTransfer(info.Substring(i * 145 + 48, 1)), ProductNameTrans(info.Substring(i * 145 + 49, 7).Trim(), info.Substring(i * 145 + 48, 1)), info.Substring(i * 145 + 56, 6), info.Substring(i * 145 + 62, 6), info.Substring(i * 145 + 68, 1));
            string period = getOptionPeriod(ddr["productId"].ToString().Substring(ddr["productId"].ToString().Length-2, 1)).ToString();
            string cp = "";
            string strikeprice = "";
            if (info.Substring(i * 145 + 48, 1) == "1")
            {
                cp = getOptionCP( ddr["productId"].ToString().Substring(8,1));
                strikeprice = decimal.Parse(ddr["productId"].ToString().Substring(3, 5)).ToString("#0.#");
                ddr["cp"] = cp;
            }


            ddr["productName"] = productdesc + strikeprice+cp+period ;
 
            ddr["MKTcomno"] = ddr["productId"].ToString().Substring(0, 3);
            ddr["comym"] = "201" + ddr["productId"].ToString().Substring(ddr["productId"].ToString().Length - 1, 1) + getOptionPeriod(ddr["productId"].ToString().Substring(ddr["productId"].ToString().Length - 2, 1)).ToString().PadLeft(2, '0');
            ddr["stkprc"] = strikeprice;


            double price = Math.Round(double.Parse(info.Substring(i * 145 + 128, 9)) / 10000, 2, MidpointRounding.AwayFromZero);
            ddr["MatchPrice"] = price.ToString("#,##0.00");

            //參考即時價
            //參考浮動損益

            //參考現值

            double dCurrentPrice = double.Parse(info.Substring(i * 145 + 161, 9)) / 10000;
            double cntsize = double.Parse(info.Substring(i * 145 + 143, 18)) / 1000000;
            //若查不到 則帶 NA
            if (dCurrentPrice == 0)
            {
                ddr["RefRealPrice"] = "NA";
                ddr["RefPL"] = "NA";
                ddr["RefNowPrice"] = "NA";     //參考現值

            }
            else
            {
                int qty = Convert.ToInt16(info.Substring(i * 145 + 70, 4));


                //added 20100326 四捨五入
                double roundoff_dCurrentPrice = Math.Round(dCurrentPrice, 2, MidpointRounding.AwayFromZero);

                ddr["RefRealPrice"] = roundoff_dCurrentPrice.ToString("#,##0.00");

                //modified by philip 20100319 CurrentBalance即時浮動損益 依成交時的買賣別計算
                if (info.Substring(i * 145 + 47, 1) == "B")
                {
                    CurrentBalance = (dCurrentPrice - price) * cntsize * qty;

                }
                else
                {
                    CurrentBalance = (price - dCurrentPrice) * cntsize * qty;
                }

                //added 20100326 四捨五入
                double roundoff_CurrentBalance = Math.Round(CurrentBalance, 2, MidpointRounding.AwayFromZero);
                ddr["RefPL"] = roundoff_CurrentBalance.ToString("#,##0.00");    //參考浮動損益


                //參考現值

                CurrentValue = dCurrentPrice * cntsize * qty;
                double roundoff_CurrentValue = Math.Round(CurrentValue, 2, MidpointRounding.AwayFromZero);
                ddr["RefNowPrice"] = roundoff_CurrentValue.ToString("#,##0.00");

            }

            ddr["OTQTY"] = Convert.ToInt16(info.Substring(i * 145 + 70, 4));  //留倉口數

            ddr["DTOVER"] = info.Substring(i * 145 + 69, 1);               //當沖
            ddr["productKind"] = spreadType(info.Substring(i * 145 + 124, 1).Trim());              //商品類別 

            //避免複式單拆開後.造成重複問題,將第二隻腳成交序號修改成"成交序號+腳號"
            if (info.Substring(i * 145 + 35, 1) != "1" && (info.Substring(i * 145 + 124, 1) == "0" || info.Substring(i * 145 + 124, 1) == "7"))
            {
                ddr["matchseq"] = info.Substring(i * 145 + 35, 2);        ////拆單續號
            }
            else
            {
                ddr["matchseq"] = info.Substring(i * 145 + 36, 1);        ////拆單續號
            }

            if (ddr["productKind"].ToString() == "3" || ddr["productKind"].ToString() == "4")
            {

                ddr["footMatchPrice"] = ddr["MatchPrice"].ToString();
            }


            return ddr;
        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            return null;
        }
    }

    //added 20100421 MOB unliquidation 複式商品資料更新
    private DataRow unLiquidationDetailCombine(DataRow dr1, DataRow dr2, string spreadKind, string productType,double cntsize,string productdesc)
    {
        try
        {

            
            if (spreadKind == "1" || spreadKind == "2" || spreadKind == "3" || spreadKind == "4" || spreadKind == "5")
            {
                string[] strReturn=MultipleProductId(productType, dr1["productId"].ToString(), dr2["productId"].ToString(), dr1["BS"].ToString(), dr2["BS"].ToString(), productdesc);
                dr1["multiplecomno"] = strReturn[0];
                dr1["productName"] = strReturn[2];
                dr1["multipleBS"] = strReturn[6];

                dr1["productId"] = strReturn[3] + "\n" + strReturn[4];
                dr1["BS"] = strReturn[5] + "\n" + strReturn[6];
                dr1["cp"] = strReturn[7] + "\n" + strReturn[8];
                 
                dr1["MKTCOMNO"] = strReturn[3].Substring(0, 3);
                dr1["COMYM"] = strReturn[11] + "\n" + strReturn[12];
                dr1["STKPRC"] = strReturn[9] + "\n" + strReturn[10];
                 
                if (dr2["BS"].ToString() == strReturn[6])
                {

                    dr1["footMatchPrice"] += "\n" + dr2["MatchPrice"].ToString();
                    dr1["MatchPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr1["MatchPrice"].ToString()), Convert.ToDecimal(dr2["MatchPrice"].ToString()));
                    dr1["RefRealPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr1["RefRealPrice"].ToString()), Convert.ToDecimal(dr2["RefRealPrice"].ToString()));
                    dr1["RefNowPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr1["RefNowPrice"].ToString()), Convert.ToDecimal(dr2["RefNowPrice"].ToString()));

                }
                else
                {
                    dr1["footMatchPrice"] = dr2["footMatchPrice"] + "\n" + dr1["MatchPrice"].ToString();
                    dr1["MatchPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr2["MatchPrice"].ToString()), Convert.ToDecimal(dr1["MatchPrice"].ToString()));
                    dr1["RefRealPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr2["RefRealPrice"].ToString()), Convert.ToDecimal(dr1["RefRealPrice"].ToString()));
                    dr1["RefNowPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr2["RefNowPrice"].ToString()), Convert.ToDecimal(dr1["RefNowPrice"].ToString()));

                    
                  
                }


                if (dr1["multipleBS"].ToString() == "B")
                {
                    dr1["RefPL"] = (double.Parse(dr1["RefRealPrice"].ToString()) - double.Parse(dr1["MatchPrice"].ToString())) * int.Parse(dr2["OTQTY"].ToString()) * cntsize;
                }
                else
                {
                    dr1["RefPL"] = (double.Parse(dr1["MatchPrice"].ToString()) - double.Parse(dr1["RefRealPrice"].ToString())) * int.Parse(dr2["OTQTY"].ToString()) * cntsize;
                }

         

            }
            else
            {
                dr1["multipleBS"] = dr2["BS"].ToString();
                dr1["productName"] = dr1["productName"].ToString() + " " + dr2["productName"].ToString();
                dr1["MatchPrice"] = DBNull.Value;
                dr1["RefRealPrice"] = "NA";
                dr1["RefNowPrice"] = "NA";
                dr1["RefPL"] = "NA";
                if (dr2["footMatchPrice"].ToString().Trim() == "")//避免三隻腳,第一腳最後回來,沒串到前面串好的成交價
                {
                    dr1["footMatchPrice"] += "\n" + dr2["MatchPrice"].ToString();
                }
                else
                {
                    dr1["footMatchPrice"] += "\n" + dr2["footMatchPrice"].ToString();
                }
                dr1["productId"] += "\n" + dr2["productId"].ToString();
                dr1["BS"] += "\n" + dr2["BS"].ToString();
                dr1["cp"] += "\n" + dr2["cp"].ToString();

                dr1["MKTCOMNO"] += "\n" + dr2["MKTCOMNO"].ToString();
                dr1["COMYM"] += "\n" + dr2["COMYM"].ToString();
                dr1["STKPRC"] += "\n" + dr2["STKPRC"].ToString();
            }
         

            return dr1;
        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(dr1["orderNo"].ToString() + dr1["productId"].ToString() + dr2["productId"].ToString() + ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            return null;
        }
    }


    // private DataRow drC = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetailTempCombine.NewRow();

    /// <summary>
    /// MOB UnLiquidation 計算   MOB未平倉損益

    /// </summary>
    /// <param name="info"></param>
    /// <returns></returns>
    private bool unLiquidation_MobInfo(string info,string[] strProducts)
    {
        
        
        //initializedUnLiquidationDetail();
        try
        {

            int BodyCount = Convert.ToInt16(info.Substring(23, 2));

            for (int i = 0; i < BodyCount; i++)
            {

                //added 20100421 複式單呈現
            
                //if (info.Substring(i * 145 + 124, 1).Trim() == "6" | info.Substring(i * 145 + 124, 1).Trim() == "1" | info.Substring(i * 145 + 124, 1).Trim() == "2" | info.Substring(i * 145 + 124, 1).Trim() == "3" | info.Substring(i * 145 + 124, 1).Trim() == "4" | info.Substring(i * 145 + 124, 1).Trim() == "5")
                //{
                if (info.Substring(i * 145 + 124, 1).Trim() != "0" && info.Substring(i * 145 + 124, 1).Trim() != "7")
                {
                    // //委託單號取前5碼當做比對     拆單續號

                    //modified 20100923 增加日期條件
                    string combineFliter = "tradedate='"+info.Substring(i * 145 + 37, 10)+"' and orderNo='" + info.Substring(i * 145 + 29, 6) + "' and matchseq ='" + info.Substring(i * 145 + 36, 1) + "'";
                   
                    DataRow[] dttCombine = mdt_UnLiquidationDetail.Select(combineFliter);

                    //當mdt_UnLiquidationDetail內有一筆複式商品落單的腳 , 才進來做兩隻腳的合併

                    if (dttCombine.Length == 1)
                    {
                        // DataRow drC = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetailTempCombine.NewRow();
                        DataRow drC = mdt_UnLiquidationDetail.NewRow();

                        drC = unLiquidation_list(info, drC, i,strProducts[i]);

                        string spreadKind = null;
                        string productType = null;
                        // 精誠  7:單式期貨 0:單式期權  6:複式期貨 12345:複選期權             
                        //// 1價差 2跨月 3跨式 4勒式 5轉換逆轉換 0期貨價差  
                        // 
                        if (info.Substring(i * 145 + 124, 1).Trim() == "6")
                        {
                            spreadKind = "0";
                            productType = "4";
                        }
                        else
                        {
                            spreadKind = info.Substring(i * 145 + 124, 1).Trim();
                            productType = "3";
                        }

                        DataRow combineRow = null;
                        //added by philip 20100923
                        double cntsize = double.Parse(info.Substring(i * 145 + 143, 18)) / 1000000;


                        //更新原本在mdt_UnLiquidationDetail 相對應的複式商品
                        if (info.Substring(i * 145 + 35, 1) == "1")
                        {

                            combineRow = unLiquidationDetailCombine(drC, dttCombine[0], spreadKind, productType, cntsize, strProducts[i]);


                            dttCombine[0]["multiplecomno"] = combineRow["multiplecomno"];
                            dttCombine[0]["multipleBS"] = combineRow["multipleBS"];
                            dttCombine[0]["MatchPrice"] = combineRow["MatchPrice"];
                            dttCombine[0]["RefRealPrice"] = combineRow["RefRealPrice"];
                            dttCombine[0]["RefNowPrice"] = combineRow["RefNowPrice"];
                            dttCombine[0]["RefPL"] = combineRow["RefPL"];
                            dttCombine[0]["matchseq"] = combineRow["matchseq"];
                            dttCombine[0]["productId"] = combineRow["productId"];
                            dttCombine[0]["BS"] = combineRow["BS"];
                            dttCombine[0]["cp"] = combineRow["cp"];
                            dttCombine[0]["productName"] = combineRow["productName"];
                            dttCombine[0]["footMatchPrice"] = combineRow["footMatchPrice"];
                            dttCombine[0]["MKTCOMNO"] = combineRow["MKTCOMNO"];
                            dttCombine[0]["COMYM"] = combineRow["COMYM"];
                            dttCombine[0]["STKPRC"] = combineRow["STKPRC"];
                        }
                        else
                        {
                            //dttCombine[0].BeginEdit();
                            //dttCombine[0] = unLiquidationDetailCombine(dttCombine[0], drC, spreadKind, productType);
                            //dttCombine[0].EndEdit();
                            //  dttCombine[0].ItemArray = unLiquidationDetailCombine(dttCombine[0], drC, spreadKind, productType).ItemArray;

                            combineRow = unLiquidationDetailCombine(dttCombine[0], drC, spreadKind, productType, cntsize, strProducts[i]);


                            dttCombine[0]["multiplecomno"] = combineRow["multiplecomno"];
                            dttCombine[0]["multipleBS"] = combineRow["multipleBS"];
                            dttCombine[0]["MatchPrice"] = combineRow["MatchPrice"];
                            dttCombine[0]["RefRealPrice"] = combineRow["RefRealPrice"];
                            dttCombine[0]["RefNowPrice"] = combineRow["RefNowPrice"];
                            dttCombine[0]["RefPL"] = combineRow["RefPL"];
                            dttCombine[0]["matchseq"] = combineRow["matchseq"];
                            dttCombine[0]["productId"] = combineRow["productId"];
                            dttCombine[0]["BS"] = combineRow["BS"];
                            dttCombine[0]["cp"] = combineRow["cp"];
                            dttCombine[0]["MKTCOMNO"] = combineRow["MKTCOMNO"];
                            dttCombine[0]["COMYM"] = combineRow["COMYM"];
                            dttCombine[0]["STKPRC"] = combineRow["STKPRC"];
                            dttCombine[0]["productName"] = combineRow["productName"];
                            dttCombine[0]["footMatchPrice"] = combineRow["footMatchPrice"];
                        }

                        //drC.
                        continue;
                        //  frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetailTempCombine.Rows.Add(drC);
                    }
                }


                DataRow ddr = mdt_UnLiquidationDetail.NewRow();

                ddr = unLiquidation_list(info, ddr, i, strProducts[i]);

                mdt_UnLiquidationDetail.Rows.Add(ddr);


            }




            //20100226 判斷是否還有資料
            //initializedUnLiquidationMain();
            //initializedPositionData();

            if (info.Substring(info.Length - 2, 1) == "\n" || info.Substring(info.Length - 2, 1) == "\r")
            {

                //判斷是否有資料


                // if (frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBUnLiquidation.Rows.Count == 0)
                if (mdt_UnLiquidationDetail.Rows.Count == 0)
                {

                    return true;
                }


                //計算加總 
                //modified by philip 20100408 多加一個條件 spread
                // DataTable dtTarget = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBUnLiquidation.DefaultView.ToTable(true, new string[] { "PS", "ProductName", "currency" , "spread" });

                //modified 201004223 用dataview來接mdt_UnLiquidationDetail 再使用

                DataView unliquidationDetail = new DataView(mdt_UnLiquidationDetail);
                DataTable dtTarget = unliquidationDetail.Table.DefaultView.ToTable(true, new string[] { "BS", "productId", "currency", "productKind" });

                //  DataTable dtTarget = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetail.DefaultView.ToTable(true, new string[] { "BS", "productId", "currency", "productKind" });


                if (dtTarget.Rows.Count != 0)
                {
                    foreach (DataRow dr in dtTarget.Rows)
                    {

                        int tempOTQTY = 0;
                        double tempTRDPRC1 = 0;
                        double tempCurrentBalance = 0;
                        double tempRefTotalPrice = 0;
                        //  unliquidationDetail.Table.NewRow()
                        DataRow drResult = mdt_PositionData.NewRow();
                        DataRow drrResult = mdt_UnLiquidationMain.NewRow();

                        //modified by philip 20100408 多加一個條件 spread
                        //string command = "PS='" + dr["PS"] + "' and ProductName = '" + dr["ProductName"] + "' and CURRENCY = '" + dr["CURRENCY"] + "' and spread='" + dr["spread"] + "'";
                        string command = "BS='" + dr["BS"] + "' and productId = '" + dr["productId"] + "' and currency = '" + dr["currency"] + "' and productKind='" + dr["productKind"] + "'";

                        // DataRow[] rCount = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBUnLiquidation.Select(command);
                        DataRow[] rCount = mdt_UnLiquidationDetail.Select(command);
                        Dictionary<int, decimal> dcFootPrice = new Dictionary<int, decimal>();
                        foreach (DataRow drr in rCount)
                        {

                            if (drr["footMatchPrice"].ToString() != "")
                            {
                                int idx = 0;
                                foreach (string foot in drr["footMatchPrice"].ToString().Split(new Char[] { }))
                                {

                                    if (dcFootPrice.ContainsKey(idx))
                                    {
                                        dcFootPrice[idx] += decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString());
                                    }
                                    else
                                    {
                                        dcFootPrice.Add(idx, decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString()));
                                    }
                                    idx++;
                                }

                            }
                            tempOTQTY += Convert.ToInt16(drr["OTQTY"].ToString());

                            if (drr["MatchPrice"].ToString() != "")
                            {
                                tempTRDPRC1 += double.Parse(drr["MatchPrice"].ToString()) * Convert.ToInt16(drr["OTQTY"].ToString());
                            }

                            //if (drr["CurrentBalance"].ToString() == "NA")
                            if (drr["RefPL"].ToString() == "NA")
                            {
                                tempCurrentBalance += 0;
                            }
                            else
                            {

                                tempCurrentBalance += double.Parse(drr["RefPL"].ToString());   //
                            }

                            if (drr["RefNowPrice"].ToString() == "NA")
                            {
                                tempRefTotalPrice += 0;
                            }
                            else
                            {
                                tempRefTotalPrice += double.Parse(drr["RefNowPrice"].ToString());
                            }



                            //update by samantha 20100415 修改只有mdt_UnLiquidationMain帶即時價 
                            //drrResult["realprice"] = drr["RefRealPrice"].ToString().Trim();
                            if (drr["RefNowPrice"].ToString() == "NA")
                            {
                                drrResult["realprice"] = System.DBNull.Value  ;
                            }
                            else
                            {
                                drrResult["realprice"] = drr["RefRealPrice"].ToString().Trim();
                            }
                            
                            //added by philip 20100416 mdt_PositionData 也需要即時價
                            drResult["MarketPrice"] = drr["RefRealPrice"].ToString().Trim();

                            //modified 20100319 即時浮動損益需要加總  再除以總口數
                            //   drResult["CurrentBalance"] = drr["CurrentBalance"].ToString().Trim();

                            drResult["BS"] = drr["BS"].ToString().Trim();
                            drResult["initBS"] = drr["BS"].ToString().Trim();
                            drrResult["BS"] = drr["BS"].ToString().Trim();

                            drResult["ProductId"] = drr["ProductId"].ToString().Trim();
                            drrResult["ProductId"] = drr["ProductId"].ToString().Trim();


                            drrResult["currency"] = drr["currency"].ToString().Trim();

                            //add 20100408 

                            drResult["productKind"] = drr["productKind"].ToString().Trim();
                            drrResult["productKind"] = drr["productKind"].ToString().Trim();

                            //added 20100414 帶入帳號
                            drResult["investorAcno"] = drr["investorAcno"].ToString().Trim();
                            drrResult["investorAcno"] = drr["investorAcno"].ToString().Trim();

                            //added 20100423 帶入複式商品資訊
                            drResult["multiplecomno"] = drr["multiplecomno"].ToString().Trim();
                            drrResult["multiplecomno"] = drr["multiplecomno"].ToString().Trim();
                            drResult["multipleBS"] = drr["multipleBS"].ToString().Trim();
                            drrResult["multipleBS"] = drr["multipleBS"].ToString().Trim();

                            drrResult["productName"] = drr["productName"].ToString().Trim();

                            drrResult["cp"] =drr["cp"];

                            drrResult["MKTCOMNO"] = drr["MKTCOMNO"];
                            drrResult["comym"] = drr["comym"];
                            drrResult["stkprc"] = drr["stkprc"];
                        }


                        drrResult["TotalOTQTY"] = tempOTQTY.ToString();

                        drResult["PositionQty"] = tempOTQTY.ToString();
                        drResult["initPositionQty"] = tempOTQTY.ToString();

                        if (tempOTQTY == 0)
                        {

                            drResult["PositionPrice"] = "NA";
                            drResult["MarketPrice"] = "NA";

                            //added 20100414 
                            drrResult["RefTotalPrice"] = "NA";
                        }
                        else
                        {
                            double TRDPRC1 = tempTRDPRC1 / tempOTQTY;
                            //added 20100326 四捨五入
                            double roundoff_TRDPRC1 = Math.Round(TRDPRC1, 2, MidpointRounding.AwayFromZero);
                            // drResult["AvgPrice"] = roundoff_TRDPRC1.ToString("#,##0.00");
                            drResult["PositionPrice"] = roundoff_TRDPRC1.ToString("#,##0.00");
                            drrResult["AvgMatchPrice"] = roundoff_TRDPRC1.ToString("#,##0.00");

                            //added 20100414  參考總現值

                            double roundoff_tempRefTotalPrice = Math.Round(tempRefTotalPrice, 2, MidpointRounding.AwayFromZero);
                            drrResult["RefTotalPrice"] = roundoff_tempRefTotalPrice.ToString("#,##0.00");



                            if (drResult["MarketPrice"].ToString().Trim() == "NA")
                            {

                                drrResult["RefTotalPL"] = "NA";
                            }
                            else
                            {
                                //added 20100326 四捨五入
                                double roundoff_tempCurrentBalance = Math.Round(tempCurrentBalance, 2, MidpointRounding.AwayFromZero);

                                drrResult["RefTotalPL"] = roundoff_tempCurrentBalance.ToString("#,##0.00");

                            }
                            if (dcFootPrice.Keys.Count > 0)
                            {

                                foreach (int key in dcFootPrice.Keys)
                                {
                                    if (key == 0)
                                    {
                                        drrResult["footMatchPrice"] = (dcFootPrice[key] / tempOTQTY).ToString("#,##0.##");
                                    }
                                    else
                                    {
                                        drrResult["footMatchPrice"] += "\n" + (dcFootPrice[key] / tempOTQTY).ToString("#,##0.##");
                                    }
                                }
                            }
                        }


                        //add by samantha 20100415 新增下單夾部位更新

                        string sign = "";
                        if (drResult["bs"].ToString().Trim() == "S")
                        {
                            sign = "-";
                        }
                        else
                        {
                            sign = "";
                        }
                        

                        //added by philip 20100505 新增彙總複式商品組成類別
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multipleBS"].ToString() != "" & drrResult["multiplecomno"].ToString() != "")
                        {
                            drrResult["MultiName"] = MultiProductParser(drrResult["productKind"].ToString(), drrResult["multipleBS"].ToString(), drrResult["multiplecomno"].ToString(), drrResult["BS"].ToString().Split('\n')[0].ToString().Trim())[0];
                        }
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multiplecomno"].ToString() == "")
                        {
                            drrResult["MultiName"] = "N/A";
                            drrResult["multiplecomno"] = drrResult["productId"].ToString();
                            drrResult["multipleBS"] = drrResult["BS"].ToString();
                        }


                        mdt_PositionData.Rows.Add(drResult);
                        object[] sss = drrResult.ItemArray ;
                        mdt_UnLiquidationMain.Rows.Add(drrResult);

                    }

                }

                return true;
            }

            return true;
            // return false;

        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            return false;
        }


    }
    //added 20100408 by philip 判別是單式還是複式商品

    //modified 20100413  1(期貨)2(選擇權)3(複式選擇權)4(複式期貨)
    // 精誠  7:單式期貨 0:單式期權  6:複式期貨 12345:複選期權
    //modified by philip 20100429 多增 N:future C:call P:put判斷
    private string spreadType(string spread)
    {
        if (spread == "7")  //單式期貨
        {
            return "1";
        }
        //if (spread == "0" | spread == "C" | spread == "P") //單式選擇權
        else if (spread == "0")
        {
            return "2";
        }
        else if (spread == "6") //複式期貨  
        {
            return "4";
        }
        else if (spread == "1" | spread == "2" | spread == "3" | spread == "4" | spread == "5")  //複式選擇權  
        {
            return "3";
        }
        else
        {
            return "3";
        }
        return "";
    }

    private string NumberTrim(string value)
    {

        if (value == "+nan")
        {
            return "N/A";
        }

        //modified by philip 20100326 數字四捨五入至小數第二位 
        // 將 decimal 都改成 type , 以利於轉型

        // 2010

        return string.Format("{0:#,#0.00}", Math.Round(double.Parse(value.ToString()), 2, MidpointRounding.AwayFromZero));



    }


    //20100226 added by philip 使用 DataAgent.cs getProductId時 1:期貨 , else : 選擇權

    //20100429 modified by philip 多增一個判斷  comtype =="N"
    private string comtypeTransfer(string comtype)
    {

        if (comtype == "0" | comtype == "N")
        {
            return "1";
        }
        else
        {
            return "0";
        }

    }

    //20100226 added by philip 使用 DataAgentcs translate_value 表格  將舊商品名轉成新商品名

    private string ProductNameTrans(string productname, string comtype)
    {

        if (comtype == "0")  //future
        {
            //DataTable dtProductNames = frmMain.mobj_DataAgent.translate_values.Copy();
            DataTable dtProductNames = mdt_translate_values.Copy();
            string command = "field_value='" + productname + "'";
            DataRow[] dr = dtProductNames.Select(command);
            return dr[0]["field_text"].ToString().Trim();
        }
        else   //option
        {
            return productname;
        }

    }

    /// <summary>
    /// MOB CurrentMargin 計算   MOB保證金查詢

    /// </summary>
    //added 20100409 by philip
    private bool unCurrentMargin_MobInfo(string info)
    {
        DataTable infoDT1 = new DataTable();
        Boolean status = false;
        try
        {

            if (info.Substring(0, 1) == "Q") //判斷頭碼是某為 Q  -> 0x51
            {
                infoDT1.Columns.Add(new DataColumn("EXRATE"));//匯率
                infoDT1.Columns.Add(new DataColumn("LCTDAB"));//昨日權益數

                infoDT1.Columns.Add(new DataColumn("LTDAB"));//昨日餘額 
                infoDT1.Columns.Add(new DataColumn("DWAMT"));//出入金

                infoDT1.Columns.Add(new DataColumn("OSPRTLOS"));//期貨平倉損益


                infoDT1.Columns.Add(new DataColumn("PRTLOS"));//期貨未平倉損益

                infoDT1.Columns.Add(new DataColumn("OPTOSPRTLOS"));//選擇權平倉損益

                infoDT1.Columns.Add(new DataColumn("OPTPRTLOS"));//選擇權未平倉損益 
                infoDT1.Columns.Add(new DataColumn("TPREMIUM"));//當日權利金支出收入

                infoDT1.Columns.Add(new DataColumn("ORIGNFEE"));//成交手續費


                infoDT1.Columns.Add(new DataColumn("CTAXAMT"));//成交期交稅

                infoDT1.Columns.Add(new DataColumn("ORDPREMIUM"));//委託預扣權利金

                infoDT1.Columns.Add(new DataColumn("CTDAB"));//權益數

                infoDT1.Columns.Add(new DataColumn("ORDIAMT"));//委託預扣原始保證金

                infoDT1.Columns.Add(new DataColumn("IAMT"));//原始保證金


                infoDT1.Columns.Add(new DataColumn("MAMT"));//維持保證金

                infoDT1.Columns.Add(new DataColumn("ORDCEXCESS"));//下單可用保證金

                infoDT1.Columns.Add(new DataColumn("BPREMIUM"));//買方權利金市值

                infoDT1.Columns.Add(new DataColumn("SPREMIUM"));//賣方權利金市值

                infoDT1.Columns.Add(new DataColumn("QPTEQUITY"));//權益總值


                infoDT1.Columns.Add(new DataColumn("INIRATE"));//原始比率
                infoDT1.Columns.Add(new DataColumn("MATRATE"));//維持比率
                infoDT1.Columns.Add(new DataColumn("OPTRATE"));//清算比率
                infoDT1.Columns.Add(new DataColumn("TWDOPTEQUITY"));//台幣權益總值

                infoDT1.Columns.Add(new DataColumn("TWDINIRATE"));//台幣原始比率

                infoDT1.Columns.Add(new DataColumn("TWDORDEXCESS"));//台幣下單可用保證金

                infoDT1.Columns.Add(new DataColumn("SYSDATE"));//資料更新日期
                infoDT1.Columns.Add(new DataColumn("SYSTIME"));//回傳資料時間
                //-----自訂的欄位--------
                infoDT1.Columns.Add(new DataColumn("DATA_TITLE"));//回傳資料時間
                infoDT1.Columns.Add(new DataColumn("AIMT"));//追繳金額
                infoDT1.Columns.Add(new DataColumn("TOTAL_DAMT"));//有價證券抵繳總額;


                DataRow dr = infoDT1.NewRow();

                dr["EXRATE"] = NumberTrim(info.Substring(37, 11));//匯率
                dr["LCTDAB"] = NumberTrim(info.Substring(48, 16));//昨日權益數

                dr["LTDAB"] = NumberTrim(info.Substring(64, 16));//昨日餘額 
                dr["DWAMT"] = NumberTrim(info.Substring(80, 16));//出入金

                dr["OSPRTLOS"] = NumberTrim(info.Substring(96, 16));//期貨平倉損益

                dr["PRTLOS"] = NumberTrim(info.Substring(112, 16));//期貨未平倉損益

                dr["OPTOSPRTLOS"] = NumberTrim(info.Substring(128, 16));//選擇權平倉損益

                dr["OPTPRTLOS"] = NumberTrim(info.Substring(144, 16));//選擇權未平倉損益 
                dr["TPREMIUM"] = NumberTrim(info.Substring(160, 16));//當日權利金支出收入

                dr["ORIGNFEE"] = NumberTrim(info.Substring(176, 16));//成交手續費

                dr["CTAXAMT"] = NumberTrim(info.Substring(192, 16));//成交期交稅

                dr["ORDPREMIUM"] = NumberTrim(info.Substring(208, 16));//委託預扣權利金

                dr["CTDAB"] = NumberTrim(info.Substring(224, 16));//權益數

                dr["ORDIAMT"] = NumberTrim(info.Substring(240, 16));//委託預扣原始保證金

                dr["IAMT"] = NumberTrim(info.Substring(256, 16));//原始保證金

                dr["MAMT"] = NumberTrim(info.Substring(272, 16));//維持保證金

                dr["ORDCEXCESS"] = NumberTrim(info.Substring(288, 16));//下單可用保證金

                dr["BPREMIUM"] = NumberTrim(info.Substring(304, 16));//買方權利金市值

                dr["SPREMIUM"] = NumberTrim(info.Substring(320, 16));//賣方權利金市值

                dr["QPTEQUITY"] = NumberTrim(info.Substring(336, 16));//權益總值

                dr["INIRATE"] = NumberTrim(info.Substring(352, 13))+"%";//原始比率
                dr["MATRATE"] = NumberTrim(info.Substring(365, 13)) + "%";//維持比率
                dr["OPTRATE"] = NumberTrim(info.Substring(378, 13)) + "%";//清算比率
                dr["TWDOPTEQUITY"] = NumberTrim(info.Substring(391, 16));//台幣權益總值

                dr["TWDINIRATE"] = NumberTrim(info.Substring(407, 16)) + "%";//台幣原始比率
                dr["TWDORDEXCESS"] = NumberTrim(info.Substring(423, 16));//台幣下單可用保證金

                dr["SYSDATE"] = info.Substring(439, 8).Insert(4, "/").Insert(7, "/");//資料更新日期
                dr["SYSTIME"] = info.Substring(447, 6).Insert(2, ":").Insert(5, ":");//回傳資料時間

                dr["DATA_TITLE"] = "本日手續費及稅";
                //追繳金額 = 原始保證金 - 權益數  , 其結果為正才顯示
                decimal recover = Convert.ToDecimal(dr["IAMT"].ToString()) - Convert.ToDecimal(dr["CTDAB"].ToString());
                if (recover < 0 &&( decimal.Parse(NumberTrim(info.Substring(365, 13))) >= 100 || decimal.Parse(NumberTrim(info.Substring(365, 13))) == 0))
                {
                    dr["AIMT"] = "無追繳金額";
                }
                else
                {
                    dr["AIMT"] =recover.ToString("#,##0.00");          //追繳金額
                }
                infoDT1.Rows.Add(dr);
                #region "註解"
                //if (radComplete.Checked == true)
                //{
                //完整查詢

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[0]["value"] = NumberTrim(info.Substring(37, 11));      //匯率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[1]["value"] = NumberTrim(info.Substring(48, 16));       //昨日權益數

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[2]["value"] = NumberTrim(info.Substring(64, 16));       //昨日餘額 
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[3]["value"] = NumberTrim(info.Substring(80, 16));       //出入金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[4]["value"] = NumberTrim(info.Substring(96, 16));       //期貨平倉損益

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[5]["value"] = NumberTrim(info.Substring(112, 16));      //期貨未平倉損益

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[6]["value"] = NumberTrim(info.Substring(128, 16));      //選擇權平倉損益 
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[7]["value"] = NumberTrim(info.Substring(144, 16));      //選擇權未平倉損益 
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[8]["value"] = NumberTrim(info.Substring(160, 16));      //當日權利金支出收入


                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[9]["value"] = "本日手續費及稅";

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[10]["value"] = NumberTrim(info.Substring(176, 16));      //成交手續費

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[11]["value"] = NumberTrim(info.Substring(192, 16));      //成交期交稅

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[12]["value"] = NumberTrim(info.Substring(208, 16));      //委託預扣權利金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[13]["value"] = NumberTrim(info.Substring(224, 16));     //權益數

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[14]["value"] = NumberTrim(info.Substring(240, 16));     //委託預扣原始保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[15]["value"] = NumberTrim(info.Substring(256, 16));     //原始保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[16]["value"] = NumberTrim(info.Substring(272, 16));     //維持保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[17]["value"] = NumberTrim(info.Substring(288, 16));     //下單可用保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[18]["value"] = NumberTrim(info.Substring(304, 16));     //買方權利金市值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[19]["value"] = NumberTrim(info.Substring(320, 16));     //賣方權利金市值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[20]["value"] = NumberTrim(info.Substring(336, 16));     //權益總值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[21]["value"] = NumberTrim(info.Substring(352, 13));    //原始比率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[22]["value"] = NumberTrim(info.Substring(365, 13));    //維持比率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[23]["value"] = NumberTrim(info.Substring(378, 13));    //清算比率

                ////modified by philip 20100319 追繳金額 = 原始保證金 - 權益數  , 其結果為正才顯示
                //decimal recover = Convert.ToDecimal(frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[15]["value"].ToString()) - Convert.ToDecimal(frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[13]["value"].ToString());
                //if (recover < 0)
                //{
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[24]["value"] = "無追繳金額";
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = "無追繳金額";
                //}
                //else
                //{
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[24]["value"] = recover.ToString("#,##0.00");          //追繳金額
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = recover.ToString("#,##0.00");
                //}
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[25]["value"] = NumberTrim(info.Substring(391, 16));    //台幣權益總值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[26]["value"] = NumberTrim(info.Substring(407, 16));    //台幣原始比率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[27]["value"] = NumberTrim(info.Substring(423, 16));    //台幣下單可用保證金

                //// dt.Rows[28]["value"] = NumberTrim(info.Substring(423, 16));  //有價證券抵繳總額

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[29]["value"] = info.Substring(439, 8).Insert(4, "/").Insert(7, "/");            //資料更新日期
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[30]["value"] = info.Substring(447, 6).Insert(2, ":").Insert(5, ":");                  //回傳資料時間



                //---------------------------------------------------------
                //////displayCompleteQuery();

                //////}
                //////else
                //////{
                //////快速查詢


                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[0]["value"] = NumberTrim(info.Substring(112, 16));      //期貨未平倉損益

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[1]["value"] = NumberTrim(info.Substring(256, 16));     //原始保證金

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[2]["value"] = NumberTrim(info.Substring(272, 16));     //維持保證金

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[3]["value"] = NumberTrim(info.Substring(288, 16));     //下單可用保證金

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[4]["value"] = NumberTrim(info.Substring(336, 16));     //權益總值

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[5]["value"] = NumberTrim(info.Substring(365, 13));    //維持比率
                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[6]["value"] = NumberTrim(info.Substring(378, 13));    //清算比率

                //////decimal recover = Convert.ToDecimal(info.Substring(256, 16)) - Convert.ToDecimal(info.Substring(224, 16));
                ////////modified by philip 20100319 追繳金額 = 原始保證金 - 權益數  , 其結果為正才顯示
                //////if (recover < 0)
                //////{
                //////    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = "無追繳金額";
                //////}
                //////else
                //////{
                //////    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = recover.ToString("#,##0.00");                                        //追繳金額
                //////}

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[8]["value"] = info.Substring(439, 8).Insert(4, "/").Insert(7, "/");                  //資料更新日期
                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[9]["value"] = info.Substring(447, 6).Insert(2, ":").Insert(5, ":");                   //回傳資料時間
                ////// displayQuickQuery();
                //////  }
                #endregion
                status = true;
            }
        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);


            // AEFutureMaster.frmMain.AOBJ_ErrLog.WriteError(ex.Source, ex.StackTrace.ToString(), ex.Message, System.Diagnostics.EventLogEntryType.Error);
            status = false;
        }
        finally
        {
        }
        mdt_MOBCurrentMargin = infoDT1;
        return status;
    }


    //added 20100419 by philip 計算 MOB即時部位查詢
    //更新 mdt_realpart
    private bool ucCurrentPosition_MobInfo(string info, string productDesc)
    {
        //initializedRealPart();
        try
        {

            DataRow dr = mdt_RealPart.NewRow();
            ucCurrentPosition_C(info, dr, productDesc);
            mdt_RealPart.Rows.Add(dr);

            //if (int.Parse(info.Substring(76, 4)) != 0) //目前留倉買有口數

            //{
            //    //DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();
            //    DataRow dr = mdt_RealPart.NewRow();
            //    ucCurrentPosition_B(info, dr);
            //    mdt_RealPart.Rows.Add(dr);
            //}
            //if (int.Parse(info.Substring(80, 4)) != 0) //目前留倉賣有口數

            //{
            //    //DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();
            //    DataRow dr = mdt_RealPart.NewRow();
            //    ucCurrentPosition_S(info, dr);
            //    mdt_RealPart.Rows.Add(dr);
            //}

            ////收到最後一筆時才將return true
            // if (info.Substring(info.Length - 2, 1) == "1" | info.Substring(info.Length - 2, 1) == "9")
            // {

            //     return true;
            // }

            //// return false;

            return true;

        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            return false;
        }

    }


    //added 20100505 by philip 計算 MOB即時部位Mix查詢
    //更新 mdt_realpartMix
    private bool ucCurrentPositionMix_MobInfo(string info)
    {
        //initializedRealPartMix();
        try
        {
            if (int.Parse(info.Substring(76, 4)) != 0) //目前留倉買有口數

            {
                DataRow dr = mdt_RealPartMix.NewRow();
                ucCurrentPosition_B(info, dr);
                mdt_RealPartMix.Rows.Add(dr);
            }
            if (int.Parse(info.Substring(80, 4)) != 0) //目前留倉賣有口數

            {
                DataRow dr = mdt_RealPartMix.NewRow();
                ucCurrentPosition_S(info, dr);
                mdt_RealPartMix.Rows.Add(dr);
            }

            ////收到最後一筆時才將return true
            if (info.Substring(info.Length - 3, 1) == "1" | info.Substring(info.Length - 3, 1) == "9")
            {

                return true;
            }

            return false;

        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            return false;
        }

    }


    //added 20100503 by philip 即時部位照商品目前留倉賣新增欄位
    private void ucCurrentPosition_S(string info, DataRow dr)
    {

        try
        {
            string CP = info.Substring(41, 1);

            // DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();

            dr["investorAcno"] = info.Substring(17, 7);                                                    //帳號    

            //dr["ProductId"] = frmMain.mobj_DataAgent.getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = this.getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = info.Substring(35, 20).Trim();
            dr["ProductId"] = info.Substring(28, 20).Trim();
            //目前都先視為單式商品
            dr["productKind"] = spreadType(info.Substring(41, 1));
            //買賣別由目前買進留倉 目前賣出留倉判別 
            dr["BS"] = "S";
            dr["OTQtyB"] = "0";                                                                         //昨日留倉買
            // dr["OTQtyS"] = NumberTrim(info.Substring(52, 4));                                              //昨日留倉賣
            dr["OTQtyS"] = int.Parse(info.Substring(52, 4));
            dr["NowOrderQtyB"] = "0";                                                                  //本日委託買

            // dr["NowOrderQtyS"] = NumberTrim(info.Substring(60, 4));                                        //本日委託賣

            dr["NowOrderQtyS"] = int.Parse(info.Substring(60, 4));
            dr["NowMatchQtyB"] = "0";                                                                   //目前成交買

            // dr["NowMatchQtyS"] = NumberTrim(info.Substring(68, 4));                                        //目前成交賣

            dr["NowMatchQtyS"] = int.Parse(info.Substring(68, 4));
            dr["TodayEnd"] = NumberTrim(info.Substring(72, 4));                                            //本日了結

            //需要串行情 要再討論 => 這個搞不出來

            //  dr["LiquidationPL"] = NumberTrim(info.Substring(72, 4));                                       //平倉損益


            dr["NowOTQtyB"] = "0";                                                                      //目前留倉買
            //dr["NowOTQtyS"] = NumberTrim(info.Substring(80, 4));                                           //目前留倉買
            dr["NowOTQtyS"] = int.Parse(info.Substring(80, 4));


            double cntsize = Math.Round(double.Parse(info.Substring(166, 18)) / 1000000, 2, MidpointRounding.AwayFromZero);
            double realprice = Math.Round(double.Parse(info.Substring(184, 9)) / 100000, 2, MidpointRounding.AwayFromZero);
            dr["RealPrice"] = realprice.ToString("#,##0.00");


            double AvgCostS = Math.Round(double.Parse(info.Substring(93, 9)), 2, MidpointRounding.AwayFromZero);
            dr["AvgCostB"] = "0.00";                                                                       //平均成本買

            dr["AvgCostS"] = AvgCostS.ToString("#,##0.00");                                                //平均成本賣


            dr["PriceDiffB"] = "0.00";                                                                     //價差買

            double PriceDiffS = AvgCostS - realprice;
            dr["PriceDiffS"] = PriceDiffS.ToString("#,##0.00");                                            //價差賣


            double PricePL = PriceDiffS * cntsize * double.Parse(dr["NowOTQtyS"].ToString());
            dr["PricePL"] = PricePL.ToString("#,##0.00");                                                 //浮動損益
            dr["Currency"] = info.Substring(25, 3);                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；

            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金

            dr["originalCost"] = NumberTrim(info.Substring(118, 16));



            double ROI = (PricePL / double.Parse(dr["originalCost"].ToString())) * 100;
            dr["ROI"] = ROI.ToString("#,##0.00") + "%";                                                    //報酬率

            //dr["fee"] =                                                                                  //手續費

            //dr["tax"] =                                                                                  //期交稅


            // frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.Rows.Add(dr);
        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        }



    }



    //added 20100503 by philip 即時部位照商品目前留倉買新增欄位
    private void ucCurrentPosition_B(string info, DataRow dr)
    {
        try
        {
            string CP = info.Substring(41, 1);

            //DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();

            dr["investorAcno"] = info.Substring(17, 7);                                                    //帳號    

            //dr["ProductId"] = frmMain.mobj_DataAgent.getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = info.Substring(35,20).Trim();
            dr["ProductId"] = info.Substring(28, 20).Trim();
            //目前都先視為單式商品
            dr["productKind"] = spreadType(info.Substring(41, 1));
            //買賣別由目前買進留倉 目前賣出留倉判別 
            dr["BS"] = "B";
            dr["OTQtyB"] = int.Parse(info.Substring(48, 4));                                              //昨日留倉買
            dr["OTQtyS"] = "0";                                                                         //昨日留倉賣
            // dr["NowOrderQtyB"] = NumberTrim(info.Substring(56, 4));                                        //本日委託買

            dr["NowOrderQtyB"] = int.Parse(info.Substring(56, 4));
            dr["NowOrderQtyS"] = "0";                                                                   //本日委託賣

            dr["NowMatchQtyB"] = NumberTrim(info.Substring(64, 4));                                        //目前成交買

            dr["NowMatchQtyB"] = int.Parse(info.Substring(64, 4));
            dr["NowMatchQtyS"] = "0";                                                                   //目前成交賣

            dr["TodayEnd"] = NumberTrim(info.Substring(72, 4));                                            //本日了結

            //需要串行情 要再討論=> 這個搞不出來

            // dr["LiquidationPL"] = NumberTrim(info.Substring(72, 4));                                       //平倉損益


            // dr["NowOTQtyB"] = NumberTrim(info.Substring(76, 4));                                           //目前留倉買
            dr["NowOTQtyB"] = int.Parse(info.Substring(76, 4));
            dr["NowOTQtyS"] = "0";                                                                      //目前留倉買


            double cntsize = Math.Round(double.Parse(info.Substring(166, 18)) / 1000000, 2, MidpointRounding.AwayFromZero);
            double realprice = Math.Round(double.Parse(info.Substring(184, 9)) / 100000, 2, MidpointRounding.AwayFromZero);
            dr["RealPrice"] = realprice.ToString("#,##0.00");                                              //即時價位


            double AvgCostB = Math.Round(double.Parse(info.Substring(84, 9)), 2, MidpointRounding.AwayFromZero);
            dr["AvgCostB"] = AvgCostB.ToString("#,##0.00");                                                //平均成本買

            dr["AvgCostS"] = "0.00";                                                                       //平均成本賣



            double PriceDiffB = realprice - AvgCostB;
            dr["PriceDiffB"] = PriceDiffB.ToString("#,##0.00");                                           //價差買

            dr["PriceDiffS"] = "0.00";                                                                    //價差賣


            double PricePL = PriceDiffB * cntsize * double.Parse(dr["NowOTQtyB"].ToString());
            dr["PricePL"] = PricePL.ToString("#,##0.00");                                                //浮動損益

            dr["Currency"] = info.Substring(25, 3);                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；

            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金

            if (CP == "N") //future
            {
                dr["originalCost"] = NumberTrim(info.Substring(102, 16));
            }
            else  // option
            {
                dr["originalCost"] = AvgCostB * double.Parse(dr["NowOTQtyB"].ToString()) * cntsize;
            }

            double ROI = (PricePL / double.Parse(dr["originalCost"].ToString())) * 100;
            dr["ROI"] = ROI.ToString("#,##0.00") + "%";                                                    //報酬率

            //dr["fee"] =                                                                                  //手續費

            //dr["tax"] =     

            // frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.Rows.Add(dr);
        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
        }


    }

    private void ucCurrentPosition_C(string info, DataRow dr,string productDesc)
    {
        try
        {
            string CP = info.Substring(41, 1);

            dr["investorAcno"] = info.Substring(17, 7);                                                    //帳號    

            dr["ProductId"] = info.Substring(28, 10).Trim();
            string period = getOptionPeriod(dr["productId"].ToString().Substring(dr["productId"].ToString().Length - 2, 1)).ToString();
            string cp = "";
            string strikeprice = "";
            if (dr["ProductId"].ToString().Length > 5)
            {
                cp = getOptionCP(dr["productId"].ToString().Substring(8, 1));
                strikeprice = decimal.Parse(dr["productId"].ToString().Substring(3, 5)).ToString("#0.#");

                dr["productKind"] = "2";
            }
            else
            {
                dr["productKind"] = "1";
            }


            dr["productName"] = productDesc + strikeprice + cp + period;
            dr["MKTCOMNO"] = dr["ProductId"].ToString().Substring(0, 3);
            dr["COMYM"] = "201" + dr["productId"].ToString().Substring(dr["productId"].ToString().Length - 1, 1) + getOptionPeriod(dr["productId"].ToString().Substring(dr["productId"].ToString().Length - 2, 1)).ToString().PadLeft(2, '0');
            dr["STKPRC"] = strikeprice;
            dr["CALLPUT"] = cp; 
            //買賣別由目前買進留倉 目前賣出留倉判別 
            dr["BS"] = "";
            dr["OTQtyB"] = int.Parse(info.Substring(48, 4));                                                  //昨日留倉買
            dr["OTQtyS"] = int.Parse(info.Substring(52, 4));                                              //昨日留倉賣

            dr["NowOrderQtyB"] = int.Parse(info.Substring(56, 4));                                       //本日委託買
            dr["NowOrderQtyS"] = int.Parse(info.Substring(60, 4));                                        //本日委託賣

            dr["NowMatchQtyB"] = int.Parse(info.Substring(64, 4));                                        //目前成交買
            dr["NowMatchQtyS"] = int.Parse(info.Substring(68, 4));                                      //目前成交賣

            dr["TodayEnd"] = NumberTrim(info.Substring(72, 4));                                            //本日了結

            //需要串行情 要再討論 => 這個搞不出來
            dr["LiquidationPL"] = NumberTrim(info.Substring(166,16));                                       //平倉損益

            dr["NowOTQtyB"] = int.Parse(info.Substring(76, 4));                                             //目前留倉買
            dr["NowOTQtyS"] = int.Parse(info.Substring(80, 4));                                           //目前留倉買



            double cntsize = Math.Round(double.Parse(info.Substring(182, 18)) / 1000000, 2, MidpointRounding.AwayFromZero);
            double realprice = Math.Round(double.Parse(info.Substring(200, 9)) / 10000, 2, MidpointRounding.AwayFromZero);
            dr["RealPrice"] = realprice.ToString("#,##0.00");


            double AvgCostS = Math.Round(double.Parse(info.Substring(93, 9)), 2, MidpointRounding.AwayFromZero);
            double AvgCostB = Math.Round(double.Parse(info.Substring(84, 9)), 2, MidpointRounding.AwayFromZero);
            dr["AvgCostB"] = AvgCostB.ToString("#,##0.00");                                                //平均成本買  
            dr["AvgCostS"] = AvgCostS.ToString("#,##0.00");                                                //平均成本賣


            double PriceDiffB = realprice - AvgCostB;
            dr["PriceDiffB"] = PriceDiffB.ToString("#,##0.00");                                           //價差買              

            double PriceDiffS = AvgCostS - realprice;
            dr["PriceDiffS"] = PriceDiffS.ToString("#,##0.00");                                            //價差賣

            double PricePL = PriceDiffS * cntsize * double.Parse(dr["NowOTQtyS"].ToString()) + PriceDiffB * cntsize * double.Parse(dr["NowOTQtyB"].ToString());


            dr["PricePL"] = PricePL.ToString("#,##0.00");                                                 //浮動損益
            dr["Currency"] = info.Substring(25, 3);                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；
            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金
            if (CP == "0") //future
            {
                // dr["originalCost"] = NumberTrim(info.Substring(102, 16))  NumberTrim(info.Substring(118, 16));
                double originalCost = double.Parse(info.Substring(102, 16)) + double.Parse(info.Substring(118, 16));
                dr["originalCost"] = NumberTrim(originalCost.ToString());
            }
            else  // option
            {
                //  dr["originalCost"] = AvgCostB * double.Parse(dr["NowOTQtyB"].ToString()) * cntsize ;
                dr["originalCost"] = AvgCostB * double.Parse(dr["NowOTQtyB"].ToString()) * cntsize + double.Parse(info.Substring(118, 16));


            }



            //added by samantha 20100927 保證金和損益是0就不算
            if (dr["PricePL"].ToString() != "" && dr["PricePL"].ToString() != "0" && ((decimal)dr["originalCost"]) != 0)
            {
                double ROI = (PricePL / double.Parse(dr["originalCost"].ToString())) * 100;
                dr["ROI"] = ROI.ToString("#,##0.00") + "%";                                                    //報酬率
            }
            //dr["fee"] =                                                                                  //手續費
            //dr["tax"] =                                                                                  //期交稅

            // frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.Rows.Add(dr);

           // return dr["ProductId"].ToString().Trim();
        }
        catch (Exception ex)
        {
            mobj_ErroLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);
            //return dr["ProductId"].ToString().Trim();
        }

    }


    //--------------------------------初始化各table 的table schema-------------------------
    /// <summary>
    /// init RealPart dt
    /// </summary>
    private void  initializedRealPart()
    {
        mdt_RealPart = new DataTable("RealPart");
        
        mdt_RealPart.Columns.Add("investorAcno", typeof(string));    //帳號   
        mdt_RealPart.Columns.Add("ProductId", typeof(string));     //商品碼  
        mdt_RealPart.Columns.Add("productKind", typeof(string));    //商品類別 
        mdt_RealPart.Columns.Add("BS", typeof(string));//買賣別

        mdt_RealPart.Columns.Add("OTQtyB", typeof(string));    //昨日留倉買
        mdt_RealPart.Columns.Add("OTQtyS", typeof(string));    //昨日留倉賣
        mdt_RealPart.Columns.Add("NowOrderQtyB", typeof(string));    //本日委託買

        mdt_RealPart.Columns.Add("NowOrderQtyS", typeof(string));    //本日委託賣

        mdt_RealPart.Columns.Add("NowMatchQtyB", typeof(string));    //目前成交買

        mdt_RealPart.Columns.Add("NowMatchQtyS", typeof(string));    //目前成交賣

        mdt_RealPart.Columns.Add("TodayEnd", typeof(string));    //本日了結
        mdt_RealPart.Columns.Add("LiquidationPL", typeof(decimal));    //平倉損益

        mdt_RealPart.Columns["LiquidationPL"].DefaultValue = 0;
        mdt_RealPart.Columns.Add("NowOTQtyB", typeof(string));    //目前留倉買
        mdt_RealPart.Columns.Add("NowOTQtyS", typeof(string));    //目前留倉賣
        mdt_RealPart.Columns.Add("RealPrice", typeof(string));    //即時價位
        mdt_RealPart.Columns.Add("AvgCostB", typeof(string));    //平均成本買

        mdt_RealPart.Columns.Add("AvgCostS", typeof(string));    //平均成本賣

        mdt_RealPart.Columns.Add("PriceDiffB", typeof(string));    //價差買

        mdt_RealPart.Columns.Add("PriceDiffS", typeof(string));    //價差賣

        mdt_RealPart.Columns.Add("PricePL", typeof(string));    //浮動損益
        mdt_RealPart.Columns.Add("Currency", typeof(string));    //幣別

        //added 20100416 by philip MOB CurrentPosition擴欄位

        mdt_RealPart.Columns.Add("originalCost", typeof(decimal));       //原始投入金額
        mdt_RealPart.Columns.Add("ROI", typeof(string));                 //報酬率

        mdt_RealPart.Columns.Add("fee", typeof(string));                //手續費

        mdt_RealPart.Columns.Add("tax", typeof(string));                //期交稅


        //added 20100428 by philip 供複式即時更新 擴欄位

        mdt_RealPart.Columns.Add("multipleMatchPrice1", typeof(string));                //複式商品第1隻腳成交價

        mdt_RealPart.Columns["multipleMatchPrice1"].DefaultValue = "0";
        mdt_RealPart.Columns.Add("multipleMatchPrice2", typeof(string));                //複式商品第2隻腳成交價

        mdt_RealPart.Columns["multipleMatchPrice2"].DefaultValue = "0";

        mdt_RealPart.Columns.Add("productName");
        mdt_RealPart.Columns.Add("MKTCOMNO");
        mdt_RealPart.Columns.Add("COMYM");
        mdt_RealPart.Columns.Add("CALLPUT");
        mdt_RealPart.Columns.Add("STKPRC"); 
        DataColumn[] dcPrimaryKey = { mdt_RealPart.Columns["investorAcno"], mdt_RealPart.Columns["ProductId"], mdt_RealPart.Columns["BS"] };
        mdt_RealPart.PrimaryKey = dcPrimaryKey;

       
    }

    /// <summary>
    /// init RealPart dt  added by philip 20100506 
    /// </summary>
    private void initializedRealPartMix()
    {
        this.mdt_RealPartMix = new DataTable("RealPartMix");

        this.mdt_RealPartMix.Columns.Add("investorAcno", typeof(string));    //帳號   
        this.mdt_RealPartMix.Columns.Add("ProductId", typeof(string));     //商品碼  
        this.mdt_RealPartMix.Columns.Add("productKind", typeof(string));    //商品類別 
        this.mdt_RealPartMix.Columns.Add("BS", typeof(string));//買賣別

        this.mdt_RealPartMix.Columns.Add("OTQtyB", typeof(string));    //昨日留倉買
        this.mdt_RealPartMix.Columns.Add("OTQtyS", typeof(string));    //昨日留倉賣
        this.mdt_RealPartMix.Columns.Add("NowOrderQtyB", typeof(string));    //本日委託買

        this.mdt_RealPartMix.Columns.Add("NowOrderQtyS", typeof(string));    //本日委託賣

        this.mdt_RealPartMix.Columns.Add("NowMatchQtyB", typeof(string));    //目前成交買

        this.mdt_RealPartMix.Columns.Add("NowMatchQtyS", typeof(string));    //目前成交賣

        this.mdt_RealPartMix.Columns.Add("TodayEnd", typeof(string));    //本日了結
        this.mdt_RealPartMix.Columns.Add("LiquidationPL", typeof(decimal));    //平倉損益

        this.mdt_RealPartMix.Columns["LiquidationPL"].DefaultValue = 0;
        this.mdt_RealPartMix.Columns.Add("NowOTQtyB", typeof(string));    //目前留倉買
        this.mdt_RealPartMix.Columns.Add("NowOTQtyS", typeof(string));    //目前留倉賣
        this.mdt_RealPartMix.Columns.Add("RealPrice", typeof(string));    //即時價位
        this.mdt_RealPartMix.Columns.Add("AvgCostB", typeof(string));    //平均成本買

        this.mdt_RealPartMix.Columns.Add("AvgCostS", typeof(string));    //平均成本賣

        this.mdt_RealPartMix.Columns.Add("PriceDiffB", typeof(string));    //價差買

        this.mdt_RealPartMix.Columns.Add("PriceDiffS", typeof(string));    //價差賣

        this.mdt_RealPartMix.Columns.Add("PricePL", typeof(string));    //浮動損益
        this.mdt_RealPartMix.Columns.Add("Currency", typeof(string));    //幣別

        //added 20100416 by philip MOB CurrentPosition擴欄位

        this.mdt_RealPartMix.Columns.Add("originalCost", typeof(decimal));       //原始投入金額
        this.mdt_RealPartMix.Columns.Add("ROI", typeof(string));                 //報酬率

        this.mdt_RealPartMix.Columns.Add("fee", typeof(string));                //手續費

        this.mdt_RealPartMix.Columns.Add("tax", typeof(string));                //期交稅


        //added 20100428 by philip 供複式即時更新 擴欄位

        this.mdt_RealPartMix.Columns.Add("multipleMatchPrice1", typeof(string));                //複式商品第1隻腳成交價

        this.mdt_RealPartMix.Columns["multipleMatchPrice1"].DefaultValue = "0";
        this.mdt_RealPartMix.Columns.Add("multipleMatchPrice2", typeof(string));                //複式商品第2隻腳成交價

        this.mdt_RealPartMix.Columns["multipleMatchPrice2"].DefaultValue = "0";


        DataColumn[] dcPrimaryKey = { this.mdt_RealPartMix.Columns["investorAcno"], this.mdt_RealPartMix.Columns["ProductId"], this.mdt_RealPartMix.Columns["BS"] };
        this.mdt_RealPartMix.PrimaryKey = dcPrimaryKey;
    }

    /// <summary>
    /// init UnLiquidationDetail dt
    /// </summary>
    private void initializedUnLiquidationDetail()
    {
        this.mdt_UnLiquidationDetail = new DataTable("PositionDetail");

        //added 201004013 by philip
        this.mdt_UnLiquidationDetail.Columns.Add("currency", typeof(string));  //幣別

        this.mdt_UnLiquidationDetail.Columns.Add("investorAcno", typeof(string));//下單帳號
        this.mdt_UnLiquidationDetail.Columns.Add("tradedate", typeof(string));
        this.mdt_UnLiquidationDetail.Columns.Add("matchTime", typeof(string));//成交時間
        this.mdt_UnLiquidationDetail.Columns.Add("orderNo", typeof(string));//成交單號
        this.mdt_UnLiquidationDetail.Columns.Add("BS", typeof(string));//買賣別

        this.mdt_UnLiquidationDetail.Columns.Add("productId", typeof(string));//商品代碼

        this.mdt_UnLiquidationDetail.Columns.Add("MatchPrice", typeof(decimal));//成交價格

        this.mdt_UnLiquidationDetail.Columns.Add("RefRealPrice", typeof(string));//參考即時價
        this.mdt_UnLiquidationDetail.Columns.Add("OTQTY", typeof(decimal));//留倉口數

        this.mdt_UnLiquidationDetail.Columns.Add("RefNowPrice", typeof(string));//參考現值

        this.mdt_UnLiquidationDetail.Columns.Add("RefPL", typeof(string));//參考浮動損益

        this.mdt_UnLiquidationDetail.Columns.Add("DTOVER", typeof(string));//當沖
        this.mdt_UnLiquidationDetail.Columns.Add("productKind", typeof(string));    //商品類別 
        this.mdt_UnLiquidationDetail.Columns.Add("matchseq", typeof(string));//網路流水序號
        mdt_UnLiquidationDetail.Columns.Add("multiplecomno", typeof(string));    //商品碼        
        mdt_UnLiquidationDetail.Columns.Add("multipleBS", typeof(string));       //買賣別    


        this.mdt_UnLiquidationDetail.Columns.Add("TatolMatchPrice", typeof(decimal));//成交價格
        this.mdt_UnLiquidationDetail.Columns["TatolMatchPrice"].Expression = "MatchPrice*OTQTY";

        //added 20100427 by philip 多擴兩個欄位供複式商品存成交價
        mdt_UnLiquidationDetail.Columns.Add("multipleMatchPrice1", typeof(string));       //複式商品成交價1
        mdt_UnLiquidationDetail.Columns["multipleMatchPrice1"].DefaultValue = "0";
        mdt_UnLiquidationDetail.Columns.Add("multipleMatchPrice2", typeof(string));       //複式商品成交價2
        mdt_UnLiquidationDetail.Columns["multipleMatchPrice2"].DefaultValue = "0";


        mdt_UnLiquidationDetail.Columns.Add("productName");
        mdt_UnLiquidationDetail.Columns.Add("cp"); 
        mdt_UnLiquidationDetail.Columns.Add("MKTCOMNO");
        mdt_UnLiquidationDetail.Columns.Add("COMYM");
        mdt_UnLiquidationDetail.Columns.Add("stkprc"); 

        //added by samantha 20101005 顯示每腳價位
        mdt_UnLiquidationDetail.Columns.Add("footMatchPrice"); 

        DataColumn[] dcPrimaryKey = { this.mdt_UnLiquidationDetail.Columns["investorAcno"], this.mdt_UnLiquidationDetail.Columns["matchseq"], this.mdt_UnLiquidationDetail.Columns["tradedate"], this.mdt_UnLiquidationDetail.Columns["matchTime"], this.mdt_UnLiquidationDetail.Columns["productId"], this.mdt_UnLiquidationDetail.Columns["orderNo"] };
        this.mdt_UnLiquidationDetail.PrimaryKey = dcPrimaryKey;


    }

    /// <summary>
    /// 初始部位Table
    /// </summary>
    private void initializedPositionData()
    {
        mdt_PositionData = new DataTable("PositionData");
        mdt_PositionData.Columns.Add("investorAcno", typeof(string));       //帳號   
        mdt_PositionData.Columns.Add("ProductId", typeof(string));          //商品碼        
        mdt_PositionData.Columns.Add("BS", typeof(string));                 //買賣別    
        mdt_PositionData.Columns.Add("initBS", typeof(string));             //買賣別    
        mdt_PositionData.Columns.Add("initPositionQty", typeof(string));    //初始昨日留倉數  
        mdt_PositionData.Columns.Add("PositionQty", typeof(string));        //部位口數        
        mdt_PositionData.Columns.Add("PositionPrice", typeof(string));      //部位均價        
        mdt_PositionData.Columns.Add("MarketPrice", typeof(string));        //市價        
        mdt_PositionData.Columns.Add("BPrice", typeof(string));             //B均價    
        mdt_PositionData.Columns.Add("SPrice", typeof(string));             //S均價
        mdt_PositionData.Columns.Add("SEQ", typeof(string));                //序號
        mdt_PositionData.Columns.Add("productKind", typeof(string));        //商品類別 
        mdt_PositionData.Columns.Add("multiplecomno", typeof(string));    //商品碼        
        mdt_PositionData.Columns.Add("multipleBS", typeof(string));       //買賣別    


        //DataColumn[] dcPrimaryKey ={ mdt_PositionData.Columns["investorAcno"], mdt_PositionData.Columns["ProductId"], mdt_PositionData.Columns["BS"] };
        //mdt_PositionData.PrimaryKey = dcPrimaryKey;

        //modified by philip 20100416 多加一個key值

        DataColumn[] dcPrimaryKey = { mdt_PositionData.Columns["investorAcno"], mdt_PositionData.Columns["ProductId"], mdt_PositionData.Columns["BS"], mdt_PositionData.Columns["productKind"] };
        mdt_PositionData.PrimaryKey = dcPrimaryKey;

    }

    /// <summary>
    /// init UnLiquidationMain dt
    /// </summary>
    private void initializedUnLiquidationMain()
    {
        this.mdt_UnLiquidationMain = new DataTable("PositionMain");



        this.mdt_UnLiquidationMain.Columns.Add("investorAcno", typeof(string));    //帳號   
        this.mdt_UnLiquidationMain.Columns.Add("BS", typeof(string));             //買賣別   
        this.mdt_UnLiquidationMain.Columns.Add("ProductId", typeof(string));     //商品碼  
        this.mdt_UnLiquidationMain.Columns.Add("TotalOTQTY", typeof(string));     //總留倉口數 
        //this._dtMain.Columns.Add("NowOTQTY", typeof(string));         //當約口數 
        this.mdt_UnLiquidationMain.Columns.Add("RefTotalPrice", typeof(string));     //參考總現值 
        this.mdt_UnLiquidationMain.Columns.Add("RefTotalPL", typeof(string));     //參考總浮動損益
        this.mdt_UnLiquidationMain.Columns.Add("AvgMatchPrice", typeof(double));     //平均成交價

        // this.mdt_UnLiquidationMain.Columns.Add("DTOVER", typeof(string));              //當沖
        this.mdt_UnLiquidationMain.Columns.Add("productKind", typeof(string));    //商品類別 

        //added 20100413 by philip
        mdt_UnLiquidationMain.Columns.Add("currency", typeof(string));           //幣別
        
        //------modify by cedric 20100623 -------
        mdt_UnLiquidationMain.Columns.Add("realPrice", typeof(double));    //即時價
        //mdt_UnLiquidationMain.Columns.Add("realPrice", typeof(string));    //即時價
        //-----------------------------------------


        mdt_UnLiquidationMain.Columns.Add("multiplecomno", typeof(string));    //商品碼        
        mdt_UnLiquidationMain.Columns.Add("multipleBS", typeof(string));       //買賣別  

        //added 20100427 by philip 多擴兩個欄位供複式商品存成交價
        mdt_UnLiquidationMain.Columns.Add("multipleMatchPrice1", typeof(string));       //複式商品成交價1
        mdt_UnLiquidationMain.Columns["multipleMatchPrice1"].DefaultValue = "0";
        mdt_UnLiquidationMain.Columns.Add("multipleMatchPrice2", typeof(string));       //複式商品成交價2
        mdt_UnLiquidationMain.Columns["multipleMatchPrice2"].DefaultValue = "0";

        //added 20100505 by philip 價差供 即時組合部位查詢 使用
        mdt_UnLiquidationMain.Columns.Add("PriceDiff", typeof(double));                 //價差
        mdt_UnLiquidationMain.Columns["PriceDiff"].Expression = "IIF(BS='B',realPrice-AvgMatchPrice ,AvgMatchPrice-realPrice) ";
        mdt_UnLiquidationMain.Columns.Add("MultiName", typeof(string));                 //組合類型

        //added by samantha 20101005 顯示每腳價位
        mdt_UnLiquidationMain.Columns.Add("footMatchPrice");

        mdt_UnLiquidationMain.Columns.Add("productName");
        mdt_UnLiquidationMain.Columns.Add("cp");
         
        mdt_UnLiquidationMain.Columns.Add("MKTCOMNO");
        mdt_UnLiquidationMain.Columns.Add("COMYM");
        mdt_UnLiquidationMain.Columns.Add("stkprc");
        //DataColumn[] dcPrimaryKey ={ this.mdt_UnLiquidationMain.Columns["investorAcno"], this.mdt_UnLiquidationMain.Columns["ProductId"], this.mdt_UnLiquidationMain.Columns["BS"] };
        //this.mdt_UnLiquidationMain.PrimaryKey = dcPrimaryKey;

        //added 20100416 by philip 多加一個key值

        DataColumn[] dcPrimaryKey = { this.mdt_UnLiquidationMain.Columns["investorAcno"], this.mdt_UnLiquidationMain.Columns["ProductId"], this.mdt_UnLiquidationMain.Columns["BS"], this.mdt_UnLiquidationMain.Columns["productKind"] };
        this.mdt_UnLiquidationMain.PrimaryKey = dcPrimaryKey;
    }
    private void initializedMOBCombineData()
    {

        //added 20101020 by will 單式商品組合

        mdt_MOBCombineData = new DataTable("MOBCombineData");

        mdt_MOBCombineData.Columns.Add("ADJNO");

        mdt_MOBCombineData.Columns.Add("COUNT");

        mdt_MOBCombineData.Columns.Add("SEQNO");

        mdt_MOBCombineData.Columns.Add("STATUS");

    }



    ///// <summary>
    /////MOB保證金查詢  added 20100409
    ///// </summary>
    //private void initializedMOBCurrentMargin()
    //{
    //    this.mdt_MOBCurrentMarginComplete = new DataTable("MOBCurrentMarginComplete");

    //    mdt_MOBCurrentMarginComplete.Columns.Add("list");
    //    mdt_MOBCurrentMarginComplete.Columns.Add("value");
    //    mdt_MOBCurrentMarginComplete.Columns.Add("explain");

    //    mdt_MOBCurrentMarginComplete.Rows.Add("匯率:", "", "-------");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("昨日帳戶權益數:", "", "昨日收盤後之帳戶權益數");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("昨日餘額:", "", "昨日收盤後之帳戶權益數(不含浮動損益)");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("本日出入金:", "", "今日存款及提款的金額總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("期貨平倉損益:", "", "(平倉價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("期貨未平倉浮動損益:", "", "(即時價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("選擇權平倉損益:", "", "(平倉價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("選擇權未平倉浮動損益:", "", "(即時價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("權利金支出/收入:", "", "今日選擇權交易所產生之收入及支出");

    //    mdt_MOBCurrentMarginComplete.Rows.Add("", "本日手續費及稅", "");

    //    mdt_MOBCurrentMarginComplete.Rows.Add("手續費:", "", "本日成交部位(期貨+選擇權)所需手續費總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("期交稅:", "", "本日成交部位(期貨+選擇權)所需期交稅總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("預扣權利金:", "", "委託成功後預扣的權利金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("權益數:", "", "    昨日權益數+本日出入金+調整後的平倉損益+權利金支出/收入-手續費-期交稅-預扣權利金+調整後未平倉浮動損益");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("下單保證金:", "", "所有委託中的部位所需原始保證金總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("所需原始保證金:", "", "所有委託中部位+在倉部位所需原始保證金總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("所需維持保證金:", "", "所有在倉部位所需維持保證金總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("下單可用(提領)保證金:", "", "權益數-原始保證金-調整後未平倉浮動損失");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("買方權利金市值:", "", "台指選擇權的買(賣)方權利金市值 = 口數 * 市價(結算價) * 50");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("賣方權利金市值:", "", "台指選擇權的買(賣)方權利金市值 = 口數 * 市價(結算價) * 50");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("權益總值:", "", "權益數+買方權利金市值-賣方權利金市值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("原始比率:", "", "權益數/所需足額原始保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("維持比率:", "", "權益數/所需足額維持保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("清算比率:", "", "權益總值/所需足額原始保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("追繳金額:", "", "原始保證金-權益數");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("台幣權益總值:", "", "台幣權益數+買方權利金市值-賣方權利金市值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("台幣原始比率:", "", "台幣權益數/台幣所需原始保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("台幣可用保證金:", "", "-------");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("有價證券抵繳總額:", "", "有價證券抵繳總額查詢");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("資料更新日期:", "", "-------");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("資料更新時間:", "", "-------");


    //    this.mdt_MOBCurrenetMarginRapid = new DataTable("MOBCurrenetMarginRapid");

    //    mdt_MOBCurrenetMarginRapid.Columns.Add("list");
    //    mdt_MOBCurrenetMarginRapid.Columns.Add("value");


    //    mdt_MOBCurrenetMarginRapid.Rows.Add("期貨未平倉浮動損益:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("所需原始保證金:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("所需維持保證金:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("下單可用(提領)保證金:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("權益總值:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("維持比率:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("清算比率:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("追繳金額:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("資料更新日期:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("資料更新時間:");



    //}


    private string getProductId(string ClassId, string Class_Name, string Settlement_month, string Strike_Price, string CP)
    {
        if (ClassId == "1") //期貨
        {
            DataRow[] dr = mdt_FutureData.Select("Class_Name='" + Class_Name + "' and Settlement_month='" + Settlement_month + "'");
            if (dr.Length == 0)
            {
                return "";
            }
            else
            {
                return dr[0]["Commodity_Id"].ToString().Trim();
            }
            //return dr[0]["Commodity_Id"].ToString().Trim();
            //return "";
        }
        else   //選擇權

        {
            DataRow[] dr = mdt_OptionData.Select("Class_Name='" + Class_Name + "' and Settlement_month='" + Settlement_month + "' and CP='" + CP + "' and Strike_Price='" + Strike_Price + "'");
            if (dr.Length == 0)
            {
                return "";
            }
            else
            {
                return dr[0]["Commodity_Id"].ToString().Trim();
            }
            //return dr[0]["Commodity_Id"].ToString().Trim();
            //return "";
        }
    }

    // from 3.0.0.8
    private decimal getMultiplePrice(string multiplekind , decimal price1, decimal price2)
    {
        decimal multiplePrice = 0;
        if ((multiplekind == "1" || multiplekind == "2" || multiplekind == "5" || multiplekind == "0") || (multiplekind == "價格價差" || multiplekind == "2" || multiplekind == "轉換/逆轉換" || multiplekind == "期貨價差"))
        {
            multiplePrice = price2 - price1;
        }
        else if ((multiplekind == "3" || multiplekind == "4") || (multiplekind == "跨式組合" || multiplekind == "勒式組合"))
        {
            multiplePrice = price1 + price2;
        }
        return multiplePrice;
    }

    // from 3.0.0.8
    private string[] MultipleProductId(string type, string ID_1st, string ID_2nd, string bs1, string bs2,string productdesc)
    {
        

        string[] strReturn = new string[13];//第一個id,第二個策略
        //預設串英文
        strReturn[2] = ID_1st + "  " + ID_2nd;

        string classid = ID_1st.Substring(0, 3);
        string period1 = ID_1st.Substring(ID_1st.Length-2, 2);
        string period2 = ID_2nd.Substring(ID_2nd.Length - 2, 2);
        int yearmonth1 = int.Parse("201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0'));
        int yearmonth2 = int.Parse("201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0'));

        if (type == "3")
        {

            string strikeprice1 = ID_1st.Substring(3, 5);
            string strikeprice2 = ID_2nd.Substring(3, 5);
            string cp1 = getOptionCP(period1.Substring(0, 1));
            string cp2 = getOptionCP(period2.Substring(0, 1));

            //判斷買賣別如果相同為跨式\勒式組合
            if (bs1 == bs2)
            {
                if (yearmonth1 == yearmonth2)
                {
                    if (cp1 != cp2)
                    {
                        if (cp1 == "P")
                        {
                            changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);
                        }
                        //跨式,價位相同
                        if (strikeprice1 == strikeprice2)
                        {
                            strReturn[0] = classid + strikeprice1 + period1 + ":" + period2;
                            strReturn[1] = "3";

                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") +cp1+ ":" + cp2 +getOptionPeriod(period2.Substring(0, 1));
                       
                        }
                        else
                        {
                            //勒式
                            strReturn[0] = classid + strikeprice1 + period1 + ":" + strikeprice2 + period2;
                            strReturn[1] = "4";

                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1+ ":" + decimal.Parse(strikeprice2).ToString("#0.#") + cp2+ getOptionPeriod(period1.Substring(0, 1));
                        }
                    }
                }
            }
            else
            {
                //價格價差,價位不同
                if (strikeprice1 != strikeprice2)
                {
                    if (yearmonth1 == yearmonth2)
                    {
                        if (cp1 == cp2)
                        {
                            

                            if ((cp1== "C" && int.Parse(strikeprice1) < int.Parse(strikeprice2)) || (cp1== "P" && int.Parse(strikeprice1) > int.Parse(strikeprice2)))
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);
                            }
                         

                            strReturn[0] = classid + strikeprice1 + "/" + strikeprice2 + period2;
                            strReturn[1] = "1";
                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + "/" + decimal.Parse(strikeprice2).ToString("#0.#") + cp1+ getOptionPeriod(period2.Substring(0, 1));
                        }
                    }
                    
                }
                else
                {
                    //判斷月份如不相同為跨月價差                    
                    if (yearmonth1 != yearmonth2)
                    {

                        if (cp1 == cp2)
                        {
                            

                            if (yearmonth1 > yearmonth2 )
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);

                            }

                            strReturn[0] = classid + strikeprice1 + period1 + "/" + period2;
                            strReturn[1] = "2";
                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + getOptionPeriod(period1.Substring(0, 1)) + "/"   + getOptionPeriod(period2.Substring(0, 1));
                        }
                    }
                    else if  (yearmonth1 == yearmonth2)
                    {
                        if (cp1 != cp2)
                        {

                           
                            if (cp1=="P")
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);

                            }
                            strReturn[0] = classid + strikeprice1 + period1 + "-" + period2;
                            strReturn[1] = "5";
                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + "-" + cp2 + getOptionPeriod(period1.Substring(0, 1));
                        }
                    }
                }
            }
            strReturn[7] = cp1;
            strReturn[8] = cp2;
            strReturn[9] = decimal.Parse(strikeprice1).ToString("#0.#");
            strReturn[10] = decimal.Parse(strikeprice2).ToString("#0.#");
        }
        else if (type == "4")
        {

 
            if (yearmonth1!=yearmonth2)
            {

               
                if (yearmonth1 > yearmonth2)
                {
                    changeFutureFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2);

                }

                strReturn[0] = classid + period1 + "/" + period2;
                strReturn[1] = "0";
                strReturn[2] = productdesc + getOptionPeriod(period1.Substring(0, 1)) + "/" + getOptionPeriod(period2.Substring(0, 1));
            }
        }
        strReturn[3] = ID_1st;
        strReturn[4] = ID_2nd;
        strReturn[5] = bs1;
        strReturn[6] = bs2;
        strReturn[11] = "201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0');
        strReturn[12] = "201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0');
      
        
        return strReturn;
    }
    private void changeOptionFoot(ref string productid1, ref string productid2, ref string bs1, ref string bs2, ref string period1, ref string period2, ref string strikeprice1, ref string strikeprice2,ref string cp1 ,ref string cp2)
    {
        string tempPeriod = "";
        string tempstrikeprice = "";
        string tempcp = "";
        string tempbs = "";
        string tempproductid = "";
        
        tempPeriod = period1;
        tempstrikeprice = strikeprice1;
        tempcp = cp1;
        tempbs = bs1;
        tempproductid = productid1;

        period1 = period2;
        strikeprice1 = strikeprice2;
        cp1 = cp2;
        bs1 = bs2;
        productid1 = productid2;

        period2 = tempPeriod;
        strikeprice2 = tempstrikeprice;
        cp2 = tempcp;
        bs2 = tempbs;
        productid2 = tempproductid;
      
    }
    private void changeFutureFoot(ref string productid1, ref string productid2, ref string bs1, ref string bs2, ref string period1, ref string period2)
    {
        string tempPeriod = ""; 
        string tempbs = "";
        string tempproductid = "";
        
        tempPeriod = period1;       
        tempbs = bs1;
        tempproductid = productid1;

        period1 = period2;           
        bs1 = bs2;
        productid1 = productid2;


        period2 = tempPeriod;
        bs2 = tempbs;
        productid2 = tempproductid;
    }
    // from 3.0.0.8
    private string getOptionCP(string period)
    {
        period = period.ToUpper();
        string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
        string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
        string cp = "";
        if (Array.IndexOf<string>(cperiod, period) != -1)
        {
            cp = "C";
        }
        else if (Array.IndexOf<string>(pperiod, period) != -1)
        {
            cp = "P";
        }

        return cp;
    }
    // from 3.0.0.8
    private int getOptionPeriod(string period)
    {
        period = period.ToUpper();
        string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
        string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
        int returnperiod = 0;
        if (Array.IndexOf<string>(cperiod, period) != -1)
        {
            returnperiod = (Array.IndexOf<string>(cperiod, period) + 1);
        }
        else if (Array.IndexOf<string>(pperiod, period) != -1)
        {
            returnperiod = (Array.IndexOf<string>(pperiod, period) + 1);
        }

        return returnperiod;
    }

    
    // from 3.0.0.8
    private string[] MultiProductParser(string productkind, string BS, string ProductID, string foot1Bs)
    {

        //string[] ParseResult = new string[6];
        //modified by philip 20100427 多傳 複式單的組合類型    Option 1：Price Spread 2：Time Spread 3：Straddle Spread 4：Strangles Spread 5：Conagles Spread    0:期貨價差
        string[] ParseResult = new string[7];

        string commidity_ID = ProductID.Substring(0, 3);
        string[] delimeter = { commidity_ID };
        string[] split = ProductID.Split(delimeter, StringSplitOptions.RemoveEmptyEntries);


        if (productkind == "4")
        {
            ParseResult[0] = "期貨價差";
            ParseResult[6] = "0";


            string[] SettlementMonth = split[0].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

            switch (BS)
            {
                case "S":
                    ParseResult[1] = "B";
                    ParseResult[3] = "S";

                    break;
                case "B":
                    ParseResult[1] = "S";
                    ParseResult[3] = "B";
                    break;
                case "":
                    ParseResult[1] = foot1Bs;
                    if (foot1Bs == "B")
                    {
                        ParseResult[3] = "S";
                    }
                    else
                    {
                        ParseResult[3] = "B";
                    }
                    break;
            }

            ParseResult[2] = commidity_ID + SettlementMonth[0].ToString();
            ParseResult[4] = commidity_ID + SettlementMonth[1].ToString();

        }
        else if (productkind == "3")
        {
            string[] Price = new string[2];

            if (ProductID.Substring(8, 1) == "/")          //價格價差 與 時間價差 商品碼中有  " / "
            {
                if (split[0].Length == 13)             // 價格價差
                {

                    string[] SettlementMonth = new string[1];


                    SettlementMonth[0] = split[0].Substring(split[0].Length - 2, 2);

                    string[] PriceSplit = split[0].Split(SettlementMonth, StringSplitOptions.RemoveEmptyEntries);
                    Price = PriceSplit[0].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

                    ParseResult[0] = "價格價差";
                    ParseResult[6] = "1";

                    switch (BS)
                    {
                        case "S":
                            ParseResult[1] = "B";
                            ParseResult[3] = "S";

                            break;
                        case "B":
                            ParseResult[1] = "S";
                            ParseResult[3] = "B";
                            break;
                        case "":
                            ParseResult[1] = foot1Bs;
                            if (foot1Bs == "B")
                            {
                                ParseResult[3] = "S";
                            }
                            else
                            {
                                ParseResult[3] = "B";
                            }
                            break;
                    }
                    ParseResult[2] = commidity_ID + Price[0].ToString() + SettlementMonth[0].ToString();
                    ParseResult[4] = commidity_ID + Price[1].ToString() + SettlementMonth[0].ToString();

                }


            }
            else if ((ProductID.Length == 13) & (ProductID.Substring(10, 1) == "-" | ProductID.Substring(10, 1) == "/" | ProductID.Substring(10, 1) == ":"))     //時間價差 轉換/逆轉換 跨式
            {

                string[] SettlementMonth = new string[2];
                string[] price = { split[0].Substring(0, 5) };  //價格
                string[] MonthSplit = split[0].Split(price, StringSplitOptions.RemoveEmptyEntries);

                switch (MonthSplit[0].Substring(2, 1))
                {
                    case "/":

                        ParseResult[0] = "時間價差";
                        ParseResult[6] = "0";
                        SettlementMonth = MonthSplit[0].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

                        switch (BS)
                        {
                            case "B":

                                ParseResult[1] = "S";
                                ParseResult[3] = "B";

                                break;
                            case "S":
                                ParseResult[1] = "B";
                                ParseResult[3] = "S";

                                break;
                            case "":
                                ParseResult[1] = foot1Bs;
                                if (foot1Bs == "B")
                                {
                                    ParseResult[3] = "S";
                                }
                                else
                                {
                                    ParseResult[3] = "B";
                                }
                                break;
                        }

                        break;
                    case "-":

                        ParseResult[0] = "轉換/逆轉換";
                        ParseResult[6] = "5";
                        SettlementMonth = MonthSplit[0].Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);

                        switch (BS)
                        {
                            case "B":
                                ParseResult[1] = "S";
                                ParseResult[3] = "B";

                                break;
                            case "S":
                                ParseResult[1] = "B";
                                ParseResult[3] = "S";
                                break;
                            case "":
                                ParseResult[1] = foot1Bs;
                                if (foot1Bs == "B")
                                {
                                    ParseResult[3] = "S";
                                }
                                else
                                {
                                    ParseResult[3] = "B";
                                }
                                break;
                        }
                        break;
                    case ":":

                        ParseResult[0] = "跨式組合";
                        ParseResult[6] = "3";
                        SettlementMonth = MonthSplit[0].Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);

                        switch (BS)
                        {
                            case "B":
                                ParseResult[1] = "B";
                                ParseResult[3] = "B";
                                break;
                            case "S":
                                ParseResult[1] = "S";
                                ParseResult[3] = "S";
                                break;
                            case "":
                                ParseResult[1] = foot1Bs;
                                ParseResult[3] = foot1Bs;

                                break;
                        }
                        break;
                }


                ParseResult[2] = commidity_ID + price[0].ToString() + SettlementMonth[0];
                ParseResult[4] = commidity_ID + price[0].ToString() + SettlementMonth[1]; ;

            }
            else if (ProductID.Substring(10, 1) == ":")     //勒式
            {
                Price = split[0].Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);

                ParseResult[0] = "勒式組合";
                ParseResult[6] = "4";

                switch (BS)
                {
                    case "B":
                        ParseResult[1] = "B";
                        ParseResult[3] = "B";

                        break;
                    case "S":

                        ParseResult[1] = "S";
                        ParseResult[3] = "S";

                        break;
                    case "":
                        ParseResult[1] = foot1Bs;
                        ParseResult[3] = foot1Bs;
                        break;
                }
                ParseResult[2] = commidity_ID + Price[0].ToString();
                ParseResult[4] = commidity_ID + Price[1].ToString();
            }
        }
        ParseResult[5] = ParseResult[3];
        return ParseResult;

    }


    ////取得基本資料-----
    //private void getINIData()
    //{

    //    try
    //    {
    //        WS_TRADELOGIC.TradeLogic objWS = new WS_TRADELOGIC.TradeLogic();
    //        DataSet dsData = objWS.WS_INI();
    //        //DataSet dsData = new DataSet(); 

    //        mdt_FutureData = dsData.Tables["future"];

    //        mdt_OptionData = dsData.Tables["option"];

    //        //mdt_MultipleFutureData = dsData.Tables["multipleFuture"];
    //        //mdt_FutureDetailData = dsData.Tables["futureDetail"];
    //        //mdt_OptionDetailData = dsData.Tables["optionDetail"];
    //        //mdt_TickData = dsData.Tables["KsCM026P"];
    //        //mdt_ErrorMapping = dsData.Tables["tblErrorMapping"];
    //        mdt_translate_values = dsData.Tables["translate_value"];

    //    }
    //    catch (Exception ex)
    //    {
    //        //mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);

    //    }

    //}

    //--------------------------------------------------------------------
    

    ///// <summary>
    ///// 0x51保證金查詢 回覆
    ///// </summary>
    ///// <returns>回傳DataTable</returns>
    //public DataTable GetMOBCurrentMarginDT(string companyID,string acctID,string currency)
    //{
    //    if (mdt_MOBCurrentMargin == null)
    //    {
    //        return null;
    //    }
    //    else
    //    {
    //        try
    //        {
    //            if (currency == "TWD")
    //            {
    //                currency = "NTT";
    //            }
    //            WSBOSHistoryQuery.BOSHistoryQuery ws = new WSBOSHistoryQuery.BOSHistoryQuery();
    //            string str = ws.WS_getTMCOFUSE(companyID, acctID, currency);
    //            mdt_MOBCurrentMargin.Rows[0]["TOTAL_DAMT"] = str;
    //            mdt_MOBCurrentMargin.AcceptChanges();

    //        }
    //        catch (Exception ex)
    //        { 
            
    //        }
    //        return mdt_MOBCurrentMargin;
    //    }
    //}

    /// <summary>
    /// // 0x53當日損益查詢回覆
    /// </summary>
    /// <returns></returns>
    public DataTable GetMOBCurrentBalanceDT()
    {
        if (mdt_MOBCurrentBalance == null)
        {
            return null;
        }
        else
        {
            return mdt_MOBCurrentBalance;
        }
    }

    /// <summary>
    /// 取得RealPartMix--0x57 即時部位查詢回覆  混合查詢
    /// </summary>
    /// <returns></returns>
    public DataTable GetRealPartMixDT()
    {
        if (mdt_RealPartMix == null)
        {
            return null;
        }
        else
        {
            return mdt_RealPartMix;
        }
    }


    /// <summary>
    /// 取得RealPart--0x57 即時部位查詢回覆  單式查詢;
    /// </summary>
    /// <returns></returns>
    public DataTable GetRealPartDT()
    {
        if (mdt_RealPart == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_RealPart.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_RealPart.Select("", " productKind, MKTCOMNO, COMYM, STKPRC,CALLPUT");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                dt.Rows.Add(drNew);
            }
            return dt;
        }
    }
    public DataTable GetMOBCombineDT()
    {
        if (mdt_MOBCombineData == null)
        {
            return null;
        }
        else
        {
            return mdt_MOBCombineData;
        }
    }

    public DataTable GetUnLiquidationMainDT()
    {
        if (mdt_UnLiquidationMain == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_UnLiquidationMain.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_UnLiquidationMain.Select("", " productKind, MKTCOMNO, COMYM, STKPRC,cp");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                dt.Rows.Add(drNew);
            }
            return dt;
        }
    }

    public DataTable GetUnLiquidationDetailDT()
    {
        if (mdt_UnLiquidationDetail == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_UnLiquidationDetail.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_UnLiquidationDetail.Select("", " productKind, MKTCOMNO, COMYM, STKPRC,cp");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                dt.Rows.Add(drNew);
            }
            return dt;
        }
    }

}
